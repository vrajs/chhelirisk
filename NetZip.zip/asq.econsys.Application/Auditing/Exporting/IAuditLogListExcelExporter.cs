﻿using System.Collections.Generic;
using asq.econsys.Auditing.Dto;
using asq.econsys.Dto;

namespace asq.econsys.Auditing.Exporting
{
    public interface IAuditLogListExcelExporter
    {
        FileDto ExportToFile(List<AuditLogListDto> auditLogListDtos);

        FileDto ExportToFile(List<EntityChangeListDto> entityChangeListDtos);
    }
}
