using Abp.Authorization;
using Abp.Authorization.Users;
using Abp.Configuration;
using Abp.Configuration.Startup;
using Abp.Dependency;
using Abp.Domain.Repositories;
using Abp.Domain.Uow;
using Abp.Zero.Configuration;
using Microsoft.AspNetCore.Identity;
using asq.econsys.Authorization.Roles;
using asq.econsys.Authorization.Users;
using asq.econsys.MultiTenancy;
using System;
using System.Threading.Tasks;
using Abp.Extensions;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Abp.Runtime.Security;
using asq.econsys.EntityFrameworkCore;
using Abp.EntityFrameworkCore;
using Abp.Runtime.Session;
using Abp.UI;

namespace asq.econsys.Authorization
{
    /// <summary>
    /// The Login Manager
    /// </summary>
    /// <seealso cref="Abp.Authorization.AbpLogInManager&lt;asq.econsys.MultiTenancy.Tenant, asq.econsys.Authorization.Roles.Role, asq.econsys.Authorization.Users.User&gt;" />
    public class LogInManager : AbpLogInManager<Tenant, Role, User>
    {
        #region private variables
        /// <summary>
        /// The user store
        /// </summary>
        private readonly UserStore _userStore;
        /// <summary>
        /// The user repository
        /// </summary>
        private readonly IRepository<User, Int64> _userRepository;

        private readonly IDbContextProvider<econsysDbContext> _dbContextProvider;

        public IAbpSession AbpSession { get; set; }

        #endregion

        #region constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="LogInManager"/> class.
        /// </summary>
        /// <param name="userManager">The user manager.</param>
        /// <param name="multiTenancyConfig">The multi tenancy configuration.</param>
        /// <param name="tenantRepository">The tenant repository.</param>
        /// <param name="unitOfWorkManager">The unit of work manager.</param>
        /// <param name="settingManager">The setting manager.</param>
        /// <param name="userLoginAttemptRepository">The user login attempt repository.</param>
        /// <param name="userManagementConfig">The user management configuration.</param>
        /// <param name="iocResolver">The ioc resolver.</param>
        /// <param name="roleManager">The role manager.</param>
        /// <param name="passwordHasher">The password hasher.</param>
        /// <param name="claimsPrincipalFactory">The claims principal factory.</param>
        /// <param name="userStore">The user store.</param>
        /// <param name="userRepository">The user repository.</param>
        public LogInManager(
            UserManager userManager,
            IMultiTenancyConfig multiTenancyConfig,
            IRepository<Tenant> tenantRepository,
            IUnitOfWorkManager unitOfWorkManager,
            ISettingManager settingManager,
            IRepository<UserLoginAttempt, long> userLoginAttemptRepository,
            IUserManagementConfig userManagementConfig,
            IIocResolver iocResolver,
            RoleManager roleManager,
            IPasswordHasher<User> passwordHasher,
            UserClaimsPrincipalFactory claimsPrincipalFactory,
            UserStore userStore,
            IRepository<User, Int64> userRepository,
            IDbContextProvider<econsysDbContext> dbContextProvider)
            : base(
                  userManager,
                  multiTenancyConfig,
                  tenantRepository,
                  unitOfWorkManager,
                  settingManager,
                  userLoginAttemptRepository,
                  userManagementConfig,
                  iocResolver,
                  passwordHasher,
                  roleManager,
                  claimsPrincipalFactory)
        {
            _userStore = userStore;
            _userRepository = userRepository;
            _dbContextProvider = dbContextProvider;
            AbpSession = NullAbpSession.Instance;
        }
        #endregion

        #region methods declaration

        /// <summary>
        /// Logins the asynchronous.
        /// </summary>
        /// <param name="login">The login.</param>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        [UnitOfWork]
        public async Task<AbpLoginResult<Tenant, User>> LoginAsync(UserLoginInfo login, string email = null, int? tenantId = null)
        {
            var result = await LoginAsyncInternal(login, email, tenantId);
            await SaveLoginAttemptAsync(result, result.Tenant != null ? result.Tenant.Name : string.Empty, login.ProviderKey + "@" + login.LoginProvider);
            return result;
        }

        /// <summary>
        /// Logins the asynchronous internal.
        /// </summary>
        /// <param name="login">The login.</param>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentException">login</exception>
        protected async Task<AbpLoginResult<Tenant, User>> LoginAsyncInternal(UserLoginInfo login, string email = null, int? tenantId = null)
        {
            if (login == null || login.LoginProvider.IsNullOrEmpty() || login.ProviderKey.IsNullOrEmpty())
            {
                throw new ArgumentException("login");
            }
            using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
            {
                //var user = await _userStore.FindAsync(login);
                User user = null;
                if (!string.IsNullOrEmpty(email))
                {
                    ////user = _userStore.FindByEmail(email);

                    if (tenantId.HasValue)
                    {

                        var selectedTenant = TenantRepository.FirstOrDefault(a => a.Id == tenantId && !a.IsDeleted);
                        if (selectedTenant != null && !string.IsNullOrEmpty(selectedTenant.ConnectionString))
                        {
                            string conn = SimpleStringCipher.Instance.Decrypt(selectedTenant.ConnectionString);
                            var options = new DbContextOptionsBuilder<econsysDbContext>().UseSqlServer(conn).UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking).Options;
                            using (var context = new econsysDbContext(options))
                            {
                                using (UnitOfWorkManager.Current.SetTenantId(tenantId))
                                {
                                    using (AbpSession.Use(tenantId, AbpSession.UserId))
                                    {
                                        user = _userRepository.GetAll().Where(u => u.EmailAddress == email && u.TenantId == tenantId).FirstOrDefault();
                                        if (user != null)
                                        {
                                            return AbpLoginResultAsync(user, tenantId).Result;
                                        }
                                    }
                                    //var loadedUser = context.Users.Include(p => p.Claims).Load();
                                    ////user = context.Users.AsNoTrackingWithIdentityResolution().Where(x => x.EmailAddress.ToLower() == email.ToLower() && x.TenantId != null && x.TenantId == tenantId).FirstOrDefault();
                                    ////if (user != null)
                                    ////{
                                    ////    context.Attach(user);
                                    ////    return AbpLoginResultAsync(user, tenantId).Result;
                                    ////}
                                }
                            }
                        }
                        else
                        {

                            user = _userRepository.GetAll().Where(u => u.EmailAddress == email && u.TenantId == tenantId).FirstOrDefault();
                            if (user != null)
                            {
                                return AbpLoginResultAsync(user, tenantId).Result;
                            }
                            //////using (UnitOfWorkManager.Current.SetTenantId(null))
                            ////{
                            ////    //var dbContext = await _dbContextProvider.GetDbContextAsync();
                            ////    //using (var context = dbContext)
                            ////    //{
                            ////    //user = _userRepository.GetAll().Where(u => u.EmailAddress == email && u.TenantId == tenantId).FirstOrDefault();
                            ////    //}
                            ////}
                        }
                    }
                    else
                    {
                        user = _userStore.FindByEmail(email);
                    }
                }
                else
                {
                    user = _userStore.FindById(login.ProviderKey);
                }

                if (user == null)
                {
                    user = await _userStore.FindAsync(login);
                }

                if (user == null)
                {
                    return new AbpLoginResult<Tenant, User>(AbpLoginResultType.UnknownExternalLogin);
                }
                //Get and check tenant

                return AbpLoginResultAsync(user, tenantId).Result;
            }
            //}
        }

        /// <summary>
        /// Gets the tenancy list for user.
        /// </summary>
        /// <param name="usernameOrEmailAddress">The username or email address.</param>
        /// <returns></returns>
        public List<string> GetTenancyListForUser(string usernameOrEmailAddress)
        {
            List<string> result = new List<string>();
            var tenants = TenantRepository.GetAllList(t => t.ConnectionString != null && t.ConnectionString != "");
            foreach (var tenant in tenants)
            {
                //using (AbpSession.Use(tenant.Id, null))
                using (UnitOfWorkManager.Current.SetTenantId(tenant.Id))
                {
                    using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        var user = _userRepository.GetAll().AsNoTracking().Where(x => x.EmailAddress == usernameOrEmailAddress.Trim() || x.UserName == usernameOrEmailAddress.Trim()).FirstOrDefault();
                        if (user != null)
                        {
                            //return user?.TenantId;
                            result.Add(tenant.TenancyName);
                        }
                    }
                }
            }
            return result;
        }

        private async Task<AbpLoginResult<Tenant, User>> AbpLoginResultAsync(User user, int? tenantId = null)
        {
            try
            {
                Tenant tenant = null;
                if (!MultiTenancyConfig.IsEnabled)
                {
                    tenant = await GetDefaultTenantAsync();
                }
                else if (user.TenantId.HasValue)
                {
                    //tenant = TenantRepository.FirstOrDefault(a => a.Id == user.TenantId);
                    try
                    {
                        tenant = await TenantRepository.FirstOrDefaultAsync(t => t.Id == user.TenantId && !t.IsDeleted);
                        if (tenant == null)
                        {
                            return new AbpLoginResult<Tenant, User>(AbpLoginResultType.InvalidTenancyName);
                        }
                        if (!tenant.IsActive)
                        {
                            return new AbpLoginResult<Tenant, User>(AbpLoginResultType.TenantIsNotActive, tenant);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new UserFriendlyException(ex.Message);
                    }

                }
                else if (tenantId.HasValue)
                {
                    tenant = TenantRepository.FirstOrDefault(a => a.Id == tenantId && !a.IsDeleted);
                    if (tenant == null)
                    {
                        return new AbpLoginResult<Tenant, User>(AbpLoginResultType.InvalidTenancyName);
                    }
                    if (!tenant.IsActive)
                    {
                        return new AbpLoginResult<Tenant, User>(AbpLoginResultType.TenantIsNotActive, tenant);
                    }
                }
                return await CreateLoginResultAsync(user, tenant);
            }
            catch (Exception ex)
            {
                throw new UserFriendlyException(ex.Message);
            }
        }

        #endregion
    }
}