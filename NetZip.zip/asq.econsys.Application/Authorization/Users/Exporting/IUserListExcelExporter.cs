using System.Collections.Generic;
using asq.econsys.Authorization.Users.Dto;
using asq.econsys.Dto;

namespace asq.econsys.Authorization.Users.Exporting
{
    public interface IUserListExcelExporter
    {
        FileDto ExportToFile(List<UserListDto> userListDtos);
    }
}