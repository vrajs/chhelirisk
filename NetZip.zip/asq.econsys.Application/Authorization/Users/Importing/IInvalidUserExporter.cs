﻿using System.Collections.Generic;
using asq.econsys.Authorization.Users.Importing.Dto;
using asq.econsys.Dto;

namespace asq.econsys.Authorization.Users.Importing
{
    public interface IInvalidUserExporter
    {
        FileDto ExportToFile(List<ImportUserDto> userListDtos);
    }
}
