﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Configuration;
using Abp.Authorization;
using Abp.Authorization.Roles;
using Abp.Authorization.Users;
using Abp.Domain.Repositories;
using Abp.Extensions;
using Abp.Linq.Extensions;
using Abp.Notifications;
using Abp.Organizations;
using Abp.Runtime.Session;
using Abp.UI;
using Abp.Zero.Configuration;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using asq.econsys.Authorization.Permissions;
using asq.econsys.Authorization.Permissions.Dto;
using asq.econsys.Authorization.Roles;
using asq.econsys.Authorization.Users.Dto;
using asq.econsys.Authorization.Users.Exporting;
using asq.econsys.Dto;
using asq.econsys.Notifications;
using asq.econsys.Url;
using asq.econsys.Organizations.Dto;
using asq.econsys.Helpers;
using Microsoft.Extensions.Configuration;
using asq.econsys.Configuration;
using Abp.Runtime.Security;
using asq.econsys.EntityFrameworkCore;
using Abp.Domain.Uow;

namespace asq.econsys.Authorization.Users
{
    [AbpAuthorize(AppPermissions.Pages_Administration_Users)]
    public class UserAppService : econsysAppServiceBase, IUserAppService
    {
        public IAppUrlService AppUrlService { get; set; }

        private readonly RoleManager _roleManager;
        private readonly IUserEmailer _userEmailer;
        private readonly IUserListExcelExporter _userListExcelExporter;
        private readonly INotificationSubscriptionManager _notificationSubscriptionManager;
        private readonly IAppNotifier _appNotifier;
        private readonly IRepository<RolePermissionSetting, long> _rolePermissionRepository;
        private readonly IRepository<UserPermissionSetting, long> _userPermissionRepository;
        private readonly IRepository<UserRole, long> _userRoleRepository;
        private readonly IRepository<Role> _roleRepository;
        private readonly IUserPolicy _userPolicy;
        private readonly IEnumerable<IPasswordValidator<User>> _passwordValidators;
        private readonly IPasswordHasher<User> _passwordHasher;
        private readonly IRepository<OrganizationUnit, long> _organizationUnitRepository;
        private readonly IRoleManagementConfig _roleManagementConfig;
        private readonly UserManager _userManager;
        private readonly IRepository<UserOrganizationUnit, long> _userOrganizationUnitRepository;
        private readonly IRepository<OrganizationUnitRole, long> _organizationUnitRoleRepository;
        private readonly IConfigurationRoot _appConfiguration;
        private readonly ICurrentUnitOfWorkProvider _unitOfWorkProvider;

        public UserAppService(
            RoleManager roleManager,
            IUserEmailer userEmailer,
            IUserListExcelExporter userListExcelExporter,
            INotificationSubscriptionManager notificationSubscriptionManager,
            IAppNotifier appNotifier,
            IRepository<RolePermissionSetting, long> rolePermissionRepository,
            IRepository<UserPermissionSetting, long> userPermissionRepository,
            IRepository<UserRole, long> userRoleRepository,
            IRepository<Role> roleRepository,
            IUserPolicy userPolicy,
            IEnumerable<IPasswordValidator<User>> passwordValidators,
            IPasswordHasher<User> passwordHasher,
            IRepository<OrganizationUnit, long> organizationUnitRepository,
            IRoleManagementConfig roleManagementConfig,
            UserManager userManager,
            IRepository<UserOrganizationUnit, long> userOrganizationUnitRepository,
            IRepository<OrganizationUnitRole, long> organizationUnitRoleRepository,
            IAppConfigurationAccessor appConfigurationAccessor,
            ICurrentUnitOfWorkProvider unitOfWorkProvider
            )
        {
            _roleManager = roleManager;
            _userEmailer = userEmailer;
            _userListExcelExporter = userListExcelExporter;
            _notificationSubscriptionManager = notificationSubscriptionManager;
            _appNotifier = appNotifier;
            _rolePermissionRepository = rolePermissionRepository;
            _userPermissionRepository = userPermissionRepository;
            _userRoleRepository = userRoleRepository;
            _userPolicy = userPolicy;
            _passwordValidators = passwordValidators;
            _passwordHasher = passwordHasher;
            _organizationUnitRepository = organizationUnitRepository;
            _roleManagementConfig = roleManagementConfig;
            _userManager = userManager;
            _userOrganizationUnitRepository = userOrganizationUnitRepository;
            _organizationUnitRoleRepository = organizationUnitRoleRepository;
            _roleRepository = roleRepository;
            _appConfiguration = appConfigurationAccessor.Configuration;
            AppUrlService = NullAppUrlService.Instance;
            _unitOfWorkProvider = unitOfWorkProvider;
        }

        [HttpPost]
        public async Task<PagedResultDto<UserListDto>> GetUsers(GetUsersInput input)
        {
            var query = GetUsersFilteredQuery(input);

            var userCount = await query.CountAsync();

            var users = await query
                .OrderBy(input.Sorting)
                .PageBy(input)
                .ToListAsync();

            var userListDtos = ObjectMapper.Map<List<UserListDto>>(users);
            await FillRoleNames(userListDtos);

            return new PagedResultDto<UserListDto>(
                userCount,
                userListDtos
            );
        }

        public async Task<FileDto> GetUsersToExcel(GetUsersToExcelInput input)
        {
            var query = GetUsersFilteredQuery(input);

            var users = await query
                .OrderBy(input.Sorting)
                .ToListAsync();

            var userListDtos = ObjectMapper.Map<List<UserListDto>>(users);
            await FillRoleNames(userListDtos);

            return _userListExcelExporter.ExportToFile(userListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_Users_Create, AppPermissions.Pages_Administration_Users_Edit)]
        public async Task<GetUserForEditOutput> GetUserForEdit(NullableIdDto<long> input)
        {
            //Getting all available roles
            var userRoleDtos = await _roleManager.Roles
                .OrderBy(r => r.DisplayName)
                .Select(r => new UserRoleDto
                {
                    RoleId = r.Id,
                    RoleName = r.Name,
                    RoleDisplayName = r.DisplayName
                })
                .ToArrayAsync();

            var allOrganizationUnits = await _organizationUnitRepository.GetAllListAsync();

            var output = new GetUserForEditOutput
            {
                Roles = userRoleDtos,
                AllOrganizationUnits = ObjectMapper.Map<List<OrganizationUnitDto>>(allOrganizationUnits),
                MemberedOrganizationUnits = new List<string>()
            };

            if (!input.Id.HasValue)
            {
                //Creating a new user
                output.User = new UserEditDto
                {
                    IsActive = true,
                    ShouldChangePasswordOnNextLogin = true,
                    IsTwoFactorEnabled =
                        await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement
                            .TwoFactorLogin.IsEnabled),
                    IsLockoutEnabled =
                        await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.UserLockOut
                            .IsEnabled)
                };

                foreach (var defaultRole in await _roleManager.Roles.Where(r => r.IsDefault).ToListAsync())
                {
                    var defaultUserRole = userRoleDtos.FirstOrDefault(ur => ur.RoleName == defaultRole.Name);
                    if (defaultUserRole != null)
                    {
                        defaultUserRole.IsAssigned = true;
                    }
                }
            }
            else
            {
                //Editing an existing user
                var user = await UserManager.GetUserByIdAsync(input.Id.Value);

                output.User = ObjectMapper.Map<UserEditDto>(user);
                output.ProfilePictureId = user.ProfilePictureId;

                var organizationUnits = await UserManager.GetOrganizationUnitsAsync(user);
                output.MemberedOrganizationUnits = organizationUnits.Select(ou => ou.Code).ToList();

                var allRolesOfUsersOrganizationUnits = GetAllRoleNamesOfUsersOrganizationUnits(input.Id.Value);

                foreach (var userRoleDto in userRoleDtos)
                {
                    userRoleDto.IsAssigned = await UserManager.IsInRoleAsync(user, userRoleDto.RoleName);
                    userRoleDto.InheritedFromOrganizationUnit =
                        allRolesOfUsersOrganizationUnits.Contains(userRoleDto.RoleName);
                }
            }

            return output;
        }

        private List<string> GetAllRoleNamesOfUsersOrganizationUnits(long userId)
        {
            return (from userOu in _userOrganizationUnitRepository.GetAll()
                join roleOu in _organizationUnitRoleRepository.GetAll() on userOu.OrganizationUnitId equals roleOu
                    .OrganizationUnitId
                join userOuRoles in _roleRepository.GetAll() on roleOu.RoleId equals userOuRoles.Id
                where userOu.UserId == userId
                select userOuRoles.Name).ToList();
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_Users_ChangePermissions)]
        public async Task<GetUserPermissionsForEditOutput> GetUserPermissionsForEdit(EntityDto<long> input)
        {
            var user = await UserManager.GetUserByIdAsync(input.Id);
            var permissions = PermissionManager.GetAllPermissions();
            var grantedPermissions = await UserManager.GetGrantedPermissionsAsync(user);

            return new GetUserPermissionsForEditOutput
            {
                Permissions = ObjectMapper.Map<List<FlatPermissionDto>>(permissions).OrderBy(p => p.DisplayName)
                    .ToList(),
                GrantedPermissionNames = grantedPermissions.Select(p => p.Name).ToList()
            };
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_Users_ChangePermissions)]
        public async Task ResetUserSpecificPermissions(EntityDto<long> input)
        {
            var user = await UserManager.GetUserByIdAsync(input.Id);
            await UserManager.ResetAllPermissionsAsync(user);
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_Users_ChangePermissions)]
        public async Task UpdateUserPermissions(UpdateUserPermissionsInput input)
        {
            var user = await UserManager.GetUserByIdAsync(input.Id);
            var grantedPermissions =
                PermissionManager.GetPermissionsFromNamesByValidating(input.GrantedPermissionNames);
            await UserManager.SetGrantedPermissionsAsync(user, grantedPermissions);
        }

        /// <summary>
        /// Creates the or update user.
        /// </summary>
        /// <param name="input">The input.</param>
        public async Task CreateOrUpdateUser(CreateOrUpdateUserInput input)
        {
            string apiURL = _appConfiguration["Authentication:OpenId:IDPRootAddress"];
            if (input.User.Id.HasValue)
            {
                await UpdateUserAsync(input);

                // Logic to update the user in the identity server
                if (bool.Parse(_appConfiguration["Authentication:OpenId:IsEnabled"]) && !String.IsNullOrEmpty(input.IDPAccessToken))
                {
                    var isSuccess = await CommonHelper.UpdateUserToIdentityServer(input, apiURL);
                }
                else
                {
                    // TODO - throw error
                }
            }
            else
            {
                if (!IsUserExist(input.User.EmailAddress))
                {
                    var existsingUser = await GetUserIfExist(input.User.EmailAddress);

                    await CreateUserAsync(input);

                    // Logic to save the user in the identity server
                    #region Activate into IDP
                    if(bool.Parse(_appConfiguration["Authentication:OpenId:IsEnabled"]) && !String.IsNullOrEmpty(input.IDPAccessToken))
                    {
                        var isSuccess = await CommonHelper.RegisterUserToIdentityServer(input, apiURL);
                        if (!isSuccess)
                        {
                            // TODO - capture - Bearer error="invalid_token", error_description="The token expired at xx
                           // throw new UserFriendlyException("Invalid token");
                        }
                        try
                        {
                            // Send Email
                            var user = _userManager.FindByNameOrEmail(input.User.EmailAddress);
                            if (user != null)
                            {
                                if (existsingUser == null && input.SendActivationEmail == false)
                                {
                                    await sendEmail(input.User.Password, user);
                                }
                                
                                if(existsingUser != null)
                                {
                                    await sendEmailIfUserExists(input.User.Password, user);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                        }
                    } else
                    {
                        // TODO - throw error
                    }
                    #endregion
                }
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_Users_Delete)]
        public async Task DeleteUser(EntityDto<long> input, string accessToken = null)
        {
            string apiURL = _appConfiguration["Authentication:OpenId:IDPRootAddress"];

            if (input.Id == AbpSession.GetUserId())
            {
                throw new UserFriendlyException(L("YouCanNotDeleteOwnAccount"));
            }

            var user = await UserManager.GetUserByIdAsync(input.Id);
            CheckErrors(await UserManager.DeleteAsync(user));

            // To DO add delete user from IDP logic here
            if (!string.IsNullOrEmpty(accessToken))
            {
                await CommonHelper.DeleteUserFromIDP(user.EmailAddress, accessToken, apiURL);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_Users_Unlock)]
        public async Task UnlockUser(EntityDto<long> input)
        {
            var user = await UserManager.GetUserByIdAsync(input.Id);
            user.Unlock();
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_Users_Edit)]
        protected virtual async Task UpdateUserAsync(CreateOrUpdateUserInput input)
        {
            Debug.Assert(input.User.Id != null, "input.User.Id should be set.");

            var user = await UserManager.FindByIdAsync(input.User.Id.Value.ToString());

            //Update user properties
            ObjectMapper.Map(input.User, user); //Passwords is not mapped (see mapping configuration)

            CheckErrors(await UserManager.UpdateAsync(user));

            if (input.SetRandomPassword)
            {
                var randomPassword = await _userManager.CreateRandomPassword();
                user.Password = _passwordHasher.HashPassword(user, randomPassword);
                input.User.Password = randomPassword;
            }
            else if (!input.User.Password.IsNullOrEmpty())
            {
                await UserManager.InitializeOptionsAsync(AbpSession.TenantId);
                CheckErrors(await UserManager.ChangePasswordAsync(user, input.User.Password));
            }

            //Update roles
            CheckErrors(await UserManager.SetRolesAsync(user, input.AssignedRoleNames));

            //update organization units
            await UserManager.SetOrganizationUnitsAsync(user, input.OrganizationUnits.ToArray());

            if (input.SendActivationEmail)
            {
                user.SetNewEmailConfirmationCode();
                await _userEmailer.SendEmailActivationLinkAsync(
                    user,
                    AppUrlService.CreateEmailActivationUrlFormat(AbpSession.TenantId),
                    input.User.Password
                );
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_Users_Create)]
        protected virtual async Task CreateUserAsync(CreateOrUpdateUserInput input)
        {
            if (AbpSession.TenantId.HasValue)
            {
                await _userPolicy.CheckMaxUserCountAsync(AbpSession.GetTenantId());
            }

            var user = ObjectMapper.Map<User>(input.User); //Passwords is not mapped (see mapping configuration)
            user.TenantId = AbpSession.TenantId;
            var existsingUser = await GetUserIfExist(input.User.EmailAddress);

            //Set password
            if (input.SetRandomPassword)
            {
                if (existsingUser != null)
                {
                    input.User.Name = existsingUser.Name;
                    input.User.Surname = existsingUser.Surname;
                    user.Name = existsingUser.Name;
                    user.Surname = existsingUser.Surname;
                    user.Password = existsingUser.Password;
                    input.User.Password = existsingUser.Password;
                }
                else
                {
                    var randomPassword = await _userManager.CreateRandomPassword();
                    user.Password = _passwordHasher.HashPassword(user, randomPassword);
                    input.User.Password = randomPassword;
                }
            }
            else if (!input.User.Password.IsNullOrEmpty())
            {
                await UserManager.InitializeOptionsAsync(AbpSession.TenantId);
                foreach (var validator in _passwordValidators)
                {
                    CheckErrors(await validator.ValidateAsync(UserManager, user, input.User.Password));
                }

                user.Password = _passwordHasher.HashPassword(user, input.User.Password);
            }

            user.ShouldChangePasswordOnNextLogin = input.User.ShouldChangePasswordOnNextLogin;

            //Assign roles
            user.Roles = new Collection<UserRole>();
            foreach (var roleName in input.AssignedRoleNames)
            {
                var role = await _roleManager.GetRoleByNameAsync(roleName);
                user.Roles.Add(new UserRole(AbpSession.TenantId, user.Id, role.Id));
            }

            CheckErrors(await UserManager.CreateAsync(user));
            await CurrentUnitOfWork.SaveChangesAsync(); //To get new user's Id.

            //Notifications
            await _notificationSubscriptionManager.SubscribeToAllAvailableNotificationsAsync(user.ToUserIdentifier());
            await _appNotifier.WelcomeToTheApplicationAsync(user);

            //Organization Units
            await UserManager.SetOrganizationUnitsAsync(user, input.OrganizationUnits.ToArray());

            //Send activation email
            if (input.SendActivationEmail && existsingUser == null)
            {
                user.SetNewEmailConfirmationCode();
                await _userEmailer.SendEmailActivationLinkAsync(
                    user,
                    AppUrlService.CreateEmailActivationUrlFormat(AbpSession.TenantId),
                    input.User.Password
                );
            }
        }


        /// <summary>
        /// Gets the user password if exist.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        public async Task<User> GetUserIfExist(string email)
        {
            string password = string.Empty;
            using (CurrentUnitOfWork.SetTenantId(null))
            {
                var tenants = TenantManager.Tenants.ToList();
                if (tenants != null && tenants.Count() > 0)
                {
                    foreach (var tenant in tenants)
                    {
                        using (_unitOfWorkProvider.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
                        {
                            try
                            {
                                if (string.IsNullOrEmpty(tenant.ConnectionString))
                                {
                                    var user = UserManager.Users.Where(a => a.EmailAddress == email.ToLower().ToString() && a.IsActive && !a.IsDeleted).FirstOrDefault();
                                    if (user != null)
                                    {
                                        return user;
                                    }
                                }
                                else
                                {
                                    string conn = SimpleStringCipher.Instance.Decrypt(tenant.ConnectionString);
                                    var options = new DbContextOptionsBuilder<econsysDbContext>().UseSqlServer(conn).Options;

                                    using (var context = new econsysDbContext(options))
                                    {
                                        var user = context.Users.Where(x => x.EmailAddress.ToLower() == email.ToLower() && x.IsActive && !x.IsDeleted).FirstOrDefault();
                                        if (user != null)
                                        {
                                            return user;
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                throw new UserFriendlyException(ex.Message);
                            }
                        }
                    }
                }
            }
            return null;
        }

        public async Task<string> IsUserEmailExists(string email)
        {
            string password = string.Empty;
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(null))
            {
                var tenants = TenantManager.Tenants.ToList();
                if (tenants != null && tenants.Count() > 0)
                {
                    foreach (var tenant in tenants)
                    {
                        using (_unitOfWorkProvider.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
                        {
                            try
                            {
                                if (string.IsNullOrEmpty(tenant.ConnectionString))
                                {
                                    var user = UserManager.Users.Where(a => a.EmailAddress == email.ToLower().ToString() && a.IsActive && !a.IsDeleted && a.TenantId == tenantId).FirstOrDefault();
                                    if (user != null)
                                    {
                                        return user.Password;
                                    }
                                }
                                else
                                {
                                    string conn = SimpleStringCipher.Instance.Decrypt(tenant.ConnectionString);
                                    var options = new DbContextOptionsBuilder<econsysDbContext>().UseSqlServer(conn).Options;

                                    using (var context = new econsysDbContext(options))
                                    {
                                        var user = context.Users.Where(x => x.EmailAddress.ToLower() == email.ToLower() && x.IsActive && !x.IsDeleted && x.TenantId == tenantId).FirstOrDefault();
                                        if (user != null)
                                        {
                                            return user.Password;
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                        }
                    }
                }
            }
            return password;
        }

        private async Task FillRoleNames(IReadOnlyCollection<UserListDto> userListDtos)
        {
            /* This method is optimized to fill role names to given list. */
            var userIds = userListDtos.Select(u => u.Id);

            var userRoles = await _userRoleRepository.GetAll()
                .Where(userRole => userIds.Contains(userRole.UserId))
                .Select(userRole => userRole).ToListAsync();

            var distinctRoleIds = userRoles.Select(userRole => userRole.RoleId).Distinct();

            foreach (var user in userListDtos)
            {
                var rolesOfUser = userRoles.Where(userRole => userRole.UserId == user.Id).ToList();
                user.Roles = ObjectMapper.Map<List<UserListRoleDto>>(rolesOfUser);
            }

            var roleNames = new Dictionary<int, string>();
            foreach (var roleId in distinctRoleIds)
            {
                var role = await _roleManager.FindByIdAsync(roleId.ToString());
                if (role != null)
                {
                    roleNames[roleId] = role.DisplayName;
                }
            }

            foreach (var userListDto in userListDtos)
            {
                foreach (var userListRoleDto in userListDto.Roles)
                {
                    if (roleNames.ContainsKey(userListRoleDto.RoleId))
                    {
                        userListRoleDto.RoleName = roleNames[userListRoleDto.RoleId];
                    }
                }

                userListDto.Roles = userListDto.Roles.Where(r => r.RoleName != null).OrderBy(r => r.RoleName).ToList();
            }
        }

        private IQueryable<User> GetUsersFilteredQuery(IGetUsersInput input)
        {
            var query = UserManager.Users
                .WhereIf(input.Role.HasValue, u => u.Roles.Any(r => r.RoleId == input.Role.Value))
                .WhereIf(input.OnlyLockedUsers,
                    u => u.LockoutEndDateUtc.HasValue && u.LockoutEndDateUtc.Value > DateTime.UtcNow)
                .WhereIf(
                    !input.Filter.IsNullOrWhiteSpace(),
                    u =>
                        u.Name.Contains(input.Filter) ||
                        u.Surname.Contains(input.Filter) ||
                        u.UserName.Contains(input.Filter) ||
                        u.EmailAddress.Contains(input.Filter)
                );

            if (input.Permissions != null && input.Permissions.Any(p => !p.IsNullOrWhiteSpace()))
            {
                var staticRoleNames = _roleManagementConfig.StaticRoles.Where(
                    r => r.GrantAllPermissionsByDefault &&
                         r.Side == AbpSession.MultiTenancySide
                ).Select(r => r.RoleName).ToList();

                input.Permissions = input.Permissions.Where(p => !string.IsNullOrEmpty(p)).ToList();

                var userIds = from user in query
                    join ur in _userRoleRepository.GetAll() on user.Id equals ur.UserId into urJoined
                    from ur in urJoined.DefaultIfEmpty()
                    join urr in _roleRepository.GetAll() on ur.RoleId equals urr.Id into urrJoined
                    from urr in urrJoined.DefaultIfEmpty()
                    join up in _userPermissionRepository.GetAll()
                        .Where(userPermission => input.Permissions.Contains(userPermission.Name)) on user.Id equals up.UserId into upJoined
                    from up in upJoined.DefaultIfEmpty()
                    join rp in _rolePermissionRepository.GetAll()
                        .Where(rolePermission => input.Permissions.Contains(rolePermission.Name)) on
                        new { RoleId = ur == null ? 0 : ur.RoleId } equals new { rp.RoleId } into rpJoined
                    from rp in rpJoined.DefaultIfEmpty()
                    where (up != null && up.IsGranted) ||
                          (up == null && rp != null && rp.IsGranted) ||
                          (up == null && rp == null && staticRoleNames.Contains(urr.Name))
                    group user by user.Id
                    into userGrouped
                    select userGrouped.Key;

                query = UserManager.Users.Where(e => userIds.Contains(e.Id));
            }

            return query;
        }

        /// <summary>
        /// Determines whether [is user exist].
        /// </summary>
        /// <returns>
        ///   <c>true</c> if [is user exist]; otherwise, <c>false</c>.
        /// </returns>
        private bool IsUserExist(string emailAddress)
        {
            return _userManager.FindByNameOrEmail(emailAddress) != null;
        }

        /// <summary>
        /// Sends the email.
        /// </summary>
        /// <param name="password">The password.</param>
        /// <param name="user">The user.</param>
        /// <returns></returns>
        private async Task<bool> sendEmail(string password, User user)
        {
            user.SetNewEmailConfirmationCode();
            await _userEmailer.SendEmailToRegisteredUser(
                    user,
                    AppUrlService.CreateEmailActivationIDPUrlFormat(AbpSession.TenantId),
                    password
                );

            return true;
        }

        private async Task<bool> sendEmailIfUserExists(string password, User user)
        {
            //user.SetNewEmailConfirmationCode();
            await _userEmailer.SendAlreadyRegisterdEmailToOtherTenancy(
                    user,
                    AppUrlService.CreateEmailActivationIDPUrlFormat(AbpSession.TenantId),
                    password
                );

            return true;
        }
    }
}
