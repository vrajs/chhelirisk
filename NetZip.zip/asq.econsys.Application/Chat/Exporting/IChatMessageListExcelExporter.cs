﻿using System.Collections.Generic;
using Abp;
using asq.econsys.Chat.Dto;
using asq.econsys.Dto;

namespace asq.econsys.Chat.Exporting
{
    public interface IChatMessageListExcelExporter
    {
        FileDto ExportToFile(UserIdentifier user, List<ChatMessageExportDto> messages);
    }
}
