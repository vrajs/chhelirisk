﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Collections.Extensions;
using Abp.Configuration;
using Abp.Extensions;
using Abp.Json;
using Abp.Net.Mail;
using Abp.Runtime.Security;
using Abp.Timing;
using Abp.Zero.Configuration;
using asq.econsys.Authentication;
using asq.econsys.Authorization;
using asq.econsys.Configuration.Dto;
using asq.econsys.Configuration.Host.Dto;
using asq.econsys.Eco.Settings.Dtos;
using asq.econsys.Editions;
using asq.econsys.NotificationTemplate;
using asq.econsys.NotificationTemplate.Dto;
using asq.econsys.Security;
using asq.econsys.Timing;
using Newtonsoft.Json;

namespace asq.econsys.Configuration.Host
{
    [AbpAuthorize(AppPermissions.Pages_Administration_Host_Settings)]
    public class HostSettingsAppService : SettingsAppServiceBase, IHostSettingsAppService
    {
        public IExternalLoginOptionsCacheManager ExternalLoginOptionsCacheManager { get; set; }

        private readonly EditionManager _editionManager;
        private readonly ITimeZoneService _timeZoneService;
        readonly ISettingDefinitionManager _settingDefinitionManager;
        private readonly INotificationTemplateAppService _notificationTemplateAppService;

        public HostSettingsAppService(
            IEmailSender emailSender,
            EditionManager editionManager,
            ITimeZoneService timeZoneService,
            ISettingDefinitionManager settingDefinitionManager,
            IAppConfigurationAccessor configurationAccessor,
            INotificationTemplateAppService notificationTemplateAppService) : base(emailSender, configurationAccessor)
        {
            ExternalLoginOptionsCacheManager = NullExternalLoginOptionsCacheManager.Instance;

            _editionManager = editionManager;
            _timeZoneService = timeZoneService;
            _settingDefinitionManager = settingDefinitionManager;
            _notificationTemplateAppService = notificationTemplateAppService;
        }

        #region Get Settings

        public async Task<HostSettingsEditDto> GetAllSettings()
        {
            return new HostSettingsEditDto
            {
                General = await GetGeneralSettingsAsync(),
                TenantManagement = await GetTenantManagementSettingsAsync(),
                UserManagement = await GetUserManagementAsync(),
                Email = await GetEmailSettingsAsync(),
                Security = await GetSecuritySettingsAsync(),
                Billing = await GetBillingSettingsAsync(),
                OtherSettings = await GetOtherSettingsAsync(),
                ExternalLoginProviderSettings = await GetExternalLoginProviderSettings(),
                CustomerSettings = await GetCustomerSettings(),
                PaymentSettings = await GetPaymentSettings(),
                PromptsAndAlertsSettings = await GetPromptsAndAlertsSettings(),
                TaskDelegationSettings = await GetTaskDelegationSettings(),
                TaskSettings = await GetTaskSettings(),
                DashboardBusinessRulesSettings = await GetDashboardBusinessRulesSettings(),
                ReportGenIntervalSettings = await GetReportGenIntervalSettings(),
                WinProbabilitySettings = await GetWinProbabilitySettings(),
                NotificationTemplateSettings = new NotificationTemplateSettingsDto(),
                SalesToOpsHandoverSettings = await GetSalesToOpsHandoverSettings()

            };
        }

        private async Task<GeneralSettingsEditDto> GetGeneralSettingsAsync()
        {
            var timezone = await SettingManager.GetSettingValueForApplicationAsync(TimingSettingNames.TimeZone);
            var settings = new GeneralSettingsEditDto
            {
                Timezone = timezone,
                TimezoneForComparison = timezone
            };

            var defaultTimeZoneId =
                await _timeZoneService.GetDefaultTimezoneAsync(SettingScopes.Application, AbpSession.TenantId);
            if (settings.Timezone == defaultTimeZoneId)
            {
                settings.Timezone = string.Empty;
            }

            return settings;
        }

        private async Task<TenantManagementSettingsEditDto> GetTenantManagementSettingsAsync()
        {
            var settings = new TenantManagementSettingsEditDto
            {
                AllowSelfRegistration =
                    await SettingManager.GetSettingValueAsync<bool>(AppSettings.TenantManagement.AllowSelfRegistration),
                IsNewRegisteredTenantActiveByDefault =
                    await SettingManager.GetSettingValueAsync<bool>(AppSettings.TenantManagement
                        .IsNewRegisteredTenantActiveByDefault),
                UseCaptchaOnRegistration =
                    await SettingManager.GetSettingValueAsync<bool>(AppSettings.TenantManagement
                        .UseCaptchaOnRegistration),
            };

            var defaultEditionId =
                await SettingManager.GetSettingValueAsync(AppSettings.TenantManagement.DefaultEdition);
            if (!string.IsNullOrEmpty(defaultEditionId) &&
                (await _editionManager.FindByIdAsync(Convert.ToInt32(defaultEditionId)) != null))
            {
                settings.DefaultEditionId = Convert.ToInt32(defaultEditionId);
            }

            return settings;
        }

        private async Task<HostUserManagementSettingsEditDto> GetUserManagementAsync()
        {
            return new HostUserManagementSettingsEditDto
            {
                IsEmailConfirmationRequiredForLogin =
                    await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement
                        .IsEmailConfirmationRequiredForLogin),
                SmsVerificationEnabled =
                    await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.SmsVerificationEnabled),
                IsCookieConsentEnabled =
                    await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.IsCookieConsentEnabled),
                IsQuickThemeSelectEnabled =
                    await SettingManager.GetSettingValueAsync<bool>(
                        AppSettings.UserManagement.IsQuickThemeSelectEnabled),
                UseCaptchaOnLogin =
                    await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.UseCaptchaOnLogin),
                AllowUsingGravatarProfilePicture =
                    await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement
                        .AllowUsingGravatarProfilePicture),
                SessionTimeOutSettings = new SessionTimeOutSettingsEditDto
                {
                    IsEnabled = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement
                        .SessionTimeOut.IsEnabled),
                    TimeOutSecond =
                        await SettingManager.GetSettingValueAsync<int>(AppSettings.UserManagement.SessionTimeOut
                            .TimeOutSecond),
                    ShowTimeOutNotificationSecond =
                        await SettingManager.GetSettingValueAsync<int>(AppSettings.UserManagement.SessionTimeOut
                            .ShowTimeOutNotificationSecond),
                    ShowLockScreenWhenTimedOut =
                        await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.SessionTimeOut
                            .ShowLockScreenWhenTimedOut)
                },
                UserPasswordSettings = new UserPasswordSettingsEditDto()
                {
                    EnableCheckingLastXPasswordWhenPasswordChange = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.Password.EnableCheckingLastXPasswordWhenPasswordChange),
                    CheckingLastXPasswordCount = await SettingManager.GetSettingValueAsync<int>(AppSettings.UserManagement.Password.CheckingLastXPasswordCount),
                    EnablePasswordExpiration = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.Password.EnablePasswordExpiration),
                    PasswordExpirationDayCount = await SettingManager.GetSettingValueAsync<int>(AppSettings.UserManagement.Password.PasswordExpirationDayCount),
                }
            };
        }

        private async Task<EmailSettingsEditDto> GetEmailSettingsAsync()
        {
            var smtpPassword = await SettingManager.GetSettingValueAsync(EmailSettingNames.Smtp.Password);

            return new EmailSettingsEditDto
            {
                DefaultFromAddress = await SettingManager.GetSettingValueAsync(EmailSettingNames.DefaultFromAddress),
                DefaultFromDisplayName =
                    await SettingManager.GetSettingValueAsync(EmailSettingNames.DefaultFromDisplayName),
                SmtpHost = await SettingManager.GetSettingValueAsync(EmailSettingNames.Smtp.Host),
                SmtpPort = await SettingManager.GetSettingValueAsync<int>(EmailSettingNames.Smtp.Port),
                SmtpUserName = await SettingManager.GetSettingValueAsync(EmailSettingNames.Smtp.UserName),
                SmtpPassword = SimpleStringCipher.Instance.Decrypt(smtpPassword),
                SmtpDomain = await SettingManager.GetSettingValueAsync(EmailSettingNames.Smtp.Domain),
                SmtpEnableSsl = await SettingManager.GetSettingValueAsync<bool>(EmailSettingNames.Smtp.EnableSsl),
                SmtpUseDefaultCredentials =
                    await SettingManager.GetSettingValueAsync<bool>(EmailSettingNames.Smtp.UseDefaultCredentials)
            };
        }

        private async Task<SecuritySettingsEditDto> GetSecuritySettingsAsync()
        {
            var passwordComplexitySetting = new PasswordComplexitySetting
            {
                RequireDigit =
                    await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement
                        .PasswordComplexity.RequireDigit),
                RequireLowercase =
                    await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement
                        .PasswordComplexity.RequireLowercase),
                RequireNonAlphanumeric =
                    await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement
                        .PasswordComplexity.RequireNonAlphanumeric),
                RequireUppercase =
                    await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement
                        .PasswordComplexity.RequireUppercase),
                RequiredLength =
                    await SettingManager.GetSettingValueAsync<int>(AbpZeroSettingNames.UserManagement.PasswordComplexity
                        .RequiredLength)
            };

            var defaultPasswordComplexitySetting = new PasswordComplexitySetting
            {
                RequireDigit = Convert.ToBoolean(_settingDefinitionManager
                    .GetSettingDefinition(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireDigit)
                    .DefaultValue),
                RequireLowercase = Convert.ToBoolean(_settingDefinitionManager
                    .GetSettingDefinition(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireLowercase)
                    .DefaultValue),
                RequireNonAlphanumeric = Convert.ToBoolean(_settingDefinitionManager
                    .GetSettingDefinition(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireNonAlphanumeric)
                    .DefaultValue),
                RequireUppercase = Convert.ToBoolean(_settingDefinitionManager
                    .GetSettingDefinition(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireUppercase)
                    .DefaultValue),
                RequiredLength = Convert.ToInt32(_settingDefinitionManager
                    .GetSettingDefinition(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequiredLength)
                    .DefaultValue)
            };

            return new SecuritySettingsEditDto
            {
                UseDefaultPasswordComplexitySettings =
                    passwordComplexitySetting.Equals(defaultPasswordComplexitySetting),
                PasswordComplexity = passwordComplexitySetting,
                DefaultPasswordComplexity = defaultPasswordComplexitySetting,
                UserLockOut = await GetUserLockOutSettingsAsync(),
                TwoFactorLogin = await GetTwoFactorLoginSettingsAsync(),
                AllowOneConcurrentLoginPerUser = await GetOneConcurrentLoginPerUserSetting()
            };
        }

        private async Task<HostBillingSettingsEditDto> GetBillingSettingsAsync()
        {
            return new HostBillingSettingsEditDto
            {
                LegalName = await SettingManager.GetSettingValueAsync(AppSettings.HostManagement.BillingLegalName),
                Address = await SettingManager.GetSettingValueAsync(AppSettings.HostManagement.BillingAddress)
            };
        }

        private async Task<OtherSettingsEditDto> GetOtherSettingsAsync()
        {
            return new OtherSettingsEditDto()
            {
                IsQuickThemeSelectEnabled =
                    await SettingManager.GetSettingValueAsync<bool>(
                        AppSettings.UserManagement.IsQuickThemeSelectEnabled)
            };
        }

        private async Task<UserLockOutSettingsEditDto> GetUserLockOutSettingsAsync()
        {
            return new UserLockOutSettingsEditDto
            {
                IsEnabled = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement
                    .UserLockOut.IsEnabled),
                MaxFailedAccessAttemptsBeforeLockout =
                    await SettingManager.GetSettingValueAsync<int>(AbpZeroSettingNames.UserManagement.UserLockOut
                        .MaxFailedAccessAttemptsBeforeLockout),
                DefaultAccountLockoutSeconds =
                    await SettingManager.GetSettingValueAsync<int>(AbpZeroSettingNames.UserManagement.UserLockOut
                        .DefaultAccountLockoutSeconds)
            };
        }

        private async Task<TwoFactorLoginSettingsEditDto> GetTwoFactorLoginSettingsAsync()
        {
            var twoFactorLoginSettingsEditDto = new TwoFactorLoginSettingsEditDto
            {
                IsEnabled = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement
                    .TwoFactorLogin.IsEnabled),
                IsEmailProviderEnabled =
                    await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.TwoFactorLogin
                        .IsEmailProviderEnabled),
                IsSmsProviderEnabled =
                    await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.TwoFactorLogin
                        .IsSmsProviderEnabled),
                IsRememberBrowserEnabled =
                    await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.TwoFactorLogin
                        .IsRememberBrowserEnabled),
                IsGoogleAuthenticatorEnabled =
                    await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.TwoFactorLogin
                        .IsGoogleAuthenticatorEnabled)
            };
            return twoFactorLoginSettingsEditDto;
        }

        private async Task<bool> GetOneConcurrentLoginPerUserSetting()
        {
            return await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement
                .AllowOneConcurrentLoginPerUser);
        }

        private async Task<ExternalLoginProviderSettingsEditDto> GetExternalLoginProviderSettings()
        {
            var facebookSettings =
                await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider.Host
                    .Facebook);
            var googleSettings =
                await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider.Host.Google);
            var twitterSettings =
                await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider.Host.Twitter);
            var microsoftSettings =
                await SettingManager.GetSettingValueForApplicationAsync(
                    AppSettings.ExternalLoginProvider.Host.Microsoft);

            var openIdConnectSettings =
                await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider.Host
                    .OpenIdConnect);
            var openIdConnectMapperClaims =
                await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider
                    .OpenIdConnectMappedClaims);

            var wsFederationSettings =
                await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider.Host
                    .WsFederation);
            var wsFederationMapperClaims =
                await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider
                    .WsFederationMappedClaims);

            return new ExternalLoginProviderSettingsEditDto
            {
                Facebook = facebookSettings.IsNullOrWhiteSpace()
                    ? new FacebookExternalLoginProviderSettings()
                    : facebookSettings.FromJsonString<FacebookExternalLoginProviderSettings>(),
                Google = googleSettings.IsNullOrWhiteSpace()
                    ? new GoogleExternalLoginProviderSettings()
                    : googleSettings.FromJsonString<GoogleExternalLoginProviderSettings>(),
                Twitter = twitterSettings.IsNullOrWhiteSpace()
                    ? new TwitterExternalLoginProviderSettings()
                    : twitterSettings.FromJsonString<TwitterExternalLoginProviderSettings>(),
                Microsoft = microsoftSettings.IsNullOrWhiteSpace()
                    ? new MicrosoftExternalLoginProviderSettings()
                    : microsoftSettings.FromJsonString<MicrosoftExternalLoginProviderSettings>(),

                OpenIdConnect = openIdConnectSettings.IsNullOrWhiteSpace()
                    ? new OpenIdConnectExternalLoginProviderSettings()
                    : openIdConnectSettings.FromJsonString<OpenIdConnectExternalLoginProviderSettings>(),
                OpenIdConnectClaimsMapping = openIdConnectMapperClaims.IsNullOrWhiteSpace()
                    ? new List<JsonClaimMapDto>()
                    : openIdConnectMapperClaims.FromJsonString<List<JsonClaimMapDto>>(),

                WsFederation = wsFederationSettings.IsNullOrWhiteSpace()
                    ? new WsFederationExternalLoginProviderSettings()
                    : wsFederationSettings.FromJsonString<WsFederationExternalLoginProviderSettings>(),
                WsFederationClaimsMapping = wsFederationMapperClaims.IsNullOrWhiteSpace()
                    ? new List<JsonClaimMapDto>()
                    : wsFederationMapperClaims.FromJsonString<List<JsonClaimMapDto>>()
            };
        }
        private async Task<CustomerSettingsDto> GetCustomerSettings()
        {
            return new CustomerSettingsDto
            {
                NewCustomerFlag = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.Customer.NewCustomerFlag),
            };
        }
        private async Task<PaymentSettingsEditDto> GetPaymentSettings()
        {
            return new PaymentSettingsEditDto()
            {
                Application = new PaymentApplicationSettingsEditDto()
                {
                    AutoPopulate = await SettingManager.GetSettingValueForApplicationAsync<bool>(
                        AppSettings.Payment.Application.AutoPopulate),
                    SubOnOrBefore = await SettingManager.GetSettingValueForApplicationAsync(
                        AppSettings.Payment.Application.SubOnOrBefore),
                    ValuedTo = await SettingManager.GetSettingValueForApplicationAsync(
                        AppSettings.Payment.Application.ValuedTo),
                    DueDate = await SettingManager.GetSettingValueForApplicationAsync<int>(
                        AppSettings.Payment.Application.DueDate),
                    PmtDueBy = await SettingManager.GetSettingValueForApplicationAsync<int>(
                        AppSettings.Payment.Application.PmtDueBy),
                    FinalDate = await SettingManager.GetSettingValueForApplicationAsync<int>(
                        AppSettings.Payment.Application.FinalDate),
                    PayLessDueBy = await SettingManager.GetSettingValueForApplicationAsync<int>(
                        AppSettings.Payment.Application.PayLessDueBy),
                    Suspend = await SettingManager.GetSettingValueForApplicationAsync<int>(
                        AppSettings.Payment.Application.Suspend),
                },
                Invoice = new PaymentInvoiceSettingsEditDto()
                {
                    AutoPopulate = await SettingManager.GetSettingValueForApplicationAsync<bool>(
                        AppSettings.Payment.Invoice.AutoPopulate),
                    Days = await SettingManager.GetSettingValueForApplicationAsync<int>(
                        AppSettings.Payment.Invoice.Days),
                    Date = await SettingManager.GetSettingValueForApplicationAsync(
                        AppSettings.Payment.Invoice.Date),
                    Period = await SettingManager.GetSettingValueForApplicationAsync(
                        AppSettings.Payment.Invoice.Period),
                },
            };
        }
        private async Task<PromptsAndAlertsSettingsEditDto> GetPromptsAndAlertsSettings()
        {
            return new PromptsAndAlertsSettingsEditDto
            {
                Hours = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.PromptsAndAlerts.Hours),
                Mins = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.PromptsAndAlerts.Mins),
                Meridiem = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.PromptsAndAlerts.Meridiem)
            };
        }
        private async Task<TaskDelegationSettingsEditDto> GetTaskDelegationSettings()
        {
            return new TaskDelegationSettingsEditDto
            {
                CommenceMail = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.TaskDelegation.CommenceMail),
                DelegateReview = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.TaskDelegation.DelegateReview),
                DelegateTask = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.TaskDelegation.DelegateTask)
            };
        }
        private async Task<TaskSettingsEditDto> GetTaskSettings()
        {
            return new TaskSettingsEditDto
            {
                AutoAssign = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.TaskSetting.AutoAssign),
                DsgnAndEst = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.TaskSetting.DsgnAndEst),
                PermToApprove = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.TaskSetting.PermToApprove),
                ProjProgDiffQuotedApproval = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.TaskSetting.ProjProgDiffQuotedApproval),
            };
        }
        private async Task<DashboardBusinessRulesSettingsEditDto> GetDashboardBusinessRulesSettings()
        {
            var projectRules = new BusinessRulesEditDto()
            {
                RedDays = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.BusinessRules.Project.Red),
                AmberDays = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.BusinessRules.Project.Amber),
            };
            var SWRules = new BusinessRulesEditDto()
            {
                RedDays = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.BusinessRules.SW.Red),
                AmberDays = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.BusinessRules.SW.Amber),
            };
            var TAndMRules = new BusinessRulesEditDto()
            {
                RedDays = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.BusinessRules.TAndM.Red),
                AmberDays = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.BusinessRules.TAndM.Amber),
            };
            var SAndMRules = new BusinessRulesEditDto()
            {
                RedDays = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.BusinessRules.SAndM.Red),
                AmberDays = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.BusinessRules.SAndM.Amber),
            };
            return new DashboardBusinessRulesSettingsEditDto
            {
                Project = projectRules,
                SW = SWRules,
                TAndM = TAndMRules,
                SAndM = SAndMRules
            };
        }
        private async Task<ReportGenerationIntervalSettingsEditDto> GetReportGenIntervalSettings()
        {
            return new ReportGenerationIntervalSettingsEditDto
            {
                Monthly = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.ReportGenInterval.Monthly),
                Weekly = await SettingManager.GetSettingValueForApplicationAsync<bool>(AppSettings.ReportGenInterval.Weekly),
                RecurDate = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.ReportGenInterval.RecurDate),
                RecurDateMonthly = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.ReportGenInterval.RecurDateMonthly),
                RecurDay = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ReportGenInterval.RecurDay),
                RecurDayMonthly = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.ReportGenInterval.RecurDayMonthly),
                RecurDaySeq = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ReportGenInterval.RecurDaySeq),
                RecurWeekly = await SettingManager.GetSettingValueForApplicationAsync<int>(AppSettings.ReportGenInterval.RecurWeekly),
                RecurWeeklyDay = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ReportGenInterval.RecurWeeklyDay),

            };
        }
        private async Task<object> GetWinProbabilitySettings()
        {
            var probabilities = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.WinProbability.WinProbabilityJson);
            var winProbability = JsonConvert.DeserializeObject(probabilities);


            return winProbability;
        }
        private async Task<object> GetSalesToOpsHandoverSettings()
        {
            var prob = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.SalesToOpsHandover.DocListJson);
            var ProjectSalesToOpsHand = prob == null ? null : JsonConvert.DeserializeObject(prob);

            return ProjectSalesToOpsHand;
        }
        #endregion

        #region Update Settings

        public async Task UpdateAllSettings(HostSettingsEditDto input)
        {
            await UpdateGeneralSettingsAsync(input.General);
            await UpdateTenantManagementAsync(input.TenantManagement);
            await UpdateUserManagementSettingsAsync(input.UserManagement);
            await UpdateSecuritySettingsAsync(input.Security);
            await UpdateEmailSettingsAsync(input.Email);
            await UpdateBillingSettingsAsync(input.Billing);
            await UpdateOtherSettingsAsync(input.OtherSettings);
            await UpdateExternalLoginSettingsAsync(input.ExternalLoginProviderSettings);
            await UpdateCustomerSettingsAsync(input.CustomerSettings);
            await UpdatePaymentSettingsAsync(input.PaymentSettings);
            await UpdatePromptsAndAlertsSettingsAsync(input.PromptsAndAlertsSettings);
            await UpdateTaskDelegationSettingsAsync(input.TaskDelegationSettings);
            await UpdateTaskSettingsAsync(input.TaskSettings);
            await UpdateDashboardBusinessRulesSettingsAsync(input.DashboardBusinessRulesSettings);
            await UpdateReportGenIntervalSettingsAsync(input.ReportGenIntervalSettings);
            await UpdateWinProbabilitySettingsAsync(input.WinProbabilitySettings);
            await UpdateNotificationTemplateForTenant(new NotificationTemplateDto { EmailBody = input.NotificationTemplateSettings.Body, TenantId = input.NotificationTemplateSettings.TenantId });
            await UpdateSalesToOpsHandoverSettingsAsync(input.SalesToOpsHandoverSettings);


        }
        private async Task UpdateCustomerSettingsAsync(CustomerSettingsDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.Customer.NewCustomerFlag, settings.NewCustomerFlag);
        }
        private async Task UpdatePaymentSettingsAsync(PaymentSettingsEditDto settings)
        {
            await UpdatePaymentApplicationSettingsAsync(settings.Application);
            await UpdatePaymentInvoiceSettingsAsync(settings.Invoice);
        }
        private async Task UpdatePaymentApplicationSettingsAsync(PaymentApplicationSettingsEditDto input)
        {

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.Payment.Application.AutoPopulate, input.AutoPopulate.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(
                   AppSettings.Payment.Application.DueDate, input.DueDate.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(
                      AppSettings.Payment.Application.FinalDate, input.FinalDate.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(
                   AppSettings.Payment.Application.ValuedTo, input.ValuedTo);
            await SettingManager.ChangeSettingForApplicationAsync(
                  AppSettings.Payment.Application.SubOnOrBefore, input.SubOnOrBefore);
            await SettingManager.ChangeSettingForApplicationAsync(
                   AppSettings.Payment.Application.PayLessDueBy, input.PayLessDueBy.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(
                   AppSettings.Payment.Application.PmtDueBy, input.PmtDueBy.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(
                   AppSettings.Payment.Application.Suspend, input.Suspend.ToString());
        }
        private async Task UpdatePaymentInvoiceSettingsAsync(PaymentInvoiceSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                        AppSettings.Payment.Invoice.AutoPopulate, input.AutoPopulate.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(
                    AppSettings.Payment.Invoice.Days, input.Days.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(
                    AppSettings.Payment.Invoice.Date, input.Date);
            await SettingManager.ChangeSettingForApplicationAsync(
                    AppSettings.Payment.Invoice.Period, input.Period);
        }
        private async Task UpdatePromptsAndAlertsSettingsAsync(PromptsAndAlertsSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.PromptsAndAlerts.Hours, settings.Hours.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.PromptsAndAlerts.Mins, settings.Mins.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.PromptsAndAlerts.Meridiem, settings.Meridiem);
        }
        private async Task UpdateTaskDelegationSettingsAsync(TaskDelegationSettingsEditDto settings)
        {

            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.TaskDelegation.CommenceMail, settings.CommenceMail.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.TaskDelegation.DelegateReview, settings.DelegateReview.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.TaskDelegation.DelegateTask, settings.DelegateTask.ToString());

        }
        private async Task UpdateTaskSettingsAsync(TaskSettingsEditDto settings)
        {

            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.TaskSetting.AutoAssign, settings.AutoAssign.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.TaskSetting.DsgnAndEst, settings.DsgnAndEst.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.TaskSetting.PermToApprove, settings.PermToApprove.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.TaskSetting.ProjProgDiffQuotedApproval, settings.ProjProgDiffQuotedApproval.ToString());

        }
        private async Task UpdateDashboardBusinessRulesSettingsAsync(DashboardBusinessRulesSettingsEditDto settings)
        {

            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.BusinessRules.Project.Red, settings.Project.RedDays.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.BusinessRules.Project.Amber, settings.Project.AmberDays.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.BusinessRules.SW.Red, settings.SW.RedDays.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.BusinessRules.SW.Amber, settings.SW.RedDays.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.BusinessRules.TAndM.Red, settings.TAndM.RedDays.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.BusinessRules.TAndM.Amber, settings.TAndM.RedDays.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.BusinessRules.SAndM.Red, settings.SAndM.RedDays.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.BusinessRules.SAndM.Amber, settings.SAndM.RedDays.ToString());
        }
        private async Task UpdateReportGenIntervalSettingsAsync(ReportGenerationIntervalSettingsEditDto settings)
        {

            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.Monthly, settings.Monthly.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.Weekly, settings.Weekly.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.RecurDate, settings.RecurDate.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.RecurDateMonthly, settings.RecurDateMonthly.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.RecurDay, settings.RecurDay);
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.RecurDayMonthly, settings.RecurDayMonthly.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.RecurDaySeq, settings.RecurDaySeq);
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.RecurWeekly, settings.RecurWeekly.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.ReportGenInterval.RecurWeeklyDay, settings.RecurWeeklyDay.ToString());


        }
        private async Task UpdateWinProbabilitySettingsAsync(object settings)
        {
            //string prjProbjson = JsonConvert.SerializeObject(settings.Project.ProbabilityList);
            //string swProbjson = JsonConvert.SerializeObject(settings.SW.ProbabilityList);
            //string tmProbjson = JsonConvert.SerializeObject(settings.TAndM.ProbabilityList);
            //string smProbjson = JsonConvert.SerializeObject(settings.SAndM.ProbabilityList);

            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.Project.DropDown,
            //    settings.Project.DropDown.ToString()
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.Project.ShowRules,
            //    settings.Project.ShowRules.ToString()
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.Project.Probabilities,
            //    prjProbjson
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.SW.DropDown,
            //    settings.SW.DropDown.ToString()
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.SW.ShowRules,
            //    settings.SW.ShowRules.ToString()
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.SW.Probabilities,
            //    swProbjson
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.TAndM.DropDown,
            //    settings.TAndM.DropDown.ToString()
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.TAndM.ShowRules,
            //    settings.TAndM.ShowRules.ToString()
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.TAndM.Probabilities,
            //    tmProbjson
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.SAndM.DropDown,
            //    settings.SAndM.DropDown.ToString()
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.SAndM.ShowRules,
            //    settings.SAndM.ShowRules.ToString()
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.SAndM.Probabilities,
            //    smProbjson
            //);
            //await SettingManager.ChangeSettingForApplicationAsync(

            //    AppSettings.WinProbability.WinProbabilityJson,
            //    JsonConvert.SerializeObject(settings)
            //);
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.WinProbability.WinProbabilityJson,
                JsonConvert.SerializeObject(settings)
            );
        }

        private async Task UpdateSalesToOpsHandoverSettingsAsync(object settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
               AppSettings.SalesToOpsHandover.DocListJson,
               JsonConvert.SerializeObject(settings)
           );
        }

        private async Task UpdateOtherSettingsAsync(OtherSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.IsQuickThemeSelectEnabled,
                input.IsQuickThemeSelectEnabled.ToString().ToLowerInvariant()
            );
        }

        private async Task UpdateBillingSettingsAsync(HostBillingSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.HostManagement.BillingLegalName,
                input.LegalName);
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.HostManagement.BillingAddress,
                input.Address);
        }

        private async Task UpdateGeneralSettingsAsync(GeneralSettingsEditDto settings)
        {
            if (Clock.SupportsMultipleTimezone)
            {
                if (settings.Timezone.IsNullOrEmpty())
                {
                    var defaultValue =
                        await _timeZoneService.GetDefaultTimezoneAsync(SettingScopes.Application, AbpSession.TenantId);
                    await SettingManager.ChangeSettingForApplicationAsync(TimingSettingNames.TimeZone, defaultValue);
                }
                else
                {
                    await SettingManager.ChangeSettingForApplicationAsync(TimingSettingNames.TimeZone,
                        settings.Timezone);
                }
            }
        }

        private async Task UpdateTenantManagementAsync(TenantManagementSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.TenantManagement.AllowSelfRegistration,
                settings.AllowSelfRegistration.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.TenantManagement.IsNewRegisteredTenantActiveByDefault,
                settings.IsNewRegisteredTenantActiveByDefault.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.TenantManagement.UseCaptchaOnRegistration,
                settings.UseCaptchaOnRegistration.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.TenantManagement.DefaultEdition,
                settings.DefaultEditionId?.ToString() ?? ""
            );
        }

        private async Task UpdateUserManagementSettingsAsync(HostUserManagementSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.IsEmailConfirmationRequiredForLogin,
                settings.IsEmailConfirmationRequiredForLogin.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.SmsVerificationEnabled,
                settings.SmsVerificationEnabled.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.IsCookieConsentEnabled,
                settings.IsCookieConsentEnabled.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.UseCaptchaOnLogin,
                settings.UseCaptchaOnLogin.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.AllowUsingGravatarProfilePicture,
                settings.AllowUsingGravatarProfilePicture.ToString().ToLowerInvariant()
            );

            await UpdateUserManagementSessionTimeOutSettingsAsync(settings.SessionTimeOutSettings);
            await UpdateUserManagementPasswordSettingsAsync(settings.UserPasswordSettings);
        }

        private async Task UpdateUserManagementPasswordSettingsAsync(UserPasswordSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.Password.EnableCheckingLastXPasswordWhenPasswordChange,
                settings.EnableCheckingLastXPasswordWhenPasswordChange.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.Password.CheckingLastXPasswordCount,
                settings.CheckingLastXPasswordCount.ToString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.Password.EnablePasswordExpiration,
                settings.EnablePasswordExpiration.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.Password.PasswordExpirationDayCount,
                settings.PasswordExpirationDayCount.ToString()
            );
        }

        private async Task UpdateUserManagementSessionTimeOutSettingsAsync(SessionTimeOutSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.SessionTimeOut.IsEnabled,
                settings.IsEnabled.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.SessionTimeOut.TimeOutSecond,
                settings.TimeOutSecond.ToString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.SessionTimeOut.ShowTimeOutNotificationSecond,
                settings.ShowTimeOutNotificationSecond.ToString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.SessionTimeOut.ShowLockScreenWhenTimedOut,
                settings.ShowLockScreenWhenTimedOut.ToString()
            );
        }

        private async Task UpdateSecuritySettingsAsync(SecuritySettingsEditDto settings)
        {
            if (settings.UseDefaultPasswordComplexitySettings)
            {
                await UpdatePasswordComplexitySettingsAsync(settings.DefaultPasswordComplexity);
            }
            else
            {
                await UpdatePasswordComplexitySettingsAsync(settings.PasswordComplexity);
            }

            await UpdateUserLockOutSettingsAsync(settings.UserLockOut);
            await UpdateTwoFactorLoginSettingsAsync(settings.TwoFactorLogin);
            await UpdateOneConcurrentLoginPerUserSettingAsync(settings.AllowOneConcurrentLoginPerUser);
        }

        private async Task UpdatePasswordComplexitySettingsAsync(PasswordComplexitySetting settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireDigit,
                settings.RequireDigit.ToString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireLowercase,
                settings.RequireLowercase.ToString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireNonAlphanumeric,
                settings.RequireNonAlphanumeric.ToString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireUppercase,
                settings.RequireUppercase.ToString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequiredLength,
                settings.RequiredLength.ToString()
            );
        }

        private async Task UpdateUserLockOutSettingsAsync(UserLockOutSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.UserLockOut.IsEnabled,
                settings.IsEnabled.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.UserLockOut.DefaultAccountLockoutSeconds,
                settings.DefaultAccountLockoutSeconds.ToString());
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.UserLockOut.MaxFailedAccessAttemptsBeforeLockout,
                settings.MaxFailedAccessAttemptsBeforeLockout.ToString());
        }

        private async Task UpdateTwoFactorLoginSettingsAsync(TwoFactorLoginSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsEnabled,
                settings.IsEnabled.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsEmailProviderEnabled,
                settings.IsEmailProviderEnabled.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsSmsProviderEnabled,
                settings.IsSmsProviderEnabled.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.TwoFactorLogin.IsGoogleAuthenticatorEnabled,
                settings.IsGoogleAuthenticatorEnabled.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForApplicationAsync(
                AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsRememberBrowserEnabled,
                settings.IsRememberBrowserEnabled.ToString().ToLowerInvariant());
        }

        private async Task UpdateEmailSettingsAsync(EmailSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.DefaultFromAddress,
                settings.DefaultFromAddress);
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.DefaultFromDisplayName,
                settings.DefaultFromDisplayName);
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.Smtp.Host, settings.SmtpHost);
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.Smtp.Port,
                settings.SmtpPort.ToString(CultureInfo.InvariantCulture));
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.Smtp.UserName,
                settings.SmtpUserName);
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.Smtp.Password,
                SimpleStringCipher.Instance.Encrypt(settings.SmtpPassword));
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.Smtp.Domain, settings.SmtpDomain);
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.Smtp.EnableSsl,
                settings.SmtpEnableSsl.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForApplicationAsync(EmailSettingNames.Smtp.UseDefaultCredentials,
                settings.SmtpUseDefaultCredentials.ToString().ToLowerInvariant());
        }

        private async Task UpdateOneConcurrentLoginPerUserSettingAsync(bool allowOneConcurrentLoginPerUser)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.UserManagement.AllowOneConcurrentLoginPerUser, allowOneConcurrentLoginPerUser.ToString());
        }

        private async Task UpdateExternalLoginSettingsAsync(ExternalLoginProviderSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.ExternalLoginProvider.Host.Facebook,
                input.Facebook == null || !input.Facebook.IsValid()
                    ? _settingDefinitionManager.GetSettingDefinition(AppSettings.ExternalLoginProvider.Host.Facebook)
                        .DefaultValue
                    : input.Facebook.ToJsonString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.ExternalLoginProvider.Host.Google,
                input.Google == null || !input.Google.IsValid()
                    ? _settingDefinitionManager.GetSettingDefinition(AppSettings.ExternalLoginProvider.Host.Google)
                        .DefaultValue
                    : input.Google.ToJsonString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.ExternalLoginProvider.Host.Twitter,
                input.Twitter == null || !input.Twitter.IsValid()
                    ? _settingDefinitionManager.GetSettingDefinition(AppSettings.ExternalLoginProvider.Host.Twitter)
                        .DefaultValue
                    : input.Twitter.ToJsonString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.ExternalLoginProvider.Host.Microsoft,
                input.Microsoft == null || !input.Microsoft.IsValid()
                    ? _settingDefinitionManager.GetSettingDefinition(AppSettings.ExternalLoginProvider.Host.Microsoft)
                        .DefaultValue
                    : input.Microsoft.ToJsonString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.ExternalLoginProvider.Host.OpenIdConnect,
                input.OpenIdConnect == null || !input.OpenIdConnect.IsValid()
                    ? _settingDefinitionManager
                        .GetSettingDefinition(AppSettings.ExternalLoginProvider.Host.OpenIdConnect).DefaultValue
                    : input.OpenIdConnect.ToJsonString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.ExternalLoginProvider.OpenIdConnectMappedClaims,
                input.OpenIdConnectClaimsMapping.IsNullOrEmpty()
                    ? _settingDefinitionManager
                        .GetSettingDefinition(AppSettings.ExternalLoginProvider.OpenIdConnectMappedClaims).DefaultValue
                    : input.OpenIdConnectClaimsMapping.ToJsonString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.ExternalLoginProvider.Host.WsFederation,
                input.WsFederation == null || !input.WsFederation.IsValid()
                    ? _settingDefinitionManager
                        .GetSettingDefinition(AppSettings.ExternalLoginProvider.Host.WsFederation).DefaultValue
                    : input.WsFederation.ToJsonString()
            );

            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.ExternalLoginProvider.WsFederationMappedClaims,
                input.WsFederationClaimsMapping.IsNullOrEmpty()
                    ? _settingDefinitionManager
                        .GetSettingDefinition(AppSettings.ExternalLoginProvider.WsFederationMappedClaims).DefaultValue
                    : input.WsFederationClaimsMapping.ToJsonString()
            );

            ExternalLoginOptionsCacheManager.ClearCache();
        }

        private async Task UpdateNotificationTemplateForTenant(NotificationTemplateDto settings)
        {
            if (settings != null && settings.TenantId != null && !string.IsNullOrEmpty(settings.EmailBody))
            {
                await _notificationTemplateAppService.CreateOrUpdate(settings);
            }
        }

        public async Task UpdateGridSettingsAsync(string input)
        {
            await SettingManager.ChangeSettingForApplicationAsync(
                AppSettings.Grid.Settings,
                input
            );
        }

        #endregion
    }
}
