﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Application.Services;
using asq.econsys.Configuration.Dto;

namespace asq.econsys.Configuration
{
    public interface IUiCustomizationSettingsAppService : IApplicationService
    {
        Task<List<ThemeSettingsDto>> GetUiManagementSettings();

        Task UpdateUiManagementSettings(ThemeSettingsDto settings);

        Task UpdateDefaultUiManagementSettings(ThemeSettingsDto settings);

        Task UseSystemDefaultSettings();
    }
}
