using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Collections.Extensions;
using Abp.Configuration;
using Abp.Configuration.Startup;
using Abp.Extensions;
using Abp.Json;
using Abp.Net.Mail;
using Abp.Runtime.Security;
using Abp.Runtime.Session;
using Abp.Timing;
using Abp.Zero.Configuration;
using Abp.Zero.Ldap.Configuration;
using asq.econsys.Authentication;
using asq.econsys.Authorization;
using asq.econsys.Configuration.Dto;
using asq.econsys.Configuration.Host.Dto;
using asq.econsys.Configuration.Tenants.Dto;
using asq.econsys.Eco.Settings.Dtos;
using asq.econsys.NotificationTemplate;
using asq.econsys.NotificationTemplate.Dto;
using asq.econsys.Security;
using asq.econsys.Storage;
using asq.econsys.Timing;
using Newtonsoft.Json;

namespace asq.econsys.Configuration.Tenants
{
    [AbpAuthorize(AppPermissions.Pages_Administration_Tenant_Settings)]
    public class TenantSettingsAppService : SettingsAppServiceBase, ITenantSettingsAppService
    {
        public IExternalLoginOptionsCacheManager ExternalLoginOptionsCacheManager { get; set; }

        private readonly IMultiTenancyConfig _multiTenancyConfig;
        private readonly ITimeZoneService _timeZoneService;
        private readonly IBinaryObjectManager _binaryObjectManager;
        private readonly IAbpZeroLdapModuleConfig _ldapModuleConfig;
        private readonly INotificationTemplateAppService _notificationTemplateAppService;

        public TenantSettingsAppService(
            IAbpZeroLdapModuleConfig ldapModuleConfig,
            IMultiTenancyConfig multiTenancyConfig,
            ITimeZoneService timeZoneService,
            IEmailSender emailSender,
            IBinaryObjectManager binaryObjectManager,
            IAppConfigurationAccessor configurationAccessor,
            INotificationTemplateAppService notificationTemplateAppService
            ) : base(emailSender, configurationAccessor)
        {
            ExternalLoginOptionsCacheManager = NullExternalLoginOptionsCacheManager.Instance;

            _multiTenancyConfig = multiTenancyConfig;
            _ldapModuleConfig = ldapModuleConfig;
            _timeZoneService = timeZoneService;
            _binaryObjectManager = binaryObjectManager;
            _notificationTemplateAppService = notificationTemplateAppService;
        }

        #region Get Settings

        public async Task<TenantSettingsEditDto> GetAllSettings()
        {
            var settings = new TenantSettingsEditDto
            {
                UserManagement = await GetUserManagementSettingsAsync(),
                Security = await GetSecuritySettingsAsync(),
                Billing = await GetBillingSettingsAsync(),
                OtherSettings = await GetOtherSettingsAsync(),
                Email = await GetEmailSettingsAsync(),
                ExternalLoginProviderSettings = await GetExternalLoginProviderSettings(),
                CustomerSettings = await GetCustomerSettings(),
                PaymentSettings = await GetPaymentSettings(),
                PromptsAndAlertsSettings = await GetPromptsAndAlertsSettings(),
                TaskDelegationSettings = await GetTaskDelegationSettings(),
                TaskSettings = await GetTaskSettings(),
                DashboardBusinessRulesSettings = await GetDashboardBusinessRulesSettings(),
                ReportGenIntervalSettings = await GetReportGenIntervalSettings(),
                WinProbabilitySettings = await GetWinProbabilitySettings(),
                WorkFlowSettings = await GetWorkFlowProjectSettings(),
                PPMSettings = await GetPPMSettings(),
                NotificationTemplateSettings = await GetEmailNotficationTempalte(),
                Currency = await GetCurrencySettingsAsync(),
                SalesToOpsHandoverSettings = await GetSalesToOpsHandoverSettings(),
            };

            if (!_multiTenancyConfig.IsEnabled || Clock.SupportsMultipleTimezone)
            {
                settings.General = await GetGeneralSettingsAsync();
            }

            if (_ldapModuleConfig.IsEnabled)
            {
                settings.Ldap = await GetLdapSettingsAsync();
            }
            else
            {
                settings.Ldap = new LdapSettingsEditDto { IsModuleEnabled = false };
            }

            return settings;
        }

        //CustomSettings
        private async Task<CustomerSettingsDto> GetCustomerSettings()
        {
            return new CustomerSettingsDto
            {
                NewCustomerFlag = await SettingManager.GetSettingValueForTenantAsync(AppSettings.Customer.NewCustomerFlag, AbpSession.GetTenantId()),
            };
        }

        private async Task<CurrencyDto> GetCurrencySettingsAsync()
        {
            return new CurrencyDto
            {
                Currency = await SettingManager.GetSettingValueForTenantAsync(AppSettings.Currency.CurrencyCode, AbpSession.GetTenantId()),
                CurrencySign = await SettingManager.GetSettingValueForTenantAsync(AppSettings.Currency.CurrencySign, AbpSession.GetTenantId())
            };
        }

        private async Task<PaymentSettingsEditDto> GetPaymentSettings()
        {
            return new PaymentSettingsEditDto()
            {
                Application = new PaymentApplicationSettingsEditDto()
                {
                    AutoPopulate = await SettingManager.GetSettingValueForTenantAsync<bool>(
                        AppSettings.Payment.Application.AutoPopulate, AbpSession.GetTenantId()),
                    SubOnOrBefore = await SettingManager.GetSettingValueForTenantAsync(
                        AppSettings.Payment.Application.SubOnOrBefore, AbpSession.GetTenantId()),
                    ValuedTo = await SettingManager.GetSettingValueForTenantAsync(
                        AppSettings.Payment.Application.ValuedTo, AbpSession.GetTenantId()),
                    DueDate = await SettingManager.GetSettingValueForTenantAsync<int>(
                        AppSettings.Payment.Application.DueDate, AbpSession.GetTenantId()),
                    PmtDueBy = await SettingManager.GetSettingValueForTenantAsync<int>(
                        AppSettings.Payment.Application.PmtDueBy, AbpSession.GetTenantId()),
                    FinalDate = await SettingManager.GetSettingValueForTenantAsync<int>(
                        AppSettings.Payment.Application.FinalDate, AbpSession.GetTenantId()),
                    PayLessDueBy = await SettingManager.GetSettingValueForTenantAsync<int>(
                        AppSettings.Payment.Application.PayLessDueBy, AbpSession.GetTenantId()),
                    Suspend = await SettingManager.GetSettingValueForTenantAsync<int>(
                        AppSettings.Payment.Application.Suspend, AbpSession.GetTenantId()),
                },
                Invoice = new PaymentInvoiceSettingsEditDto()
                {
                    AutoPopulate = await SettingManager.GetSettingValueForTenantAsync<bool>(
                        AppSettings.Payment.Invoice.AutoPopulate, AbpSession.GetTenantId()),
                    Days = await SettingManager.GetSettingValueForTenantAsync<int>(
                        AppSettings.Payment.Invoice.Days, AbpSession.GetTenantId()),
                    Date = await SettingManager.GetSettingValueForTenantAsync(
                        AppSettings.Payment.Invoice.Date, AbpSession.GetTenantId()),
                    Period = await SettingManager.GetSettingValueForTenantAsync(
                        AppSettings.Payment.Invoice.Period, AbpSession.GetTenantId()),
                },
            };
        }
        private async Task<PromptsAndAlertsSettingsEditDto> GetPromptsAndAlertsSettings()
        {
            return new PromptsAndAlertsSettingsEditDto
            {
                Hours = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.PromptsAndAlerts.Hours, AbpSession.GetTenantId()),
                Mins = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.PromptsAndAlerts.Mins, AbpSession.GetTenantId()),
                Meridiem = await SettingManager.GetSettingValueForTenantAsync(AppSettings.PromptsAndAlerts.Meridiem, AbpSession.GetTenantId())
            };
        }
        private async Task<TaskDelegationSettingsEditDto> GetTaskDelegationSettings()
        {
            return new TaskDelegationSettingsEditDto
            {
                CommenceMail = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.TaskDelegation.CommenceMail, AbpSession.GetTenantId()),
                DelegateReview = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.TaskDelegation.DelegateReview, AbpSession.GetTenantId()),
                DelegateTask = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.TaskDelegation.DelegateTask, AbpSession.GetTenantId())
            };
        }
        private async Task<TaskSettingsEditDto> GetTaskSettings()
        {
            return new TaskSettingsEditDto
            {
                AutoAssign = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.TaskSetting.AutoAssign, AbpSession.GetTenantId()),
                DsgnAndEst = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.TaskSetting.DsgnAndEst, AbpSession.GetTenantId()),
                PermToApprove = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.TaskSetting.PermToApprove, AbpSession.GetTenantId()),
                ProjProgDiffQuotedApproval = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.TaskSetting.ProjProgDiffQuotedApproval, AbpSession.GetTenantId()),
            };
        }
        private async Task<DashboardBusinessRulesSettingsEditDto> GetDashboardBusinessRulesSettings()
        {
            var projectRules = new BusinessRulesEditDto()
            {
                RedDays = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.BusinessRules.Project.Red, AbpSession.GetTenantId()),
                AmberDays = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.BusinessRules.Project.Amber, AbpSession.GetTenantId()),
            };
            var SWRules = new BusinessRulesEditDto()
            {
                RedDays = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.BusinessRules.SW.Red, AbpSession.GetTenantId()),
                AmberDays = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.BusinessRules.SW.Amber, AbpSession.GetTenantId()),
            };
            var TAndMRules = new BusinessRulesEditDto()
            {
                RedDays = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.BusinessRules.TAndM.Red, AbpSession.GetTenantId()),
                AmberDays = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.BusinessRules.TAndM.Amber, AbpSession.GetTenantId()),
            };
            var SAndMRules = new BusinessRulesEditDto()
            {
                RedDays = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.BusinessRules.SAndM.Red, AbpSession.GetTenantId()),
                AmberDays = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.BusinessRules.SAndM.Amber, AbpSession.GetTenantId()),
            };
            return new DashboardBusinessRulesSettingsEditDto
            {
                Project = projectRules,
                SW = SWRules,
                TAndM = TAndMRules,
                SAndM = SAndMRules
            };
        }
        private async Task<ReportGenerationIntervalSettingsEditDto> GetReportGenIntervalSettings()
        {
            return new ReportGenerationIntervalSettingsEditDto
            {
                Monthly = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.ReportGenInterval.Monthly, AbpSession.GetTenantId()),
                Weekly = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.ReportGenInterval.Weekly, AbpSession.GetTenantId()),
                RecurDate = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.ReportGenInterval.RecurDate, AbpSession.GetTenantId()),
                RecurDateMonthly = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.ReportGenInterval.RecurDateMonthly, AbpSession.GetTenantId()),
                RecurDay = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ReportGenInterval.RecurDay, AbpSession.GetTenantId()),
                RecurDayMonthly = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.ReportGenInterval.RecurDayMonthly, AbpSession.GetTenantId()),
                RecurDaySeq = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ReportGenInterval.RecurDaySeq, AbpSession.GetTenantId()),
                RecurWeekly = await SettingManager.GetSettingValueForTenantAsync<int>(AppSettings.ReportGenInterval.RecurWeekly, AbpSession.GetTenantId()),
                RecurWeeklyDay = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ReportGenInterval.RecurWeeklyDay, AbpSession.GetTenantId()),

            };
        }

        public async Task<WorkFlowSettingDto> GetWorkFlowProjectSettings()
        {
            WorkFlowSettingDto workFlowSettingDto = new WorkFlowSettingDto();
            workFlowSettingDto.PRJ = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WorkflowCore.PRJ, AbpSession.GetTenantId());
            workFlowSettingDto.SWK = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WorkflowCore.SWK, AbpSession.GetTenantId());
            workFlowSettingDto.PPM = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WorkflowCore.PPM, AbpSession.GetTenantId());
            workFlowSettingDto.TandM = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WorkflowCore.TandM, AbpSession.GetTenantId());
            workFlowSettingDto.CALL = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WorkflowCore.CALL, AbpSession.GetTenantId());

            return workFlowSettingDto;
        }

        private async Task<object> GetWinProbabilitySettings()
        {
            var prjProbabilites = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WinProbability.Project.Probabilities, AbpSession.GetTenantId());
            var swProbabilites = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WinProbability.SW.Probabilities, AbpSession.GetTenantId());
            var tmProbabilites = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WinProbability.TAndM.Probabilities, AbpSession.GetTenantId());
            var smProbabilites = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WinProbability.SAndM.Probabilities, AbpSession.GetTenantId());
            var probabilities = await SettingManager.GetSettingValueForTenantAsync(AppSettings.WinProbability.WinProbabilityJson, AbpSession.GetTenantId());
            var winProbability = JsonConvert.DeserializeObject(probabilities);


            var json = JsonConvert.DeserializeObject<List<ProbabilityListEditDto>>(smProbabilites);

            return winProbability;
            //return new WinProbabilitySettingsEditDto
            //{
            //Project = new WinProbabilityEditDto
            //{
            //    DropDown = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.WinProbability.Project.DropDown, AbpSession.GetTenantId()),
            //    ShowRules = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.WinProbability.Project.ShowRules, AbpSession.GetTenantId()),
            //    ProbabilityList = JsonConvert.DeserializeObject<List<ProbabilityListEditDto>>(prjProbabilites),
            //},
            //SW = new WinProbabilityEditDto
            //{
            //    DropDown = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.WinProbability.SW.DropDown, AbpSession.GetTenantId()),
            //    ShowRules = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.WinProbability.SW.ShowRules, AbpSession.GetTenantId()),
            //    ProbabilityList = JsonConvert.DeserializeObject<List<ProbabilityListEditDto>>(swProbabilites),
            //},
            //TAndM = new WinProbabilityEditDto
            //{
            //    DropDown = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.WinProbability.TAndM.DropDown, AbpSession.GetTenantId()),
            //    ShowRules = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.WinProbability.TAndM.ShowRules, AbpSession.GetTenantId()),
            //    ProbabilityList = JsonConvert.DeserializeObject<List<ProbabilityListEditDto>>(tmProbabilites),
            //},
            //SAndM = new WinProbabilityEditDto
            //{
            //    DropDown = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.WinProbability.SAndM.DropDown, AbpSession.GetTenantId()),
            //    ShowRules = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.WinProbability.SAndM.ShowRules, AbpSession.GetTenantId()),
            //    ProbabilityList = JsonConvert.DeserializeObject<List<ProbabilityListEditDto>>(smProbabilites),
            //}
            //};
        }

        private async Task<object> GetPPMSettings()
        {
            var ppmSettings = await SettingManager.GetSettingValueForTenantAsync(AppSettings.PPM.PPMJson, AbpSession.GetTenantId());
            return ppmSettings;
        }
        private async Task<object> GetSalesToOpsHandoverSettings()
        {
            var doclist = await SettingManager.GetSettingValueForTenantAsync(AppSettings.SalesToOpsHandover.DocListJson, AbpSession.GetTenantId());
            if (doclist == null)
            {
                return null;
            }
            var ProjectSalesToOpsHand = JsonConvert.DeserializeObject(doclist);
            return ProjectSalesToOpsHand;
        }

        //End of Custom Settings
        private async Task<LdapSettingsEditDto> GetLdapSettingsAsync()
        {
            return new LdapSettingsEditDto
            {
                IsModuleEnabled = true,
                IsEnabled = await SettingManager.GetSettingValueForTenantAsync<bool>(LdapSettingNames.IsEnabled, AbpSession.GetTenantId()),
                Domain = await SettingManager.GetSettingValueForTenantAsync(LdapSettingNames.Domain, AbpSession.GetTenantId()),
                UserName = await SettingManager.GetSettingValueForTenantAsync(LdapSettingNames.UserName, AbpSession.GetTenantId()),
                Password = await SettingManager.GetSettingValueForTenantAsync(LdapSettingNames.Password, AbpSession.GetTenantId()),
            };
        }

        private async Task<TenantEmailSettingsEditDto> GetEmailSettingsAsync()
        {
            var useHostDefaultEmailSettings = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.Email.UseHostDefaultEmailSettings, AbpSession.GetTenantId());

            if (useHostDefaultEmailSettings)
            {
                return new TenantEmailSettingsEditDto
                {
                    UseHostDefaultEmailSettings = true
                };
            }

            var smtpPassword = await SettingManager.GetSettingValueForTenantAsync(EmailSettingNames.Smtp.Password, AbpSession.GetTenantId());

            return new TenantEmailSettingsEditDto
            {
                UseHostDefaultEmailSettings = false,
                DefaultFromAddress = await SettingManager.GetSettingValueForTenantAsync(EmailSettingNames.DefaultFromAddress, AbpSession.GetTenantId()),
                DefaultFromDisplayName = await SettingManager.GetSettingValueForTenantAsync(EmailSettingNames.DefaultFromDisplayName, AbpSession.GetTenantId()),
                SmtpHost = await SettingManager.GetSettingValueForTenantAsync(EmailSettingNames.Smtp.Host, AbpSession.GetTenantId()),
                SmtpPort = await SettingManager.GetSettingValueForTenantAsync<int>(EmailSettingNames.Smtp.Port, AbpSession.GetTenantId()),
                SmtpUserName = await SettingManager.GetSettingValueForTenantAsync(EmailSettingNames.Smtp.UserName, AbpSession.GetTenantId()),
                SmtpPassword = SimpleStringCipher.Instance.Decrypt(smtpPassword),
                SmtpDomain = await SettingManager.GetSettingValueForTenantAsync(EmailSettingNames.Smtp.Domain, AbpSession.GetTenantId()),
                SmtpEnableSsl = await SettingManager.GetSettingValueForTenantAsync<bool>(EmailSettingNames.Smtp.EnableSsl, AbpSession.GetTenantId()),
                SmtpUseDefaultCredentials = await SettingManager.GetSettingValueForTenantAsync<bool>(EmailSettingNames.Smtp.UseDefaultCredentials, AbpSession.GetTenantId())
            };
        }

        private async Task<GeneralSettingsEditDto> GetGeneralSettingsAsync()
        {
            var settings = new GeneralSettingsEditDto();

            if (Clock.SupportsMultipleTimezone)
            {
                var timezone = await SettingManager.GetSettingValueForTenantAsync(TimingSettingNames.TimeZone, AbpSession.GetTenantId());

                settings.Timezone = timezone;
                settings.TimezoneForComparison = timezone;
            }

            var defaultTimeZoneId = await _timeZoneService.GetDefaultTimezoneAsync(SettingScopes.Tenant, AbpSession.TenantId);

            if (settings.Timezone == defaultTimeZoneId)
            {
                settings.Timezone = string.Empty;
            }

            return settings;
        }

        private async Task<TenantUserManagementSettingsEditDto> GetUserManagementSettingsAsync()
        {
            return new TenantUserManagementSettingsEditDto
            {
                AllowSelfRegistration = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.AllowSelfRegistration),
                IsNewRegisteredUserActiveByDefault = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.IsNewRegisteredUserActiveByDefault),
                IsEmailConfirmationRequiredForLogin = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.IsEmailConfirmationRequiredForLogin),
                UseCaptchaOnRegistration = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.UseCaptchaOnRegistration),
                UseCaptchaOnLogin = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.UseCaptchaOnLogin),
                IsCookieConsentEnabled = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.IsCookieConsentEnabled),
                IsQuickThemeSelectEnabled = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.IsQuickThemeSelectEnabled),
                AllowUsingGravatarProfilePicture = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.AllowUsingGravatarProfilePicture),
                SessionTimeOutSettings = new SessionTimeOutSettingsEditDto()
                {
                    IsEnabled = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.SessionTimeOut.IsEnabled),
                    TimeOutSecond = await SettingManager.GetSettingValueAsync<int>(AppSettings.UserManagement.SessionTimeOut.TimeOutSecond),
                    ShowTimeOutNotificationSecond = await SettingManager.GetSettingValueAsync<int>(AppSettings.UserManagement.SessionTimeOut.ShowTimeOutNotificationSecond),
                    ShowLockScreenWhenTimedOut = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.SessionTimeOut.ShowLockScreenWhenTimedOut)
                }
            };
        }

        private async Task<SecuritySettingsEditDto> GetSecuritySettingsAsync()
        {
            var passwordComplexitySetting = new PasswordComplexitySetting
            {
                RequireDigit = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireDigit),
                RequireLowercase = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireLowercase),
                RequireNonAlphanumeric = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireNonAlphanumeric),
                RequireUppercase = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireUppercase),
                RequiredLength = await SettingManager.GetSettingValueAsync<int>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequiredLength)
            };

            var defaultPasswordComplexitySetting = new PasswordComplexitySetting
            {
                RequireDigit = await SettingManager.GetSettingValueForApplicationAsync<bool>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireDigit),
                RequireLowercase = await SettingManager.GetSettingValueForApplicationAsync<bool>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireLowercase),
                RequireNonAlphanumeric = await SettingManager.GetSettingValueForApplicationAsync<bool>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireNonAlphanumeric),
                RequireUppercase = await SettingManager.GetSettingValueForApplicationAsync<bool>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireUppercase),
                RequiredLength = await SettingManager.GetSettingValueForApplicationAsync<int>(AbpZeroSettingNames.UserManagement.PasswordComplexity.RequiredLength)
            };

            return new SecuritySettingsEditDto
            {
                UseDefaultPasswordComplexitySettings = passwordComplexitySetting.Equals(defaultPasswordComplexitySetting),
                PasswordComplexity = passwordComplexitySetting,
                DefaultPasswordComplexity = defaultPasswordComplexitySetting,
                UserLockOut = await GetUserLockOutSettingsAsync(),
                TwoFactorLogin = await GetTwoFactorLoginSettingsAsync(),
                AllowOneConcurrentLoginPerUser = await GetOneConcurrentLoginPerUserSetting()
            };
        }

        private async Task<TenantBillingSettingsEditDto> GetBillingSettingsAsync()
        {
            return new TenantBillingSettingsEditDto()
            {
                LegalName = await SettingManager.GetSettingValueAsync(AppSettings.TenantManagement.BillingLegalName),
                Address = await SettingManager.GetSettingValueAsync(AppSettings.TenantManagement.BillingAddress),
                TaxVatNo = await SettingManager.GetSettingValueAsync(AppSettings.TenantManagement.BillingTaxVatNo)
            };
        }

        private async Task<TenantOtherSettingsEditDto> GetOtherSettingsAsync()
        {
            return new TenantOtherSettingsEditDto()
            {
                IsQuickThemeSelectEnabled = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.IsQuickThemeSelectEnabled)
            };
        }

        private async Task<UserLockOutSettingsEditDto> GetUserLockOutSettingsAsync()
        {
            return new UserLockOutSettingsEditDto
            {
                IsEnabled = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.UserLockOut.IsEnabled),
                MaxFailedAccessAttemptsBeforeLockout = await SettingManager.GetSettingValueAsync<int>(AbpZeroSettingNames.UserManagement.UserLockOut.MaxFailedAccessAttemptsBeforeLockout),
                DefaultAccountLockoutSeconds = await SettingManager.GetSettingValueAsync<int>(AbpZeroSettingNames.UserManagement.UserLockOut.DefaultAccountLockoutSeconds)
            };
        }

        private Task<bool> IsTwoFactorLoginEnabledForApplicationAsync()
        {
            return SettingManager.GetSettingValueForApplicationAsync<bool>(AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsEnabled);
        }

        private async Task<TwoFactorLoginSettingsEditDto> GetTwoFactorLoginSettingsAsync()
        {
            var settings = new TwoFactorLoginSettingsEditDto
            {
                IsEnabledForApplication = await IsTwoFactorLoginEnabledForApplicationAsync()
            };

            if (_multiTenancyConfig.IsEnabled && !settings.IsEnabledForApplication)
            {
                return settings;
            }

            settings.IsEnabled = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsEnabled);
            settings.IsRememberBrowserEnabled = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsRememberBrowserEnabled);

            if (!_multiTenancyConfig.IsEnabled)
            {
                settings.IsEmailProviderEnabled = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsEmailProviderEnabled);
                settings.IsSmsProviderEnabled = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsSmsProviderEnabled);
                settings.IsGoogleAuthenticatorEnabled = await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.TwoFactorLogin.IsGoogleAuthenticatorEnabled);
            }

            return settings;
        }

        private async Task<bool> GetOneConcurrentLoginPerUserSetting()
        {
            return await SettingManager.GetSettingValueAsync<bool>(AppSettings.UserManagement.AllowOneConcurrentLoginPerUser);
        }

        private async Task<ExternalLoginProviderSettingsEditDto> GetExternalLoginProviderSettings()
        {
            var facebookSettings = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ExternalLoginProvider.Tenant.Facebook, AbpSession.GetTenantId());
            var googleSettings = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ExternalLoginProvider.Tenant.Google, AbpSession.GetTenantId());
            var twitterSettings = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ExternalLoginProvider.Tenant.Twitter, AbpSession.GetTenantId());
            var microsoftSettings = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ExternalLoginProvider.Tenant.Microsoft, AbpSession.GetTenantId());

            var openIdConnectSettings = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ExternalLoginProvider.Tenant.OpenIdConnect, AbpSession.GetTenantId());
            var openIdConnectMappedClaims = await SettingManager.GetSettingValueAsync(AppSettings.ExternalLoginProvider.OpenIdConnectMappedClaims);

            var wsFederationSettings = await SettingManager.GetSettingValueForTenantAsync(AppSettings.ExternalLoginProvider.Tenant.WsFederation, AbpSession.GetTenantId());
            var wsFederationMappedClaims = await SettingManager.GetSettingValueAsync(AppSettings.ExternalLoginProvider.WsFederationMappedClaims);

            return new ExternalLoginProviderSettingsEditDto
            {
                Facebook_IsDeactivated = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.ExternalLoginProvider.Tenant.Facebook_IsDeactivated, AbpSession.GetTenantId()),
                Facebook = facebookSettings.IsNullOrWhiteSpace()
                    ? new FacebookExternalLoginProviderSettings()
                    : facebookSettings.FromJsonString<FacebookExternalLoginProviderSettings>(),

                Google_IsDeactivated = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.ExternalLoginProvider.Tenant.Google_IsDeactivated, AbpSession.GetTenantId()),
                Google = googleSettings.IsNullOrWhiteSpace()
                    ? new GoogleExternalLoginProviderSettings()
                    : googleSettings.FromJsonString<GoogleExternalLoginProviderSettings>(),

                Twitter_IsDeactivated = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.ExternalLoginProvider.Tenant.Twitter_IsDeactivated, AbpSession.GetTenantId()),
                Twitter = twitterSettings.IsNullOrWhiteSpace()
                    ? new TwitterExternalLoginProviderSettings()
                    : twitterSettings.FromJsonString<TwitterExternalLoginProviderSettings>(),

                Microsoft_IsDeactivated = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.ExternalLoginProvider.Tenant.Microsoft_IsDeactivated, AbpSession.GetTenantId()),
                Microsoft = microsoftSettings.IsNullOrWhiteSpace()
                    ? new MicrosoftExternalLoginProviderSettings()
                    : microsoftSettings.FromJsonString<MicrosoftExternalLoginProviderSettings>(),

                OpenIdConnect_IsDeactivated = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.ExternalLoginProvider.Tenant.OpenIdConnect_IsDeactivated, AbpSession.GetTenantId()),
                OpenIdConnect = openIdConnectSettings.IsNullOrWhiteSpace()
                    ? new OpenIdConnectExternalLoginProviderSettings()
                    : openIdConnectSettings.FromJsonString<OpenIdConnectExternalLoginProviderSettings>(),
                OpenIdConnectClaimsMapping = openIdConnectMappedClaims.IsNullOrWhiteSpace()
                    ? new List<JsonClaimMapDto>()
                    : openIdConnectMappedClaims.FromJsonString<List<JsonClaimMapDto>>(),

                WsFederation_IsDeactivated = await SettingManager.GetSettingValueForTenantAsync<bool>(AppSettings.ExternalLoginProvider.Tenant.WsFederation_IsDeactivated, AbpSession.GetTenantId()),
                WsFederation = wsFederationSettings.IsNullOrWhiteSpace()
                    ? new WsFederationExternalLoginProviderSettings()
                    : wsFederationSettings.FromJsonString<WsFederationExternalLoginProviderSettings>(),
                WsFederationClaimsMapping = wsFederationMappedClaims.IsNullOrWhiteSpace()
                    ? new List<JsonClaimMapDto>()
                    : wsFederationMappedClaims.FromJsonString<List<JsonClaimMapDto>>()
            };
        }

        private async Task<NotificationTemplateSettingsDto> GetEmailNotficationTempalte()
        {
            NotificationTemplateSettingsDto notificationTemplateSettingsDto = new NotificationTemplateSettingsDto();
            try
            {
                var tenantId = AbpSession.TenantId.Value;
                var notificationTemplateDto = await _notificationTemplateAppService.GetNotificationTemplteForTenant(tenantId);
                if (notificationTemplateDto != null)
                {
                    notificationTemplateSettingsDto.Body = notificationTemplateDto.EmailBody;
                    notificationTemplateSettingsDto.TenantId = notificationTemplateDto.TenantId;
                }
            }
            catch (System.Exception ex)
            {
            }


            return notificationTemplateSettingsDto;
        }

        #endregion

        #region Update Settings

        public async Task UpdateAllSettings(TenantSettingsEditDto input)
        {
            await UpdateUserManagementSettingsAsync(input.UserManagement);
            await UpdateSecuritySettingsAsync(input.Security);
            await UpdateBillingSettingsAsync(input.Billing);
            await UpdateEmailSettingsAsync(input.Email);
            await UpdateExternalLoginSettingsAsync(input.ExternalLoginProviderSettings);
            await UpdateCustomerSettingsAsync(input.CustomerSettings);
            await UpdatePaymentSettingsAsync(input.PaymentSettings);
            await UpdatePromptsAndAlertsSettingsAsync(input.PromptsAndAlertsSettings);
            await UpdateTaskDelegationSettingsAsync(input.TaskDelegationSettings);
            await UpdateTaskSettingsAsync(input.TaskSettings);
            await UpdateDashboardBusinessRulesSettingsAsync(input.DashboardBusinessRulesSettings);
            await UpdateReportGenIntervalSettingsAsync(input.ReportGenIntervalSettings);
            await UpdateWinProbabilitySettingsAsync(input.WinProbabilitySettings);
            await UpdateWorkFlowProjectSettingAsync(input.WorkFlowSettings);
            await UpdatePPMSettingsAsync(input.PPMSettings);
            await UpdateNotificationTemplateForTenant(new NotificationTemplateDto { EmailBody = input.NotificationTemplateSettings.Body, TenantId = input.NotificationTemplateSettings.TenantId });

            await UpdateCurrencySettingsAsync(input.Currency);
            await UpdateSalesToOpsHandoverSettingsAsync(input.SalesToOpsHandoverSettings);
            //Time Zone
            if (Clock.SupportsMultipleTimezone)
            {
                if (input.General.Timezone.IsNullOrEmpty())
                {
                    var defaultValue = await _timeZoneService.GetDefaultTimezoneAsync(SettingScopes.Tenant, AbpSession.TenantId);
                    await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), TimingSettingNames.TimeZone, defaultValue);
                }
                else
                {
                    await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), TimingSettingNames.TimeZone, input.General.Timezone);
                }
            }

            if (!_multiTenancyConfig.IsEnabled)
            {
                await UpdateOtherSettingsAsync(input.OtherSettings);

                input.ValidateHostSettings();
            }

            if (_ldapModuleConfig.IsEnabled)
            {
                await UpdateLdapSettingsAsync(input.Ldap);
            }
        }

        private async Task UpdateCurrencySettingsAsync(CurrencyDto settings)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(), AppSettings.Currency.CurrencyCode, settings.Currency);

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(), AppSettings.Currency.CurrencySign, settings.CurrencySign);
        }

        private async Task UpdateCustomerSettingsAsync(CustomerSettingsDto settings)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(), AppSettings.Customer.NewCustomerFlag, settings.NewCustomerFlag);
        }

        private async Task UpdatePaymentSettingsAsync(PaymentSettingsEditDto settings)
        {
            await UpdatePaymentApplicationSettingsAsync(settings.Application);
            await UpdatePaymentInvoiceSettingsAsync(settings.Invoice);
        }
        private async Task UpdatePaymentApplicationSettingsAsync(PaymentApplicationSettingsEditDto input)
        {

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(), AppSettings.Payment.Application.AutoPopulate, input.AutoPopulate.ToString());
            await SettingManager.ChangeSettingForTenantAsync(
                   AbpSession.GetTenantId(), AppSettings.Payment.Application.DueDate, input.DueDate.ToString());
            await SettingManager.ChangeSettingForTenantAsync(
                      AbpSession.GetTenantId(), AppSettings.Payment.Application.FinalDate, input.FinalDate.ToString());
            await SettingManager.ChangeSettingForTenantAsync(
                   AbpSession.GetTenantId(), AppSettings.Payment.Application.ValuedTo, input.ValuedTo);
            await SettingManager.ChangeSettingForTenantAsync(
                  AbpSession.GetTenantId(), AppSettings.Payment.Application.SubOnOrBefore, input.SubOnOrBefore);
            await SettingManager.ChangeSettingForTenantAsync(
                   AbpSession.GetTenantId(), AppSettings.Payment.Application.PayLessDueBy, input.PayLessDueBy.ToString());
            await SettingManager.ChangeSettingForTenantAsync(
                   AbpSession.GetTenantId(), AppSettings.Payment.Application.PmtDueBy, input.PmtDueBy.ToString());
            await SettingManager.ChangeSettingForTenantAsync(
                   AbpSession.GetTenantId(), AppSettings.Payment.Application.Suspend, input.Suspend.ToString());

            var applicationSettings = new PaymentApplicationSettingsEditDto
            {
                AutoPopulate = input.AutoPopulate,
                SubOnOrBefore = input.SubOnOrBefore,
                ValuedTo = input.ValuedTo,
                DueDate = input.DueDate,
                PmtDueBy = input.PmtDueBy,
                FinalDate = input.FinalDate,
                PayLessDueBy = input.PayLessDueBy,
                Suspend = input.Suspend
            };

            string json = JsonConvert.SerializeObject(applicationSettings);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.Payment.Application.ApplicationJson, json);
        }
        private async Task UpdatePaymentInvoiceSettingsAsync(PaymentInvoiceSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                        AbpSession.GetTenantId(), AppSettings.Payment.Invoice.AutoPopulate, input.AutoPopulate.ToString());
            await SettingManager.ChangeSettingForTenantAsync(
                    AbpSession.GetTenantId(), AppSettings.Payment.Invoice.Days, input.Days.ToString());
            await SettingManager.ChangeSettingForTenantAsync(
                    AbpSession.GetTenantId(), AppSettings.Payment.Invoice.Date, input.Date);
            await SettingManager.ChangeSettingForTenantAsync(
                    AbpSession.GetTenantId(), AppSettings.Payment.Invoice.Period, input.Period);

            var invoiceSettings = new PaymentInvoiceSettingsEditDto
            {
                AutoPopulate = input.AutoPopulate,
                Days = input.Days,
                Date = input.Date,
                Period = input.Period,
              
            };

            string json = JsonConvert.SerializeObject(invoiceSettings);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.Payment.Invoice.InvoiceJson, json);

        }
        private async Task UpdatePromptsAndAlertsSettingsAsync(PromptsAndAlertsSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.PromptsAndAlerts.Hours, settings.Hours.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.PromptsAndAlerts.Mins, settings.Mins.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.PromptsAndAlerts.Meridiem, settings.Meridiem);
        }
        private async Task UpdateTaskDelegationSettingsAsync(TaskDelegationSettingsEditDto settings)
        {

            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TaskDelegation.CommenceMail, settings.CommenceMail.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TaskDelegation.DelegateReview, settings.DelegateReview.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TaskDelegation.DelegateTask, settings.DelegateTask.ToString());

        }
        private async Task UpdateTaskSettingsAsync(TaskSettingsEditDto settings)
        {

            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TaskSetting.AutoAssign, settings.AutoAssign.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TaskSetting.DsgnAndEst, settings.DsgnAndEst.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TaskSetting.PermToApprove, settings.PermToApprove.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TaskSetting.ProjProgDiffQuotedApproval, settings.ProjProgDiffQuotedApproval.ToString());

        }
        private async Task UpdateDashboardBusinessRulesSettingsAsync(DashboardBusinessRulesSettingsEditDto settings)
        {

            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.BusinessRules.Project.Red, settings.Project.RedDays.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.BusinessRules.Project.Amber, settings.Project.AmberDays.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.BusinessRules.SW.Red, settings.SW.RedDays.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.BusinessRules.SW.Amber, settings.SW.RedDays.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.BusinessRules.TAndM.Red, settings.TAndM.RedDays.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.BusinessRules.TAndM.Amber, settings.TAndM.RedDays.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.BusinessRules.SAndM.Red, settings.SAndM.RedDays.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.BusinessRules.SAndM.Amber, settings.SAndM.RedDays.ToString());
        }
        private async Task UpdateReportGenIntervalSettingsAsync(ReportGenerationIntervalSettingsEditDto settings)
        {

            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.Monthly, settings.Monthly.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.Weekly, settings.Weekly.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.RecurDate, settings.RecurDate.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.RecurDateMonthly, settings.RecurDateMonthly.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.RecurDay, settings.RecurDay);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.RecurDayMonthly, settings.RecurDayMonthly.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.RecurDaySeq, settings.RecurDaySeq);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.RecurWeekly, settings.RecurWeekly.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.ReportGenInterval.RecurWeeklyDay, settings.RecurWeeklyDay.ToString());


        }

        private async Task UpdateWorkFlowProjectSettingAsync(WorkFlowSettingDto workFlowSettingDto)
        {
            if (workFlowSettingDto.PRJ != null)
            {
                workFlowSettingDto.PRJ = workFlowSettingDto.PRJ.ToString().Replace("\n", "").Replace(@"\", "");
            }
            if (workFlowSettingDto.SWK != null)
            {
                workFlowSettingDto.SWK = workFlowSettingDto.SWK.ToString().Replace("\n", "").Replace(@"\", "");
            }
            if (workFlowSettingDto.PPM != null)
            {
                workFlowSettingDto.PPM = workFlowSettingDto.PPM.ToString().Replace("\n", "").Replace(@"\", "");
            }
            if (workFlowSettingDto.TandM != null)
            {
                workFlowSettingDto.TandM = workFlowSettingDto.TandM.ToString().Replace("\n", "").Replace(@"\", "");
            }
            if (workFlowSettingDto.CALL != null)
            {
                workFlowSettingDto.CALL = workFlowSettingDto.CALL.ToString().Replace("\n", "").Replace(@"\", "");
            }
            try
            {
                await SettingManager.ChangeSettingForTenantAsync(
                        AbpSession.GetTenantId(),
                        AppSettings.WorkflowCore.PRJ,
                        JsonConvert.SerializeObject(workFlowSettingDto.PRJ)
                    );
                await SettingManager.ChangeSettingForTenantAsync(
                        AbpSession.GetTenantId(),
                        AppSettings.WorkflowCore.SWK,
                        JsonConvert.SerializeObject(workFlowSettingDto.SWK)
                    );
                await SettingManager.ChangeSettingForTenantAsync(
                        AbpSession.GetTenantId(),
                        AppSettings.WorkflowCore.PPM,
                        JsonConvert.SerializeObject(workFlowSettingDto.PPM)
                    );
                await SettingManager.ChangeSettingForTenantAsync(
                        AbpSession.GetTenantId(),
                        AppSettings.WorkflowCore.TandM,
                        JsonConvert.SerializeObject(workFlowSettingDto.TandM)
                    );
                await SettingManager.ChangeSettingForTenantAsync(
                        AbpSession.GetTenantId(),
                        AppSettings.WorkflowCore.CALL,
                        JsonConvert.SerializeObject(workFlowSettingDto.CALL)
                    );
            }
            catch (System.Exception e)
            {

                throw;
            }
        }

        private async Task UpdateNotificationTemplateForTenant(NotificationTemplateDto settings)
        {
            if (settings != null && settings.TenantId != null && !string.IsNullOrEmpty(settings.EmailBody))
            {
                await _notificationTemplateAppService.CreateOrUpdate(settings);
            }
        }

        private async Task UpdateWinProbabilitySettingsAsync(object settings)
        {
            //string prjProbjson = JsonConvert.SerializeObject(settings.Project.ProbabilityList);
            //string swProbjson = JsonConvert.SerializeObject(settings.SW.ProbabilityList);
            //string tmProbjson = JsonConvert.SerializeObject(settings.TAndM.ProbabilityList);
            //string smProbjson = JsonConvert.SerializeObject(settings.SAndM.ProbabilityList);

            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.Project.DropDown,
            //    settings.Project.DropDown.ToString()
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.Project.ShowRules,
            //    settings.Project.ShowRules.ToString()
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.Project.Probabilities,
            //    prjProbjson
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.SW.DropDown,
            //    settings.SW.DropDown.ToString()
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.SW.ShowRules,
            //    settings.SW.ShowRules.ToString()
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.SW.Probabilities,
            //    swProbjson
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.TAndM.DropDown,
            //    settings.TAndM.DropDown.ToString()
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.TAndM.ShowRules,
            //    settings.TAndM.ShowRules.ToString()
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.TAndM.Probabilities,
            //    tmProbjson
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.SAndM.DropDown,
            //    settings.SAndM.DropDown.ToString()
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.SAndM.ShowRules,
            //    settings.SAndM.ShowRules.ToString()
            //);
            //await SettingManager.ChangeSettingForTenantAsync(
            //    AbpSession.GetTenantId(),
            //    AppSettings.WinProbability.SAndM.Probabilities,
            //    smProbjson
            //);
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.WinProbability.WinProbabilityJson,
                JsonConvert.SerializeObject(settings)
            );
        }
        private async Task UpdatePPMSettingsAsync(object ppmSettings)
        {
            //var settings = ppmSettings.ToString().Replace("\n", "").Replace(@"\", "");

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.PPM.PPMJson,
                JsonConvert.SerializeObject(ppmSettings)
            );
        }
        private async Task UpdateSalesToOpsHandoverSettingsAsync(object settings)
        {
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(),
                AppSettings.SalesToOpsHandover.DocListJson,
                JsonConvert.SerializeObject(settings)
            );
        }

        private async Task UpdateOtherSettingsAsync(TenantOtherSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.IsQuickThemeSelectEnabled,
                input.IsQuickThemeSelectEnabled.ToString().ToLowerInvariant()
            );
        }

        private async Task UpdateBillingSettingsAsync(TenantBillingSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TenantManagement.BillingLegalName, input.LegalName);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TenantManagement.BillingAddress, input.Address);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.TenantManagement.BillingTaxVatNo, input.TaxVatNo);
        }

        private async Task UpdateLdapSettingsAsync(LdapSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), LdapSettingNames.IsEnabled, input.IsEnabled.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), LdapSettingNames.Domain, input.Domain.IsNullOrWhiteSpace() ? null : input.Domain);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), LdapSettingNames.UserName, input.UserName.IsNullOrWhiteSpace() ? null : input.UserName);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), LdapSettingNames.Password, input.Password.IsNullOrWhiteSpace() ? null : input.Password);
        }

        private async Task UpdateEmailSettingsAsync(TenantEmailSettingsEditDto input)
        {
            if (_multiTenancyConfig.IsEnabled && !econsysConsts.AllowTenantsToChangeEmailSettings)
            {
                return;
            }

            var useHostDefaultEmailSettings = _multiTenancyConfig.IsEnabled && input.UseHostDefaultEmailSettings;

            if (useHostDefaultEmailSettings)
            {
                var smtpPassword = await SettingManager.GetSettingValueForApplicationAsync(EmailSettingNames.Smtp.Password);

                input = new TenantEmailSettingsEditDto
                {
                    UseHostDefaultEmailSettings = true,
                    DefaultFromAddress = await SettingManager.GetSettingValueForApplicationAsync(EmailSettingNames.DefaultFromAddress),
                    DefaultFromDisplayName = await SettingManager.GetSettingValueForApplicationAsync(EmailSettingNames.DefaultFromDisplayName),
                    SmtpHost = await SettingManager.GetSettingValueForApplicationAsync(EmailSettingNames.Smtp.Host),
                    SmtpPort = await SettingManager.GetSettingValueForApplicationAsync<int>(EmailSettingNames.Smtp.Port),
                    SmtpUserName = await SettingManager.GetSettingValueForApplicationAsync(EmailSettingNames.Smtp.UserName),
                    SmtpPassword = SimpleStringCipher.Instance.Decrypt(smtpPassword),
                    SmtpDomain = await SettingManager.GetSettingValueForApplicationAsync(EmailSettingNames.Smtp.Domain),
                    SmtpEnableSsl = await SettingManager.GetSettingValueForApplicationAsync<bool>(EmailSettingNames.Smtp.EnableSsl),
                    SmtpUseDefaultCredentials = await SettingManager.GetSettingValueForApplicationAsync<bool>(EmailSettingNames.Smtp.UseDefaultCredentials)
                };
            }

            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.Email.UseHostDefaultEmailSettings, useHostDefaultEmailSettings.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.DefaultFromAddress, input.DefaultFromAddress);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.DefaultFromDisplayName, input.DefaultFromDisplayName);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.Smtp.Host, input.SmtpHost);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.Smtp.Port, input.SmtpPort.ToString(CultureInfo.InvariantCulture));
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.Smtp.UserName, input.SmtpUserName);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.Smtp.Password, SimpleStringCipher.Instance.Encrypt(input.SmtpPassword));
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.Smtp.Domain, input.SmtpDomain);
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.Smtp.EnableSsl, input.SmtpEnableSsl.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), EmailSettingNames.Smtp.UseDefaultCredentials, input.SmtpUseDefaultCredentials.ToString().ToLowerInvariant());
        }

        private async Task UpdateUserManagementSettingsAsync(TenantUserManagementSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.AllowSelfRegistration,
                settings.AllowSelfRegistration.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.IsNewRegisteredUserActiveByDefault,
                settings.IsNewRegisteredUserActiveByDefault.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AbpZeroSettingNames.UserManagement.IsEmailConfirmationRequiredForLogin,
                settings.IsEmailConfirmationRequiredForLogin.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.UseCaptchaOnRegistration,
                settings.UseCaptchaOnRegistration.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.UseCaptchaOnLogin,
                settings.UseCaptchaOnLogin.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.IsCookieConsentEnabled,
                settings.IsCookieConsentEnabled.ToString().ToLowerInvariant()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.AllowUsingGravatarProfilePicture,
                settings.AllowUsingGravatarProfilePicture.ToString().ToLowerInvariant()
            );

            await UpdateUserManagementSessionTimeOutSettingsAsync(settings.SessionTimeOutSettings);
        }

        private async Task UpdateUserManagementSessionTimeOutSettingsAsync(SessionTimeOutSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.SessionTimeOut.IsEnabled,
                settings.IsEnabled.ToString().ToLowerInvariant()
            );
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.SessionTimeOut.TimeOutSecond,
                settings.TimeOutSecond.ToString()
            );
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.SessionTimeOut.ShowTimeOutNotificationSecond,
                settings.ShowTimeOutNotificationSecond.ToString()
            );
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.UserManagement.SessionTimeOut.ShowLockScreenWhenTimedOut,
                settings.ShowLockScreenWhenTimedOut.ToString()
            );
        }

        private async Task UpdateSecuritySettingsAsync(SecuritySettingsEditDto settings)
        {
            if (settings.UseDefaultPasswordComplexitySettings)
            {
                await UpdatePasswordComplexitySettingsAsync(settings.DefaultPasswordComplexity);
            }
            else
            {
                await UpdatePasswordComplexitySettingsAsync(settings.PasswordComplexity);
            }

            await UpdateUserLockOutSettingsAsync(settings.UserLockOut);
            await UpdateTwoFactorLoginSettingsAsync(settings.TwoFactorLogin);
            await UpdateOneConcurrentLoginPerUserSettingAsync(settings.AllowOneConcurrentLoginPerUser);
        }

        private async Task UpdatePasswordComplexitySettingsAsync(PasswordComplexitySetting settings)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireDigit,
                settings.RequireDigit.ToString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireLowercase,
                settings.RequireLowercase.ToString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireNonAlphanumeric,
                settings.RequireNonAlphanumeric.ToString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequireUppercase,
                settings.RequireUppercase.ToString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AbpZeroSettingNames.UserManagement.PasswordComplexity.RequiredLength,
                settings.RequiredLength.ToString()
            );
        }

        private async Task UpdateUserLockOutSettingsAsync(UserLockOutSettingsEditDto settings)
        {
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AbpZeroSettingNames.UserManagement.UserLockOut.IsEnabled, settings.IsEnabled.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AbpZeroSettingNames.UserManagement.UserLockOut.DefaultAccountLockoutSeconds, settings.DefaultAccountLockoutSeconds.ToString());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AbpZeroSettingNames.UserManagement.UserLockOut.MaxFailedAccessAttemptsBeforeLockout, settings.MaxFailedAccessAttemptsBeforeLockout.ToString());
        }

        private async Task UpdateTwoFactorLoginSettingsAsync(TwoFactorLoginSettingsEditDto settings)
        {
            if (_multiTenancyConfig.IsEnabled &&
                !await IsTwoFactorLoginEnabledForApplicationAsync()) //Two factor login can not be used by tenants if disabled by the host
            {
                return;
            }

            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsEnabled, settings.IsEnabled.ToString().ToLowerInvariant());
            await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsRememberBrowserEnabled, settings.IsRememberBrowserEnabled.ToString().ToLowerInvariant());

            if (!_multiTenancyConfig.IsEnabled)
            {
                //These settings can only be changed by host, in a multitenant application.
                await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsEmailProviderEnabled, settings.IsEmailProviderEnabled.ToString().ToLowerInvariant());
                await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsSmsProviderEnabled, settings.IsSmsProviderEnabled.ToString().ToLowerInvariant());
                await SettingManager.ChangeSettingForTenantAsync(AbpSession.GetTenantId(), AppSettings.UserManagement.TwoFactorLogin.IsGoogleAuthenticatorEnabled, settings.IsGoogleAuthenticatorEnabled.ToString().ToLowerInvariant());
            }
        }

        private async Task UpdateOneConcurrentLoginPerUserSettingAsync(bool allowOneConcurrentLoginPerUser)
        {
            if (_multiTenancyConfig.IsEnabled)
            {
                return;
            }
            await SettingManager.ChangeSettingForApplicationAsync(AppSettings.UserManagement.AllowOneConcurrentLoginPerUser, allowOneConcurrentLoginPerUser.ToString());
        }

        private async Task UpdateExternalLoginSettingsAsync(ExternalLoginProviderSettingsEditDto input)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.Facebook,
                input.Facebook == null || !input.Facebook.IsValid() ? "" : input.Facebook.ToJsonString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.Facebook_IsDeactivated,
                input.Facebook_IsDeactivated.ToString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.Google,
                input.Google == null || !input.Google.IsValid() ? "" : input.Google.ToJsonString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.Google_IsDeactivated,
                input.Google_IsDeactivated.ToString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.Twitter,
                input.Twitter == null || !input.Twitter.IsValid() ? "" : input.Twitter.ToJsonString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.Twitter_IsDeactivated,
                input.Twitter_IsDeactivated.ToString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.Microsoft,
                input.Microsoft == null || !input.Microsoft.IsValid() ? "" : input.Microsoft.ToJsonString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.Microsoft_IsDeactivated,
                input.Microsoft_IsDeactivated.ToString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.OpenIdConnect,
                input.OpenIdConnect == null || !input.OpenIdConnect.IsValid() ? "" : input.OpenIdConnect.ToJsonString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.OpenIdConnect_IsDeactivated,
                input.OpenIdConnect_IsDeactivated.ToString()
            );

            var openIdConnectMappedClaimsValue = "";
            if (input.OpenIdConnect == null || !input.OpenIdConnect.IsValid() || input.OpenIdConnectClaimsMapping.IsNullOrEmpty())
            {
                openIdConnectMappedClaimsValue = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider.OpenIdConnectMappedClaims);//set default value
            }
            else
            {
                openIdConnectMappedClaimsValue = input.OpenIdConnectClaimsMapping.ToJsonString();
            }

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.OpenIdConnectMappedClaims,
                openIdConnectMappedClaimsValue
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.WsFederation,
                input.WsFederation == null || !input.WsFederation.IsValid() ? "" : input.WsFederation.ToJsonString()
            );

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.Tenant.WsFederation_IsDeactivated,
                input.WsFederation_IsDeactivated.ToString()
            );

            var wsFederationMappedClaimsValue = "";
            if (input.WsFederation == null || !input.WsFederation.IsValid() || input.WsFederationClaimsMapping.IsNullOrEmpty())
            {
                wsFederationMappedClaimsValue = await SettingManager.GetSettingValueForApplicationAsync(AppSettings.ExternalLoginProvider.WsFederationMappedClaims);//set default value
            }
            else
            {
                wsFederationMappedClaimsValue = input.WsFederationClaimsMapping.ToJsonString();
            }

            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(),
                AppSettings.ExternalLoginProvider.WsFederationMappedClaims,
                wsFederationMappedClaimsValue
            );

            ExternalLoginOptionsCacheManager.ClearCache();
        }

        private async Task UpdateGridSettingsAsync(string input)
        {
            await SettingManager.ChangeSettingForTenantAsync(
                AbpSession.GetTenantId(), AppSettings.Grid.Settings, input);
        }

        #endregion

        #region Others

        public async Task ClearLogo()
        {
            var tenant = await GetCurrentTenantAsync();

            if (!tenant.HasLogo())
            {
                return;
            }

            var logoObject = await _binaryObjectManager.GetOrNullAsync(tenant.LogoId.Value);
            if (logoObject != null)
            {
                await _binaryObjectManager.DeleteAsync(tenant.LogoId.Value);
            }

            tenant.ClearLogo();
        }

        public async Task ClearCustomCss()
        {
            var tenant = await GetCurrentTenantAsync();

            if (!tenant.CustomCssId.HasValue)
            {
                return;
            }

            var cssObject = await _binaryObjectManager.GetOrNullAsync(tenant.CustomCssId.Value);
            if (cssObject != null)
            {
                await _binaryObjectManager.DeleteAsync(tenant.CustomCssId.Value);
            }

            tenant.CustomCssId = null;
        }

        #endregion

        #region Default Interval Settings

        /// <summary>
        /// Gets the default repeat interval settings.
        /// </summary>
        /// <returns>
        /// Default repeat interval
        /// </returns>
        public async Task<ReportGenerationIntervalSettingsEditDto> GetDefaultRepeatInterval()
        {
            return await GetReportGenIntervalSettings();
        }
        #endregion
    }
}
