﻿using asq.econsys.Eco.SiteRefConfig.Dtos;
using asq.econsys.Eco.SiteRefConfig;
using asq.econsys.Eco.GuidanceNotes.Dtos;
using asq.econsys.Eco.GuidanceNotes;
using asq.econsys.Eco;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Eco.BusinessRules;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Eco.Projects;
using asq.econsys.Eco.Leads.Dtos;
using asq.econsys.Eco.Leads;
using asq.econsys.Flexi.Dtos;
using asq.econsys.Flexi;
using asq.econsys.Eco.Customers.Dtos;
using asq.econsys.Eco.Customers;
using asq.econsys.Eco.NodeMailConfig.Dtos;
using asq.econsys.Eco.NodeMailConfig;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Eco.NodeTasks;
using asq.econsys.Eco.RefNoConfig.Dtos;
using asq.econsys.Eco.RefNoConfig;
using asq.econsys.Eco.GridMaster.Dtos;
using asq.econsys.Eco.GridMaster;
using Abp.Application.Editions;
using Abp.Application.Features;
using Abp.Auditing;
using Abp.Authorization;
using Abp.Authorization.Users;
using Abp.DynamicEntityProperties;
using Abp.EntityHistory;
using Abp.Localization;
using Abp.Notifications;
using Abp.Organizations;
using Abp.UI.Inputs;
using Abp.Webhooks;
using AutoMapper;
using IdentityServer4.Extensions;
using asq.econsys.Auditing.Dto;
using asq.econsys.Authorization.Accounts.Dto;
using asq.econsys.Authorization.Delegation;
using asq.econsys.Authorization.Permissions.Dto;
using asq.econsys.Authorization.Roles;
using asq.econsys.Authorization.Roles.Dto;
using asq.econsys.Authorization.Users;
using asq.econsys.Authorization.Users.Delegation.Dto;
using asq.econsys.Authorization.Users.Dto;
using asq.econsys.Authorization.Users.Importing.Dto;
using asq.econsys.Authorization.Users.Profile.Dto;
using asq.econsys.Chat;
using asq.econsys.Chat.Dto;
using asq.econsys.DynamicEntityProperties.Dto;
using asq.econsys.Editions;
using asq.econsys.Editions.Dto;
using asq.econsys.Friendships;
using asq.econsys.Friendships.Cache;
using asq.econsys.Friendships.Dto;
using asq.econsys.Localization.Dto;
using asq.econsys.MultiTenancy;
using asq.econsys.MultiTenancy.Dto;
using asq.econsys.MultiTenancy.HostDashboard.Dto;
using asq.econsys.MultiTenancy.Payments;
using asq.econsys.MultiTenancy.Payments.Dto;
using asq.econsys.Notifications.Dto;
using asq.econsys.Organizations.Dto;
using asq.econsys.Sessions.Dto;
using asq.econsys.WebHooks.Dto;
using asq.econsys.Eco.Dto;

namespace asq.econsys
{
    internal static class CustomDtoMapper
    {
        public static void CreateMappings(IMapperConfigurationExpression configuration)
        {
            configuration.CreateMap<ProjectPaymentCycleTermDto, ProjectPaymentCycleTerm>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectPaymentCycleTermDto, ProjectPaymentCycleTerm>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectComRevOfCCDto, ProjectComRevOfCC>().ReverseMap();
            configuration.CreateMap<ProjectComRevOfCCDto, ProjectComRevOfCC>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectCommercialTasksPriorCommenceDto, ProjectCommercialTasksPriorCommence>().ReverseMap();
            configuration.CreateMap<ProjectCommercialTasksPriorCommenceDto, ProjectCommercialTasksPriorCommence>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectPTCWDto, ProjectPTCW>().ReverseMap();
            configuration.CreateMap<ProjectPTCWDto, ProjectPTCW>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectOACustCommAcceptanceResetDto, ProjectOACustCommAcceptance>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectOACustCommAcceptanceVCApprovalDto, ProjectOACustCommAcceptance>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectOACustCommAcceptanceDto, ProjectOACustCommAcceptance>().ReverseMap();
            configuration.CreateMap<ProjectOACustCommAcceptanceDto, ProjectOACustCommAcceptance>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectOAReviewDto, ProjectOAReview>().ReverseMap();
            configuration.CreateMap<ProjectOAReviewDto, ProjectOAReview>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectStatusOfSubmittedQuoteDto, ProjectStatusOfSubmittedQuote>().ReverseMap();
            configuration.CreateMap<StatusOfSubmittedQuoteDto, ProjectStatusOfSubmittedQuote>().ReverseMap();
            configuration.CreateMap<QuoteMetaDto, ProjectQuoteMeta>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectPreOrderInformationDto, ProjectPreOrderInformation>().ReverseMap();
            configuration.CreateMap<ProjectPreOrderInformationDto, ProjectPreOrderInformation>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectMRABPLDto, ProjectMRABPL>().ReverseMap();
            configuration.CreateMap<ProjectMRABPLDto, ProjectMRABPL>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectOpsConfirOfHandDto, ProjectOpsConfirOfHand>().ReverseMap();
            configuration.CreateMap<ProjectOpsConfirOfHandDto, ProjectOpsConfirOfHand>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectSalesToOpsHandDto, ProjectSalesToOpsHand>().ReverseMap();
            configuration.CreateMap<ProjectSalesToOpsHandDto, ProjectSalesToOpsHand>().ReverseMap();
            configuration.CreateMap<UpdateRTQDto, Project>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectPersonnelDto, ProjectPersonnel>().ReverseMap();
            configuration.CreateMap<ProjectPersonnelDto, ProjectPersonnel>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectQFDelegationDto, ProjectQFDelegation>().ReverseMap();
            configuration.CreateMap<ProjectQFDelegationDto, ProjectQFDelegation>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectQuoteFormDto, ProjectQuoteForm>().ReverseMap();
            configuration.CreateMap<ProjectQuoteFormDto, ProjectQuoteForm>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectSubcontractorDto, ProjectSubcontractor>().ReverseMap();
            configuration.CreateMap<ProjectSubcontractorDto, ProjectSubcontractor>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectKeyDeliverableDto, ProjectKeyDeliverable>().ReverseMap();
            configuration.CreateMap<ProjectKeyDeliverableDto, ProjectKeyDeliverable>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectReviewPlanDto, ProjectReviewPlan>().ReverseMap();
            configuration.CreateMap<ProjectReviewPlanDto, ProjectReviewPlan>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectExReviewRiskOppDto, ProjectExReviewRiskOpp>().ReverseMap();
            configuration.CreateMap<ProjectExReviewRiskOppDto, ProjectExReviewRiskOpp>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectExReviewAppInvoiceForecastDto, ProjectExReviewAppInvoiceForecast>().ReverseMap();
            configuration.CreateMap<ProjectExReviewAppInvoiceForecastDto, ProjectExReviewAppInvoiceForecast>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectBaselineProgramDto, ProjectBaselineProgram>().ReverseMap();
            configuration.CreateMap<ProjectBaselineProgramDto, ProjectBaselineProgram>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectCostDetailDto, ProjectCostDetail>().ReverseMap();
            configuration.CreateMap<ProjectCostDetailDto, ProjectCostDetail>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectExReviewDetailDto, ProjectExReviewDetail>().ReverseMap();
            configuration.CreateMap<ProjectExReviewDetailDto, ProjectExReviewDetail>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectExReviewDto, ProjectExReview>().ReverseMap();
            configuration.CreateMap<ProjectExReviewDto, ProjectExReview>().ReverseMap();
            configuration.CreateMap<GetProjectCommercialForViewDto, ProjectCommercial>().ReverseMap();
            configuration.CreateMap<GetProjectEngineeringForViewDto, ProjectEngineering>().ReverseMap();
            configuration.CreateMap<ProjectCommercial, GetProjectCommercialForViewDto>().ReverseMap();
            configuration.CreateMap<ProjectEngineering, GetProjectEngineeringForViewDto>().ReverseMap();
            configuration.CreateMap<ProjectEngineering, ProjectCommercial>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectRuleDto, ProjectRule>().ReverseMap();
            configuration.CreateMap<ProjectRuleDto, ProjectRule>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectActionDto, ProjectAction>().ReverseMap();
            configuration.CreateMap<ProjectActionDto, ProjectAction>().ReverseMap();
            configuration.CreateMap<CreateOrEditNodeActionDto, NodeAction>().ReverseMap();
            configuration.CreateMap<NodeActionDto, NodeAction>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectCommercialDto, ProjectCommercial>().ReverseMap();
            configuration.CreateMap<ProjectCommercialDto, ProjectCommercial>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectSiteOutputDto, ProjectSite>().ReverseMap();
            configuration.CreateMap<CreateOrEditSiteRefConfigDetailsDto, SiteRefConfigDetails>().ReverseMap();
            configuration.CreateMap<SiteRefConfigDetailsDto, SiteRefConfigDetails>().ReverseMap();
            configuration.CreateMap<CreateOrEditSiteRefConfigDto, Eco.SiteRefConfig.SiteRefConfig>().ReverseMap();
            configuration.CreateMap<SiteRefConfigDto, Eco.SiteRefConfig.SiteRefConfig>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectEngineeringDto, ProjectEngineering>().ReverseMap();
            configuration.CreateMap<ProjectEngineeringDto, ProjectEngineering>().ReverseMap();
            configuration.CreateMap<CreateOrEditNodeStageDto, NodeStage>().ReverseMap();
            configuration.CreateMap<NodeStageDto, NodeStage>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectEstimateDto, ProjectEstimate>().ReverseMap();
            configuration.CreateMap<ProjectEstimateDto, ProjectEstimate>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectDto, Project>().ReverseMap();
            configuration.CreateMap<ProjectDto, Project>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectWishlistDto, ProjectWishlist>().ReverseMap();
            configuration.CreateMap<ProjectWishlistDto, ProjectWishlist>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectCommentDto, ProjectComment>().ReverseMap();
            configuration.CreateMap<ProjectCommentDto, ProjectComment>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectSiteDto, ProjectSite>().ReverseMap();
            configuration.CreateMap<ProjectSiteDto, ProjectSite>().ReverseMap();
            configuration.CreateMap<CreateOrEditGuidanceNoteDto, GuidanceNote>().ReverseMap();
            configuration.CreateMap<GuidanceNoteDto, GuidanceNote>().ReverseMap();
            configuration.CreateMap<CreateOrEditRuleSettingDto, RuleSetting>().ReverseMap();
            configuration.CreateMap<RuleSettingDto, RuleSetting>().ReverseMap();
            configuration.CreateMap<CreateOrEditRuleConfigurationDto, RuleConfiguration>().ReverseMap();
            configuration.CreateMap<RuleConfigurationDto, RuleConfiguration>().ReverseMap();
            configuration.CreateMap<CreateOrEditRuleValueDto, RuleValue>().ReverseMap();
            configuration.CreateMap<RuleValueDto, RuleValue>().ReverseMap();
            configuration.CreateMap<CreateOrEditRuleElementDto, RuleElement>().ReverseMap();
            configuration.CreateMap<RuleElementDto, RuleElement>().ReverseMap();
            configuration.CreateMap<CreateOrEditRevenueRangeDto, RevenueRange>().ReverseMap();
            configuration.CreateMap<RevenueRangeDto, RevenueRange>().ReverseMap();
            configuration.CreateMap<CreateOrEditRuleTypeDto, RuleType>().ReverseMap();
            configuration.CreateMap<RuleTypeDto, RuleType>().ReverseMap();
            configuration.CreateMap<CreateOrEditRuleFlagDto, RuleFlag>().ReverseMap();
            configuration.CreateMap<RuleFlagDto, RuleFlag>().ReverseMap();
            configuration.CreateMap<CreateOrEditLeadContactDto, LeadContact>().ReverseMap();
            configuration.CreateMap<LeadContactDto, LeadContact>().ReverseMap();
            configuration.CreateMap<CreateOrEditLeadDto, Lead>().ReverseMap();
            configuration.CreateMap<LeadDto, Lead>().ReverseMap();
            configuration.CreateMap<CreateOrEditProjectTypeDto, ProjectType>().ReverseMap();
            configuration.CreateMap<ProjectTypeDto, ProjectType>().ReverseMap();
            configuration.CreateMap<GetProjectTypeForViewDto, ProjectType>().ReverseMap();
            configuration.CreateMap<CreateOrEditLeadSourceDto, LeadSource>().ReverseMap();
            configuration.CreateMap<LeadSourceDto, LeadSource>().ReverseMap();
            configuration.CreateMap<CreateOrEditFlexiFieldDto, FlexiField>().ReverseMap();
            configuration.CreateMap<FlexiFieldDto, FlexiField>().ReverseMap();
            configuration.CreateMap<CreateOrEditFlexiSectionDto, FlexiSection>().ReverseMap();
            configuration.CreateMap<FlexiSectionDto, FlexiSection>().ReverseMap();
            configuration.CreateMap<CreateOrEditContactPersonDto, ContactPerson>().ReverseMap();
            configuration.CreateMap<ContactPersonDto, ContactPerson>().ReverseMap();
            configuration.CreateMap<CreateOrEditCustomerDto, Customer>().ReverseMap();
            configuration.CreateMap<CustomerDto, Customer>().ReverseMap();
            configuration.CreateMap<CreateOrEditNodeMailConfigDto, Eco.NodeMailConfig.NodeMailConfig>().ReverseMap();
            configuration.CreateMap<NodeMailConfigDto, Eco.NodeMailConfig.NodeMailConfig>().ReverseMap();
            configuration.CreateMap<CreateOrEditNodeTaskDto, NodeTask>().ReverseMap();
            configuration.CreateMap<NodeTaskDto, NodeTask>().ReverseMap();
            configuration.CreateMap<CreateOrEditRefNoConfigDto, Eco.RefNoConfig.RefNoConfig>().ReverseMap();
            configuration.CreateMap<RefNoConfigDto, Eco.RefNoConfig.RefNoConfig>().ReverseMap();
            configuration.CreateMap<CreateOrEditRefNoConfigDetailsDto, RefNoConfigDetails>().ReverseMap();
            configuration.CreateMap<RefNoConfigDetailsDto, RefNoConfigDetails>().ReverseMap();
            configuration.CreateMap<CreateOrEditGridMasterDto, Eco.GridMaster.GridMaster>().ReverseMap();
            configuration.CreateMap<GridMasterDto, Eco.GridMaster.GridMaster>().ReverseMap();
            //Inputs
            configuration.CreateMap<CheckboxInputType, FeatureInputTypeDto>();
            configuration.CreateMap<SingleLineStringInputType, FeatureInputTypeDto>();
            configuration.CreateMap<ComboboxInputType, FeatureInputTypeDto>();
            configuration.CreateMap<IInputType, FeatureInputTypeDto>()
                .Include<CheckboxInputType, FeatureInputTypeDto>()
                .Include<SingleLineStringInputType, FeatureInputTypeDto>()
                .Include<ComboboxInputType, FeatureInputTypeDto>();
            configuration.CreateMap<StaticLocalizableComboboxItemSource, LocalizableComboboxItemSourceDto>();
            configuration.CreateMap<ILocalizableComboboxItemSource, LocalizableComboboxItemSourceDto>()
                .Include<StaticLocalizableComboboxItemSource, LocalizableComboboxItemSourceDto>();
            configuration.CreateMap<LocalizableComboboxItem, LocalizableComboboxItemDto>();
            configuration.CreateMap<ILocalizableComboboxItem, LocalizableComboboxItemDto>()
                .Include<LocalizableComboboxItem, LocalizableComboboxItemDto>();

            //Chat
            configuration.CreateMap<ChatMessage, ChatMessageDto>();
            configuration.CreateMap<ChatMessage, ChatMessageExportDto>();

            //Feature
            configuration.CreateMap<FlatFeatureSelectDto, Feature>().ReverseMap();
            configuration.CreateMap<Feature, FlatFeatureDto>();

            //Role
            configuration.CreateMap<RoleEditDto, Role>().ReverseMap();
            configuration.CreateMap<Role, RoleListDto>();
            configuration.CreateMap<UserRole, UserListRoleDto>();

            //Edition
            configuration.CreateMap<EditionEditDto, SubscribableEdition>().ReverseMap();
            configuration.CreateMap<EditionCreateDto, SubscribableEdition>();
            configuration.CreateMap<EditionSelectDto, SubscribableEdition>().ReverseMap();
            configuration.CreateMap<SubscribableEdition, EditionInfoDto>();

            configuration.CreateMap<Edition, EditionInfoDto>().Include<SubscribableEdition, EditionInfoDto>();

            configuration.CreateMap<SubscribableEdition, EditionListDto>();
            configuration.CreateMap<Edition, EditionEditDto>();
            configuration.CreateMap<Edition, SubscribableEdition>();
            configuration.CreateMap<Edition, EditionSelectDto>();

            //Payment
            configuration.CreateMap<SubscriptionPaymentDto, SubscriptionPayment>().ReverseMap();
            configuration.CreateMap<SubscriptionPaymentListDto, SubscriptionPayment>().ReverseMap();
            configuration.CreateMap<SubscriptionPayment, SubscriptionPaymentInfoDto>();

            //Permission
            configuration.CreateMap<Permission, FlatPermissionDto>();
            configuration.CreateMap<Permission, FlatPermissionWithLevelDto>();

            //Language
            configuration.CreateMap<ApplicationLanguage, ApplicationLanguageEditDto>();
            configuration.CreateMap<ApplicationLanguage, ApplicationLanguageListDto>();
            configuration.CreateMap<NotificationDefinition, NotificationSubscriptionWithDisplayNameDto>();
            configuration.CreateMap<ApplicationLanguage, ApplicationLanguageEditDto>()
                .ForMember(ldto => ldto.IsEnabled, options => options.MapFrom(l => !l.IsDisabled));

            //Tenant
            configuration.CreateMap<Tenant, RecentTenant>();
            configuration.CreateMap<Tenant, TenantLoginInfoDto>();
            configuration.CreateMap<Tenant, TenantListDto>();
            configuration.CreateMap<TenantEditDto, Tenant>().ReverseMap();
            configuration.CreateMap<CurrentTenantInfoDto, Tenant>().ReverseMap();

            //User
            configuration.CreateMap<User, UserEditDto>()
                .ForMember(dto => dto.Password, options => options.Ignore())
                .ReverseMap()
                .ForMember(user => user.Password, options => options.Ignore());
            configuration.CreateMap<User, UserLoginInfoDto>();
            configuration.CreateMap<User, UserListDto>();
            configuration.CreateMap<User, ChatUserDto>();
            configuration.CreateMap<User, OrganizationUnitUserListDto>();
            configuration.CreateMap<Role, OrganizationUnitRoleListDto>();
            configuration.CreateMap<CurrentUserProfileEditDto, User>().ReverseMap();
            configuration.CreateMap<UserLoginAttemptDto, UserLoginAttempt>().ReverseMap();
            configuration.CreateMap<ImportUserDto, User>();

            //AuditLog
            configuration.CreateMap<AuditLog, AuditLogListDto>();
            configuration.CreateMap<EntityChange, EntityChangeListDto>();
            configuration.CreateMap<EntityPropertyChange, EntityPropertyChangeDto>();

            //Friendship
            configuration.CreateMap<Friendship, FriendDto>();
            configuration.CreateMap<FriendCacheItem, FriendDto>();

            //OrganizationUnit
            configuration.CreateMap<OrganizationUnit, OrganizationUnitDto>();

            //Webhooks
            configuration.CreateMap<WebhookSubscription, GetAllSubscriptionsOutput>();
            configuration.CreateMap<WebhookSendAttempt, GetAllSendAttemptsOutput>()
                .ForMember(webhookSendAttemptListDto => webhookSendAttemptListDto.WebhookName,
                    options => options.MapFrom(l => l.WebhookEvent.WebhookName))
                .ForMember(webhookSendAttemptListDto => webhookSendAttemptListDto.Data,
                    options => options.MapFrom(l => l.WebhookEvent.Data));

            configuration.CreateMap<WebhookSendAttempt, GetAllSendAttemptsOfWebhookEventOutput>();

            configuration.CreateMap<DynamicProperty, DynamicPropertyDto>().ReverseMap();
            configuration.CreateMap<DynamicPropertyValue, DynamicPropertyValueDto>().ReverseMap();
            configuration.CreateMap<DynamicEntityProperty, DynamicEntityPropertyDto>()
                .ForMember(dto => dto.DynamicPropertyName,
                    options => options.MapFrom(entity => entity.DynamicProperty.DisplayName.IsNullOrEmpty() ? entity.DynamicProperty.PropertyName : entity.DynamicProperty.DisplayName));
            configuration.CreateMap<DynamicEntityPropertyDto, DynamicEntityProperty>();

            configuration.CreateMap<DynamicEntityPropertyValue, DynamicEntityPropertyValueDto>().ReverseMap();

            //User Delegations
            configuration.CreateMap<CreateUserDelegationDto, UserDelegation>();

            /* ADD YOUR OWN CUSTOM AUTOMAPPER MAPPINGS HERE */
        }
    }
}