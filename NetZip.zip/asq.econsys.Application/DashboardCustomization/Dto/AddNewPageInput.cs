﻿namespace asq.econsys.DashboardCustomization.Dto
{
    public class AddNewPageInput
    {
        public string DashboardName { get; set; }

        public string Name { get; set; }

        public string Application { get; set; }
    }
}
