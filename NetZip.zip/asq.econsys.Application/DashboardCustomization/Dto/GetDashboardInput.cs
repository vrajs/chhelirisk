﻿namespace asq.econsys.DashboardCustomization.Dto
{
    public class GetDashboardInput
    {
        public string DashboardName { get; set; }

        public string Application { get; set; }
    }
}
