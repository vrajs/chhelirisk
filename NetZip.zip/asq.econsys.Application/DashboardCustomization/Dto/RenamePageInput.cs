﻿namespace asq.econsys.DashboardCustomization.Dto
{
    public class RenamePageInput
    {
        public string DashboardName { get; set; }

        public string Id { get; set; }

        public string Name { get; set; }

        public string Application { get; set; }
    }
}