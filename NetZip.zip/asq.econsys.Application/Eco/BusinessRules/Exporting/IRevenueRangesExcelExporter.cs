﻿using System.Collections.Generic;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public interface IRevenueRangesExcelExporter
    {
        FileDto ExportToFile(List<GetRevenueRangeForViewDto> revenueRanges);
    }
}