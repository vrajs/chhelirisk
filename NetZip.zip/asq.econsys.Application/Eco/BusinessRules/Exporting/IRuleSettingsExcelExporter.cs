﻿using System.Collections.Generic;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public interface IRuleSettingsExcelExporter
    {
        FileDto ExportToFile(List<GetRuleSettingForViewDto> ruleSettings);
    }
}