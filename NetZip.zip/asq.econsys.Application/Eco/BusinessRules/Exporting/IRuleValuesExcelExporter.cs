﻿using System.Collections.Generic;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public interface IRuleValuesExcelExporter
    {
        FileDto ExportToFile(List<GetRuleValueForViewDto> ruleValues);
    }
}