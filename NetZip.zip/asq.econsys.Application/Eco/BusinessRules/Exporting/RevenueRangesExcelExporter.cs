﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public class RevenueRangesExcelExporter : NpoiExcelExporterBase, IRevenueRangesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public RevenueRangesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetRevenueRangeForViewDto> revenueRanges)
        {
            return CreateExcelPackage(
                "RevenueRanges.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("RevenueRanges"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("DisplayOrder"),
                        L("MinRange"),
                        L("MaxRange")
                        );

                    AddObjects(
                        sheet, revenueRanges,
                        _ => _.RevenueRange.Title,
                        _ => _.RevenueRange.DisplayOrder,
                        _ => _.RevenueRange.MinRange,
                        _ => _.RevenueRange.MaxRange
                        );

                });
        }
    }
}