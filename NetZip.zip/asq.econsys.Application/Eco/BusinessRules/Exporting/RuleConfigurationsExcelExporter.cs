﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public class RuleConfigurationsExcelExporter : NpoiExcelExporterBase, IRuleConfigurationsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public RuleConfigurationsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetRuleConfigurationForViewDto> ruleConfigurations)
        {
            return CreateExcelPackage(
                "RuleConfigurations.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("RuleConfigurations"));

                    AddHeader(
                        sheet,
                        (L("OrganizationUnit")) + L("DisplayName"),
                        (L("RuleElement")) + L("Title"),
                        (L("RevenueRange")) + L("Title"),
                        (L("RuleFlag")) + L("Title"),
                        (L("RuleValue")) + L("Title")
                        );

                    AddObjects(
                        sheet, ruleConfigurations,
                        _ => _.OrganizationUnitDisplayName,
                        _ => _.RuleElementTitle,
                        _ => _.RevenueRangeTitle,
                        _ => _.RuleFlagTitle,
                        _ => _.RuleValueTitle
                        );

                });
        }
    }
}