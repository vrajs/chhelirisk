﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public class RuleElementsExcelExporter : NpoiExcelExporterBase, IRuleElementsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public RuleElementsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetRuleElementForViewDto> ruleElements)
        {
            return CreateExcelPackage(
                "RuleElements.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("RuleElements"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("DisplayOrder"),
                        L("VariableName"),
                        (L("OrganizationUnit")) + L("DisplayName"),
                        (L("RuleType")) + L("Title")
                        );

                    AddObjects(
                        sheet, ruleElements,
                        _ => _.RuleElement.Title,
                        _ => _.RuleElement.DisplayOrder,
                        _ => _.RuleElement.VariableName,
                        _ => _.OrganizationUnitDisplayName,
                        _ => _.RuleTypeTitle
                        );

                });
        }
    }
}