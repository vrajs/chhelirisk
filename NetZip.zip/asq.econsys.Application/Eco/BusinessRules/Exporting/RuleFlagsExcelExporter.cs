﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public class RuleFlagsExcelExporter : NpoiExcelExporterBase, IRuleFlagsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public RuleFlagsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetRuleFlagForViewDto> ruleFlags)
        {
            return CreateExcelPackage(
                "RuleFlags.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("RuleFlags"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("HexColor"),
                        L("DisplayOrder")
                        );

                    AddObjects(
                        sheet, ruleFlags,
                        _ => _.RuleFlag.Title,
                        _ => _.RuleFlag.HexColor,
                        _ => _.RuleFlag.DisplayOrder
                        );

                });
        }
    }
}