﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public class RuleSettingsExcelExporter : NpoiExcelExporterBase, IRuleSettingsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public RuleSettingsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetRuleSettingForViewDto> ruleSettings)
        {
            return CreateExcelPackage(
                "RuleSettings.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("RuleSettings"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("Value"),
                        L("FieldType"),
                        L("DisplayOrder"),
                        (L("RuleType")) + L("Title"),
                        (L("OrganizationUnit")) + L("DisplayName")
                        );

                    AddObjects(
                        sheet, ruleSettings,
                        _ => _.RuleSetting.Title,
                        _ => _.RuleSetting.Value,
                        _ => _.RuleSetting.FieldType,
                        _ => _.RuleSetting.DisplayOrder,
                        _ => _.RuleTypeTitle,
                        _ => _.OrganizationUnitDisplayName
                        );

                });
        }
    }
}