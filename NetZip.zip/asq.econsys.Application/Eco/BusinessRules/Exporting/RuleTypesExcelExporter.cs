﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public class RuleTypesExcelExporter : NpoiExcelExporterBase, IRuleTypesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public RuleTypesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetRuleTypeForViewDto> ruleTypes)
        {
            return CreateExcelPackage(
                "RuleTypes.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("RuleTypes"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("DisplayOrder"),
                        L("OutputVariable"),
                        L("StatusDetailsVariable"),
                        L("IsRangeSpecific")
                        );

                    AddObjects(
                        sheet, ruleTypes,
                        _ => _.RuleType.Title,
                        _ => _.RuleType.DisplayOrder,
                        _ => _.RuleType.OutputVariable,
                        _ => _.RuleType.StatusDetailsVariable,
                        _ => _.RuleType.IsRangeSpecific
                        );

                });
        }
    }
}