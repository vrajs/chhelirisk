﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules.Exporting
{
    public class RuleValuesExcelExporter : NpoiExcelExporterBase, IRuleValuesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public RuleValuesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetRuleValueForViewDto> ruleValues)
        {
            return CreateExcelPackage(
                "RuleValues.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("RuleValues"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("DisplayOrder"),
                        L("IsRangeSpecific"),
                        (L("OrganizationUnit")) + L("DisplayName"),
                        (L("RuleType")) + L("Title"),
                        (L("RuleElement")) + L("Title")
                        );

                    AddObjects(
                        sheet, ruleValues,
                        _ => _.RuleValue.Title,
                        _ => _.RuleValue.DisplayOrder,
                        _ => _.RuleValue.IsRangeSpecific,
                        _ => _.OrganizationUnitDisplayName,
                        _ => _.RuleTypeTitle,
                        _ => _.RuleElementTitle
                        );

                });
        }
    }
}