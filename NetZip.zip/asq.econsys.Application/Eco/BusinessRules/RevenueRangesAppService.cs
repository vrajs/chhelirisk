﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.BusinessRules.Exporting;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules
{
    [AbpAuthorize(AppPermissions.Pages_Administration_RevenueRanges)]
    public class RevenueRangesAppService : econsysAppServiceBase, IRevenueRangesAppService
    {
        private readonly IRepository<RevenueRange, long> _revenueRangeRepository;
        private readonly IRevenueRangesExcelExporter _revenueRangesExcelExporter;

        public RevenueRangesAppService(IRepository<RevenueRange, long> revenueRangeRepository, IRevenueRangesExcelExporter revenueRangesExcelExporter)
        {
            _revenueRangeRepository = revenueRangeRepository;
            _revenueRangesExcelExporter = revenueRangesExcelExporter;

        }
        public async Task<PagedResultDto<GetRevenueRangeForViewDto>> GetAll(GetAllRevenueRangesInput input)
        {

            var filteredRevenueRanges = _revenueRangeRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(input.MinMinRangeFilter != null, e => e.MinRange >= input.MinMinRangeFilter)
                        .WhereIf(input.MaxMinRangeFilter != null, e => e.MinRange <= input.MaxMinRangeFilter)
                        .WhereIf(input.MinMaxRangeFilter != null, e => e.MaxRange >= input.MinMaxRangeFilter)
                        .WhereIf(input.MaxMaxRangeFilter != null, e => e.MaxRange <= input.MaxMaxRangeFilter);

            var pagedAndFilteredRevenueRanges = filteredRevenueRanges
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var revenueRanges = from o in pagedAndFilteredRevenueRanges
                                select new
                                {

                                    o.Title,
                                    o.DisplayOrder,
                                    o.MinRange,
                                    o.MaxRange,
                                    Id = o.Id
                                };

            var totalCount = await filteredRevenueRanges.CountAsync();

            var dbList = await revenueRanges.ToListAsync();
            var results = new List<GetRevenueRangeForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetRevenueRangeForViewDto()
                {
                    RevenueRange = new RevenueRangeDto
                    {

                        Title = o.Title,
                        DisplayOrder = o.DisplayOrder,
                        MinRange = o.MinRange,
                        MaxRange = o.MaxRange,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetRevenueRangeForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetRevenueRangeForViewDto> GetRevenueRangeForView(long id)
        {
            var revenueRange = await _revenueRangeRepository.GetAsync(id);

            var output = new GetRevenueRangeForViewDto { RevenueRange = ObjectMapper.Map<RevenueRangeDto>(revenueRange) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RevenueRanges_Edit)]
        public async Task<GetRevenueRangeForEditOutput> GetRevenueRangeForEdit(EntityDto<long> input)
        {
            var revenueRange = await _revenueRangeRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRevenueRangeForEditOutput { RevenueRange = ObjectMapper.Map<CreateOrEditRevenueRangeDto>(revenueRange) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditRevenueRangeDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RevenueRanges_Create)]
        protected virtual async Task Create(CreateOrEditRevenueRangeDto input)
        {
            var revenueRange = ObjectMapper.Map<RevenueRange>(input);

            if (AbpSession.TenantId != null)
            {
                revenueRange.TenantId = (int?)AbpSession.TenantId;
            }

            await _revenueRangeRepository.InsertAsync(revenueRange);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RevenueRanges_Edit)]
        protected virtual async Task Update(CreateOrEditRevenueRangeDto input)
        {
            var revenueRange = await _revenueRangeRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, revenueRange);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RevenueRanges_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _revenueRangeRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetRevenueRangesToExcel(GetAllRevenueRangesForExcelInput input)
        {

            var filteredRevenueRanges = _revenueRangeRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(input.MinMinRangeFilter != null, e => e.MinRange >= input.MinMinRangeFilter)
                        .WhereIf(input.MaxMinRangeFilter != null, e => e.MinRange <= input.MaxMinRangeFilter)
                        .WhereIf(input.MinMaxRangeFilter != null, e => e.MaxRange >= input.MinMaxRangeFilter)
                        .WhereIf(input.MaxMaxRangeFilter != null, e => e.MaxRange <= input.MaxMaxRangeFilter);

            var query = (from o in filteredRevenueRanges
                         select new GetRevenueRangeForViewDto()
                         {
                             RevenueRange = new RevenueRangeDto
                             {
                                 Title = o.Title,
                                 DisplayOrder = o.DisplayOrder,
                                 MinRange = o.MinRange,
                                 MaxRange = o.MaxRange,
                                 Id = o.Id
                             }
                         });

            var revenueRangeListDtos = await query.ToListAsync();

            return _revenueRangesExcelExporter.ExportToFile(revenueRangeListDtos);
        }

    }
}