﻿using Abp.Organizations;
using asq.econsys.Eco.BusinessRules;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.BusinessRules.Exporting;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.BusinessRules
{
    [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations)]
    public class RuleConfigurationsAppService : econsysAppServiceBase, IRuleConfigurationsAppService
    {
        private readonly IRepository<RuleConfiguration, long> _ruleConfigurationRepository;
        private readonly IRepository<RuleSetting , int > _lookup_ruleSettingRepository;
        private readonly IRuleConfigurationsExcelExporter _ruleConfigurationsExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IRepository<RuleElement, long> _lookup_ruleElementRepository;
        private readonly IRepository<RevenueRange, long> _lookup_revenueRangeRepository;
        private readonly IRepository<RuleFlag, string> _lookup_ruleFlagRepository;
        private readonly IRepository<RuleValue, long> _lookup_ruleValueRepository;
        private readonly IRepository<RuleType, string> _lookup_ruleTypeRepository;

        public RuleConfigurationsAppService(
            IRepository<RuleConfiguration, long> ruleConfigurationRepository, 
            IRuleConfigurationsExcelExporter ruleConfigurationsExcelExporter, 
            IRepository<OrganizationUnit, long> lookup_organizationUnitRepository, 
            IRepository<RuleElement, long> lookup_ruleElementRepository, 
            IRepository<RevenueRange, long> lookup_revenueRangeRepository, 
            IRepository<RuleFlag, string> lookup_ruleFlagRepository, 
            IRepository<RuleValue, long> lookup_ruleValueRepository, 
            IRepository<RuleType, string> lookup_ruleTypeRepository,
            IRepository<RuleSetting , int> lookup_ruleSettingRepository)


        {
            _ruleConfigurationRepository = ruleConfigurationRepository;
            _ruleConfigurationsExcelExporter = ruleConfigurationsExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _lookup_ruleElementRepository = lookup_ruleElementRepository;
            _lookup_revenueRangeRepository = lookup_revenueRangeRepository;
            _lookup_ruleFlagRepository = lookup_ruleFlagRepository;
            _lookup_ruleValueRepository = lookup_ruleValueRepository;
            _lookup_ruleTypeRepository = lookup_ruleTypeRepository;
            _lookup_ruleSettingRepository = lookup_ruleSettingRepository;

        }

        public async Task<PagedResultDto<GetRuleConfigurationForViewDto>> GetAll(GetAllRuleConfigurationsInput input)
        {

            var filteredRuleConfigurations = _ruleConfigurationRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.RuleElementFk)
                        .Include(e => e.RevenueRangeFk)
                        .Include(e => e.RuleFlagFk)
                        .Include(e => e.RuleValueFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleElementTitleFilter), e => e.RuleElementFk != null && e.RuleElementFk.Title == input.RuleElementTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevenueRangeTitleFilter), e => e.RevenueRangeFk != null && e.RevenueRangeFk.Title == input.RevenueRangeTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagTitleFilter), e => e.RuleFlagFk != null && e.RuleFlagFk.Title == input.RuleFlagTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleValueTitleFilter), e => e.RuleValueFk != null && e.RuleValueFk.Title == input.RuleValueTitleFilter);

            var pagedAndFilteredRuleConfigurations = filteredRuleConfigurations
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var ruleConfigurations = from o in pagedAndFilteredRuleConfigurations
                                     join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                                     from s1 in j1.DefaultIfEmpty()

                                     join o2 in _lookup_ruleElementRepository.GetAll() on o.RuleElementId equals o2.Id into j2
                                     from s2 in j2.DefaultIfEmpty()

                                     join o3 in _lookup_revenueRangeRepository.GetAll() on o.RevenueRangeId equals o3.Id into j3
                                     from s3 in j3.DefaultIfEmpty()

                                     join o4 in _lookup_ruleFlagRepository.GetAll() on o.RuleFlagId equals o4.Id into j4
                                     from s4 in j4.DefaultIfEmpty()

                                     join o5 in _lookup_ruleValueRepository.GetAll() on o.RuleValueId equals o5.Id into j5
                                     from s5 in j5.DefaultIfEmpty()

                                     select new
                                     {

                                         Id = o.Id,
                                         OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                                         RuleElementTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                                         RevenueRangeTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString(),
                                         RuleFlagTitle = s4 == null || s4.Title == null ? "" : s4.Title.ToString(),
                                         RuleValueTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString()
                                     };

            var totalCount = await filteredRuleConfigurations.CountAsync();

            var dbList = await ruleConfigurations.ToListAsync();
            var results = new List<GetRuleConfigurationForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetRuleConfigurationForViewDto()
                {
                    RuleConfiguration = new RuleConfigurationDto
                    {

                        Id = o.Id,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
                    RuleElementTitle = o.RuleElementTitle,
                    RevenueRangeTitle = o.RevenueRangeTitle,
                    RuleFlagTitle = o.RuleFlagTitle,
                    RuleValueTitle = o.RuleValueTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetRuleConfigurationForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetRuleConfigurationForViewDto> GetRuleConfigurationForView(long id)
        {
            var ruleConfiguration = await _ruleConfigurationRepository.GetAsync(id);

            var output = new GetRuleConfigurationForViewDto { RuleConfiguration = ObjectMapper.Map<RuleConfigurationDto>(ruleConfiguration) };

            if (output.RuleConfiguration.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RuleConfiguration.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.RuleConfiguration.RuleElementId != null)
            {
                var _lookupRuleElement = await _lookup_ruleElementRepository.FirstOrDefaultAsync((long)output.RuleConfiguration.RuleElementId);
                output.RuleElementTitle = _lookupRuleElement?.Title?.ToString();
            }

            if (output.RuleConfiguration.RevenueRangeId != null)
            {
                var _lookupRevenueRange = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)output.RuleConfiguration.RevenueRangeId);
                output.RevenueRangeTitle = _lookupRevenueRange?.Title?.ToString();
            }

            if (output.RuleConfiguration.RuleFlagId != null)
            {
                var _lookupRuleFlag = await _lookup_ruleFlagRepository.FirstOrDefaultAsync((string)output.RuleConfiguration.RuleFlagId);
                output.RuleFlagTitle = _lookupRuleFlag?.Title?.ToString();
            }

            if (output.RuleConfiguration.RuleValueId != null)
            {
                var _lookupRuleValue = await _lookup_ruleValueRepository.FirstOrDefaultAsync((long)output.RuleConfiguration.RuleValueId);
                output.RuleValueTitle = _lookupRuleValue?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations_Edit)]
        public async Task<GetRuleConfigurationForEditOutput> GetRuleConfigurationForEdit(EntityDto<long> input)
        {
            var ruleConfiguration = await _ruleConfigurationRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRuleConfigurationForEditOutput { RuleConfiguration = ObjectMapper.Map<CreateOrEditRuleConfigurationDto>(ruleConfiguration) };

            if (output.RuleConfiguration.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RuleConfiguration.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.RuleConfiguration.RuleElementId != null)
            {
                var _lookupRuleElement = await _lookup_ruleElementRepository.FirstOrDefaultAsync((long)output.RuleConfiguration.RuleElementId);
                output.RuleElementTitle = _lookupRuleElement?.Title?.ToString();
            }

            if (output.RuleConfiguration.RevenueRangeId != null)
            {
                var _lookupRevenueRange = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)output.RuleConfiguration.RevenueRangeId);
                output.RevenueRangeTitle = _lookupRevenueRange?.Title?.ToString();
            }

            if (output.RuleConfiguration.RuleFlagId != null)
            {
                var _lookupRuleFlag = await _lookup_ruleFlagRepository.FirstOrDefaultAsync((string)output.RuleConfiguration.RuleFlagId);
                output.RuleFlagTitle = _lookupRuleFlag?.Title?.ToString();
            }

            if (output.RuleConfiguration.RuleValueId != null)
            {
                var _lookupRuleValue = await _lookup_ruleValueRepository.FirstOrDefaultAsync((long)output.RuleConfiguration.RuleValueId);
                output.RuleValueTitle = _lookupRuleValue?.Title?.ToString();
            }

            return output;
        }

        public async Task BulkCreateOrEdit(IEnumerable<CreateOrEditRuleConfigurationDto> inputs)
        {
            foreach (var input in inputs)
            {
                if (input.Id == null)
                {
                    await Create(input);
                }
                else
                {
                    await Update(input);
                }
            }
        }

        public async Task CreateOrEdit(CreateOrEditRuleConfigurationDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations_Create)]
        protected virtual async Task Create(CreateOrEditRuleConfigurationDto input)
        {
            var ruleConfiguration = ObjectMapper.Map<RuleConfiguration>(input);

            if (AbpSession.TenantId != null)
            {
                ruleConfiguration.TenantId = (int?)AbpSession.TenantId;
            }

            await _ruleConfigurationRepository.InsertAsync(ruleConfiguration);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations_Edit)]
        protected virtual async Task Update(CreateOrEditRuleConfigurationDto input)
        {
            var ruleConfiguration = await _ruleConfigurationRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, ruleConfiguration);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _ruleConfigurationRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetRuleConfigurationsToExcel(GetAllRuleConfigurationsForExcelInput input)
        {

            var filteredRuleConfigurations = _ruleConfigurationRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.RuleElementFk)
                        .Include(e => e.RevenueRangeFk)
                        .Include(e => e.RuleFlagFk)
                        .Include(e => e.RuleValueFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleElementTitleFilter), e => e.RuleElementFk != null && e.RuleElementFk.Title == input.RuleElementTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevenueRangeTitleFilter), e => e.RevenueRangeFk != null && e.RevenueRangeFk.Title == input.RevenueRangeTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagTitleFilter), e => e.RuleFlagFk != null && e.RuleFlagFk.Title == input.RuleFlagTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleValueTitleFilter), e => e.RuleValueFk != null && e.RuleValueFk.Title == input.RuleValueTitleFilter);

            var query = (from o in filteredRuleConfigurations
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_ruleElementRepository.GetAll() on o.RuleElementId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_revenueRangeRepository.GetAll() on o.RevenueRangeId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         join o4 in _lookup_ruleFlagRepository.GetAll() on o.RuleFlagId equals o4.Id into j4
                         from s4 in j4.DefaultIfEmpty()

                         join o5 in _lookup_ruleValueRepository.GetAll() on o.RuleValueId equals o5.Id into j5
                         from s5 in j5.DefaultIfEmpty()

                         select new GetRuleConfigurationForViewDto()
                         {
                             RuleConfiguration = new RuleConfigurationDto
                             {
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                             RuleElementTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                             RevenueRangeTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString(),
                             RuleFlagTitle = s4 == null || s4.Title == null ? "" : s4.Title.ToString(),
                             RuleValueTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString()
                         });

            var ruleConfigurationListDtos = await query.ToListAsync();

            return _ruleConfigurationsExcelExporter.ExportToFile(ruleConfigurationListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations)]
        public async Task<List<RuleConfigurationOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new RuleConfigurationOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations)]
        public async Task<List<RuleConfigurationRuleElementLookupTableDto>> GetAllRuleElementForTableDropdown()
        {
            return await _lookup_ruleElementRepository.GetAll()
                .Select(ruleElement => new RuleConfigurationRuleElementLookupTableDto
                {
                    Id = ruleElement.Id,
                    DisplayName = ruleElement == null || ruleElement.Title == null ? "" : ruleElement.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations)]
        public async Task<List<RuleConfigurationRevenueRangeLookupTableDto>> GetAllRevenueRangeForTableDropdown()
        {
            return await _lookup_revenueRangeRepository.GetAll()
                .Select(revenueRange => new RuleConfigurationRevenueRangeLookupTableDto
                {
                    Id = revenueRange.Id,
                    DisplayName = revenueRange == null || revenueRange.Title == null ? "" : revenueRange.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations)]
        public async Task<List<RuleConfigurationRuleFlagLookupTableDto>> GetAllRuleFlagForTableDropdown()
        {
            return await _lookup_ruleFlagRepository.GetAll()
                .Select(ruleFlag => new RuleConfigurationRuleFlagLookupTableDto
                {
                    Id = ruleFlag.Id,
                    DisplayName = ruleFlag == null || ruleFlag.Title == null ? "" : ruleFlag.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleConfigurations)]
        public async Task<List<RuleConfigurationRuleValueLookupTableDto>> GetAllRuleValueForTableDropdown()
        {
            return await _lookup_ruleValueRepository.GetAll()
                .Select(ruleValue => new RuleConfigurationRuleValueLookupTableDto
                {
                    Id = ruleValue.Id,
                    DisplayName = ruleValue == null || ruleValue.Title == null ? "" : ruleValue.Title.ToString()
                }).ToListAsync();
        }

        public async Task<BusinessRuleAllDDLDto> GetBusinessRuleAllDDL()
        {
            var result = new BusinessRuleAllDDLDto();
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var flags = await _lookup_ruleFlagRepository.GetAll()
                        .Select(x => new GetRuleFlagForViewDto()
                        {
                            RuleFlag = new RuleFlagDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                HexColor = x.HexColor
                            }
                        }).OrderBy(s => s.RuleFlag.DisplayOrder).ToListAsync();

                    result.RuleFlags = ObjectMapper.Map<List<GetRuleFlagForViewDto>>(flags);

                    //var types = _lookup_ruleTypeRepository.GetAll().ToList();
                    var types = await _lookup_ruleTypeRepository.GetAll()
                        .Select(x => new GetRuleTypeForViewDto()
                        {
                            RuleType = new RuleTypeDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                IsRangeSpecific = x.IsRangeSpecific,
                                OutputVariable = x.OutputVariable,
                                StatusDetailsVariable = x.StatusDetailsVariable
                            }
                        }).OrderBy(s => s.RuleType.DisplayOrder).ToListAsync();

                    result.RuleTypes = ObjectMapper.Map<List<GetRuleTypeForViewDto>>(types);

                    //var revenueRanges = _lookup_revenueRangeRepository.GetAll().ToList();
                    var revenueRanges = await _lookup_revenueRangeRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRevenueRangeForViewDto()
                        {
                            RevenueRange = new RevenueRangeDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                MinRange = x.MinRange,
                                MaxRange = x.MaxRange
                            }
                        }).OrderBy(s => s.RevenueRange.DisplayOrder).ToListAsync();

                    result.RevenueRanges = ObjectMapper.Map<List<GetRevenueRangeForViewDto>>(revenueRanges);

                    //var ruleElements = _lookup_ruleElementRepository.GetAll().ToList();
                    var ruleElements = await _lookup_ruleElementRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRuleElementForViewDto()
                        {
                            RuleElement = new RuleElementDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                RuleTypeId = x.RuleTypeId,
                                VariableName = x.VariableName
                            }
                        }).OrderBy(s => s.RuleElement.DisplayOrder).ToListAsync();

                    result.RuleElements = ObjectMapper.Map<List<GetRuleElementForViewDto>>(ruleElements);

                    //var ruleValue = _lookup_ruleValueRepository.GetAll().ToList();
                    var ruleValues = await _lookup_ruleValueRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRuleValueForViewDto()
                        {
                            RuleValue = new RuleValueDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                RuleTypeId = x.RuleTypeId,
                                RuleElementId = x.RuleElementId,
                                IsRangeSpecific = x.IsRangeSpecific
                            }
                        }).OrderBy(s => s.RuleValue.DisplayOrder).ToListAsync();

                    result.RuleValues = ObjectMapper.Map<List<GetRuleValueForViewDto>>(ruleValues);

                    //var ruleConfiguration = _ruleConfigurationRepository.GetAll().ToList();
                    var ruleConfigurations = await _ruleConfigurationRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRuleConfigurationForViewDto()
                        {
                            RuleConfiguration = new RuleConfigurationDto()
                            {
                                Id = x.Id,
                                RevenueRangeId = x.RevenueRangeId,
                                RuleElementId = x.RuleElementId,
                                RuleFlagId = x.RuleFlagId,
                                RuleValueId = x.RuleValueId
                            }
                        }).ToListAsync();
                    result.RuleConfigurations = ObjectMapper.Map<List<GetRuleConfigurationForViewDto>>(ruleConfigurations);

                    //rule settings
                    var ruleSettings = await _lookup_ruleSettingRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRuleSettingForViewDto()
                        {
                            RuleSetting = new RuleSettingDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                FieldType = x.FieldType,
                                DisplayOrder = x.DisplayOrder,
                                RuleTypeId = x.RuleTypeId,
                                Value = x.Value

                            }
                        }).OrderBy(s => s.RuleSetting.DisplayOrder).ToListAsync();

                    result.RuleSettings = ObjectMapper.Map<List<GetRuleSettingForViewDto>>(ruleSettings);
                }
            }

            return result;
        }

    }
}