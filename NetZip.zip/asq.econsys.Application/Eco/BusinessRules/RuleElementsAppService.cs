﻿using Abp.Organizations;
using asq.econsys.Eco.BusinessRules;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.BusinessRules.Exporting;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.BusinessRules
{
    [AbpAuthorize(AppPermissions.Pages_Administration_RuleElements)]
    public class RuleElementsAppService : econsysAppServiceBase, IRuleElementsAppService
    {
        private readonly IRepository<RuleElement, long> _ruleElementRepository;
        private readonly IRuleElementsExcelExporter _ruleElementsExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IRepository<RuleType, string> _lookup_ruleTypeRepository;

        public RuleElementsAppService(IRepository<RuleElement, long> ruleElementRepository, IRuleElementsExcelExporter ruleElementsExcelExporter, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository, IRepository<RuleType, string> lookup_ruleTypeRepository)
        {
            _ruleElementRepository = ruleElementRepository;
            _ruleElementsExcelExporter = ruleElementsExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _lookup_ruleTypeRepository = lookup_ruleTypeRepository;

        }

        public async Task<PagedResultDto<GetRuleElementForViewDto>> GetAll(GetAllRuleElementsInput input)
        {
            PagedResultDto<GetRuleElementForViewDto> result = new PagedResultDto<GetRuleElementForViewDto>();
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var filteredRuleElements = _ruleElementRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.RuleTypeFk)
                        .Where(e => e.TenantId == AbpSession.TenantId)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.VariableName.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.VariableNameFilter), e => e.VariableName == input.VariableNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleTypeTitleFilter), e => e.RuleTypeFk != null && e.RuleTypeFk.Title == input.RuleTypeTitleFilter);

                    var pagedAndFilteredRuleElements = filteredRuleElements
                        .OrderBy(input.Sorting ?? "id asc")
                        .PageBy(input);

                    var ruleElements = from o in pagedAndFilteredRuleElements
                                       join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                                       from s1 in j1.DefaultIfEmpty()

                                       join o2 in _lookup_ruleTypeRepository.GetAll() on o.RuleTypeId equals o2.Id into j2
                                       from s2 in j2.DefaultIfEmpty()

                                       select new
                                       {

                                           o.Title,
                                           o.DisplayOrder,
                                           o.VariableName,
                                           Id = o.Id,
                                           OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                                           RuleTypeTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
                                       };

                    var totalCount = await filteredRuleElements.CountAsync();

                    var dbList = await ruleElements.ToListAsync();
                    var results = new List<GetRuleElementForViewDto>();

                    foreach (var o in dbList)
                    {
                        var res = new GetRuleElementForViewDto()
                        {
                            RuleElement = new RuleElementDto
                            {

                                Title = o.Title,
                                DisplayOrder = o.DisplayOrder,
                                VariableName = o.VariableName,
                                Id = o.Id,
                            },
                            OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
                            RuleTypeTitle = o.RuleTypeTitle
                        };

                        results.Add(res);
                    }

                    result = new PagedResultDto<GetRuleElementForViewDto>(
                        totalCount,
                        results
                    );
                }
            }

            return result;
        }

        public async Task<GetRuleElementForViewDto> GetRuleElementForView(long id)
        {
            var ruleElement = await _ruleElementRepository.GetAsync(id);

            var output = new GetRuleElementForViewDto { RuleElement = ObjectMapper.Map<RuleElementDto>(ruleElement) };

            if (output.RuleElement.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RuleElement.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.RuleElement.RuleTypeId != null)
            {
                var _lookupRuleType = await _lookup_ruleTypeRepository.FirstOrDefaultAsync((string)output.RuleElement.RuleTypeId);
                output.RuleTypeTitle = _lookupRuleType?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleElements_Edit)]
        public async Task<GetRuleElementForEditOutput> GetRuleElementForEdit(EntityDto<long> input)
        {
            var ruleElement = await _ruleElementRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRuleElementForEditOutput { RuleElement = ObjectMapper.Map<CreateOrEditRuleElementDto>(ruleElement) };

            if (output.RuleElement.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RuleElement.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.RuleElement.RuleTypeId != null)
            {
                var _lookupRuleType = await _lookup_ruleTypeRepository.FirstOrDefaultAsync((string)output.RuleElement.RuleTypeId);
                output.RuleTypeTitle = _lookupRuleType?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditRuleElementDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleElements_Create)]
        protected virtual async Task Create(CreateOrEditRuleElementDto input)
        {
            var ruleElement = ObjectMapper.Map<RuleElement>(input);

            if (AbpSession.TenantId != null)
            {
                ruleElement.TenantId = (int?)AbpSession.TenantId;
            }

            await _ruleElementRepository.InsertAsync(ruleElement);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleElements_Edit)]
        protected virtual async Task Update(CreateOrEditRuleElementDto input)
        {
            var ruleElement = await _ruleElementRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, ruleElement);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleElements_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _ruleElementRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetRuleElementsToExcel(GetAllRuleElementsForExcelInput input)
        {

            var filteredRuleElements = _ruleElementRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.RuleTypeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.VariableName.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.VariableNameFilter), e => e.VariableName == input.VariableNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleTypeTitleFilter), e => e.RuleTypeFk != null && e.RuleTypeFk.Title == input.RuleTypeTitleFilter);

            var query = (from o in filteredRuleElements
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_ruleTypeRepository.GetAll() on o.RuleTypeId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         select new GetRuleElementForViewDto()
                         {
                             RuleElement = new RuleElementDto
                             {
                                 Title = o.Title,
                                 DisplayOrder = o.DisplayOrder,
                                 VariableName = o.VariableName,
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                             RuleTypeTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
                         });

            var ruleElementListDtos = await query.ToListAsync();

            return _ruleElementsExcelExporter.ExportToFile(ruleElementListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleElements)]
        public async Task<List<RuleElementOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new RuleElementOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleElements)]
        public async Task<List<RuleElementRuleTypeLookupTableDto>> GetAllRuleTypeForTableDropdown()
        {
            using (CurrentUnitOfWork.SetTenantId(null))
            {
                return await _lookup_ruleTypeRepository.GetAll()
                    .Select(ruleType => new RuleElementRuleTypeLookupTableDto
                    {
                        Id = ruleType.Id,
                        DisplayName = ruleType == null || ruleType.Title == null ? "" : ruleType.Title.ToString()
                    }).ToListAsync();
            }
        }

        public async Task<List<RuleElement>> GetAllByProjectId(int id)
        {
            return await _ruleElementRepository.GetAll().ToListAsync();
        }
    }
}