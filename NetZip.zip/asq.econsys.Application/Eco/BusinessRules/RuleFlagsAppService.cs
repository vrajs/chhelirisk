﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.BusinessRules.Exporting;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules
{
    [AbpAuthorize(AppPermissions.Pages_Administration_RuleFlags)]
    public class RuleFlagsAppService : econsysAppServiceBase, IRuleFlagsAppService
    {
        private readonly IRepository<RuleFlag, string> _ruleFlagRepository;
        private readonly IRuleFlagsExcelExporter _ruleFlagsExcelExporter;

        public RuleFlagsAppService(IRepository<RuleFlag, string> ruleFlagRepository, IRuleFlagsExcelExporter ruleFlagsExcelExporter)
        {
            _ruleFlagRepository = ruleFlagRepository;
            _ruleFlagsExcelExporter = ruleFlagsExcelExporter;

        }

        public async Task<PagedResultDto<GetRuleFlagForViewDto>> GetAll(GetAllRuleFlagsInput input)
        {

            var filteredRuleFlags = _ruleFlagRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.HexColor.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HexColorFilter), e => e.HexColor == input.HexColorFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter);

            var pagedAndFilteredRuleFlags = filteredRuleFlags
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var ruleFlags = from o in pagedAndFilteredRuleFlags
                            select new
                            {

                                o.Title,
                                o.HexColor,
                                o.DisplayOrder,
                                Id = o.Id
                            };

            var totalCount = await filteredRuleFlags.CountAsync();

            var dbList = await ruleFlags.ToListAsync();
            var results = new List<GetRuleFlagForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetRuleFlagForViewDto()
                {
                    RuleFlag = new RuleFlagDto
                    {

                        Title = o.Title,
                        HexColor = o.HexColor,
                        DisplayOrder = o.DisplayOrder,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetRuleFlagForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetRuleFlagForViewDto> GetRuleFlagForView(string id)
        {
            var ruleFlag = await _ruleFlagRepository.GetAsync(id);

            var output = new GetRuleFlagForViewDto { RuleFlag = ObjectMapper.Map<RuleFlagDto>(ruleFlag) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleFlags_Edit)]
        public async Task<GetRuleFlagForEditOutput> GetRuleFlagForEdit(EntityDto<string> input)
        {
            var ruleFlag = await _ruleFlagRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRuleFlagForEditOutput { RuleFlag = ObjectMapper.Map<CreateOrEditRuleFlagDto>(ruleFlag) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditRuleFlagDto input)
        {
            if (input.Id.IsNullOrWhiteSpace())
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleFlags_Create)]
        protected virtual async Task Create(CreateOrEditRuleFlagDto input)
        {
            var ruleFlag = ObjectMapper.Map<RuleFlag>(input);

            if (AbpSession.TenantId != null)
            {
                ruleFlag.TenantId = (int?)AbpSession.TenantId;
            }

            if (ruleFlag.Id.IsNullOrWhiteSpace())
            {
                //ruleFlag.Id = Guid.NewGuid().ToString();
                ruleFlag.Id = input.Title.ToLower();
            }

            await _ruleFlagRepository.InsertAsync(ruleFlag);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleFlags_Edit)]
        protected virtual async Task Update(CreateOrEditRuleFlagDto input)
        {
            var ruleFlag = await _ruleFlagRepository.FirstOrDefaultAsync((string)input.Id);
            ObjectMapper.Map(input, ruleFlag);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleFlags_Delete)]
        public async Task Delete(EntityDto<string> input)
        {
            await _ruleFlagRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetRuleFlagsToExcel(GetAllRuleFlagsForExcelInput input)
        {

            var filteredRuleFlags = _ruleFlagRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.HexColor.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HexColorFilter), e => e.HexColor == input.HexColorFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter);

            var query = (from o in filteredRuleFlags
                         select new GetRuleFlagForViewDto()
                         {
                             RuleFlag = new RuleFlagDto
                             {
                                 Title = o.Title,
                                 HexColor = o.HexColor,
                                 DisplayOrder = o.DisplayOrder,
                                 Id = o.Id
                             }
                         });

            var ruleFlagListDtos = await query.ToListAsync();

            return _ruleFlagsExcelExporter.ExportToFile(ruleFlagListDtos);
        }

    }
}