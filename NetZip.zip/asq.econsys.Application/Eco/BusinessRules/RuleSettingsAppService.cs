﻿using asq.econsys.Eco.BusinessRules;
using Abp.Organizations;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.BusinessRules.Exporting;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules
{
    [AbpAuthorize(AppPermissions.Pages_RuleSettings)]
    public class RuleSettingsAppService : econsysAppServiceBase, IRuleSettingsAppService
    {
        private readonly IRepository<RuleSetting> _ruleSettingRepository;
        private readonly IRuleSettingsExcelExporter _ruleSettingsExcelExporter;
        private readonly IRepository<RuleType, string> _lookup_ruleTypeRepository;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;

        public RuleSettingsAppService(IRepository<RuleSetting> ruleSettingRepository, IRuleSettingsExcelExporter ruleSettingsExcelExporter, IRepository<RuleType, string> lookup_ruleTypeRepository, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository)
        {
            _ruleSettingRepository = ruleSettingRepository;
            _ruleSettingsExcelExporter = ruleSettingsExcelExporter;
            _lookup_ruleTypeRepository = lookup_ruleTypeRepository;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;

        }

        public async Task<PagedResultDto<GetRuleSettingForViewDto>> GetAll(GetAllRuleSettingsInput input)
        {

            var filteredRuleSettings = _ruleSettingRepository.GetAll()
                        .Include(e => e.RuleTypeFk)
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.Value.Contains(input.Filter) || e.FieldType.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ValueFilter), e => e.Value == input.ValueFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.FieldTypeFilter), e => e.FieldType == input.FieldTypeFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleTypeTitleFilter), e => e.RuleTypeFk != null && e.RuleTypeFk.Title == input.RuleTypeTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var pagedAndFilteredRuleSettings = filteredRuleSettings
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var ruleSettings = from o in pagedAndFilteredRuleSettings
                               join o1 in _lookup_ruleTypeRepository.GetAll() on o.RuleTypeId equals o1.Id into j1
                               from s1 in j1.DefaultIfEmpty()

                               join o2 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o2.Id into j2
                               from s2 in j2.DefaultIfEmpty()

                               select new
                               {

                                   o.Title,
                                   o.Value,
                                   o.FieldType,
                                   o.DisplayOrder,
                                   Id = o.Id,
                                   RuleTypeTitle = s1 == null || s1.Title == null ? "" : s1.Title.ToString(),
                                   OrganizationUnitDisplayName = s2 == null || s2.DisplayName == null ? "" : s2.DisplayName.ToString()
                               };

            var totalCount = await filteredRuleSettings.CountAsync();

            var dbList = await ruleSettings.ToListAsync();
            var results = new List<GetRuleSettingForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetRuleSettingForViewDto()
                {
                    RuleSetting = new RuleSettingDto
                    {

                        Title = o.Title,
                        Value = o.Value,
                        FieldType = o.FieldType,
                        DisplayOrder = o.DisplayOrder,
                        Id = o.Id,
                    },
                    RuleTypeTitle = o.RuleTypeTitle,
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetRuleSettingForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetRuleSettingForViewDto> GetRuleSettingForView(int id)
        {
            var ruleSetting = await _ruleSettingRepository.GetAsync(id);

            var output = new GetRuleSettingForViewDto { RuleSetting = ObjectMapper.Map<RuleSettingDto>(ruleSetting) };

            if (output.RuleSetting.RuleTypeId != null)
            {
                var _lookupRuleType = await _lookup_ruleTypeRepository.FirstOrDefaultAsync((string)output.RuleSetting.RuleTypeId);
                output.RuleTypeTitle = _lookupRuleType?.Title?.ToString();
            }

            if (output.RuleSetting.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RuleSetting.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_RuleSettings_Edit)]
        public async Task<GetRuleSettingForEditOutput> GetRuleSettingForEdit(EntityDto input)
        {
            var ruleSetting = await _ruleSettingRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRuleSettingForEditOutput { RuleSetting = ObjectMapper.Map<CreateOrEditRuleSettingDto>(ruleSetting) };

            if (output.RuleSetting.RuleTypeId != null)
            {
                var _lookupRuleType = await _lookup_ruleTypeRepository.FirstOrDefaultAsync((string)output.RuleSetting.RuleTypeId);
                output.RuleTypeTitle = _lookupRuleType?.Title?.ToString();
            }

            if (output.RuleSetting.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RuleSetting.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(IEnumerable<CreateOrEditRuleSettingDto> inputs)
        {
            foreach (var input in inputs)
            {
                if (input.Id == null)
                {
                    await Create(input);
                }
                else
                {
                    await Update(input);
                }
            }
        }

        [AbpAuthorize(AppPermissions.Pages_RuleSettings_Create)]
        protected virtual async Task Create(CreateOrEditRuleSettingDto input)
        {
            var ruleSetting = ObjectMapper.Map<RuleSetting>(input);

            if (AbpSession.TenantId != null)
            {
                ruleSetting.TenantId = (int?)AbpSession.TenantId;
            }

            await _ruleSettingRepository.InsertAsync(ruleSetting);

        }

        [AbpAuthorize(AppPermissions.Pages_RuleSettings_Edit)]
        protected virtual async Task Update(CreateOrEditRuleSettingDto input)
        {
            var ruleSetting = await _ruleSettingRepository.FirstOrDefaultAsync((int)input.Id);
            ObjectMapper.Map(input, ruleSetting);

        }

        [AbpAuthorize(AppPermissions.Pages_RuleSettings_Delete)]
        public async Task Delete(EntityDto input)
        {
            await _ruleSettingRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetRuleSettingsToExcel(GetAllRuleSettingsForExcelInput input)
        {

            var filteredRuleSettings = _ruleSettingRepository.GetAll()
                        .Include(e => e.RuleTypeFk)
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.Value.Contains(input.Filter) || e.FieldType.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ValueFilter), e => e.Value == input.ValueFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.FieldTypeFilter), e => e.FieldType == input.FieldTypeFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleTypeTitleFilter), e => e.RuleTypeFk != null && e.RuleTypeFk.Title == input.RuleTypeTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var query = (from o in filteredRuleSettings
                         join o1 in _lookup_ruleTypeRepository.GetAll() on o.RuleTypeId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         select new GetRuleSettingForViewDto()
                         {
                             RuleSetting = new RuleSettingDto
                             {
                                 Title = o.Title,
                                 Value = o.Value,
                                 FieldType = o.FieldType,
                                 DisplayOrder = o.DisplayOrder,
                                 Id = o.Id
                             },
                             RuleTypeTitle = s1 == null || s1.Title == null ? "" : s1.Title.ToString(),
                             OrganizationUnitDisplayName = s2 == null || s2.DisplayName == null ? "" : s2.DisplayName.ToString()
                         });

            var ruleSettingListDtos = await query.ToListAsync();

            return _ruleSettingsExcelExporter.ExportToFile(ruleSettingListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_RuleSettings)]
        public async Task<List<RuleSettingRuleTypeLookupTableDto>> GetAllRuleTypeForTableDropdown()
        {
            return await _lookup_ruleTypeRepository.GetAll()
                .Select(ruleType => new RuleSettingRuleTypeLookupTableDto
                {
                    Id = ruleType.Id,
                    DisplayName = ruleType == null || ruleType.Title == null ? "" : ruleType.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_RuleSettings)]
        public async Task<List<RuleSettingOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new RuleSettingOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

    }
}