﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.BusinessRules.Exporting;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules
{
    [AbpAuthorize(AppPermissions.Pages_Administration_RuleTypes)]
    public class RuleTypesAppService : econsysAppServiceBase, IRuleTypesAppService
    {
        private readonly IRepository<RuleType, string> _ruleTypeRepository;
        private readonly IRuleTypesExcelExporter _ruleTypesExcelExporter;

        public RuleTypesAppService(IRepository<RuleType, string> ruleTypeRepository, IRuleTypesExcelExporter ruleTypesExcelExporter)
        {
            _ruleTypeRepository = ruleTypeRepository;
            _ruleTypesExcelExporter = ruleTypesExcelExporter;

        }

        public async Task<PagedResultDto<GetRuleTypeForViewDto>> GetAll(GetAllRuleTypesInput input)
        {

            var filteredRuleTypes = _ruleTypeRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.OutputVariable.Contains(input.Filter) || e.StatusDetailsVariable.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OutputVariableFilter), e => e.OutputVariable == input.OutputVariableFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StatusDetailsVariableFilter), e => e.StatusDetailsVariable == input.StatusDetailsVariableFilter)
                        .WhereIf(input.IsRangeSpecificFilter.HasValue && input.IsRangeSpecificFilter > -1, e => (input.IsRangeSpecificFilter == 1 && e.IsRangeSpecific) || (input.IsRangeSpecificFilter == 0 && !e.IsRangeSpecific));

            var pagedAndFilteredRuleTypes = filteredRuleTypes
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var ruleTypes = from o in pagedAndFilteredRuleTypes
                            select new
                            {

                                o.Title,
                                o.DisplayOrder,
                                o.OutputVariable,
                                o.StatusDetailsVariable,
                                o.IsRangeSpecific,
                                Id = o.Id
                            };

            var totalCount = await filteredRuleTypes.CountAsync();

            var dbList = await ruleTypes.ToListAsync();
            var results = new List<GetRuleTypeForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetRuleTypeForViewDto()
                {
                    RuleType = new RuleTypeDto
                    {

                        Title = o.Title,
                        DisplayOrder = o.DisplayOrder,
                        OutputVariable = o.OutputVariable,
                        StatusDetailsVariable = o.StatusDetailsVariable,
                        IsRangeSpecific = o.IsRangeSpecific,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetRuleTypeForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetRuleTypeForViewDto> GetRuleTypeForView(string id)
        {
            var ruleType = await _ruleTypeRepository.GetAsync(id);

            var output = new GetRuleTypeForViewDto { RuleType = ObjectMapper.Map<RuleTypeDto>(ruleType) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleTypes_Edit)]
        public async Task<GetRuleTypeForEditOutput> GetRuleTypeForEdit(EntityDto<string> input)
        {
            var ruleType = await _ruleTypeRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRuleTypeForEditOutput { RuleType = ObjectMapper.Map<CreateOrEditRuleTypeDto>(ruleType) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditRuleTypeDto input)
        {
            if (input.Id.IsNullOrWhiteSpace())
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleTypes_Create)]
        protected virtual async Task Create(CreateOrEditRuleTypeDto input)
        {
            var ruleType = ObjectMapper.Map<RuleType>(input);

            if (AbpSession.TenantId != null)
            {
                ruleType.TenantId = (int?)AbpSession.TenantId;
            }

            if (ruleType.Id.IsNullOrWhiteSpace())
            {
                //ruleType.Id = Guid.NewGuid().ToString();
                ruleType.Id = input.Title.ToLower();
            }

            await _ruleTypeRepository.InsertAsync(ruleType);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleTypes_Edit)]
        protected virtual async Task Update(CreateOrEditRuleTypeDto input)
        {
            var ruleType = await _ruleTypeRepository.FirstOrDefaultAsync((string)input.Id);
            ObjectMapper.Map(input, ruleType);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleTypes_Delete)]
        public async Task Delete(EntityDto<string> input)
        {
            await _ruleTypeRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetRuleTypesToExcel(GetAllRuleTypesForExcelInput input)
        {

            var filteredRuleTypes = _ruleTypeRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.OutputVariable.Contains(input.Filter) || e.StatusDetailsVariable.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OutputVariableFilter), e => e.OutputVariable == input.OutputVariableFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StatusDetailsVariableFilter), e => e.StatusDetailsVariable == input.StatusDetailsVariableFilter)
                        .WhereIf(input.IsRangeSpecificFilter.HasValue && input.IsRangeSpecificFilter > -1, e => (input.IsRangeSpecificFilter == 1 && e.IsRangeSpecific) || (input.IsRangeSpecificFilter == 0 && !e.IsRangeSpecific));

            var query = (from o in filteredRuleTypes
                         select new GetRuleTypeForViewDto()
                         {
                             RuleType = new RuleTypeDto
                             {
                                 Title = o.Title,
                                 DisplayOrder = o.DisplayOrder,
                                 OutputVariable = o.OutputVariable,
                                 StatusDetailsVariable = o.StatusDetailsVariable,
                                 IsRangeSpecific = o.IsRangeSpecific,
                                 Id = o.Id
                             }
                         });

            var ruleTypeListDtos = await query.ToListAsync();

            return _ruleTypesExcelExporter.ExportToFile(ruleTypeListDtos);
        }

    }
}