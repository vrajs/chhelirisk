﻿using Abp.Organizations;
using asq.econsys.Eco.BusinessRules;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.BusinessRules.Exporting;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.BusinessRules
{
    [AbpAuthorize(AppPermissions.Pages_Administration_RuleValues)]
    public class RuleValuesAppService : econsysAppServiceBase, IRuleValuesAppService
    {
        private readonly IRepository<RuleValue, long> _ruleValueRepository;
        private readonly IRuleValuesExcelExporter _ruleValuesExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IRepository<RuleType, string> _lookup_ruleTypeRepository;
        private readonly IRepository<RuleElement, long> _lookup_ruleElementRepository;

        public RuleValuesAppService(IRepository<RuleValue, long> ruleValueRepository, IRuleValuesExcelExporter ruleValuesExcelExporter, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository, IRepository<RuleType, string> lookup_ruleTypeRepository, IRepository<RuleElement, long> lookup_ruleElementRepository)
        {
            _ruleValueRepository = ruleValueRepository;
            _ruleValuesExcelExporter = ruleValuesExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _lookup_ruleTypeRepository = lookup_ruleTypeRepository;
            _lookup_ruleElementRepository = lookup_ruleElementRepository;

        }

        public async Task<PagedResultDto<GetRuleValueForViewDto>> GetAll(GetAllRuleValuesInput input)
        {

            var filteredRuleValues = _ruleValueRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.RuleTypeFk)
                        .Include(e => e.RuleElementFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(input.IsRangeSpecificFilter.HasValue && input.IsRangeSpecificFilter > -1, e => (input.IsRangeSpecificFilter == 1 && e.IsRangeSpecific) || (input.IsRangeSpecificFilter == 0 && !e.IsRangeSpecific))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleTypeTitleFilter), e => e.RuleTypeFk != null && e.RuleTypeFk.Title == input.RuleTypeTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleElementTitleFilter), e => e.RuleElementFk != null && e.RuleElementFk.Title == input.RuleElementTitleFilter);

            var pagedAndFilteredRuleValues = filteredRuleValues
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var ruleValues = from o in pagedAndFilteredRuleValues
                             join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                             from s1 in j1.DefaultIfEmpty()

                             join o2 in _lookup_ruleTypeRepository.GetAll() on o.RuleTypeId equals o2.Id into j2
                             from s2 in j2.DefaultIfEmpty()

                             join o3 in _lookup_ruleElementRepository.GetAll() on o.RuleElementId equals o3.Id into j3
                             from s3 in j3.DefaultIfEmpty()

                             select new
                             {

                                 o.Title,
                                 o.DisplayOrder,
                                 o.IsRangeSpecific,
                                 Id = o.Id,
                                 OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                                 RuleTypeTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                                 RuleElementTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
                             };

            var totalCount = await filteredRuleValues.CountAsync();

            var dbList = await ruleValues.ToListAsync();
            var results = new List<GetRuleValueForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetRuleValueForViewDto()
                {
                    RuleValue = new RuleValueDto
                    {

                        Title = o.Title,
                        DisplayOrder = o.DisplayOrder,
                        IsRangeSpecific = o.IsRangeSpecific,
                        Id = o.Id,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
                    RuleTypeTitle = o.RuleTypeTitle,
                    RuleElementTitle = o.RuleElementTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetRuleValueForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetRuleValueForViewDto> GetRuleValueForView(long id)
        {
            var ruleValue = await _ruleValueRepository.GetAsync(id);

            var output = new GetRuleValueForViewDto { RuleValue = ObjectMapper.Map<RuleValueDto>(ruleValue) };

            if (output.RuleValue.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RuleValue.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.RuleValue.RuleTypeId != null)
            {
                var _lookupRuleType = await _lookup_ruleTypeRepository.FirstOrDefaultAsync((string)output.RuleValue.RuleTypeId);
                output.RuleTypeTitle = _lookupRuleType?.Title?.ToString();
            }

            if (output.RuleValue.RuleElementId != null)
            {
                var _lookupRuleElement = await _lookup_ruleElementRepository.FirstOrDefaultAsync((long)output.RuleValue.RuleElementId);
                output.RuleElementTitle = _lookupRuleElement?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleValues_Edit)]
        public async Task<GetRuleValueForEditOutput> GetRuleValueForEdit(EntityDto<long> input)
        {
            var ruleValue = await _ruleValueRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRuleValueForEditOutput { RuleValue = ObjectMapper.Map<CreateOrEditRuleValueDto>(ruleValue) };

            if (output.RuleValue.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RuleValue.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.RuleValue.RuleTypeId != null)
            {
                var _lookupRuleType = await _lookup_ruleTypeRepository.FirstOrDefaultAsync((string)output.RuleValue.RuleTypeId);
                output.RuleTypeTitle = _lookupRuleType?.Title?.ToString();
            }

            if (output.RuleValue.RuleElementId != null)
            {
                var _lookupRuleElement = await _lookup_ruleElementRepository.FirstOrDefaultAsync((long)output.RuleValue.RuleElementId);
                output.RuleElementTitle = _lookupRuleElement?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditRuleValueDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleValues_Create)]
        protected virtual async Task Create(CreateOrEditRuleValueDto input)
        {
            var ruleValue = ObjectMapper.Map<RuleValue>(input);

            if (AbpSession.TenantId != null)
            {
                ruleValue.TenantId = (int?)AbpSession.TenantId;
            }

            await _ruleValueRepository.InsertAsync(ruleValue);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleValues_Edit)]
        protected virtual async Task Update(CreateOrEditRuleValueDto input)
        {
            var ruleValue = await _ruleValueRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, ruleValue);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleValues_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _ruleValueRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetRuleValuesToExcel(GetAllRuleValuesForExcelInput input)
        {

            var filteredRuleValues = _ruleValueRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.RuleTypeFk)
                        .Include(e => e.RuleElementFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(input.IsRangeSpecificFilter.HasValue && input.IsRangeSpecificFilter > -1, e => (input.IsRangeSpecificFilter == 1 && e.IsRangeSpecific) || (input.IsRangeSpecificFilter == 0 && !e.IsRangeSpecific))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleTypeTitleFilter), e => e.RuleTypeFk != null && e.RuleTypeFk.Title == input.RuleTypeTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleElementTitleFilter), e => e.RuleElementFk != null && e.RuleElementFk.Title == input.RuleElementTitleFilter);

            var query = (from o in filteredRuleValues
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_ruleTypeRepository.GetAll() on o.RuleTypeId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_ruleElementRepository.GetAll() on o.RuleElementId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         select new GetRuleValueForViewDto()
                         {
                             RuleValue = new RuleValueDto
                             {
                                 Title = o.Title,
                                 DisplayOrder = o.DisplayOrder,
                                 IsRangeSpecific = o.IsRangeSpecific,
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                             RuleTypeTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                             RuleElementTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
                         });

            var ruleValueListDtos = await query.ToListAsync();

            return _ruleValuesExcelExporter.ExportToFile(ruleValueListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleValues)]
        public async Task<List<RuleValueOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new RuleValueOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleValues)]
        public async Task<List<RuleValueRuleTypeLookupTableDto>> GetAllRuleTypeForTableDropdown()
        {
            using (CurrentUnitOfWork.SetTenantId(null))
            {
                return await _lookup_ruleTypeRepository.GetAll()
                    .Select(ruleType => new RuleValueRuleTypeLookupTableDto
                    {
                        Id = ruleType.Id,
                        DisplayName = ruleType == null || ruleType.Title == null ? "" : ruleType.Title.ToString()
                    }).ToListAsync();
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RuleValues)]
        public async Task<List<RuleValueRuleElementLookupTableDto>> GetAllRuleElementForTableDropdown()
        {
            return await _lookup_ruleElementRepository.GetAll()
                .Select(ruleElement => new RuleValueRuleElementLookupTableDto
                {
                    Id = ruleElement.Id,
                    DisplayName = ruleElement == null || ruleElement.Title == null ? "" : ruleElement.Title.ToString()
                }).ToListAsync();
        }

    }
}