﻿using asq.econsys.Eco.Customers;
using Abp.Organizations;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Customers.Exporting;
using asq.econsys.Eco.Customers.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Domain.Uow;
using Abp.EntityFrameworkCore.EFPlus;

namespace asq.econsys.Eco.Customers
{
    [AbpAuthorize(AppPermissions.Pages_ContactPersons)]
    public class ContactPersonsAppService : econsysAppServiceBase, IContactPersonsAppService
    {
        private readonly IRepository<ContactPerson, long> _contactPersonRepository;
        private readonly IContactPersonsExcelExporter _contactPersonsExcelExporter;
        private readonly IRepository<Customer, long> _lookup_customerRepository;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;

        public ContactPersonsAppService(IRepository<ContactPerson, long> contactPersonRepository, IContactPersonsExcelExporter contactPersonsExcelExporter, IRepository<Customer, long> lookup_customerRepository, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository)
        {
            _contactPersonRepository = contactPersonRepository;
            _contactPersonsExcelExporter = contactPersonsExcelExporter;
            _lookup_customerRepository = lookup_customerRepository;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;

        }

        public async Task<PagedResultDto<GetContactPersonForViewDto>> GetAll(GetAllContactPersonsInput input)
        {

            var filteredContactPersons = _contactPersonRepository.GetAll()
                        .Include(e => e.CustomerFk)
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.Email.Contains(input.Filter) || e.Phone.Contains(input.Filter) || e.Role.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.EmailFilter), e => e.Email == input.EmailFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PhoneFilter), e => e.Phone == input.PhoneFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RoleFilter), e => e.Role == input.RoleFilter)
                        .WhereIf(input.IsPrimaryFilter.HasValue && input.IsPrimaryFilter > -1, e => (input.IsPrimaryFilter == 1 && e.IsPrimary) || (input.IsPrimaryFilter == 0 && !e.IsPrimary))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerNameFilter), e => e.CustomerFk != null && e.CustomerFk.Name == input.CustomerNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(input.CustomerIdFilter.HasValue, e => false || e.CustomerId == input.CustomerIdFilter.Value);

            var pagedAndFilteredContactPersons = filteredContactPersons
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var contactPersons = from o in pagedAndFilteredContactPersons
                                 join o1 in _lookup_customerRepository.GetAll() on o.CustomerId equals o1.Id into j1
                                 from s1 in j1.DefaultIfEmpty()

                                 join o2 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o2.Id into j2
                                 from s2 in j2.DefaultIfEmpty()

                                 select new
                                 {

                                     o.Name,
                                     o.Email,
                                     o.Phone,
                                     o.Role,
                                     o.IsPrimary,
                                     Id = o.Id,
                                     CustomerName = s1 == null || s1.Name == null ? "" : s1.Name.ToString(),
                                     OrganizationUnitDisplayName = s2 == null || s2.DisplayName == null ? "" : s2.DisplayName.ToString()
                                 };

            var totalCount = await filteredContactPersons.CountAsync();

            var dbList = await contactPersons.ToListAsync();
            var results = new List<GetContactPersonForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetContactPersonForViewDto()
                {
                    ContactPerson = new ContactPersonDto
                    {

                        Name = o.Name,
                        Email = o.Email,
                        Phone = o.Phone,
                        Role = o.Role,
                        IsPrimary = o.IsPrimary,
                        Id = o.Id,
                    },
                    CustomerName = o.CustomerName,
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetContactPersonForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetContactPersonForViewDto> GetContactPersonForView(long id)
        {
            var contactPerson = await _contactPersonRepository.GetAsync(id);

            var output = new GetContactPersonForViewDto { ContactPerson = ObjectMapper.Map<ContactPersonDto>(contactPerson) };

            if (output.ContactPerson.CustomerId != null)
            {
                var _lookupCustomer = await _lookup_customerRepository.FirstOrDefaultAsync((long)output.ContactPerson.CustomerId);
                output.CustomerName = _lookupCustomer?.Name?.ToString();
            }

            if (output.ContactPerson.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.ContactPerson.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ContactPersons_Edit)]
        public async Task<GetContactPersonForEditOutput> GetContactPersonForEdit(EntityDto<long> input)
        {
            var contactPerson = await _contactPersonRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetContactPersonForEditOutput { ContactPerson = ObjectMapper.Map<CreateOrEditContactPersonDto>(contactPerson) };

            if (output.ContactPerson.CustomerId != null)
            {
                var _lookupCustomer = await _lookup_customerRepository.FirstOrDefaultAsync((long)output.ContactPerson.CustomerId);
                output.CustomerName = _lookupCustomer?.Name?.ToString();
            }

            if (output.ContactPerson.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.ContactPerson.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditContactPersonDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ContactPersons_Create)]
        protected virtual async Task Create(CreateOrEditContactPersonDto input)
        {
            try
            {
                var contactPerson = ObjectMapper.Map<ContactPerson>(input);

                if (AbpSession.TenantId != null)
                {
                    contactPerson.TenantId = (int?)AbpSession.TenantId;
                }

                await _contactPersonRepository.InsertAndGetIdAsync(contactPerson);
            }
            catch (Exception ex)
            {

                throw;
            }

            

        }

        [AbpAuthorize(AppPermissions.Pages_ContactPersons_Edit)]
        protected virtual async Task Update(CreateOrEditContactPersonDto input)
        {
            var contactPerson = await _contactPersonRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, contactPerson);

        }

        [AbpAuthorize(AppPermissions.Pages_ContactPersons_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _contactPersonRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetContactPersonsToExcel(GetAllContactPersonsForExcelInput input)
        {

            var filteredContactPersons = _contactPersonRepository.GetAll()
                        .Include(e => e.CustomerFk)
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.Email.Contains(input.Filter) || e.Phone.Contains(input.Filter) || e.Role.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.EmailFilter), e => e.Email == input.EmailFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PhoneFilter), e => e.Phone == input.PhoneFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RoleFilter), e => e.Role == input.RoleFilter)
                        .WhereIf(input.IsPrimaryFilter.HasValue && input.IsPrimaryFilter > -1, e => (input.IsPrimaryFilter == 1 && e.IsPrimary) || (input.IsPrimaryFilter == 0 && !e.IsPrimary))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerNameFilter), e => e.CustomerFk != null && e.CustomerFk.Name == input.CustomerNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var query = (from o in filteredContactPersons
                         join o1 in _lookup_customerRepository.GetAll() on o.CustomerId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         select new GetContactPersonForViewDto()
                         {
                             ContactPerson = new ContactPersonDto
                             {
                                 Name = o.Name,
                                 Email = o.Email,
                                 Phone = o.Phone,
                                 Role = o.Role,
                                 IsPrimary = o.IsPrimary,
                                 Id = o.Id
                             },
                             CustomerName = s1 == null || s1.Name == null ? "" : s1.Name.ToString(),
                             OrganizationUnitDisplayName = s2 == null || s2.DisplayName == null ? "" : s2.DisplayName.ToString()
                         });

            var contactPersonListDtos = await query.ToListAsync();

            return _contactPersonsExcelExporter.ExportToFile(contactPersonListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ContactPersons)]
        public async Task<List<ContactPersonCustomerLookupTableDto>> GetAllCustomerForTableDropdown()
        {
            return await _lookup_customerRepository.GetAll()
                .Select(customer => new ContactPersonCustomerLookupTableDto
                {
                    Id = customer.Id,
                    DisplayName = customer == null || customer.Name == null ? "" : customer.Name.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ContactPersons)]
        public async Task<List<ContactPersonOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new ContactPersonOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        public async Task<List<CreateOrEditContactPersonDto>> GetCustomerContactPerson(long customerId)
        {
            List<CreateOrEditContactPersonDto> result = new List<CreateOrEditContactPersonDto>();
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    result = await _contactPersonRepository.GetAll().Where(e => e.CustomerId == customerId && e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                       .Select(customer => new CreateOrEditContactPersonDto
                       {
                           Id = customer.Id,
                           Name = customer.Name,
                           Email = customer.Email,
                           Phone = customer.Phone,
                           Role = customer.Role,
                           IsPrimary = customer.IsPrimary,
                           CustomerId = customer.CustomerId,
                           OrganizationUnitId = customer.OrganizationUnitId,
                       }).ToListAsync();
                }
            }
            return result;

        }

        public async Task CreateOrEditCustomerContactPerson(List<CreateOrEditContactPersonDto> inputs)
        {
           foreach (var input in inputs)
            {
                try
                {
                    if (input.Id == null)
                    {
                        await Create(input);
                    }
                    else
                    {
                        
                        await Update(input);
                    }
                }
                catch (Exception ex)
                {

                    throw;
                }
                
            }
        }

        public async Task DeleteCustomerContact(long customerId)
        {
            using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.SoftDelete))
            {
                 await _contactPersonRepository.BatchDeleteAsync(e => e.CustomerId == customerId);
            }
        }
    }
}