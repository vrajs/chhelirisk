﻿using Abp.Organizations;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Customers.Exporting;
using asq.econsys.Eco.Customers.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Domain.Uow;
using System.Transactions;

namespace asq.econsys.Eco.Customers
{
    [AbpAuthorize(AppPermissions.Pages_Customers)]
    public class CustomersAppService : econsysAppServiceBase, ICustomersAppService
    {
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly IRepository<Customer, long> _customerRepository;
        private readonly ICustomersExcelExporter _customersExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IContactPersonsAppService _contactPersonsAppService;
        private readonly IRepository<ContactPerson, long> _contactPersonRepository;
        public CustomersAppService(IUnitOfWorkManager unitOfWorkManager, IRepository<Customer, long> customerRepository, ICustomersExcelExporter customersExcelExporter, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository
            , IContactPersonsAppService contactPersonsAppService, IRepository<ContactPerson, long> contactPersonRepository)
        {
            _unitOfWorkManager = unitOfWorkManager;
            _customerRepository = customerRepository;
            _customersExcelExporter = customersExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _contactPersonsAppService = contactPersonsAppService;
            _contactPersonRepository = contactPersonRepository;
        }

        public async Task<List<GetCustomerForViewDto>> GetCustomers()
        {
            var filteredCustomers = _customerRepository.GetAll();
            var totalCount = await filteredCustomers.CountAsync();
            var customers = from o in filteredCustomers
                            join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                            from s1 in j1.DefaultIfEmpty()

                            select new
                            {

                                o.Name,
                                o.Email,
                                o.Phone,
                                o.Address1,
                                o.Address2,
                                o.PostalCode,
                                o.Source,
                                o.Branch,
                                o.RuleFlagId,
                                o.IsRebate,
                                o.RebateDetail,
                                o.CreditLimit,
                                o.StringField1,
                                o.Stringfield2,
                                o.StringField3,
                                o.StringField4,
                                o.StringField5,
                                o.DecimalField1,
                                o.DecimalField2,
                                o.DecimalField3,
                                o.DecimalField4,
                                o.DecimalField5,
                                o.DateField1,
                                o.DateField2,
                                o.DateField3,
                                o.DateField4,
                                o.DateField5,
                                Id = o.Id,
                                OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                            };
            var dbList = await customers.ToListAsync();
            var results = new List<GetCustomerForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetCustomerForViewDto()
                {
                    Customer = new CustomerDto
                    {

                        Name = o.Name,
                        Email = o.Email,
                        Phone = o.Phone,
                        Address1 = o.Address1,
                        Address2 = o.Address2,
                        PostalCode = o.PostalCode,
                        Source = o.Source,
                        Branch = o.Branch,
                        RuleFlagId = o.RuleFlagId,
                        IsRebate = o.IsRebate,
                        RebateDetail = o.RebateDetail,
                        CreditLimit = o.CreditLimit,
                        StringField1 = o.StringField1,
                        Stringfield2 = o.Stringfield2,
                        StringField3 = o.StringField3,
                        StringField4 = o.StringField4,
                        StringField5 = o.StringField5,
                        DecimalField1 = o.DecimalField1,
                        DecimalField2 = o.DecimalField2,
                        DecimalField3 = o.DecimalField3,
                        DecimalField4 = o.DecimalField4,
                        DecimalField5 = o.DecimalField5,
                        DateField1 = o.DateField1,
                        DateField2 = o.DateField2,
                        DateField3 = o.DateField3,
                        DateField4 = o.DateField4,
                        DateField5 = o.DateField5,
                        Id = o.Id,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName
                };

                results.Add(res);
            }

            return results;

        }
        public async Task<PagedResultDto<GetCustomerForViewDto>> GetAll(GetAllCustomersInput input)
        {

            var filteredCustomers = _customerRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.Email.Contains(input.Filter) || e.Address1.Contains(input.Filter) || e.PostalCode.Contains(input.Filter) || e.Source.Contains(input.Filter) || e.Branch.Contains(input.Filter) || e.RuleFlagId.Contains(input.Filter) || e.RebateDetail.Contains(input.Filter) || e.StringField1.Contains(input.Filter) || e.Stringfield2.Contains(input.Filter) || e.StringField3.Contains(input.Filter) || e.StringField4.Contains(input.Filter) || e.StringField5.Contains(input.Filter) || e.Phone.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.EmailFilter), e => e.Email == input.EmailFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PhoneFilter), e => e.Phone == input.PhoneFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Address1Filter), e => e.Address1 == input.Address1Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PostalCodeFilter), e => e.PostalCode == input.PostalCodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SourceFilter), e => e.Source == input.SourceFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.BranchFilter), e => e.Branch == input.BranchFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagIdFilter), e => e.RuleFlagId == input.RuleFlagIdFilter)
                        .WhereIf(input.IsRebateFilter.HasValue && input.IsRebateFilter > -1, e => (input.IsRebateFilter == 1 && e.IsRebate) || (input.IsRebateFilter == 0 && !e.IsRebate))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RebateDetailFilter), e => e.RebateDetail == input.RebateDetailFilter)
                        .WhereIf(input.MinCreditLimitFilter != null, e => e.CreditLimit >= input.MinCreditLimitFilter)
                        .WhereIf(input.MaxCreditLimitFilter != null, e => e.CreditLimit <= input.MaxCreditLimitFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StringField1Filter), e => e.StringField1 == input.StringField1Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Stringfield2Filter), e => e.Stringfield2 == input.Stringfield2Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StringField3Filter), e => e.StringField3 == input.StringField3Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StringField4Filter), e => e.StringField4 == input.StringField4Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StringField5Filter), e => e.StringField5 == input.StringField5Filter)
                        .WhereIf(input.MinDecimalField1Filter != null, e => e.DecimalField1 >= input.MinDecimalField1Filter)
                        .WhereIf(input.MaxDecimalField1Filter != null, e => e.DecimalField1 <= input.MaxDecimalField1Filter)
                        .WhereIf(input.MinDecimalField2Filter != null, e => e.DecimalField2 >= input.MinDecimalField2Filter)
                        .WhereIf(input.MaxDecimalField2Filter != null, e => e.DecimalField2 <= input.MaxDecimalField2Filter)
                        .WhereIf(input.MinDecimalField3Filter != null, e => e.DecimalField3 >= input.MinDecimalField3Filter)
                        .WhereIf(input.MaxDecimalField3Filter != null, e => e.DecimalField3 <= input.MaxDecimalField3Filter)
                        .WhereIf(input.MinDecimalField4Filter != null, e => e.DecimalField4 >= input.MinDecimalField4Filter)
                        .WhereIf(input.MaxDecimalField4Filter != null, e => e.DecimalField4 <= input.MaxDecimalField4Filter)
                        .WhereIf(input.MinDecimalField5Filter != null, e => e.DecimalField5 >= input.MinDecimalField5Filter)
                        .WhereIf(input.MaxDecimalField5Filter != null, e => e.DecimalField5 <= input.MaxDecimalField5Filter)
                        .WhereIf(input.MinDateField1Filter != null, e => e.DateField1 >= input.MinDateField1Filter)
                        .WhereIf(input.MaxDateField1Filter != null, e => e.DateField1 <= input.MaxDateField1Filter)
                        .WhereIf(input.MinDateField2Filter != null, e => e.DateField2 >= input.MinDateField2Filter)
                        .WhereIf(input.MaxDateField2Filter != null, e => e.DateField2 <= input.MaxDateField2Filter)
                        .WhereIf(input.MinDateField3Filter != null, e => e.DateField3 >= input.MinDateField3Filter)
                        .WhereIf(input.MaxDateField3Filter != null, e => e.DateField3 <= input.MaxDateField3Filter)
                        .WhereIf(input.MinDateField4Filter != null, e => e.DateField4 >= input.MinDateField4Filter)
                        .WhereIf(input.MaxDateField4Filter != null, e => e.DateField4 <= input.MaxDateField4Filter)
                        .WhereIf(input.MinDateField5Filter != null, e => e.DateField5 >= input.MinDateField5Filter)
                        .WhereIf(input.MaxDateField5Filter != null, e => e.DateField5 <= input.MaxDateField5Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var pagedAndFilteredCustomers = filteredCustomers
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var customers = from o in pagedAndFilteredCustomers
                            join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                            from s1 in j1.DefaultIfEmpty()

                            select new
                            {

                                o.Name,
                                o.Email,
                                o.Phone,
                                o.Address1,
                                o.Address2,
                                o.PostalCode,
                                o.Source,
                                o.Branch,
                                o.RuleFlagId,
                                o.IsRebate,
                                o.RebateDetail,
                                o.CreditLimit,
                                o.StringField1,
                                o.Stringfield2,
                                o.StringField3,
                                o.StringField4,
                                o.StringField5,
                                o.DecimalField1,
                                o.DecimalField2,
                                o.DecimalField3,
                                o.DecimalField4,
                                o.DecimalField5,
                                o.DateField1,
                                o.DateField2,
                                o.DateField3,
                                o.DateField4,
                                o.DateField5,
                                Id = o.Id,
                                OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                            };

            var totalCount = await filteredCustomers.CountAsync();

            var dbList = await customers.ToListAsync();
            var results = new List<GetCustomerForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetCustomerForViewDto()
                {
                    Customer = new CustomerDto
                    {

                        Name = o.Name,
                        Email = o.Email,
                        Phone = o.Phone,
                        Address1 = o.Address1,
                        Address2 = o.Address2,
                        PostalCode = o.PostalCode,
                        Source = o.Source,
                        Branch = o.Branch,
                        RuleFlagId = o.RuleFlagId,
                        IsRebate = o.IsRebate,
                        RebateDetail = o.RebateDetail,
                        CreditLimit = o.CreditLimit,
                        StringField1 = o.StringField1,
                        Stringfield2 = o.Stringfield2,
                        StringField3 = o.StringField3,
                        StringField4 = o.StringField4,
                        StringField5 = o.StringField5,
                        DecimalField1 = o.DecimalField1,
                        DecimalField2 = o.DecimalField2,
                        DecimalField3 = o.DecimalField3,
                        DecimalField4 = o.DecimalField4,
                        DecimalField5 = o.DecimalField5,
                        DateField1 = o.DateField1,
                        DateField2 = o.DateField2,
                        DateField3 = o.DateField3,
                        DateField4 = o.DateField4,
                        DateField5 = o.DateField5,
                        Id = o.Id,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetCustomerForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetCustomerForViewDto> GetCustomerForView(long id)
        {
            var customer = await _customerRepository.GetAsync(id);

            var output = new GetCustomerForViewDto { Customer = ObjectMapper.Map<CustomerDto>(customer) };

            if (output.Customer.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.Customer.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Customers_Edit)]
        public async Task<GetCustomerForEditOutput> GetCustomerForEdit(EntityDto<long> input)
        {
         
            var customer = await _customerRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetCustomerForEditOutput { Customer = ObjectMapper.Map<CreateOrEditCustomerDto>(customer) };

            if (output.Customer.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.Customer.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        public async Task<long> CreateOrEdit(CreateOrEditCustomerDto input)
        {
            long insertedCustomerId = 0;
            if (input.Id == null)
            {
                insertedCustomerId = await Create(input);
            }
            else
            {
                insertedCustomerId = await Update(input);
            }

            return insertedCustomerId;
        }

        [AbpAuthorize(AppPermissions.Pages_Customers_Create)]
        protected virtual async Task<long> Create(CreateOrEditCustomerDto input)
        {
            var customer = ObjectMapper.Map<Customer>(input);

            if (AbpSession.TenantId != null)
            {
                customer.TenantId = (int?)AbpSession.TenantId;
            }

            //return _customerRepository.InsertAndGetId(customer);

            using (var uow = _unitOfWorkManager.Begin(TransactionScopeOption.RequiresNew))
            {
                var customerId = _customerRepository.InsertAndGetId(customer);

                if (input.ContactPersons!= null && input.ContactPersons.Count > 0)
                {
                    foreach (var item in input.ContactPersons)
                    {
                        try
                        {
                            if (item.Id == null)
                            {
                                var contactPerson = ObjectMapper.Map<ContactPerson>(item);
                                contactPerson.CustomerId = customerId;

                                if (AbpSession.TenantId != null)
                                {
                                    contactPerson.TenantId = (int?)AbpSession.TenantId;
                                }

                                await _contactPersonRepository.InsertAndGetIdAsync(contactPerson);
                            }
                            else
                            {
                                var contactPerson = await _contactPersonRepository.FirstOrDefaultAsync((long)item.Id);
                                contactPerson.CustomerId = customerId;
                                ObjectMapper.Map(item, contactPerson);
                            }
                        }
                        catch (Exception ex)
                        {

                            throw;
                        }
                    }
                }
                uow.Complete();

                return customerId;
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Customers_Edit)]
        protected virtual async Task<long> Update(CreateOrEditCustomerDto input)
        {
            var customer = await _customerRepository.FirstOrDefaultAsync((long)input.Id);

            using (var uow = _unitOfWorkManager.Begin(TransactionScopeOption.RequiresNew))
            {
                ObjectMapper.Map(input, customer);

                if (input.ContactPersons.Count > 0)
                {
                    foreach (var item in input.ContactPersons)
                    {
                        try
                        {
                            if (item.Id == null)
                            {
                                var contactPerson = ObjectMapper.Map<ContactPerson>(item);
                                contactPerson.CustomerId = customer.Id;

                                if (AbpSession.TenantId != null)
                                {
                                    contactPerson.TenantId = (int?)AbpSession.TenantId;
                                }

                                await _contactPersonRepository.InsertAndGetIdAsync(contactPerson);
                            }
                            else
                            {
                                var contactPerson = await _contactPersonRepository.FirstOrDefaultAsync((long)item.Id);
                                contactPerson.CustomerId = customer.Id;
                                ObjectMapper.Map(item, contactPerson);
                            }
                        }
                        catch (Exception ex)
                        {

                            throw;
                        }
                    }
                }
                uow.Complete();
            }

            return customer.Id;
        }

        [AbpAuthorize(AppPermissions.Pages_Customers_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _contactPersonsAppService.DeleteCustomerContact(input.Id);
            await _customerRepository.DeleteAsync(input.Id);            
        }

        public async Task<FileDto> GetCustomersToExcel(GetAllCustomersForExcelInput input)
        {

            var filteredCustomers = _customerRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.Email.Contains(input.Filter) || e.Address1.Contains(input.Filter) || e.PostalCode.Contains(input.Filter) || e.Source.Contains(input.Filter) || e.Branch.Contains(input.Filter) || e.RuleFlagId.Contains(input.Filter) || e.RebateDetail.Contains(input.Filter) || e.StringField1.Contains(input.Filter) || e.Stringfield2.Contains(input.Filter) || e.StringField3.Contains(input.Filter) || e.StringField4.Contains(input.Filter) || e.StringField5.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.EmailFilter), e => e.Email == input.EmailFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Address1Filter), e => e.Address1 == input.Address1Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PostalCodeFilter), e => e.PostalCode == input.PostalCodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SourceFilter), e => e.Source == input.SourceFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.BranchFilter), e => e.Branch == input.BranchFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagIdFilter), e => e.RuleFlagId == input.RuleFlagIdFilter)
                        .WhereIf(input.IsRebateFilter.HasValue && input.IsRebateFilter > -1, e => (input.IsRebateFilter == 1 && e.IsRebate) || (input.IsRebateFilter == 0 && !e.IsRebate))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RebateDetailFilter), e => e.RebateDetail == input.RebateDetailFilter)
                        .WhereIf(input.MinCreditLimitFilter != null, e => e.CreditLimit >= input.MinCreditLimitFilter)
                        .WhereIf(input.MaxCreditLimitFilter != null, e => e.CreditLimit <= input.MaxCreditLimitFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StringField1Filter), e => e.StringField1 == input.StringField1Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Stringfield2Filter), e => e.Stringfield2 == input.Stringfield2Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StringField3Filter), e => e.StringField3 == input.StringField3Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StringField4Filter), e => e.StringField4 == input.StringField4Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StringField5Filter), e => e.StringField5 == input.StringField5Filter)
                        .WhereIf(input.MinDecimalField1Filter != null, e => e.DecimalField1 >= input.MinDecimalField1Filter)
                        .WhereIf(input.MaxDecimalField1Filter != null, e => e.DecimalField1 <= input.MaxDecimalField1Filter)
                        .WhereIf(input.MinDecimalField2Filter != null, e => e.DecimalField2 >= input.MinDecimalField2Filter)
                        .WhereIf(input.MaxDecimalField2Filter != null, e => e.DecimalField2 <= input.MaxDecimalField2Filter)
                        .WhereIf(input.MinDecimalField3Filter != null, e => e.DecimalField3 >= input.MinDecimalField3Filter)
                        .WhereIf(input.MaxDecimalField3Filter != null, e => e.DecimalField3 <= input.MaxDecimalField3Filter)
                        .WhereIf(input.MinDecimalField4Filter != null, e => e.DecimalField4 >= input.MinDecimalField4Filter)
                        .WhereIf(input.MaxDecimalField4Filter != null, e => e.DecimalField4 <= input.MaxDecimalField4Filter)
                        .WhereIf(input.MinDecimalField5Filter != null, e => e.DecimalField5 >= input.MinDecimalField5Filter)
                        .WhereIf(input.MaxDecimalField5Filter != null, e => e.DecimalField5 <= input.MaxDecimalField5Filter)
                        .WhereIf(input.MinDateField1Filter != null, e => e.DateField1 >= input.MinDateField1Filter)
                        .WhereIf(input.MaxDateField1Filter != null, e => e.DateField1 <= input.MaxDateField1Filter)
                        .WhereIf(input.MinDateField2Filter != null, e => e.DateField2 >= input.MinDateField2Filter)
                        .WhereIf(input.MaxDateField2Filter != null, e => e.DateField2 <= input.MaxDateField2Filter)
                        .WhereIf(input.MinDateField3Filter != null, e => e.DateField3 >= input.MinDateField3Filter)
                        .WhereIf(input.MaxDateField3Filter != null, e => e.DateField3 <= input.MaxDateField3Filter)
                        .WhereIf(input.MinDateField4Filter != null, e => e.DateField4 >= input.MinDateField4Filter)
                        .WhereIf(input.MaxDateField4Filter != null, e => e.DateField4 <= input.MaxDateField4Filter)
                        .WhereIf(input.MinDateField5Filter != null, e => e.DateField5 >= input.MinDateField5Filter)
                        .WhereIf(input.MaxDateField5Filter != null, e => e.DateField5 <= input.MaxDateField5Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var query = (from o in filteredCustomers
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetCustomerForViewDto()
                         {
                             Customer = new CustomerDto
                             {
                                 Name = o.Name,
                                 Email = o.Email,
                                 Address1 = o.Address1,
                                 Address2 = o.Address2,
                                 PostalCode = o.PostalCode,
                                 Source = o.Source,
                                 Branch = o.Branch,
                                 RuleFlagId = o.RuleFlagId,
                                 IsRebate = o.IsRebate,
                                 RebateDetail = o.RebateDetail,
                                 CreditLimit = o.CreditLimit,
                                 StringField1 = o.StringField1,
                                 Stringfield2 = o.Stringfield2,
                                 StringField3 = o.StringField3,
                                 StringField4 = o.StringField4,
                                 StringField5 = o.StringField5,
                                 DecimalField1 = o.DecimalField1,
                                 DecimalField2 = o.DecimalField2,
                                 DecimalField3 = o.DecimalField3,
                                 DecimalField4 = o.DecimalField4,
                                 DecimalField5 = o.DecimalField5,
                                 DateField1 = o.DateField1,
                                 DateField2 = o.DateField2,
                                 DateField3 = o.DateField3,
                                 DateField4 = o.DateField4,
                                 DateField5 = o.DateField5,
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                         });

            var customerListDtos = await query.ToListAsync();

            return _customersExcelExporter.ExportToFile(customerListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Customers)]
        public async Task<List<CustomerOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new CustomerOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

      
    }
}