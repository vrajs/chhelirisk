﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Customers.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Customers.Exporting
{
    public class ContactPersonsExcelExporter : NpoiExcelExporterBase, IContactPersonsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ContactPersonsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetContactPersonForViewDto> contactPersons)
        {
            return CreateExcelPackage(
                "ContactPersons.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ContactPersons"));

                    AddHeader(
                        sheet,
                        L("Name"),
                        L("Email"),
                        L("Phone"),
                        L("Role"),
                        L("IsPrimary"),
                        (L("Customer")) + L("Name"),
                        (L("OrganizationUnit")) + L("DisplayName")
                        );

                    AddObjects(
                        sheet, contactPersons,
                        _ => _.ContactPerson.Name,
                        _ => _.ContactPerson.Email,
                        _ => _.ContactPerson.Phone,
                        _ => _.ContactPerson.Role,
                        _ => _.ContactPerson.IsPrimary,
                        _ => _.CustomerName,
                        _ => _.OrganizationUnitDisplayName
                        );

                });
        }
    }
}