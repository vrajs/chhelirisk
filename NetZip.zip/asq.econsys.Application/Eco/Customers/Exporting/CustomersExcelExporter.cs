﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Customers.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Customers.Exporting
{
    public class CustomersExcelExporter : NpoiExcelExporterBase, ICustomersExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public CustomersExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetCustomerForViewDto> customers)
        {
            return CreateExcelPackage(
                "Customers.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("Customers"));

                    AddHeader(
                        sheet,
                        L("Name"),
                        L("Email"),
                        L("Address"),
                        L("PostalCode"),
                        L("Source"),
                        L("Branch"),
                        L("RuleFlagId"),
                        L("IsRebate"),
                        L("RebateDetail"),
                        L("CreditLimit"),
                        L("StringField1"),
                        L("Stringfield2"),
                        L("StringField3"),
                        L("StringField4"),
                        L("StringField5"),
                        L("DecimalField1"),
                        L("DecimalField2"),
                        L("DecimalField3"),
                        L("DecimalField4"),
                        L("DecimalField5"),
                        L("DateField1"),
                        L("DateField2"),
                        L("DateField3"),
                        L("DateField4"),
                        L("DateField5"),
                        (L("OrganizationUnit")) + L("DisplayName")
                        );

                    AddObjects(
                        sheet, customers,
                        _ => _.Customer.Name,
                        _ => _.Customer.Email,
                        _ => _.Customer.Address1,
                        _ => _.Customer.PostalCode,
                        _ => _.Customer.Source,
                        _ => _.Customer.Branch,
                        _ => _.Customer.RuleFlagId,
                        _ => _.Customer.IsRebate,
                        _ => _.Customer.RebateDetail,
                        _ => _.Customer.CreditLimit,
                        _ => _.Customer.StringField1,
                        _ => _.Customer.Stringfield2,
                        _ => _.Customer.StringField3,
                        _ => _.Customer.StringField4,
                        _ => _.Customer.StringField5,
                        _ => _.Customer.DecimalField1,
                        _ => _.Customer.DecimalField2,
                        _ => _.Customer.DecimalField3,
                        _ => _.Customer.DecimalField4,
                        _ => _.Customer.DecimalField5,
                        _ => _timeZoneConverter.Convert(_.Customer.DateField1, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.Customer.DateField2, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.Customer.DateField3, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.Customer.DateField4, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.Customer.DateField5, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.OrganizationUnitDisplayName
                        );

                    for (var i = 1; i <= customers.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[21], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(21); for (var i = 1; i <= customers.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[22], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(22); for (var i = 1; i <= customers.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[23], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(23); for (var i = 1; i <= customers.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[24], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(24); for (var i = 1; i <= customers.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[25], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(25);
                });
        }
    }
}