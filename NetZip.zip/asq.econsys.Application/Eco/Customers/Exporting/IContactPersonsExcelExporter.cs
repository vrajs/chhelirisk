﻿using System.Collections.Generic;
using asq.econsys.Eco.Customers.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.Customers.Exporting
{
    public interface IContactPersonsExcelExporter
    {
        FileDto ExportToFile(List<GetContactPersonForViewDto> contactPersons);
    }
}