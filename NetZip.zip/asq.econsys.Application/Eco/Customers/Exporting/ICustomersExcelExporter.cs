﻿using System.Collections.Generic;
using asq.econsys.Eco.Customers.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.Customers.Exporting
{
    public interface ICustomersExcelExporter
    {
        FileDto ExportToFile(List<GetCustomerForViewDto> customers);
    }
}