﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.GridMaster.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.GridMaster.Exporting
{
    public class GridMastersExcelExporter : NpoiExcelExporterBase, IGridMastersExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public GridMastersExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetGridMasterForViewDto> gridMasters)
        {
            return CreateExcelPackage(
                "GridMasters.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("GridMasters"));

                    AddHeader(
                        sheet,
                        L("Name"),
                        L("CoumnOne"),
                        L("ColumnTwo"),
                        L("ForPRJ"),
                        L("ForSWK"),
                        L("ForCALL"),
                        L("ForPPM"),
                        L("ForTandM"),
                        L("DisplayOrder"),
                        (L("OrganizationUnit")) + L("DisplayName")
                        );

                    AddObjects(
                        sheet, gridMasters,
                        _ => _.GridMaster.Name,
                        _ => _.GridMaster.CoumnOne,
                        _ => _.GridMaster.ColumnTwo,
                        _ => _.GridMaster.ForPRJ,
                        _ => _.GridMaster.ForSWK,
                        _ => _.GridMaster.ForCALL,
                        _ => _.GridMaster.ForPPM,
                        _ => _.GridMaster.ForTandM,
                        _ => _.GridMaster.DisplayOrder,
                        _ => _.OrganizationUnitDisplayName
                        );

                });
        }
    }
}