﻿using System.Collections.Generic;
using asq.econsys.Eco.GridMaster.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.GridMaster.Exporting
{
    public interface IGridMastersExcelExporter
    {
        FileDto ExportToFile(List<GetGridMasterForViewDto> gridMasters);
    }
}