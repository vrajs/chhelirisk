﻿using Abp.Organizations;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.GridMaster.Exporting;
using asq.econsys.Eco.GridMaster.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.GridMaster
{
    [AbpAuthorize(AppPermissions.Pages_GridMasters)]
    public class GridMastersAppService : econsysAppServiceBase, IGridMastersAppService
    {
        private readonly IRepository<GridMaster, long> _gridMasterRepository;
        private readonly IGridMastersExcelExporter _gridMastersExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;

        public GridMastersAppService(IRepository<GridMaster, long> gridMasterRepository, IGridMastersExcelExporter gridMastersExcelExporter, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository)
        {
            _gridMasterRepository = gridMasterRepository;
            _gridMastersExcelExporter = gridMastersExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;

        }

        public async Task<PagedResultDto<GetGridMasterForViewDto>> GetAll(GetAllGridMastersInput input)
        {
            input.MaxResultCount = 100;
            var filteredGridMasters = _gridMasterRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk);
                        /*.WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.CoumnOne.Contains(input.Filter) || e.ColumnTwo.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CoumnOneFilter), e => e.CoumnOne == input.CoumnOneFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ColumnTwoFilter), e => e.ColumnTwo == input.ColumnTwoFilter)
                        .WhereIf(input.ForPRJFilter.HasValue && input.ForPRJFilter > -1, e => (input.ForPRJFilter == 1 && e.ForPRJ) || (input.ForPRJFilter == 0 && !e.ForPRJ))
                        .WhereIf(input.ForSWKFilter.HasValue && input.ForSWKFilter > -1, e => (input.ForSWKFilter == 1 && e.ForSWK) || (input.ForSWKFilter == 0 && !e.ForSWK))
                        .WhereIf(input.ForCALLFilter.HasValue && input.ForCALLFilter > -1, e => (input.ForCALLFilter == 1 && e.ForCALL) || (input.ForCALLFilter == 0 && !e.ForCALL))
                        .WhereIf(input.ForPPMFilter.HasValue && input.ForPPMFilter > -1, e => (input.ForPPMFilter == 1 && e.ForPPM) || (input.ForPPMFilter == 0 && !e.ForPPM))
                        .WhereIf(input.ForTandMFilter.HasValue && input.ForTandMFilter > -1, e => (input.ForTandMFilter == 1 && e.ForTandM) || (input.ForTandMFilter == 0 && !e.ForTandM))
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);*/

            var pagedAndFilteredGridMasters = filteredGridMasters
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var gridMasters = from o in pagedAndFilteredGridMasters
                              join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                              from s1 in j1.DefaultIfEmpty()

                              select new
                              {

                                  o.Name,
                                  o.CoumnOne,
                                  o.ColumnTwo,
                                  o.ForPRJ,
                                  o.ForSWK,
                                  o.ForCALL,
                                  o.ForPPM,
                                  o.ForTandM,
                                  o.DisplayOrder,
                                  Id = o.Id,
                                  OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                              };

            var totalCount = await filteredGridMasters.CountAsync();

            var dbList = await gridMasters.ToListAsync();
            var results = new List<GetGridMasterForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetGridMasterForViewDto()
                {
                    GridMaster = new GridMasterDto
                    {

                        Name = o.Name,
                        CoumnOne = o.CoumnOne,
                        ColumnTwo = o.ColumnTwo,
                        ForPRJ = o.ForPRJ,
                        ForSWK = o.ForSWK,
                        ForCALL = o.ForCALL,
                        ForPPM = o.ForPPM,
                        ForTandM = o.ForTandM,
                        DisplayOrder = o.DisplayOrder,
                        Id = o.Id,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetGridMasterForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetGridMasterForViewDto> GetGridMasterForView(long id)
        {
            var gridMaster = await _gridMasterRepository.GetAsync(id);

            var output = new GetGridMasterForViewDto { GridMaster = ObjectMapper.Map<GridMasterDto>(gridMaster) };

            if (output.GridMaster.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.GridMaster.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_GridMasters_Edit)]
        public async Task<GetGridMasterForEditOutput> GetGridMasterForEdit(EntityDto<long> input)
        {
            var gridMaster = await _gridMasterRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetGridMasterForEditOutput { GridMaster = ObjectMapper.Map<CreateOrEditGridMasterDto>(gridMaster) };

            if (output.GridMaster.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.GridMaster.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditGridMasterDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_GridMasters_Create)]
        protected virtual async Task Create(CreateOrEditGridMasterDto input)
        {
            var gridMaster = ObjectMapper.Map<GridMaster>(input);

            if (AbpSession.TenantId != null)
            {
                gridMaster.TenantId = (int?)AbpSession.TenantId;
            }

            var item = _gridMasterRepository.FirstOrDefault(x => x.Name.ToLower() == input.Name.ToLower() && x.CoumnOne.ToLower() == input.CoumnOne.ToLower());
            if (item != null)
            {
                throw new UserFriendlyException(L($"Entry with the name \"{input.Name}\" - \"{input.CoumnOne}\" already exists!"));
            }

            await _gridMasterRepository.InsertAsync(gridMaster);

        }

        [AbpAuthorize(AppPermissions.Pages_GridMasters_Edit)]
        protected virtual async Task Update(CreateOrEditGridMasterDto input)
        {
            var gridMaster = await _gridMasterRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, gridMaster);

        }

        [AbpAuthorize(AppPermissions.Pages_GridMasters_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _gridMasterRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetGridMastersToExcel(GetAllGridMastersForExcelInput input)
        {

            var filteredGridMasters = _gridMasterRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.CoumnOne.Contains(input.Filter) || e.ColumnTwo.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CoumnOneFilter), e => e.CoumnOne == input.CoumnOneFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ColumnTwoFilter), e => e.ColumnTwo == input.ColumnTwoFilter)
                        .WhereIf(input.ForPRJFilter.HasValue && input.ForPRJFilter > -1, e => (input.ForPRJFilter == 1 && e.ForPRJ) || (input.ForPRJFilter == 0 && !e.ForPRJ))
                        .WhereIf(input.ForSWKFilter.HasValue && input.ForSWKFilter > -1, e => (input.ForSWKFilter == 1 && e.ForSWK) || (input.ForSWKFilter == 0 && !e.ForSWK))
                        .WhereIf(input.ForCALLFilter.HasValue && input.ForCALLFilter > -1, e => (input.ForCALLFilter == 1 && e.ForCALL) || (input.ForCALLFilter == 0 && !e.ForCALL))
                        .WhereIf(input.ForPPMFilter.HasValue && input.ForPPMFilter > -1, e => (input.ForPPMFilter == 1 && e.ForPPM) || (input.ForPPMFilter == 0 && !e.ForPPM))
                        .WhereIf(input.ForTandMFilter.HasValue && input.ForTandMFilter > -1, e => (input.ForTandMFilter == 1 && e.ForTandM) || (input.ForTandMFilter == 0 && !e.ForTandM))
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var query = (from o in filteredGridMasters
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetGridMasterForViewDto()
                         {
                             GridMaster = new GridMasterDto
                             {
                                 Name = o.Name,
                                 CoumnOne = o.CoumnOne,
                                 ColumnTwo = o.ColumnTwo,
                                 ForPRJ = o.ForPRJ,
                                 ForSWK = o.ForSWK,
                                 ForCALL = o.ForCALL,
                                 ForPPM = o.ForPPM,
                                 ForTandM = o.ForTandM,
                                 DisplayOrder = o.DisplayOrder,
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                         });

            var gridMasterListDtos = await query.ToListAsync();

            return _gridMastersExcelExporter.ExportToFile(gridMasterListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_GridMasters)]
        public async Task<List<GridMasterOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new GridMasterOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        public async Task<List<GridMaster>> GetAllCostCodes()
        {
            return await _gridMasterRepository.GetAll()
            .Where(c => c.Name == "Cost Code" && c.ForPRJ == true)
            .Select(data => new GridMaster
            {
                CoumnOne = data.CoumnOne,
                ForPRJ = data.ForPRJ
            }).ToListAsync();

        }

    }
}