﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.GuidanceNotes.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.GuidanceNotes.Exporting
{
    public class GuidanceNotesExcelExporter : NpoiExcelExporterBase, IGuidanceNotesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public GuidanceNotesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetGuidanceNoteForViewDto> guidanceNotes)
        {
            return CreateExcelPackage(
                "GuidanceNotes.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("GuidanceNotes"));

                    AddHeader(
                        sheet,
                        L("Stage"),
                        L("Task"),
                        L("HelpContent")
                        );

                    AddObjects(
                        sheet, guidanceNotes,
                        _ => _.GuidanceNote.Stage,
                        _ => _.GuidanceNote.Task,
                        _ => _.GuidanceNote.HelpContent
                        );

                });
        }
    }
}