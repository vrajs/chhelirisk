﻿using System.Collections.Generic;
using asq.econsys.Eco.GuidanceNotes.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.GuidanceNotes.Exporting
{
    public interface IGuidanceNotesExcelExporter
    {
        FileDto ExportToFile(List<GetGuidanceNoteForViewDto> guidanceNotes);
    }
}