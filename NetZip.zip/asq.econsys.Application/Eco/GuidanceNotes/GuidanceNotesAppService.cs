﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.GuidanceNotes.Exporting;
using asq.econsys.Eco.GuidanceNotes.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.GuidanceNotes
{
    [AbpAuthorize(AppPermissions.Pages_Administration_GuidanceNotes)]
    public class GuidanceNotesAppService : econsysAppServiceBase, IGuidanceNotesAppService
    {
        private readonly IRepository<GuidanceNote, long> _guidanceNoteRepository;
        private readonly IGuidanceNotesExcelExporter _guidanceNotesExcelExporter;

        public GuidanceNotesAppService(IRepository<GuidanceNote, long> guidanceNoteRepository, IGuidanceNotesExcelExporter guidanceNotesExcelExporter)
        {
            _guidanceNoteRepository = guidanceNoteRepository;
            _guidanceNotesExcelExporter = guidanceNotesExcelExporter;

        }

        public async Task<PagedResultDto<GetGuidanceNoteForViewDto>> GetAll(GetAllGuidanceNotesInput input)
        {

            var filteredGuidanceNotes = _guidanceNoteRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Stage.Contains(input.Filter) || e.Task.Contains(input.Filter) || e.HelpContent.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StageFilter), e => e.Stage == input.StageFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TaskFilter), e => e.Task == input.TaskFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HelpContentFilter), e => e.HelpContent == input.HelpContentFilter);

            var pagedAndFilteredGuidanceNotes = filteredGuidanceNotes
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var guidanceNotes = from o in pagedAndFilteredGuidanceNotes
                                select new
                                {

                                    o.Stage,
                                    o.Task,
                                    o.HelpContent,
                                    Id = o.Id
                                };

            var totalCount = await filteredGuidanceNotes.CountAsync();

            var dbList = await guidanceNotes.ToListAsync();
            var results = new List<GetGuidanceNoteForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetGuidanceNoteForViewDto()
                {
                    GuidanceNote = new GuidanceNoteDto
                    {

                        Stage = o.Stage,
                        Task = o.Task,
                        HelpContent = o.HelpContent,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetGuidanceNoteForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetGuidanceNoteForViewDto> GetGuidanceNoteForView(long id)
        {
            var guidanceNote = await _guidanceNoteRepository.GetAsync(id);

            var output = new GetGuidanceNoteForViewDto { GuidanceNote = ObjectMapper.Map<GuidanceNoteDto>(guidanceNote) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_GuidanceNotes_Edit)]
        public async Task<GetGuidanceNoteForEditOutput> GetGuidanceNoteForEdit(EntityDto<long> input)
        {
            var guidanceNote = await _guidanceNoteRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetGuidanceNoteForEditOutput { GuidanceNote = ObjectMapper.Map<CreateOrEditGuidanceNoteDto>(guidanceNote) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditGuidanceNoteDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_GuidanceNotes_Create)]
        protected virtual async Task Create(CreateOrEditGuidanceNoteDto input)
        {
            var guidanceNote = ObjectMapper.Map<GuidanceNote>(input);

            if (AbpSession.TenantId != null)
            {
                guidanceNote.TenantId = (int?)AbpSession.TenantId;
            }

            await _guidanceNoteRepository.InsertAsync(guidanceNote);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_GuidanceNotes_Edit)]
        protected virtual async Task Update(CreateOrEditGuidanceNoteDto input)
        {
            var guidanceNote = await _guidanceNoteRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, guidanceNote);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_GuidanceNotes_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _guidanceNoteRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetGuidanceNotesToExcel(GetAllGuidanceNotesForExcelInput input)
        {

            var filteredGuidanceNotes = _guidanceNoteRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Stage.Contains(input.Filter) || e.Task.Contains(input.Filter) || e.HelpContent.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StageFilter), e => e.Stage == input.StageFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TaskFilter), e => e.Task == input.TaskFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HelpContentFilter), e => e.HelpContent == input.HelpContentFilter);

            var query = (from o in filteredGuidanceNotes
                         select new GetGuidanceNoteForViewDto()
                         {
                             GuidanceNote = new GuidanceNoteDto
                             {
                                 Stage = o.Stage,
                                 Task = o.Task,
                                 HelpContent = o.HelpContent,
                                 Id = o.Id
                             }
                         });

            var guidanceNoteListDtos = await query.ToListAsync();

            return _guidanceNotesExcelExporter.ExportToFile(guidanceNoteListDtos);
        }

    }
}