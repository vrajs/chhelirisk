﻿using System.Collections.Generic;
using asq.econsys.Eco.Leads.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.Leads.Exporting
{
    public interface ILeadContactsExcelExporter
    {
        FileDto ExportToFile(List<GetLeadContactForViewDto> leadContacts);
    }
}