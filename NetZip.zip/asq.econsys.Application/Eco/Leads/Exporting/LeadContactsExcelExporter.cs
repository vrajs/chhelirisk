﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Leads.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Leads.Exporting
{
    public class LeadContactsExcelExporter : NpoiExcelExporterBase, ILeadContactsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public LeadContactsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetLeadContactForViewDto> leadContacts)
        {
            return CreateExcelPackage(
                "LeadContacts.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("LeadContacts"));

                    AddHeader(
                        sheet,
                        L("Name"),
                        L("Email"),
                        L("Phone"),
                        L("IsPrimary"),
                        (L("Lead")) + L("ProjectName")
                        );

                    AddObjects(
                        sheet, leadContacts,
                        _ => _.LeadContact.Name,
                        _ => _.LeadContact.Email,
                        _ => _.LeadContact.Phone,
                        _ => _.LeadContact.IsPrimary,
                        _ => _.LeadProjectName
                        );

                });
        }
    }
}