﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Leads.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Leads.Exporting
{
    public class LeadsExcelExporter : NpoiExcelExporterBase, ILeadsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public LeadsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetLeadForViewDto> leads)
        {
            return CreateExcelPackage(
                "Leads.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("Leads"));

                    AddHeader(
                        sheet,
                        L("ProjectName"),
                        L("CustomerName"),
                        L("CustomerAddress"),
                        L("PostalCode"),
                        L("Email"),
                        L("Phone"),
                        L("SiteName"),
                        L("EndUser"),
                        L("OrderProbabilityPerc"),
                        L("BudgetOrderValue"),
                        L("AnticipatedEnquiryReceiptDate"),
                        L("AnticipatedOrderPlacementDate"),
                        L("ApproxProjectDurationMonths"),
                        L("Comments"),
                        L("Status"),
                        (L("OrganizationUnit")) + L("DisplayName"),
                        (L("LeadSource")) + L("Title"),
                        (L("Customer")) + L("Name"),
                        (L("ProjectType")) + L("Code")
                        );

                    AddObjects(
                        sheet, leads,
                        _ => _.Lead.ProjectName,
                        _ => _.Lead.CustomerName,
                        _ => _.Lead.CustomerAddress1,
                        _ => _.Lead.PostalCode,
                        _ => _.Lead.Email,
                        _ => _.Lead.Phone,
                        _ => _.Lead.SiteName,
                        _ => _.Lead.EndUser,
                        _ => _.Lead.OrderProbabilityPerc,
                        _ => _.Lead.BudgetOrderValue,
                        _ => _timeZoneConverter.Convert(_.Lead.AnticipatedEnquiryReceiptDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.Lead.AnticipatedOrderPlacementDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.Lead.ApproxProjectDurationMonths,
                        _ => _.Lead.Comments,
                        _ => _.Lead.Status,
                        _ => _.OrganizationUnitDisplayName,
                        _ => _.LeadSourceTitle,
                        _ => _.CustomerName,
                        _ => _.ProjectTypeCode
                        );

                    for (var i = 1; i <= leads.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[9], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(9); for (var i = 1; i <= leads.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[10], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(10);
                });
        }
    }
}