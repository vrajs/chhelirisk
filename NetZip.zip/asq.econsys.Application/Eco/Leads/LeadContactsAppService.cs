﻿using asq.econsys.Eco.Leads;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Leads.Exporting;
using asq.econsys.Eco.Leads.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Leads
{
    [AbpAuthorize(AppPermissions.Pages_LeadContacts)]
    public class LeadContactsAppService : econsysAppServiceBase, ILeadContactsAppService
    {
        private readonly IRepository<LeadContact, long> _leadContactRepository;
        private readonly ILeadContactsExcelExporter _leadContactsExcelExporter;
        private readonly IRepository<Lead, long> _lookup_leadRepository;

        public LeadContactsAppService(IRepository<LeadContact, long> leadContactRepository, ILeadContactsExcelExporter leadContactsExcelExporter, IRepository<Lead, long> lookup_leadRepository)
        {
            _leadContactRepository = leadContactRepository;
            _leadContactsExcelExporter = leadContactsExcelExporter;
            _lookup_leadRepository = lookup_leadRepository;

        }

        public async Task<PagedResultDto<GetLeadContactForViewDto>> GetAll(GetAllLeadContactsInput input)
        {

            var filteredLeadContacts = _leadContactRepository.GetAll()
                        .Include(e => e.LeadFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.Email.Contains(input.Filter) || e.Phone.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.EmailFilter), e => e.Email == input.EmailFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PhoneFilter), e => e.Phone == input.PhoneFilter)
                        .WhereIf(input.IsPrimaryFilter.HasValue && input.IsPrimaryFilter > -1, e => (input.IsPrimaryFilter == 1 && e.IsPrimary) || (input.IsPrimaryFilter == 0 && !e.IsPrimary))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadProjectNameFilter), e => e.LeadFk != null && e.LeadFk.ProjectName == input.LeadProjectNameFilter)
                        .WhereIf(input.LeadIdFilter.HasValue, e => false || e.LeadId == input.LeadIdFilter.Value);

            var pagedAndFilteredLeadContacts = filteredLeadContacts
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var leadContacts = from o in pagedAndFilteredLeadContacts
                               join o1 in _lookup_leadRepository.GetAll() on o.LeadId equals o1.Id into j1
                               from s1 in j1.DefaultIfEmpty()

                               select new
                               {

                                   o.Name,
                                   o.Email,
                                   o.Phone,
                                   o.IsPrimary,
                                   Id = o.Id,
                                   LeadProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                               };

            var totalCount = await filteredLeadContacts.CountAsync();

            var dbList = await leadContacts.ToListAsync();
            var results = new List<GetLeadContactForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetLeadContactForViewDto()
                {
                    LeadContact = new LeadContactDto
                    {

                        Name = o.Name,
                        Email = o.Email,
                        Phone = o.Phone,
                        IsPrimary = o.IsPrimary,
                        Id = o.Id,
                    },
                    LeadProjectName = o.LeadProjectName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetLeadContactForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetLeadContactForViewDto> GetLeadContactForView(long id)
        {
            var leadContact = await _leadContactRepository.GetAsync(id);

            var output = new GetLeadContactForViewDto { LeadContact = ObjectMapper.Map<LeadContactDto>(leadContact) };

            if (output.LeadContact.LeadId != null)
            {
                var _lookupLead = await _lookup_leadRepository.FirstOrDefaultAsync((long)output.LeadContact.LeadId);
                output.LeadProjectName = _lookupLead?.ProjectName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_LeadContacts_Edit)]
        public async Task<GetLeadContactForEditOutput> GetLeadContactForEdit(EntityDto<long> input)
        {
            var leadContact = await _leadContactRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetLeadContactForEditOutput { LeadContact = ObjectMapper.Map<CreateOrEditLeadContactDto>(leadContact) };

            if (output.LeadContact.LeadId != null)
            {
                var _lookupLead = await _lookup_leadRepository.FirstOrDefaultAsync((long)output.LeadContact.LeadId);
                output.LeadProjectName = _lookupLead?.ProjectName?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditLeadContactDto input)
        {
            if (input.Id == null || input.Id == 0)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_LeadContacts_Create)]
        protected virtual async Task Create(CreateOrEditLeadContactDto input)
        {
            var leadContact = ObjectMapper.Map<LeadContact>(input);

            if (AbpSession.TenantId != null)
            {
                leadContact.TenantId = (int?)AbpSession.TenantId;
            }

            await _leadContactRepository.InsertAsync(leadContact);

        }

        [AbpAuthorize(AppPermissions.Pages_LeadContacts_Edit)]
        protected virtual async Task Update(CreateOrEditLeadContactDto input)
        {
            var leadContact = await _leadContactRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, leadContact);

        }

        [AbpAuthorize(AppPermissions.Pages_LeadContacts_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _leadContactRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetLeadContactsToExcel(GetAllLeadContactsForExcelInput input)
        {

            var filteredLeadContacts = _leadContactRepository.GetAll()
                        .Include(e => e.LeadFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.Email.Contains(input.Filter) || e.Phone.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.EmailFilter), e => e.Email == input.EmailFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PhoneFilter), e => e.Phone == input.PhoneFilter)
                        .WhereIf(input.IsPrimaryFilter.HasValue && input.IsPrimaryFilter > -1, e => (input.IsPrimaryFilter == 1 && e.IsPrimary) || (input.IsPrimaryFilter == 0 && !e.IsPrimary))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadProjectNameFilter), e => e.LeadFk != null && e.LeadFk.ProjectName == input.LeadProjectNameFilter);

            var query = (from o in filteredLeadContacts
                         join o1 in _lookup_leadRepository.GetAll() on o.LeadId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetLeadContactForViewDto()
                         {
                             LeadContact = new LeadContactDto
                             {
                                 Name = o.Name,
                                 Email = o.Email,
                                 Phone = o.Phone,
                                 IsPrimary = o.IsPrimary,
                                 Id = o.Id
                             },
                             LeadProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                         });

            var leadContactListDtos = await query.ToListAsync();

            return _leadContactsExcelExporter.ExportToFile(leadContactListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_LeadContacts)]
        public async Task<List<LeadContactLeadLookupTableDto>> GetAllLeadForTableDropdown()
        {
            return await _lookup_leadRepository.GetAll()
                .Select(lead => new LeadContactLeadLookupTableDto
                {
                    Id = lead.Id,
                    DisplayName = lead == null || lead.ProjectName == null ? "" : lead.ProjectName.ToString()
                }).ToListAsync();
        }
        public async Task CreateOrEditLeads(List<CreateOrEditLeadContactDto> input)
        {
            foreach (var item in input)
            {
                await CreateOrEdit(item);
            }
        }
        public async Task<List<CreateOrEditLeadContactDto>> GetLeadContactsById(int id)
        {
            return await _leadContactRepository.GetAll()
                .Where(l => l.LeadId == id)
                .Select(leadContact => new CreateOrEditLeadContactDto
                {
                    Id = leadContact.Id,
                    Name = leadContact.Name,
                    Email = leadContact.Email,
                    Phone = leadContact.Phone,
                    IsPrimary = leadContact.IsPrimary
                }).ToListAsync();
        }
        [AbpAuthorize(AppPermissions.Pages_LeadContacts_Delete)]
        public async Task DeleteLeadContacts(EntityDto<long> input)
        {
            var leadContactList = _leadContactRepository.GetAll().Where(o => o.LeadId == input.Id).ToList();
            foreach (var item in leadContactList)
                await _leadContactRepository.DeleteAsync(item.Id);
        }

    }
}