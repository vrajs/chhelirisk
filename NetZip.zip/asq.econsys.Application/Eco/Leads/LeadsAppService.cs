﻿using Abp.Organizations;
using asq.econsys.Eco.Leads;
using asq.econsys.Eco.Customers;
using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Leads.Exporting;
using asq.econsys.Eco.Leads.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.Customers.Dtos;

namespace asq.econsys.Eco.Leads
{
    [AbpAuthorize(AppPermissions.Pages_Leads)]
    public class LeadsAppService : econsysAppServiceBase, ILeadsAppService
    {
        private readonly IRepository<Lead, long> _leadRepository;
        private readonly ILeadsExcelExporter _leadsExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IRepository<LeadSource, int> _lookup_leadSourceRepository;
        private readonly IRepository<Customer, long> _lookup_customerRepository;
        private readonly IRepository<ProjectType, string> _lookup_projectTypeRepository;
        private readonly ILeadContactsAppService _leadContactsAppService;
        private readonly ICustomersAppService _customersAppService;
        private readonly IRepository<ContactPerson, long> _contactPersonRepository;

        public LeadsAppService(IRepository<Lead, long> leadRepository, ILeadsExcelExporter leadsExcelExporter, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository, IRepository<LeadSource, int> lookup_leadSourceRepository, IRepository<Customer, long> lookup_customerRepository, IRepository<ProjectType, string> lookup_projectTypeRepository, ILeadContactsAppService leadContactsAppService, ICustomersAppService customersAppService, IRepository<ContactPerson, long> contactPersonRepository)
        {
            _leadRepository = leadRepository;
            _leadsExcelExporter = leadsExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _lookup_leadSourceRepository = lookup_leadSourceRepository;
            _lookup_customerRepository = lookup_customerRepository;
            _lookup_projectTypeRepository = lookup_projectTypeRepository;
            _leadContactsAppService = leadContactsAppService;
            _customersAppService = customersAppService;
            _contactPersonRepository = contactPersonRepository;
        }

        public async Task<PagedResultDto<GetLeadForViewDto>> GetAll(GetAllLeadsInput input, bool myLeads = false)
        {

            var filteredLeads = _leadRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.LeadSourceFk)
                        .Include(e => e.CustomerFk)
                        .Include(e => e.ProjectTypeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ProjectName.Contains(input.Filter) || e.CustomerName.Contains(input.Filter) || e.Email.Contains(input.Filter) || e.Phone.Contains(input.Filter) || e.CustomerAddress1.Contains(input.Filter) || e.PostalCode.Contains(input.Filter) || e.SiteName.Contains(input.Filter) || e.EndUser.Contains(input.Filter) || e.BudgetOrderValue.Contains(input.Filter) || e.Comments.Contains(input.Filter) || e.Status.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectNameFilter), e => e.ProjectName == input.ProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerNameFilter), e => e.CustomerName == input.CustomerNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerAddress1Filter), e => e.CustomerAddress1 == input.CustomerAddress1Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PostalCodeFilter), e => e.PostalCode == input.PostalCodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Emailfilter), e => e.Email == input.Emailfilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Phonefilter), e => e.Phone == input.Phonefilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SiteNameFilter), e => e.SiteName == input.SiteNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.EndUserFilter), e => e.EndUser == input.EndUserFilter)
                        .WhereIf(input.MinOrderProbabilityPercFilter != null, e => e.OrderProbabilityPerc >= input.MinOrderProbabilityPercFilter)
                        .WhereIf(input.MaxOrderProbabilityPercFilter != null, e => e.OrderProbabilityPerc <= input.MaxOrderProbabilityPercFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.BudgetOrderValueFilter), e => e.BudgetOrderValue == input.BudgetOrderValueFilter)
                        .WhereIf(input.MinAnticipatedEnquiryReceiptDateFilter != null, e => e.AnticipatedEnquiryReceiptDate >= input.MinAnticipatedEnquiryReceiptDateFilter)
                        .WhereIf(input.MaxAnticipatedEnquiryReceiptDateFilter != null, e => e.AnticipatedEnquiryReceiptDate <= input.MaxAnticipatedEnquiryReceiptDateFilter)
                        .WhereIf(input.MinAnticipatedOrderPlacementDateFilter != null, e => e.AnticipatedOrderPlacementDate >= input.MinAnticipatedOrderPlacementDateFilter)
                        .WhereIf(input.MaxAnticipatedOrderPlacementDateFilter != null, e => e.AnticipatedOrderPlacementDate <= input.MaxAnticipatedOrderPlacementDateFilter)
                        .WhereIf(input.MinApproxProjectDurationMonthsFilter != null, e => e.ApproxProjectDurationMonths >= input.MinApproxProjectDurationMonthsFilter)
                        .WhereIf(input.MaxApproxProjectDurationMonthsFilter != null, e => e.ApproxProjectDurationMonths <= input.MaxApproxProjectDurationMonthsFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments == input.CommentsFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StatusFilter), e => e.Status == input.StatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadSourceTitleFilter), e => e.LeadSourceFk != null && e.LeadSourceFk.Title == input.LeadSourceTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectTypeCodeFilter), e => e.ProjectTypeFk != null && e.ProjectTypeFk.Code == input.ProjectTypeCodeFilter)
                        .WhereIf(myLeads, e => e.CreatorUserId == AbpSession.UserId);

            var pagedAndFilteredLeads = filteredLeads
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var leads = from o in pagedAndFilteredLeads
                        join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                        from s1 in j1.DefaultIfEmpty()

                        join o2 in _lookup_leadSourceRepository.GetAll() on o.LeadSourceId equals o2.Id into j2
                        from s2 in j2.DefaultIfEmpty()

                        join o3 in _lookup_customerRepository.GetAll() on o.CustomerId equals o3.Id into j3
                        from s3 in j3.DefaultIfEmpty()

                        join o4 in _lookup_projectTypeRepository.GetAll() on o.ProjectTypeId equals o4.Id into j4
                        from s4 in j4.DefaultIfEmpty()

                        select new
                        {

                            o.ProjectName,
                            //o.CustomerName,
                            //o.CustomerAddress,
                            //o.Postalcode,
                            //o.Email,
                            //o.Phone,
                            s3.Name,
                            s3.Address1,
                            s3.Address2,
                            s3.PostalCode,
                            s3.Email,
                            s3.Phone,
                            o.SiteName,
                            o.EndUser,
                            o.OrderProbabilityPerc,
                            o.BudgetOrderValue,
                            o.AnticipatedEnquiryReceiptDate,
                            o.AnticipatedOrderPlacementDate,
                            o.ApproxProjectDurationMonths,
                            o.Comments,
                            o.Status,
                            Id = o.Id,
                            o.StringField1,
                            o.StringField2,
                            o.StringField3,
                            o.StringField4,
                            o.StringField5,
                            o.DecimalField1,
                            o.DecimalField2,
                            o.DecimalField3,
                            o.DecimalField4,
                            o.DecimalField5,
                            o.DateField1,
                            o.DateField2,
                            o.DateField3,
                            o.DateField4,
                            o.DateField5,
                            OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                            LeadSourceTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                            ProjectTypeCode = s4 == null || s4.Code == null ? "" : s4.Code.ToString()
                        };

            var totalCount = await filteredLeads.CountAsync();

            var dbList = await leads.ToListAsync();
            var results = new List<GetLeadForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetLeadForViewDto()
                {
                    Lead = new LeadDto
                    {

                        ProjectName = o.ProjectName,
                        //CustomerName = o.CustomerName,
                        //CustomerAddress = o.CustomerAddress,
                        //PostalCode = o.Postalcode,
                        CustomerName = o.Name,
                        CustomerAddress1 = o.Address1,
                        CustomerAddress2 = o.Address2,
                        PostalCode = o.PostalCode,
                        Email = o.Email,
                        Phone = o.Phone,
                        SiteName = o.SiteName,
                        EndUser = o.EndUser,
                        OrderProbabilityPerc = o.OrderProbabilityPerc,
                        BudgetOrderValue = o.BudgetOrderValue,
                        AnticipatedEnquiryReceiptDate = o.AnticipatedEnquiryReceiptDate,
                        AnticipatedOrderPlacementDate = o.AnticipatedOrderPlacementDate,
                        ApproxProjectDurationMonths = o.ApproxProjectDurationMonths,
                        Comments = o.Comments,
                        Status = o.Status,
                        Id = o.Id,
                        StringField1 = o.StringField1,
                        StringField2 = o.StringField2,
                        StringField3 = o.StringField3,
                        StringField4 = o.StringField4,
                        StringField5 = o.StringField5,
                        DecimalField1 = o.DecimalField1,
                        DecimalField2 = o.DecimalField2,
                        DecimalField3 = o.DecimalField3,
                        DecimalField4 = o.DecimalField4,
                        DecimalField5 = o.DecimalField5,
                        DateField1 = o.DateField1,
                        DateField2 = o.DateField2,
                        DateField3 = o.DateField3,
                        DateField4 = o.DateField4,
                        DateField5 = o.DateField5,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
                    LeadSourceTitle = o.LeadSourceTitle,
                    //CustomerName = o.CustomerName,
                    CustomerName = o.Name,
                    ProjectTypeCode = o.ProjectTypeCode
                };

                results.Add(res);
            }

            return new PagedResultDto<GetLeadForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetLeadForViewDto> GetLeadForView(long id)
        {
            var lead = await _leadRepository.GetAsync(id);

            var output = new GetLeadForViewDto { Lead = ObjectMapper.Map<LeadDto>(lead) };

            if (output.Lead.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.Lead.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.Lead.LeadSourceId != null)
            {
                var _lookupLeadSource = await _lookup_leadSourceRepository.FirstOrDefaultAsync((int)output.Lead.LeadSourceId);
                output.LeadSourceTitle = _lookupLeadSource?.Title?.ToString();
            }

            if (output.Lead.CustomerId != null)
            {
                var _lookupCustomer = await _lookup_customerRepository.FirstOrDefaultAsync((long)output.Lead.CustomerId);
                output.CustomerName = _lookupCustomer?.Name?.ToString();
            }

            if (output.Lead.ProjectTypeId != null)
            {
                var _lookupProjectType = await _lookup_projectTypeRepository.FirstOrDefaultAsync((string)output.Lead.ProjectTypeId);
                output.ProjectTypeCode = _lookupProjectType?.Code?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Leads_Edit)]
        public async Task<GetLeadForEditOutput> GetLeadForEdit(EntityDto<long> input)
        {
            var lead = await _leadRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetLeadForEditOutput { Lead = ObjectMapper.Map<CreateOrEditLeadDto>(lead) };

            if (output.Lead.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.Lead.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.Lead.LeadSourceId != null)
            {
                var _lookupLeadSource = await _lookup_leadSourceRepository.FirstOrDefaultAsync((int)output.Lead.LeadSourceId);
                output.LeadSourceTitle = _lookupLeadSource?.Title?.ToString();
            }

            if (output.Lead.CustomerId != null)
            {
                var _lookupCustomer = await _lookup_customerRepository.FirstOrDefaultAsync((long)output.Lead.CustomerId);
                output.Lead.CustomerName = _lookupCustomer?.Name?.ToString();
                output.Lead.CustomerAddress1 = _lookupCustomer?.Address1?.ToString();
                output.Lead.PostalCode = _lookupCustomer?.PostalCode?.ToString();
                output.Lead.Email = _lookupCustomer?.Email?.ToString();
                output.Lead.Phone = _lookupCustomer?.Phone?.ToString();
            }

            if (output.Lead.ProjectTypeId != null)
            {
                var _lookupProjectType = await _lookup_projectTypeRepository.FirstOrDefaultAsync((string)output.Lead.ProjectTypeId);
                output.ProjectTypeCode = _lookupProjectType?.Code?.ToString();
            }

            return output;
        }

        public async Task<long> CreateOrEdit(CreateOrEditLeadDto input)
        {
            long id = 0;
            if (input.Id == null)
            {
                id = await Create(input);
            }
            else
            {
                await Update(input);
                id = Convert.ToInt64(input.Id);
            }
            return id;
        }

        [AbpAuthorize(AppPermissions.Pages_Leads_Create)]
        protected virtual async Task<long> Create(CreateOrEditLeadDto input)
        {
            if (input.CustomerId == null || input.CustomerId == 0)
            {
                var customerList = new CreateOrEditCustomerDto() { Name = input.CustomerName, Address1 = input.CustomerAddress1, PostalCode = input.PostalCode, Email = input.Email, Phone = input.Phone };
                input.CustomerId = await _customersAppService.CreateOrEdit(customerList);
                foreach (var item in input.LeadContactObject)
                {
                    var customerContact = new ContactPerson() { Name = item.Name, Email = item.Email, Phone = item.Phone, IsPrimary = item.IsPrimary, CustomerId = input.CustomerId };
                    if (customerContact.IsPrimary)
                        await _contactPersonRepository.InsertAsync(customerContact);
                }
            }
            var lead = ObjectMapper.Map<Lead>(input);

            if (AbpSession.TenantId != null)
            {
                lead.TenantId = (int?)AbpSession.TenantId;
            }
            long id = await _leadRepository.InsertAndGetIdAsync(lead);
            var leadContactlist = input.LeadContactObject.Select(item => new CreateOrEditLeadContactDto() { Name = item.Name, Email = item.Email, Phone = item.Phone, IsPrimary = item.IsPrimary, LeadId = id }).ToList();
            await _leadContactsAppService.CreateOrEditLeads(leadContactlist);
            return id;
        }

        [AbpAuthorize(AppPermissions.Pages_Leads_Edit)]
        protected virtual async Task Update(CreateOrEditLeadDto input)
        {
            if (input.CustomerId == null || input.CustomerId == 0)
            {
                var customerList = new CreateOrEditCustomerDto() { Name = input.CustomerName, Address1 = input.CustomerAddress1, PostalCode = input.PostalCode, Email = input.Email, Phone = input.Phone };
                input.CustomerId = await _customersAppService.CreateOrEdit(customerList);
                foreach (var item in input.LeadContactObject)
                {
                    var customerContact = new ContactPerson() { Name = item.Name, Email = item.Email, Phone = item.Phone, IsPrimary = item.IsPrimary, CustomerId = input.CustomerId };
                    if (customerContact.IsPrimary)
                        await _contactPersonRepository.InsertAsync(customerContact);
                }
            }

            var lead = await _leadRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, lead);
            foreach (var item in input.LeadContactObject)
            {
                var leadContactList = new CreateOrEditLeadContactDto() { Id = item.Id, LeadId = item.LeadId, Name = item.Name, Email = item.Email, Phone = item.Phone, IsPrimary = item.IsPrimary };
                await _leadContactsAppService.CreateOrEdit(leadContactList);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Leads_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _leadContactsAppService.DeleteLeadContacts(input);
            await _leadRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetLeadsToExcel(GetAllLeadsForExcelInput input)
        {

            var filteredLeads = _leadRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.LeadSourceFk)
                        .Include(e => e.CustomerFk)
                        .Include(e => e.ProjectTypeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ProjectName.Contains(input.Filter) || e.CustomerName.Contains(input.Filter) || e.Email.Contains(input.Filter) || e.Phone.Contains(input.Filter) || e.CustomerAddress1.Contains(input.Filter) || e.PostalCode.Contains(input.Filter) || e.SiteName.Contains(input.Filter) || e.EndUser.Contains(input.Filter) || e.BudgetOrderValue.Contains(input.Filter) || e.Comments.Contains(input.Filter) || e.Status.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectNameFilter), e => e.ProjectName == input.ProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerNameFilter), e => e.CustomerName == input.CustomerNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Emailfilter), e => e.Email == input.Emailfilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PhoneFilter), e => e.Email == input.PhoneFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerAddress1Filter), e => e.CustomerAddress1 == input.CustomerAddress1Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PostalCodeFilter), e => e.PostalCode == input.PostalCodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SiteNameFilter), e => e.SiteName == input.SiteNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.EndUserFilter), e => e.EndUser == input.EndUserFilter)
                        .WhereIf(input.MinOrderProbabilityPercFilter != null, e => e.OrderProbabilityPerc >= input.MinOrderProbabilityPercFilter)
                        .WhereIf(input.MaxOrderProbabilityPercFilter != null, e => e.OrderProbabilityPerc <= input.MaxOrderProbabilityPercFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.BudgetOrderValueFilter), e => e.BudgetOrderValue == input.BudgetOrderValueFilter)
                        .WhereIf(input.MinAnticipatedEnquiryReceiptDateFilter != null, e => e.AnticipatedEnquiryReceiptDate >= input.MinAnticipatedEnquiryReceiptDateFilter)
                        .WhereIf(input.MaxAnticipatedEnquiryReceiptDateFilter != null, e => e.AnticipatedEnquiryReceiptDate <= input.MaxAnticipatedEnquiryReceiptDateFilter)
                        .WhereIf(input.MinAnticipatedOrderPlacementDateFilter != null, e => e.AnticipatedOrderPlacementDate >= input.MinAnticipatedOrderPlacementDateFilter)
                        .WhereIf(input.MaxAnticipatedOrderPlacementDateFilter != null, e => e.AnticipatedOrderPlacementDate <= input.MaxAnticipatedOrderPlacementDateFilter)
                        .WhereIf(input.MinApproxProjectDurationMonthsFilter != null, e => e.ApproxProjectDurationMonths >= input.MinApproxProjectDurationMonthsFilter)
                        .WhereIf(input.MaxApproxProjectDurationMonthsFilter != null, e => e.ApproxProjectDurationMonths <= input.MaxApproxProjectDurationMonthsFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments == input.CommentsFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StatusFilter), e => e.Status == input.StatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadSourceTitleFilter), e => e.LeadSourceFk != null && e.LeadSourceFk.Title == input.LeadSourceTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerNameFilter), e => e.CustomerFk != null && e.CustomerFk.Name == input.CustomerNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectTypeCodeFilter), e => e.ProjectTypeFk != null && e.ProjectTypeFk.Code == input.ProjectTypeCodeFilter);

            var query = (from o in filteredLeads
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_leadSourceRepository.GetAll() on o.LeadSourceId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_customerRepository.GetAll() on o.CustomerId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         join o4 in _lookup_projectTypeRepository.GetAll() on o.ProjectTypeId equals o4.Id into j4
                         from s4 in j4.DefaultIfEmpty()

                         select new GetLeadForViewDto()
                         {
                             Lead = new LeadDto
                             {
                                 ProjectName = o.ProjectName,
                                 CustomerName = o.CustomerName,
                                 CustomerAddress1 = o.CustomerAddress1,
                                 CustomerAddress2 = o.CustomerAddress2,
                                 PostalCode = o.PostalCode,
                                 Email = o.Email,
                                 Phone = o.Phone,
                                 SiteName = o.SiteName,
                                 EndUser = o.EndUser,
                                 OrderProbabilityPerc = o.OrderProbabilityPerc,
                                 BudgetOrderValue = o.BudgetOrderValue,
                                 AnticipatedEnquiryReceiptDate = o.AnticipatedEnquiryReceiptDate,
                                 AnticipatedOrderPlacementDate = o.AnticipatedOrderPlacementDate,
                                 ApproxProjectDurationMonths = o.ApproxProjectDurationMonths,
                                 Comments = o.Comments,
                                 Status = o.Status,
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                             LeadSourceTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                             CustomerName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
                             ProjectTypeCode = s4 == null || s4.Code == null ? "" : s4.Code.ToString()
                         });

            var leadListDtos = await query.ToListAsync();

            return _leadsExcelExporter.ExportToFile(leadListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Leads)]
        public async Task<List<LeadOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new LeadOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Leads)]
        public async Task<List<LeadLeadSourceLookupTableDto>> GetAllLeadSourceForTableDropdown()
        {
            return await _lookup_leadSourceRepository.GetAll()
                .Select(leadSource => new LeadLeadSourceLookupTableDto
                {
                    Id = leadSource.Id,
                    DisplayName = leadSource == null || leadSource.Title == null ? "" : leadSource.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Leads)]
        public async Task<List<LeadCustomerLookupTableDto>> GetAllCustomerForTableDropdown()
        {
            return await _lookup_customerRepository.GetAll()
                .Select(customer => new LeadCustomerLookupTableDto
                {
                    Id = customer.Id,
                    DisplayName = customer == null || customer.Name == null ? "" : customer.Name.ToString(),
                    Address1 = customer == null || customer.Address1 == null ? "" : customer.Address1.ToString(),
                    PostalCode = customer == null || customer.PostalCode == null ? "" : customer.PostalCode.ToString(),
                    Email = customer == null || customer.Email == null ? "" : customer.Email.ToString(),
                    Phone = customer == null || customer.Phone == null ? "" : customer.Phone.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Leads)]
        public async Task<List<LeadProjectTypeLookupTableDto>> GetAllProjectTypeForTableDropdown()
        {
            return await _lookup_projectTypeRepository.GetAll()
                .Select(projectType => new LeadProjectTypeLookupTableDto
                {
                    Id = projectType.Id,
                    DisplayName = projectType == null || projectType.Code == null ? "" : projectType.Code.ToString()
                }).ToListAsync();
        }

    }
}