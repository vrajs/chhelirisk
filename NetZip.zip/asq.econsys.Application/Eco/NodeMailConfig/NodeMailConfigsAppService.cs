﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using Abp.Domain.Repositories;
using Abp.Domain.Uow;
using Abp.Linq.Extensions;
using asq.econsys.Authorization;
using asq.econsys.Authorization.Roles;
using asq.econsys.Authorization.Roles.Dto;
using asq.econsys.Eco.NodeMailConfig.Dtos;
using asq.econsys.Eco.NodeTasks;
using asq.econsys.Net.Sms;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using Newtonsoft.Json;
using asq.econsys.Flexi;
using asq.econsys.Flexi.Dtos;

namespace asq.econsys.Eco.NodeMailConfig
{
    [AbpAuthorize(AppPermissions.Pages_NodeMailConfigs)]
    public class NodeMailConfigsAppService : econsysAppServiceBase, INodeMailConfigsAppService
    {
        private readonly IRepository<NodeMailConfig, long> _nodeMailConfigRepository;
        private readonly IRepository<NodeTask, string> _lookup_nodeTaskRepository;
        //private readonly ISmsSender<TwilioSmsSender> _smsSender;
        private readonly RoleManager _roleManager;
        private readonly IRepository<FlexiField, long> _flexiFieldRepository;

        public NodeMailConfigsAppService(IRepository<NodeMailConfig, long> nodeMailConfigRepository,
            IRepository<NodeTask, string> lookup_nodeTaskRepository,
            //ISmsSender<TwilioSmsSender> smsSender, 
            RoleManager roleManager,
            IRepository<FlexiField, long> flexiFieldRepository)
        {
            _nodeMailConfigRepository = nodeMailConfigRepository;
            _lookup_nodeTaskRepository = lookup_nodeTaskRepository;
            //_smsSender = smsSender;
            _roleManager = roleManager;
            _flexiFieldRepository = flexiFieldRepository;
        }


        public async Task<List<GetNodeMailConfigForViewDto>> GetAllForTask(string taskId)
        {
            List<GetNodeMailConfigForViewDto> result = new List<GetNodeMailConfigForViewDto>();
            using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
            {
                var items = await _nodeMailConfigRepository.GetAllIncluding(X => X.NodeTaskFk)
                    .Where(x => x.NodeTaskId.ToLower() == taskId.ToLower())
                    .WhereIf(AbpSession.TenantId.HasValue, x => x.TenantId == AbpSession.TenantId)
                    .WhereIf(!AbpSession.TenantId.HasValue, x => x.TenantId == AbpSession.TenantId)
                    .ToListAsync();
                foreach (var o in items)
                {
                    result.Add(new GetNodeMailConfigForViewDto()
                    {
                        NodeMailConfig = new NodeMailConfigDto
                        {
                            OrganizationId = o.OrganizationId,
                            TemplateId = o.TemplateId,
                            NodeName = o.NodeName,
                            To = o.To,
                            CC = o.CC,
                            BCC = o.BCC,
                            Subject = o.Subject,
                            Attachments = o.Attachments,
                            Body = o.Body,
                            IsGroupMail = o.IsGroupMail,
                            IsCCGroupMail = o.IsCCGroupMail,
                            IsSLA = o.IsSLA,
                            SLATaskName = o.SLATaskName,
                            IsDisabled = o.IsDisabled,
                            Type = o.Type,
                            Rule = o.Rule,
                            RuleJson = o.RuleJson,
                            Id = o.Id,
                            NodeTaskId = o.NodeTaskId
                        },
                        NodeTaskTaskName = o.NodeTaskFk.TaskName
                    });
                }
            }
            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_NodeMailConfigs_Edit)]
        public async Task<GetNodeMailConfigForEditOutput> GetNodeMailConfigForEdit(EntityDto<long> input)
        {
            var nodeMailConfig = await _nodeMailConfigRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetNodeMailConfigForEditOutput { NodeMailConfig = ObjectMapper.Map<CreateOrEditNodeMailConfigDto>(nodeMailConfig) };

            if (output != null && !string.IsNullOrEmpty(output.NodeMailConfig.Weekly))
            {
                output.NodeMailConfig.WeekMonth = true;
            }
            else
            {
                output.NodeMailConfig.WeekMonth = false;
            }

            if (output.NodeMailConfig.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync(output.NodeMailConfig.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            return output;
        }

        public async Task<GetNodeMailConfigForViewDto> CreateOrEdit(CreateOrEditNodeMailConfigDto input)
        {
            var getNodeMailConfigForViewDto = new GetNodeMailConfigForViewDto();
            var nodeMailConfig = new NodeMailConfig();
            if (input.Id == null)
            {
                var data = await Create(input);
                nodeMailConfig = data;
            }
            else
            {
                var data = await Update(input);
                nodeMailConfig = data;
            }

            getNodeMailConfigForViewDto.NodeMailConfig = ObjectMapper.Map<NodeMailConfigDto>(nodeMailConfig);

            //  getNodeMailConfigForViewDto.Project = ObjectMapper.Map<ProjectDto>(project);            
            return getNodeMailConfigForViewDto;
        }

        [AbpAuthorize(AppPermissions.Pages_NodeMailConfigs_Create)]
        protected virtual async Task<NodeMailConfig> Create(CreateOrEditNodeMailConfigDto input)
        {
            // PagedResultDto<GetNodeMailConfigForViewDto> data = GetDuplicateNodeName(input);

            var nodeMailConfig = ObjectMapper.Map<NodeMailConfig>(input);
            //     runHangFireScheduler(input.weekly, input.monthly, input.Id.ToString(), input.To, input.CC);

            if (input != null && input.WeekMonth == true)
            {
                input.Monthly = null;
                nodeMailConfig.Monthly = null;
            }
            else
            {
                input.Weekly = null;
                nodeMailConfig.Weekly = null;
            }

            if (AbpSession.TenantId != null)
            {
                nodeMailConfig.TenantId = (int?)AbpSession.TenantId;
            }
            //if (data.TotalCount <= 0)
            var id = await _nodeMailConfigRepository.InsertAndGetIdAsync(nodeMailConfig);
            //else
            //throw new UserFriendlyException("Node Name is already exists " + input.NodeName);
            return await _nodeMailConfigRepository.GetAsync(id);
        }

        [AbpAuthorize(AppPermissions.Pages_NodeMailConfigs_Edit)]
        protected virtual async Task<NodeMailConfig> Update(CreateOrEditNodeMailConfigDto input)
        {
            //PagedResultDto<GetNodeMailConfigForViewDto> data = GetDuplicateNodeName(input);
            var nodes = _nodeMailConfigRepository.GetAll().Where(x => x.NodeName == input.NodeName && x.Id != (long)input.Id);
            //if (nodes.Count() == 0)
            //{
            var nodeMailConfig = await _nodeMailConfigRepository.FirstOrDefaultAsync((long)input.Id);
            if (input != null && input.WeekMonth == true)
            {
                input.Monthly = null;
            }
            else
            {
                input.Weekly = null;
            }
            ObjectMapper.Map(input, nodeMailConfig);
            //      runHangFireScheduler(input.weekly, input.monthly, input.Id.ToString(), input.To, input.CC);
            return nodeMailConfig;
            //}
            //else
            //{
            //throw new UserFriendlyException("Node Name is already exists " + input.NodeName);
            //}


        }

        [AbpAuthorize(AppPermissions.Pages_NodeMailConfigs_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            var nodeMailConfig = _nodeMailConfigRepository.FirstOrDefault((long)input.Id);
            await _nodeMailConfigRepository.DeleteAsync(input.Id);

            var nodeTask = _lookup_nodeTaskRepository.FirstOrDefault(x => x.Id == nodeMailConfig.NodeTaskId);
            if (nodeTask != null)
            {
                if (nodeMailConfig.Type.ToLower() == CNodeMailConfigType.Event.ToLower())
                {
                    nodeTask.Events -= 1;
                }
                else if (nodeMailConfig.Type.ToLower() == CNodeMailConfigType.Prompt.ToLower())
                {
                    nodeTask.Prompts -= 1;
                }
                else if (nodeMailConfig.Type.ToLower() == CNodeMailConfigType.Escalation.ToLower())
                {
                    nodeTask.Escalations -= 1;
                }
                await _lookup_nodeTaskRepository.UpdateAsync(nodeTask);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_NodeMailConfigs)]
        public async Task<List<NodeMailConfigNodeTaskLookupTableDto>> GetAllNodeTaskForTableDropdown()
        {
            return await _lookup_nodeTaskRepository.GetAll()
                .Select(nodeTask => new NodeMailConfigNodeTaskLookupTableDto
                {
                    Id = nodeTask.Id,
                    DisplayName = nodeTask == null || nodeTask.TaskName == null ? "" : nodeTask.TaskName.ToString()
                }).ToListAsync();
        }
        public PagedResultDto<GetNodeMailConfigForViewDto> GetDuplicateNodeName(CreateOrEditNodeMailConfigDto input)
        {
            var getAllNodeMailConfigsInput = new GetAllNodeMailConfigsInput();
            getAllNodeMailConfigsInput.Filter = input.NodeName;
            Task<PagedResultDto<GetNodeMailConfigForViewDto>> data = GetAll(getAllNodeMailConfigsInput);
            return data.Result;
        }

        
        [AbpAuthorize(AppPermissions.Pages_NodeMailConfigs_Create)]
        public async Task<ListResultDto<RoleListDto>> GetRoles()
        {
            var allRoles = await _roleManager.Roles.ToListAsync();
            return new ListResultDto<RoleListDto>(ObjectMapper.Map<List<RoleListDto>>(allRoles));
        }

        #region commented code

        //public void runHangFireScheduler(DayOfWeek? dayofWeek, string monthly, string id)
        //{
        //    //var id = Guid.NewGuid().ToString("N");
        //    if (dayofWeek != null)
        //    {
        //        switch (dayofWeek)
        //        {
        //            case DayOfWeek.Monday:
        //                RecurringJob.AddOrUpdate(id, () => UserEmailerBJ.SendEmail(), Cron.Weekly(DayOfWeek.Monday));
        //                break;
        //            case DayOfWeek.Tuesday:
        //                RecurringJob.AddOrUpdate(id, () => UserEmailerBJ.SendEmail(), Cron.Weekly(DayOfWeek.Tuesday));
        //                break;
        //            case DayOfWeek.Wednesday:
        //                RecurringJob.AddOrUpdate(id, () => UserEmailerBJ.SendEmail(), Cron.Weekly(DayOfWeek.Wednesday));
        //                break;
        //            case DayOfWeek.Thursday:
        //                RecurringJob.AddOrUpdate(id, () => UserEmailerBJ.SendEmail(), Cron.Weekly(DayOfWeek.Thursday));
        //                break;
        //            case DayOfWeek.Friday:
        //                RecurringJob.AddOrUpdate(id, () => UserEmailerBJ.SendEmail(), Cron.Weekly(DayOfWeek.Friday));
        //                break;
        //            case DayOfWeek.Saturday:
        //                RecurringJob.AddOrUpdate(id, () => UserEmailerBJ.SendEmail(), Cron.Weekly(DayOfWeek.Saturday));
        //                break;
        //            case DayOfWeek.Sunday:
        //                RecurringJob.AddOrUpdate(id, () => UserEmailerBJ.SendEmail(), Cron.Weekly(DayOfWeek.Sunday));
        //                break;
        //            default:
        //                break;
        //        }
        //    }
        //    else
        //    {
        //        var selectedDate = DateTimeOffset.Parse(monthly);
        //        //selectedDate = selectedDate.AddMonths(1);
        //        RecurringJob.AddOrUpdate(id, () => UserEmailerBJ.SendEmail(), Cron.Monthly(selectedDate.Day));
        //    }
        //}


        //[AbpAuthorize(AppPermissions.Pages_NodeMailConfigs_Create)]
        //public async Task<List<FlexiFieldDto>> GetEconsysVariables(string nodeMailConfigType, string nodeTaskId, long? nodeMailConfigId = null)
        //{
        //    List<FlexiFieldDto> flexiFields = new List<FlexiFieldDto>();
        //    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
        //    {
        //        NodeMailConfig nodeMailConfig = new NodeMailConfig();
        //        if (nodeMailConfigId.HasValue)
        //        {
        //            nodeMailConfig = await _nodeMailConfigRepository.GetAll().Where(nmc => nmc.Type == nodeMailConfigType
        //            && nmc.NodeTaskId == nodeTaskId && nmc.Id == nodeMailConfigId.Value)
        //            .WhereIf(AbpSession.TenantId.HasValue, x => x.TenantId == AbpSession.TenantId)
        //            .WhereIf(!AbpSession.TenantId.HasValue, x => x.TenantId == null).FirstOrDefaultAsync();
        //        }
        //        else
        //        {
        //            nodeMailConfig = await _nodeMailConfigRepository.GetAll().Where(nmc => nmc.Type == nodeMailConfigType
        //            && nmc.NodeTaskId == nodeTaskId)
        //            .WhereIf(AbpSession.TenantId.HasValue, x => x.TenantId == AbpSession.TenantId)
        //            .WhereIf(!AbpSession.TenantId.HasValue, x => x.TenantId == null).FirstOrDefaultAsync();
        //        }

        //        NodeTask nodeTask = new NodeTask();

        //        if (nodeMailConfig != null)
        //        {
        //            nodeTask = await _lookup_nodeTaskRepository.GetAll().Where(nt => nt.Id == nodeMailConfig.NodeTaskId).FirstOrDefaultAsync();
        //        }

        //        if (nodeTask != null)
        //        {
        //            var metaData = nodeTask.MetaData;
        //            if (!string.IsNullOrEmpty(metaData))
        //            {
        //                var jsonStr = JsonConvert.DeserializeObject(metaData).ToString().Replace("'", "");
        //                var deserilizedMetaData = JsonConvert.DeserializeObject<Dictionary<string, List<object>>>(jsonStr)["EmailVariableSections"];
        //                if (deserilizedMetaData != null && deserilizedMetaData.Count > 0)
        //                {
        //                    foreach (string item in deserilizedMetaData)
        //                    {
        //                        var selectedFlexiFields = await _flexiFieldRepository.GetAll().Where(ff => ff.FlexiSectionId == item)
        //                            .WhereIf(AbpSession.TenantId.HasValue, x => x.TenantId == AbpSession.TenantId).ToListAsync();
        //                        if (selectedFlexiFields != null && selectedFlexiFields.Count() > 0)
        //                        {
        //                            foreach (var flexiField in selectedFlexiFields)
        //                            {
        //                                var output = ObjectMapper.Map<FlexiFieldDto>(flexiField);
        //                                flexiFields.Add(output);
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }

        //    return flexiFields = flexiFields.OrderBy(a => a.Code).ToList();
        //}

        public async Task<PagedResultDto<GetNodeMailConfigForViewDto>> GetAll(GetAllNodeMailConfigsInput input)
        {
            using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
            {
                var filteredNodeMailConfigs = _nodeMailConfigRepository.GetAll()
               .WhereIf(AbpSession.TenantId.HasValue, x => x.TenantId == AbpSession.TenantId)
               .WhereIf(!AbpSession.TenantId.HasValue, x => x.TenantId == AbpSession.TenantId)
                       .Include(e => e.NodeTaskFk)
                       .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.TemplateId.Contains(input.Filter) || e.NodeName.Contains(input.Filter) || e.To.Contains(input.Filter) || e.CC.Contains(input.Filter) || e.BCC.Contains(input.Filter) || e.Subject.Contains(input.Filter) || e.Attachments.Contains(input.Filter) || e.Body.Contains(input.Filter) || e.SLATaskName.Contains(input.Filter) || e.Type.Contains(input.Filter) || e.Rule.Contains(input.Filter) || e.RuleJson.Contains(input.Filter))
                       .WhereIf(!string.IsNullOrWhiteSpace(input.TypeFilter), e => e.Type == input.TypeFilter)
                       .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFilter), e => e.Rule == input.RuleFilter)
                       .WhereIf(!string.IsNullOrWhiteSpace(input.RuleJsonFilter), e => e.RuleJson == input.RuleJsonFilter)
                       .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter);

                var pagedAndFilteredNodeMailConfigs = filteredNodeMailConfigs
                    .OrderBy(input.Sorting ?? "id asc")
                    .PageBy(input);

                var nodeMailConfigs = from o in pagedAndFilteredNodeMailConfigs
                                      join o1 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o1.Id into j1
                                      from s1 in j1.DefaultIfEmpty()

                                      select new
                                      {

                                          o.OrganizationId,
                                          o.TemplateId,
                                          o.NodeName,
                                          o.To,
                                          o.CC,
                                          o.BCC,
                                          o.Subject,
                                          o.Attachments,
                                          o.Body,
                                          o.IsGroupMail,
                                          o.IsCCGroupMail,
                                          o.IsSLA,
                                          o.SLATaskName,
                                          o.IsDisabled,
                                          o.Type,
                                          o.Rule,
                                          o.RuleJson,
                                          Id = o.Id,
                                          NodeTaskTaskName = s1 == null || s1.TaskName == null ? "" : s1.TaskName.ToString()
                                      };

                var totalCount = await filteredNodeMailConfigs.CountAsync();

                var dbList = await nodeMailConfigs.ToListAsync();
                var results = new List<GetNodeMailConfigForViewDto>();

                foreach (var o in dbList)
                {
                    var res = new GetNodeMailConfigForViewDto()
                    {
                        NodeMailConfig = new NodeMailConfigDto
                        {

                            OrganizationId = o.OrganizationId,
                            TemplateId = o.TemplateId,
                            NodeName = o.NodeName,
                            To = o.To,
                            CC = o.CC,
                            BCC = o.BCC,
                            Subject = o.Subject,
                            Attachments = o.Attachments,
                            Body = o.Body,
                            IsGroupMail = o.IsGroupMail,
                            IsCCGroupMail = o.IsCCGroupMail,
                            IsSLA = o.IsSLA,
                            SLATaskName = o.SLATaskName,
                            IsDisabled = o.IsDisabled,
                            Type = o.Type,
                            Rule = o.Rule,
                            RuleJson = o.RuleJson,
                            Id = o.Id,
                        },
                        NodeTaskTaskName = o.NodeTaskTaskName
                    };

                    results.Add(res);
                }

                return new PagedResultDto<GetNodeMailConfigForViewDto>(
                    totalCount,
                    results
                );
            }

            return null;
        }

        #endregion


    }
}