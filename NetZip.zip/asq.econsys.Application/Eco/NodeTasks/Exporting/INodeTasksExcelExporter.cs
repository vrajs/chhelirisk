﻿using System.Collections.Generic;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.NodeTasks.Exporting
{
    public interface INodeTasksExcelExporter
    {
        FileDto ExportToFile(List<GetNodeTaskForViewDto> nodeTasks);
    }
}