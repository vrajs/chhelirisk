﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.NodeTasks.Exporting
{
    public class NodeActionsExcelExporter : NpoiExcelExporterBase, INodeActionsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public NodeActionsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetNodeActionForViewDto> nodeActions)
        {
            return CreateExcelPackage(
                "NodeActions.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("NodeActions"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        (L("NodeStage")) + L("Id")
                        );

                    AddObjects(
                        sheet, nodeActions,
                        _ => _.NodeAction.Title,
                        _ => _.NodeStageId
                        );

                });
        }
    }
}