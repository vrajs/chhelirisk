﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.NodeTasks.Exporting
{
    public class NodeStagesExcelExporter : NpoiExcelExporterBase, INodeStagesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public NodeStagesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetNodeStageForViewDto> nodeStages)
        {
            return CreateExcelPackage(
                "NodeStages.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("NodeStages"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("HexColorBg"),
                        L("HexColorText"),
                        L("DisplayOrder"),
                        (L("OrganizationUnit")) + L("DisplayName")
                        );

                    AddObjects(
                        sheet, nodeStages,
                        _ => _.NodeStage.Title,
                        _ => _.NodeStage.HexColorBg,
                        _ => _.NodeStage.HexColorText,
                        _ => _.NodeStage.DisplayOrder,
                        _ => _.OrganizationUnitDisplayName
                        );

                });
        }
    }
}