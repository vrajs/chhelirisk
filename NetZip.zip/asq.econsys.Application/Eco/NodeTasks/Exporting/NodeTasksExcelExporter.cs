﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.NodeTasks.Exporting
{
    public class NodeTasksExcelExporter : NpoiExcelExporterBase, INodeTasksExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public NodeTasksExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetNodeTaskForViewDto> nodeTasks)
        {
            return CreateExcelPackage(
                "NodeTasks.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("NodeTasks"));

                    AddHeader(
                        sheet,
                        L("TaskName"),
                        L("Events"),
                        L("Prompts"),
                        L("Escalation")
                        );

                    AddObjects(
                        sheet, nodeTasks,
                        _ => _.NodeTask.TaskName,
                        _ => _.NodeTask.Events,
                        _ => _.NodeTask.Prompts,
                        _ => _.NodeTask.Escalations
                        );

                });
        }
    }
}