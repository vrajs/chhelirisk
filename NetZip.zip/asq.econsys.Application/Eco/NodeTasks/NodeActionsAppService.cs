﻿using asq.econsys.Eco.NodeTasks;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.NodeTasks.Exporting;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.NodeTasks
{
    [AbpAuthorize(AppPermissions.Pages_Administration_NodeActions)]
    public class NodeActionsAppService : econsysAppServiceBase, INodeActionsAppService
    {
        private readonly IRepository<NodeAction, string> _nodeActionRepository;
        private readonly INodeActionsExcelExporter _nodeActionsExcelExporter;
        private readonly IRepository<NodeStage, string> _lookup_nodeStageRepository;
        private readonly Utils.UtilsHelper _utilsHelper;

        public NodeActionsAppService(IRepository<NodeAction, string> nodeActionRepository, INodeActionsExcelExporter nodeActionsExcelExporter, IRepository<NodeStage, string> lookup_nodeStageRepository, Utils.UtilsHelper utilsHelper)
        {
            _nodeActionRepository = nodeActionRepository;
            _nodeActionsExcelExporter = nodeActionsExcelExporter;
            _lookup_nodeStageRepository = lookup_nodeStageRepository;
            _utilsHelper = utilsHelper;
        }

        public async Task<PagedResultDto<GetNodeActionForViewDto>> GetAll(GetAllNodeActionsInput input)
        {

            var filteredNodeActions = _nodeActionRepository.GetAll()
                        .Include(e => e.NodeStageFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeStageIdFilter), e => e.NodeStageFk != null && e.NodeStageFk.Id == input.NodeStageIdFilter);

            var pagedAndFilteredNodeActions = filteredNodeActions
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var nodeActions = from o in pagedAndFilteredNodeActions
                              join o1 in _lookup_nodeStageRepository.GetAll() on o.NodeStageId equals o1.Id into j1
                              from s1 in j1.DefaultIfEmpty()

                              select new
                              {

                                  o.Title,
                                  Id = o.Id,
                                  NodeStageId = s1 == null || s1.Id == null ? "" : s1.Id.ToString()
                              };

            var totalCount = await filteredNodeActions.CountAsync();

            var dbList = await nodeActions.ToListAsync();
            var results = new List<GetNodeActionForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetNodeActionForViewDto()
                {
                    NodeAction = new NodeActionDto
                    {

                        Title = o.Title,
                        Id = o.Id,
                    },
                    NodeStageId = o.NodeStageId
                };

                results.Add(res);
            }

            return new PagedResultDto<GetNodeActionForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetNodeActionForViewDto> GetNodeActionForView(string id)
        {
            var nodeAction = await _nodeActionRepository.GetAsync(id);

            var output = new GetNodeActionForViewDto { NodeAction = ObjectMapper.Map<NodeActionDto>(nodeAction) };

            if (output.NodeAction.NodeStageId != null)
            {
                var _lookupNodeStage = await _lookup_nodeStageRepository.FirstOrDefaultAsync((string)output.NodeAction.NodeStageId);
                output.NodeStageId = _lookupNodeStage?.Id?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeActions_Edit)]
        public async Task<GetNodeActionForEditOutput> GetNodeActionForEdit(EntityDto<string> input)
        {
            var nodeAction = await _nodeActionRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetNodeActionForEditOutput { NodeAction = ObjectMapper.Map<CreateOrEditNodeActionDto>(nodeAction) };

            if (output.NodeAction.NodeStageId != null)
            {
                var _lookupNodeStage = await _lookup_nodeStageRepository.FirstOrDefaultAsync((string)output.NodeAction.NodeStageId);
                output.NodeStageId = _lookupNodeStage?.Id?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditNodeActionDto input)
        {
            if (input.Id.IsNullOrWhiteSpace())
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeActions_Create)]
        protected virtual async Task Create(CreateOrEditNodeActionDto input)
        {
            var nodeAction = ObjectMapper.Map<NodeAction>(input);

            if (AbpSession.TenantId != null)
            {
                nodeAction.TenantId = (int?)AbpSession.TenantId;
            }

            if (nodeAction.Id.IsNullOrWhiteSpace())
            {
                nodeAction.Id = _utilsHelper.GenerateSlug(input.Title);
            }

            await _nodeActionRepository.InsertAsync(nodeAction);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeActions_Edit)]
        protected virtual async Task Update(CreateOrEditNodeActionDto input)
        {
            var nodeAction = await _nodeActionRepository.FirstOrDefaultAsync((string)input.Id);
            ObjectMapper.Map(input, nodeAction);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeActions_Delete)]
        public async Task Delete(EntityDto<string> input)
        {
            await _nodeActionRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetNodeActionsToExcel(GetAllNodeActionsForExcelInput input)
        {

            var filteredNodeActions = _nodeActionRepository.GetAll()
                        .Include(e => e.NodeStageFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeStageIdFilter), e => e.NodeStageFk != null && e.NodeStageFk.Id == input.NodeStageIdFilter);

            var query = (from o in filteredNodeActions
                         join o1 in _lookup_nodeStageRepository.GetAll() on o.NodeStageId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetNodeActionForViewDto()
                         {
                             NodeAction = new NodeActionDto
                             {
                                 Title = o.Title,
                                 Id = o.Id
                             },
                             NodeStageId = s1 == null || s1.Id == null ? "" : s1.Id.ToString()
                         });

            var nodeActionListDtos = await query.ToListAsync();

            return _nodeActionsExcelExporter.ExportToFile(nodeActionListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeActions)]
        public async Task<List<NodeActionNodeStageLookupTableDto>> GetAllNodeStageForTableDropdown()
        {
            return await _lookup_nodeStageRepository.GetAll()
                .Select(nodeStage => new NodeActionNodeStageLookupTableDto
                {
                    Id = nodeStage.Id,
                    DisplayName = nodeStage == null || nodeStage.Id == null ? "" : nodeStage.Id.ToString()
                }).ToListAsync();
        }

    }
}