﻿using Abp.Organizations;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.NodeTasks.Exporting;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.NodeTasks
{
    [AbpAuthorize(AppPermissions.Pages_Administration_NodeStages)]
    public class NodeStagesAppService : econsysAppServiceBase, INodeStagesAppService
    {
        private readonly IRepository<NodeStage, string> _nodeStageRepository;
        private readonly INodeStagesExcelExporter _nodeStagesExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly Utils.UtilsHelper _utilsHelper;

        public NodeStagesAppService(IRepository<NodeStage, string> nodeStageRepository, INodeStagesExcelExporter nodeStagesExcelExporter, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository, Utils.UtilsHelper utilsHelper)
        {
            _nodeStageRepository = nodeStageRepository;
            _nodeStagesExcelExporter = nodeStagesExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _utilsHelper = utilsHelper;

        }

        public async Task<PagedResultDto<GetNodeStageForViewDto>> GetAll(GetAllNodeStagesInput input)
        {

            var filteredNodeStages = _nodeStageRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.HexColorBg.Contains(input.Filter) || e.HexColorText.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HexColorBgFilter), e => e.HexColorBg == input.HexColorBgFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HexColorTextFilter), e => e.HexColorText == input.HexColorTextFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var pagedAndFilteredNodeStages = filteredNodeStages
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var nodeStages = from o in pagedAndFilteredNodeStages
                             join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                             from s1 in j1.DefaultIfEmpty()

                             select new
                             {

                                 o.Title,
                                 o.HexColorBg,
                                 o.HexColorText,
                                 o.DisplayOrder,
                                 Id = o.Id,
                                 OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                             };

            var totalCount = await filteredNodeStages.CountAsync();

            var dbList = await nodeStages.ToListAsync();
            var results = new List<GetNodeStageForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetNodeStageForViewDto()
                {
                    NodeStage = new NodeStageDto
                    {

                        Title = o.Title,
                        HexColorBg = o.HexColorBg,
                        HexColorText = o.HexColorText,
                        DisplayOrder = o.DisplayOrder,
                        Id = o.Id,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetNodeStageForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetNodeStageForViewDto> GetNodeStageForView(string id)
        {
            var nodeStage = await _nodeStageRepository.GetAsync(id);

            var output = new GetNodeStageForViewDto { NodeStage = ObjectMapper.Map<NodeStageDto>(nodeStage) };

            if (output.NodeStage.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.NodeStage.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeStages_Edit)]
        public async Task<GetNodeStageForEditOutput> GetNodeStageForEdit(EntityDto<string> input)
        {
            var nodeStage = await _nodeStageRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetNodeStageForEditOutput { NodeStage = ObjectMapper.Map<CreateOrEditNodeStageDto>(nodeStage) };

            if (output.NodeStage.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.NodeStage.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditNodeStageDto input)
        {
            if (input.Id.IsNullOrWhiteSpace())
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeStages_Create)]
        protected virtual async Task Create(CreateOrEditNodeStageDto input)
        {
            var nodeStage = ObjectMapper.Map<NodeStage>(input);

            if (AbpSession.TenantId != null)
            {
                nodeStage.TenantId = (int?)AbpSession.TenantId;
            }

            if (nodeStage.Id.IsNullOrWhiteSpace())
            {
                //nodeStage.Id = Guid.NewGuid().ToString();
                nodeStage.Id = _utilsHelper.GenerateSlug(input.Title);
            }

            await _nodeStageRepository.InsertAsync(nodeStage);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeStages_Edit)]
        protected virtual async Task Update(CreateOrEditNodeStageDto input)
        {
            var nodeStage = await _nodeStageRepository.FirstOrDefaultAsync((string)input.Id);
            ObjectMapper.Map(input, nodeStage);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeStages_Delete)]
        public async Task Delete(EntityDto<string> input)
        {
            await _nodeStageRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetNodeStagesToExcel(GetAllNodeStagesForExcelInput input)
        {

            var filteredNodeStages = _nodeStageRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.HexColorBg.Contains(input.Filter) || e.HexColorText.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HexColorBgFilter), e => e.HexColorBg == input.HexColorBgFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HexColorTextFilter), e => e.HexColorText == input.HexColorTextFilter)
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var query = (from o in filteredNodeStages
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetNodeStageForViewDto()
                         {
                             NodeStage = new NodeStageDto
                             {
                                 Title = o.Title,
                                 HexColorBg = o.HexColorBg,
                                 HexColorText = o.HexColorText,
                                 DisplayOrder = o.DisplayOrder,
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                         });

            var nodeStageListDtos = await query.ToListAsync();

            return _nodeStagesExcelExporter.ExportToFile(nodeStageListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeStages)]
        public async Task<List<NodeStageOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new NodeStageOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

    }
}