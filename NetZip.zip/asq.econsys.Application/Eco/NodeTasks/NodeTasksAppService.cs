﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.NodeTasks
{
    [AbpAuthorize(AppPermissions.Pages_Administration_NodeTasks)]
    public class NodeTasksAppService : econsysAppServiceBase, INodeTasksAppService
    {
        private readonly IRepository<NodeTask, string> _nodeTaskRepository;
        private readonly IRepository<NodeStage, string> _nodeStageRepository;

        public NodeTasksAppService(IRepository<NodeTask, string> nodeTaskRepository, IRepository<NodeStage, string> nodeStageRepository)
        {
            _nodeTaskRepository = nodeTaskRepository;
            _nodeStageRepository = nodeStageRepository;
        }

        public async Task<PagedResultDto<GetNodeTaskForViewDto>> GetAll(GetAllNodeTasksInput input)
        {
            using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
            {
                var filteredNodeTasks = _nodeTaskRepository.GetAll()
                        .Include(e => e.NodeStageFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.TaskName.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeStageTitleFilter), e => e.NodeStageFk != null && e.NodeStageFk.Title == input.NodeStageTitleFilter);

                ////var filteredNodeTasks = _nodeTaskRepository.GetAll()
                ////            .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.TaskName.Contains(input.Filter));

                var pagedAndFilteredNodeTasks = filteredNodeTasks
                    .OrderBy(input.Sorting ?? "id asc");

                var nodeTasks = from o in pagedAndFilteredNodeTasks
                                select new
                                {

                                    o.TaskName,
                                    o.Events,
                                    o.Prompts,
                                    o.Escalations,
                                    Id = o.Id
                                };

                var totalCount = await filteredNodeTasks.CountAsync();

                var dbList = await nodeTasks.ToListAsync();
                var results = new List<GetNodeTaskForViewDto>();

                foreach (var o in dbList)
                {
                    var res = new GetNodeTaskForViewDto()
                    {
                        NodeTask = new NodeTaskDto
                        {

                            TaskName = o.TaskName,
                            Events = o.Events,
                            Prompts = o.Prompts,
                            Escalations = o.Escalations,
                            Id = o.Id,
                        }
                    };

                    results.Add(res);
                }

                var pagedAndFilteredMappings = results.Skip(input.SkipCount).Take(input.MaxResultCount).ToList();

                return new PagedResultDto<GetNodeTaskForViewDto>(
                    results.Count,
                    pagedAndFilteredMappings
                );
            }

            return null;
        }

        public async Task<GetNodeTaskForViewDto> GetNodeTaskForView(string id)
        {
            var nodeTask = await _nodeTaskRepository.GetAsync(id);

            var output = new GetNodeTaskForViewDto { NodeTask = ObjectMapper.Map<NodeTaskDto>(nodeTask) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeTasks_Edit)]
        public async Task<GetNodeTaskForEditOutput> GetNodeTaskForEdit(EntityDto<string> input)
        {
            var nodeTask = await _nodeTaskRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetNodeTaskForEditOutput { NodeTask = ObjectMapper.Map<CreateOrEditNodeTaskDto>(nodeTask) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditNodeTaskDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeTasks_Create)]
        protected virtual async Task Create(CreateOrEditNodeTaskDto input)
        {
            var nodeTask = ObjectMapper.Map<NodeTask>(input);

            if (AbpSession.TenantId != null)
            {
                nodeTask.TenantId = (int?)AbpSession.TenantId;
            }

            await _nodeTaskRepository.InsertAsync(nodeTask);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeTasks_Edit)]
        protected virtual async Task Update(CreateOrEditNodeTaskDto input)
        {
            var nodeTask = await _nodeTaskRepository.FirstOrDefaultAsync((string)input.Id);
            ObjectMapper.Map(input, nodeTask);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_NodeTasks_Delete)]
        public async Task Delete(EntityDto<string> input)
        {
            await _nodeTaskRepository.DeleteAsync(input.Id);
        }

        public async Task<List<NodeStageDto>> GetAllStages()
        {
            List<NodeStageDto> nodeStageDtos = new List<NodeStageDto>();
            try
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var stages = _nodeStageRepository.GetAll().Where(x => !x.IsDeleted).OrderBy(a => a.DisplayOrder).ToList();
                    if (stages != null && stages.Count > 0)
                    {
                        foreach (var stage in stages)
                        {
                            NodeStageDto nodeStageDto = new NodeStageDto();
                            nodeStageDto.Id = stage.Id;
                            nodeStageDto.DisplayOrder = stage.DisplayOrder;
                            nodeStageDto.Title = stage.Title;
                            nodeStageDtos.Add(nodeStageDto);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new UserFriendlyException(L("Something went wrong while fetching Stages"));
            }
            return nodeStageDtos;
        }
    }
}