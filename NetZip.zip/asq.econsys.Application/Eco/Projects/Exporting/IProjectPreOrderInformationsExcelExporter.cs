﻿using System.Collections.Generic;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.Projects.Exporting
{
    public interface IProjectPreOrderInformationsExcelExporter
    {
        FileDto ExportToFile(List<GetProjectPreOrderInformationForViewDto> projectPreOrderInformations);
    }
}