﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectActionsExcelExporter : NpoiExcelExporterBase, IProjectActionsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectActionsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectActionForViewDto> projectActions)
        {
            return CreateExcelPackage(
                "ProjectActions.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectActions"));

                    AddHeader(
                        sheet,
                        L("Status"),
                        L("MetaData"),
                        (L("Project")) + L("ProjectName"),
                        (L("NodeAction")) + L("Title"),
                        (L("NodeAction")) + L("Title"),
                        (L("NodeTask")) + L("TaskName"),
                        (L("NodeTask")) + L("TaskName")
                        );

                    AddObjects(
                        sheet, projectActions,
                        _ => _.ProjectAction.Status,
                        _ => _.ProjectAction.MetaData,
                        _ => _.ProjectProjectName,
                        _ => _.NodeActionTitle,
                        _ => _.NodeActionTitle2,
                        _ => _.NodeTaskTaskName,
                        _ => _.NodeTaskTaskName2
                        );

                });
        }
    }
}