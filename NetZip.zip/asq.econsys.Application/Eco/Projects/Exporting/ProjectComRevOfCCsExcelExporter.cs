﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectComRevOfCCsExcelExporter : NpoiExcelExporterBase, IProjectComRevOfCCsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectComRevOfCCsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectComRevOfCCForViewDto> projectComRevOfCCs)
        {
            return CreateExcelPackage(
                "ProjectComRevOfCCs.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectComRevOfCCs"));

                    AddHeader(
                        sheet,
                        L("Comment"),
                        L("String1"),
                        L("String2"),
                        (L("Project")) + L("ProjectName")
                        );

                    AddObjects(
                        sheet, projectComRevOfCCs,
                        _ => _.ProjectComRevOfCC.Comment,
                        _ => _.ProjectComRevOfCC.String1,
                        _ => _.ProjectComRevOfCC.String2,
                        _ => _.ProjectProjectName
                        );

                });
        }
    }
}