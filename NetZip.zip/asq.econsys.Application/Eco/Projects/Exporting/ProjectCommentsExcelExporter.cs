﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectCommentsExcelExporter : NpoiExcelExporterBase, IProjectCommentsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectCommentsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectCommentForViewDto> projectComments)
        {
            return CreateExcelPackage(
                "ProjectComments.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectComments"));

                    AddHeader(
                        sheet,
                        L("NodeAction"),
                        L("Content"),
                        L("Level"),
                        L("MetaData"),
                        (L("Project")) + L("ProjectName"),
                        (L("NodeTask")) + L("TaskName"),
                        (L("ProjectComment")) + L("Comment")
                        );

                    AddObjects(
                        sheet, projectComments,
                        _ => _.ProjectComment.NodeAction,
                        _ => _.ProjectComment.Content,
                        _ => _.ProjectComment.Level,
                        _ => _.ProjectComment.MetaData,
                        _ => _.ProjectProjectName,
                        _ => _.NodeTaskTaskName,
                        _ => _.ProjectCommentComment
                        );

                });
        }
    }
}