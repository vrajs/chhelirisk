﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectCommercialTasksPriorCommencesExcelExporter : NpoiExcelExporterBase, IProjectCommercialTasksPriorCommencesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectCommercialTasksPriorCommencesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectCommercialTasksPriorCommenceForViewDto> projectCommercialTasksPriorCommences)
        {
            return CreateExcelPackage(
                "ProjectCommercialTasksPriorCommences.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectCommercialTasksPriorCommences"));

                    AddHeader(
                        sheet,
                        L("ProjectOAReviewId"),
                        L("JobReference"),
                        L("IsProjAppInvoice"),
                        L("ComRuleFoPayTerm"),
                        L("PaymentTerm"),
                        L("DaysFrom"),
                        L("PayCycTer"),
                        L("DownPayCycTempExc"),
                        L("NotInteSuspPer"),
                        L("IsTheDefLiaPerAppToThJob"),
                        L("IsTheDefLiaHowManMon"),
                        L("IsTheDefLiaWhyNot"),
                        L("IsTheRetenOnJob"),
                        L("RetenOnJobWhatPercentage"),
                        L("WhWilFinMoiReteBeDueSpe"),
                        L("WhWilFinMoiReteBeDue"),
                        L("WhWilFinMoiReteBeDueMonth"),
                        L("IsScheOfRatNeeOnThisProj"),
                        L("Comments"),
                        (L("Project")) + L("ProjectName")
                        );

                    AddObjects(
                        sheet, projectCommercialTasksPriorCommences,
                        _ => _.ProjectCommercialTasksPriorCommence.ProjectOAReviewId,
                        _ => _.ProjectCommercialTasksPriorCommence.JobReference,
                        _ => _.ProjectCommercialTasksPriorCommence.IsProjAppInvoice,
                        _ => _.ProjectCommercialTasksPriorCommence.ComRuleFoPayTerm,
                        _ => _.ProjectCommercialTasksPriorCommence.PaymentTerm,
                        _ => _.ProjectCommercialTasksPriorCommence.DaysFrom,
                        _ => _.ProjectCommercialTasksPriorCommence.PayCycTer,
                        _ => _.ProjectCommercialTasksPriorCommence.DownPayCycTempExc,
                        _ => _.ProjectCommercialTasksPriorCommence.NotInteSuspPer,
                        _ => _.ProjectCommercialTasksPriorCommence.IsTheDefLiaPerAppToThJob,
                        _ => _.ProjectCommercialTasksPriorCommence.IsTheDefLiaHowManMon,
                        _ => _.ProjectCommercialTasksPriorCommence.IsTheDefLiaWhyNot,
                        _ => _.ProjectCommercialTasksPriorCommence.IsTheRetenOnJob,
                        _ => _.ProjectCommercialTasksPriorCommence.RetenOnJobWhatPercentage,
                        _ => _.ProjectCommercialTasksPriorCommence.WhWilFinMoiReteBeDueSpe,
                        _ => _timeZoneConverter.Convert(_.ProjectCommercialTasksPriorCommence.WhWilFinMoiReteBeDue, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectCommercialTasksPriorCommence.WhWilFinMoiReteBeDueMonth,
                        _ => _.ProjectCommercialTasksPriorCommence.IsScheOfRatNeeOnThisProj,
                        _ => _.ProjectCommercialTasksPriorCommence.Comments,
                        _ => _.ProjectProjectName
                        );

                    for (var i = 1; i <= projectCommercialTasksPriorCommences.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[14], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(14);
                });
        }
    }
}