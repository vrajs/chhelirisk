﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectCostDetailsExcelExporter : NpoiExcelExporterBase, IProjectCostDetailsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectCostDetailsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectCostDetailForViewDto> projectCostDetails)
        {
            return CreateExcelPackage(
                "ProjectCostDetails.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectCostDetails"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("Category"),
                        L("CostAmountApproved"),
                        L("CostAmount"),
                        L("CostEstimate"),
                        L("CostVariance"),
                        L("CostActualReceived"),
                        L("CostEstimatedToCome"),
                        L("SellAmountApproved"),
                        L("SellAmount"),
                        L("SellEstimate"),
                        L("SellVariance"),
                        L("MarginAmount"),
                        L("MarginPerc"),
                        L("Comment"),
                        (L("Project")) + L("ProjectName"),
                        (L("ProjectAction")) + L("Status"),
                        (L("ProjectExReviewDetail")) + L("Title")
                        );

                    AddObjects(
                        sheet, projectCostDetails,
                        _ => _.ProjectCostDetail.Title,
                        _ => _.ProjectCostDetail.Category,
                        _ => _.ProjectCostDetail.CostAmountApproved,
                        _ => _.ProjectCostDetail.CostAmount,
                        _ => _.ProjectCostDetail.CostEstimate,
                        _ => _.ProjectCostDetail.CostVariance,
                        _ => _.ProjectCostDetail.CostActualReceived,
                        _ => _.ProjectCostDetail.CostEstimatedToCome,
                        _ => _.ProjectCostDetail.SellAmountApproved,
                        _ => _.ProjectCostDetail.SellAmount,
                        _ => _.ProjectCostDetail.SellEstimate,
                        _ => _.ProjectCostDetail.SellVariance,
                        _ => _.ProjectCostDetail.MarginAmount,
                        _ => _.ProjectCostDetail.MarginPerc,
                        _ => _.ProjectCostDetail.Comment,
                        _ => _.ProjectProjectName,
                        _ => _.ProjectActionStatus,
                        _ => _.ProjectExReviewDetailTitle
                        );

                });
        }
    }
}