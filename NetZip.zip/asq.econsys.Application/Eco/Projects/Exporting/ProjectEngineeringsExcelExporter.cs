﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectEngineeringsExcelExporter : NpoiExcelExporterBase, IProjectEngineeringsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectEngineeringsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectEngineeringForViewDto> projectEngineerings)
        {
            return CreateExcelPackage(
                "ProjectEngineerings.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectEngineerings"));

                    AddHeader(
                        sheet,
                        (L("Project")) + L("ProjectName"),
                        (L("RuleElement")) + L("Title"),
                        (L("RuleValue")) + L("Title"),
                        (L("RuleFlag")) + L("Title"),
                        (L("RevenueRange")) + L("Title")
                        );

                    AddObjects(
                        sheet, projectEngineerings,
                        _ => _.ProjectProjectName,
                        _ => _.RuleElementTitle,
                        _ => _.RuleValueTitle,
                        _ => _.RuleFlagTitle,
                        _ => _.RevenueRangeTitle
                        );

                });
        }
    }
}