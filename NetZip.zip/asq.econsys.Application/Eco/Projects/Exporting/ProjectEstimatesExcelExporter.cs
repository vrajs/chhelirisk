﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectEstimatesExcelExporter : NpoiExcelExporterBase, IProjectEstimatesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectEstimatesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectEstimateForViewDto> projectEstimates)
        {
            return CreateExcelPackage(
                "ProjectEstimates.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectEstimates"));

                    AddHeader(
                        sheet,
                        L("BidStarts"),
                        L("BidEnds"),
                        L("BidWeeks"),
                        L("RFIDeadline"),
                        L("RFIDeadlineDate"),
                        L("OrderDate"),
                        L("ProjectStarts"),
                        L("ProjectEnds"),
                        L("Points"),
                        L("SurveryReq"),
                        L("ExplicitSurveyReqmnts"),
                        L("ProposedSurvey"),
                        L("ProjectWeeks"),
                        (L("Project")) + L("ProjectName"),
                        (L("RevenueRange")) + L("Title")
                        );

                    AddObjects(
                        sheet, projectEstimates,
                        _ => _timeZoneConverter.Convert(_.ProjectEstimate.BidStartDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.ProjectEstimate.BidEndDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectEstimate.BidWeeks,
                        _ => _.ProjectEstimate.RFIDeadline,
                        _ => _timeZoneConverter.Convert(_.ProjectEstimate.RFIDeadlineDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.ProjectEstimate.AnticipatedOrderDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.ProjectEstimate.ProjectStartDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.ProjectEstimate.ProjectEndDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectEstimate.Points,
                        _ => _.ProjectEstimate.SurveryReq,
                        _ => _.ProjectEstimate.ExplicitSurveyReqmnts,
                        _ => _.ProjectEstimate.ProposedSurvey,
                        _ => _.ProjectEstimate.ProjectWeeks,
                        _ => _.ProjectProjectName,
                        _ => _.RevenueRangeTitle
                        );

                    for (var i = 1; i <= projectEstimates.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[1], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(1); for (var i = 1; i <= projectEstimates.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[2], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(2); for (var i = 1; i <= projectEstimates.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[5], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(5); for (var i = 1; i <= projectEstimates.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[6], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(6); for (var i = 1; i <= projectEstimates.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[7], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(7); for (var i = 1; i <= projectEstimates.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[8], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(8);
                });
        }
    }
}