﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectExReviewAppInvoiceForecastsExcelExporter : NpoiExcelExporterBase, IProjectExReviewAppInvoiceForecastsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectExReviewAppInvoiceForecastsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectExReviewAppInvoiceForecastForViewDto> projectExReviewAppInvoiceForecasts)
        {
            return CreateExcelPackage(
                "ProjectExReviewAppInvoiceForecasts.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectExReviewAppInvoiceForecasts"));

                    AddHeader(
                        sheet,
                        L("Category"),
                        L("SubmissionDate"),
                        L("FinalPaymentDate"),
                        L("ContractWorks"),
                        L("Remaining"),
                        L("Variation"),
                        L("Claim"),
                        L("Total"),
                        L("Comment"),
                        (L("Project")) + L("ProjectName"),
                        (L("ProjectExReviewDetail")) + L("Title")
                        );

                    AddObjects(
                        sheet, projectExReviewAppInvoiceForecasts,
                        _ => _.ProjectExReviewAppInvoiceForecast.Category,
                        _ => _timeZoneConverter.Convert(_.ProjectExReviewAppInvoiceForecast.SubmissionDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.ProjectExReviewAppInvoiceForecast.FinalPaymentDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectExReviewAppInvoiceForecast.ContractWorks,
                        _ => _.ProjectExReviewAppInvoiceForecast.Remaining,
                        _ => _.ProjectExReviewAppInvoiceForecast.Variation,
                        _ => _.ProjectExReviewAppInvoiceForecast.Claim,
                        _ => _.ProjectExReviewAppInvoiceForecast.Total,
                        _ => _.ProjectExReviewAppInvoiceForecast.Comment,
                        _ => _.ProjectProjectName,
                        _ => _.ProjectExReviewDetailTitle
                        );

                    for (var i = 1; i <= projectExReviewAppInvoiceForecasts.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[2], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(2); for (var i = 1; i <= projectExReviewAppInvoiceForecasts.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[3], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(3);
                });
        }
    }
}