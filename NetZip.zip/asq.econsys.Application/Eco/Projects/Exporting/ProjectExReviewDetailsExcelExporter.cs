﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectExReviewDetailsExcelExporter : NpoiExcelExporterBase, IProjectExReviewDetailsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectExReviewDetailsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectExReviewDetailForViewDto> projectExReviewDetails)
        {
            return CreateExcelPackage(
                "ProjectExReviewDetails.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectExReviewDetails"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("ReviewType"),
                        L("IsSubcontract"),
                        L("IsCurrent"),
                        L("DisplayOrder"),
                        (L("ProjectExReview")) + L("Title")
                        );

                    AddObjects(
                        sheet, projectExReviewDetails,
                        _ => _.ProjectExReviewDetail.Title,
                        _ => _.ProjectExReviewDetail.ReviewType,
                        _ => _.ProjectExReviewDetail.IsSubcontract,
                        _ => _.ProjectExReviewDetail.IsCurrent,
                        _ => _.ProjectExReviewDetail.DisplayOrder,
                        _ => _.ProjectExReviewTitle
                        );

                });
        }
    }
}