﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectExReviewsExcelExporter : NpoiExcelExporterBase, IProjectExReviewsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectExReviewsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectExReviewForViewDto> projectExReviews)
        {
            return CreateExcelPackage(
                "ProjectExReviews.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectExReviews"));

                    AddHeader(
                        sheet,
                        L("Title"),
                        L("IsCurrent"),
                        L("DisplayOrder"),
                        (L("Project")) + L("ProjectName")
                        );

                    AddObjects(
                        sheet, projectExReviews,
                        _ => _.ProjectExReview.Title,
                        _ => _.ProjectExReview.IsCurrent,
                        _ => _.ProjectExReview.DisplayOrder,
                        _ => _.ProjectProjectName
                        );

                });
        }
    }
}