﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectMRABPLsExcelExporter : NpoiExcelExporterBase, IProjectMRABPLsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectMRABPLsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectMRABPLForViewDto> ProjectMRABPLs)
        {
            return CreateExcelPackage(
                "ProjectMRABPLs.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectMRABPLs"));

                    AddHeader(
                        sheet,
                        L("ScheMeetWiOpe"),
                        L("Comment"),
                        (L("Project")) + L("ProjectName"),
                        (L("ProjectSalesToOpsHand")) + L("ScheMeetWiOpe")
                        );

                    AddObjects(
                        sheet, ProjectMRABPLs,
                        _ => _.ProjectMRABPL.ScheMeetWiOpe,
                        _ => _.ProjectMRABPL.Comment,
                        _ => _.ProjectProjectName,
                        _ => _.ProjectSalesToOpsHandScheMeetWiOpe
                        );

                });
        }
    }
}