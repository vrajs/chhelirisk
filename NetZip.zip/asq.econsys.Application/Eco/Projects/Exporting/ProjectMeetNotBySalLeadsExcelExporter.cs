﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectMeetNotBySalLeadsExcelExporter : NpoiExcelExporterBase, IProjectMeetNotBySalLeadsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectMeetNotBySalLeadsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectMeetNotBySalLeadForViewDto> projectMeetNotBySalLeads)
        {
            return CreateExcelPackage(
                "ProjectMeetNotBySalLeads.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectMeetNotBySalLeads"));

                    AddHeader(
                        sheet,
                        L("MeetingNoteSL"),
                        L("Comment"),
                        L("MeetingNotePL"),
                        (L("Project")) + L("ProjectName")
                        );

                    AddObjects(
                        sheet, projectMeetNotBySalLeads,
                        _ => _.ProjectMeetNotBySalLead.MeetingNoteSL,
                        _ => _.ProjectMeetNotBySalLead.Comment,
                        _ => _.ProjectMeetNotBySalLead.MeetingNotePL,
                        _ => _.ProjectProjectName
                        );

                });
        }
    }
}