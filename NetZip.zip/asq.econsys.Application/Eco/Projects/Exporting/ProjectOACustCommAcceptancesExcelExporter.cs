﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectOACustCommAcceptancesExcelExporter : NpoiExcelExporterBase, IProjectOACustCommAcceptancesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectOACustCommAcceptancesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectOACustCommAcceptanceForViewDto> projectOACustCommAcceptances)
        {
            return CreateExcelPackage(
                "ProjectOACustCommAcceptances.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectOACustCommAcceptances"));

                    AddHeader(
                        sheet,
                        L("IsRecReqComOfWork"),
                        L("IsLimitFinalQuote"),
                        L("IsRecImpLimitExp"),
                        L("ExpenditureLimit"),
                        L("IsRecimpTimeLimitValidity"),
                        L("ProposedStartDate"),
                        L("ProposedEndDate"),
                        L("ProposedStartDateCommit"),
                        L("ProposedEndDateCommit"),
                        L("IsRecOtherItemFurtherReview"),
                        L("IsIntroTermsCondition"),
                        L("IsScopeDetClientComFinQuoteScope"),
                        L("IsDocRefClientComQuoteBase"),
                        L("IsTermCondComQuoteBasedOn"),
                        L("IsHappyCLAsExcKeyTechFinalQuote"),
                        L("ProposedContractValue"),
                        L("ResponseText"),
                        L("Comments"),
                        L("status"),
                        (L("Project")) + L("ProjectName"),
                        (L("NodeTask")) + L("TaskName"),
                        (L("ProjectOAReview")) + L("Title")
                        );

                    AddObjects(
                        sheet, projectOACustCommAcceptances,
                        _ => _.projectOACustCommAcceptance.IsRecReqComOfWork,
                        _ => _.projectOACustCommAcceptance.IsLimitFinalQuote,
                        _ => _.projectOACustCommAcceptance.IsRecImpLimitExp,
                        _ => _.projectOACustCommAcceptance.ExpenditureLimit,
                        _ => _.projectOACustCommAcceptance.IsRecimpTimeLimitValidity,
                        _ => _timeZoneConverter.Convert(_.projectOACustCommAcceptance.ProposedStartDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.projectOACustCommAcceptance.ProposedEndDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.projectOACustCommAcceptance.SLRProposedStartDateCommit, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _timeZoneConverter.Convert(_.projectOACustCommAcceptance.SLRProposedEndDateCommit, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.projectOACustCommAcceptance.IsRecOtherItemFurtherReview,
                        _ => _.projectOACustCommAcceptance.IsIntroTermsCondition,
                        _ => _.projectOACustCommAcceptance.IsSLRScopeDetClientComFinQuoteScope,
                        _ => _.projectOACustCommAcceptance.IsSLRDocRefClientComQuoteBase,
                        _ => _.projectOACustCommAcceptance.IsSLRTermCondComQuoteBasedOn,
                        _ => _.projectOACustCommAcceptance.IsSLRHappyCLAsExcKeyTechFinalQuote,
                        _ => _.projectOACustCommAcceptance.IsSLRProposedContractValueAgreed,
                        _ => _.projectOACustCommAcceptance.ResponseText,
                        _ => _.projectOACustCommAcceptance.Comments,
                        _ => _.projectOACustCommAcceptance.status,
                        _ => _.ProjectProjectName,
                        _ => _.NodeTaskTaskName,
                        _ => _.ProjectOAReviewTitle
                        );

                    for (var i = 1; i <= projectOACustCommAcceptances.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[6], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(6); for (var i = 1; i <= projectOACustCommAcceptances.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[7], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(7); for (var i = 1; i <= projectOACustCommAcceptances.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[8], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(8); for (var i = 1; i <= projectOACustCommAcceptances.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[9], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(9);
                });
        }
    }
}