﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectOpsConfirOfHandsExcelExporter : NpoiExcelExporterBase, IProjectOpsConfirOfHandsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectOpsConfirOfHandsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectOpsConfirOfHandForViewDto> projectOpsConfirOfHands)
        {
            return CreateExcelPackage(
                "ProjectOpsConfirOfHands.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectOpsConfirOfHands"));

                    AddHeader(
                        sheet,
                        L("DocumentList"),
                        L("SalLeadreqmeet"),
                        L("Confirmed"),
                        L("WhyNot"),
                        L("SchedMeetWithSales"),
                        L("SchedMeetWithSalesTime"),
                        L("Comments"),
                        L("ProjectId")
                        );

                    AddObjects(
                        sheet, projectOpsConfirOfHands,
                        _ => _.ProjectOpsConfirOfHand.DocumentList,
                        _ => _.ProjectOpsConfirOfHand.SalLeadreqmeet,
                        _ => _.ProjectOpsConfirOfHand.Confirmed,
                        _ => _.ProjectOpsConfirOfHand.WhyNot,
                        _ => _.ProjectOpsConfirOfHand.SchedMeetWithSales,
                        _ => _timeZoneConverter.Convert(_.ProjectOpsConfirOfHand.SchedMeetWithSalesTime, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectOpsConfirOfHand.Comments,
                        _ => _.ProjectOpsConfirOfHand.ProjectId
                        );

                    for (var i = 1; i <= projectOpsConfirOfHands.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[6], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(6);
                });
        }
    }
}