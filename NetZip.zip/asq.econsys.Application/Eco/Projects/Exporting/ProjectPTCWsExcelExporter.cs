﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectPTCWsExcelExporter : NpoiExcelExporterBase, IProjectPTCWsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectPTCWsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectPTCWForViewDto> projectPTCWs)
        {
            return CreateExcelPackage(
                "ProjectPTCWs.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectPTCWs"));

                    AddHeader(
                        sheet,
                        L("ClientOrderRefNo"),
                        L("Date"),
                        L("Address"),
                        L("Attensionof"),
                        L("Subject"),
                        L("PostalCode"),
                        L("Company"),
                        L("Scopeofworks"),
                        L("ValueoftheCommitment"),
                        L("CorrespondWithRole"),
                        L("CorrespondWithName"),
                        L("CorrespondWithEmail"),
                        L("Comments")
                        );

                    AddObjects(
                        sheet, projectPTCWs,
                        _ => _.ProjectPTCW.ClientOrderRefNo,
                        _ => _timeZoneConverter.Convert(_.ProjectPTCW.BidStartDate, _abpSession.TenantId, _abpSession.GetUserId())
                        );

                    for (var i = 1; i <= projectPTCWs.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[2], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(2);
                });
        }
    }
}