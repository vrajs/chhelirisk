﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectPaymentCycleTermExcelExporter : NpoiExcelExporterBase, IProjectPaymentCycleTermExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectPaymentCycleTermExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectPaymentCycleTermForViewDto> projectPaymentCycleTerms)
        {
            return CreateExcelPackage(
                "ProjectPaymentCycleTerms.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectPaymentCycleTerms"));

                    AddHeader(
                        sheet,
                        L("SubmitBy"),
                        L("ValuedTo"),
                        L("DueDate"),
                        L("PayNoticeBy"),
                        L("PayLessNoticeBy"),
                        L("FinalDateForPayment"),
                        (L("Project")) + L("ProjectName"),
                        (L("ProjectAction")) + L("Status"),
                        (L("ProjectExReviewDetail")) + L("Title")
                        );

                    AddObjects(
                        sheet, projectPaymentCycleTerms,
                        _ => _.ProjectPaymentCycleTerm.SubmitBy,
                        _ => _.ProjectPaymentCycleTerm.ValuedTo,
                        _ => _.ProjectPaymentCycleTerm.DueDate,
                        _ => _.ProjectPaymentCycleTerm.PayNoticeBy,
                        _ => _.ProjectPaymentCycleTerm.PayLessNoticeBy,
                        _ => _.ProjectPaymentCycleTerm.FinalDateForPayment,
                        _ => _.ProjectProjectName,
                        _ => _.ProjectActionStatus,
                        _ => _.ProjectExReviewDetailTitle
                        );

                });
        }
    }
}