﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectPersonnelsExcelExporter : NpoiExcelExporterBase, IProjectPersonnelsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectPersonnelsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectPersonnelForViewDto> projectPersonnels)
        {
            return CreateExcelPackage(
                "ProjectPersonnels.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectPersonnels"));

                    AddHeader(
                        sheet,
                        (L("OrganizationUnit")) + L("DisplayName"),
                        (L("Project")) + L("ProjectName"),
                        (L("User")) + L("Name"),
                        (L("Role")) + L("Name"),
                        (L("NodeStage")) + L("Id"),
                        (L("NodeTask")) + L("TaskName")
                        );

                    AddObjects(
                        sheet, projectPersonnels,
                        _ => _.OrganizationUnitDisplayName,
                        _ => _.ProjectProjectName,
                        _ => _.UserName,
                        _ => _.RoleName,
                        _ => _.NodeStageId,
                        _ => _.NodeTaskTaskName
                        );

                });
        }
    }
}