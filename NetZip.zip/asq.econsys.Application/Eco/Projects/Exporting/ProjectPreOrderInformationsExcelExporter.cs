﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectPreOrderInformationsExcelExporter : NpoiExcelExporterBase, IProjectPreOrderInformationsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectPreOrderInformationsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectPreOrderInformationForViewDto> projectPreOrderInformations)
        {
            return CreateExcelPackage(
                "ProjectPreOrderInformations.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectPreOrderInformations"));

                    AddHeader(
                        sheet,
                        L("InformationDate"),
                        (L("Project")) + L("ProjectName")
                        );

                    AddObjects(
                        sheet, projectPreOrderInformations,
                        _ => _timeZoneConverter.Convert(_.ProjectPreOrderInformation.InformationDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectProjectName
                        );

                    for (var i = 1; i <= projectPreOrderInformations.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[1], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(1);
                });
        }
    }
}