﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectQFDelegationsExcelExporter : NpoiExcelExporterBase, IProjectQFDelegationsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectQFDelegationsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectQFDelegationForViewDto> projectQFDelegations)
        {
            return CreateExcelPackage(
                "ProjectQFDelegations.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectQFDelegations"));

                    AddHeader(
                        sheet,
                        L("Category"),
                        L("Revision"),
                        L("RequiredByDate"),
                        L("RequestComments"),
                        L("ResponseDate"),
                        L("ResponseComments"),
                        L("IsCurrent"),
                        L("DisplayOrder"),
                        (L("Project")) + L("ProjectName"),
                        (L("User")) + L("Name"),
                        (L("ProjectQuoteForm")) + L("QRN")
                        );

                    AddObjects(
                        sheet, projectQFDelegations,
                        _ => _.ProjectQFDelegation.Category,
                        _ => _.ProjectQFDelegation.Revision,
                        _ => _timeZoneConverter.Convert(_.ProjectQFDelegation.RequiredByDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectQFDelegation.RequestComments,
                        _ => _timeZoneConverter.Convert(_.ProjectQFDelegation.ResponseDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectQFDelegation.ResponseComments,
                        _ => _.ProjectQFDelegation.IsCurrent,
                        _ => _.ProjectQFDelegation.DisplayOrder,
                        _ => _.ProjectProjectName,
                        _ => _.UserName,
                        _ => _.ProjectQuoteFormQRN
                        );

                    for (var i = 1; i <= projectQFDelegations.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[3], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(3); for (var i = 1; i <= projectQFDelegations.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[5], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(5);
                });
        }
    }
}