﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectQuoteFormsExcelExporter : NpoiExcelExporterBase, IProjectQuoteFormsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectQuoteFormsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectQuoteFormForViewDto> projectQuoteForms)
        {
            return CreateExcelPackage(
                "ProjectQuoteForms.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectQuoteForms"));

                    AddHeader(
                        sheet,
                        L("QRN"),
                        L("IsDelegateEstimationTask"),
                        L("IsDelegateDesignTask"),
                        L("Bidinfo"),
                        L("IsCompanyAuthCriteria"),
                        L("IsPopulateFromBidSheet"),
                        L("IsQuotationOnOurFormat"),
                        L("DateShownOnQuote"),
                        L("OverAllProjectCost"),
                        L("OverAllProjectSell"),
                        L("SubmissionDate"),
                        L("WinProbability"),
                        L("IsCustomerWonOrGotOrderToPlace"),
                        L("Notes"),
                        (L("Project")) + L("ProjectName"),
                        (L("User")) + L("Name")
                        );

                    AddObjects(
                        sheet, projectQuoteForms,
                        _ => _.ProjectQuoteForm.QRN,
                        _ => _.ProjectQuoteForm.IsDelegateEstimationTask,
                        _ => _.ProjectQuoteForm.IsDelegateDesignTask,
                        _ => _.ProjectQuoteForm.Bidinfo,
                        _ => _.ProjectQuoteForm.IsCompanyAuthCriteria,
                        _ => _.ProjectQuoteForm.IsPopulateFromBidSheet,
                        _ => _.ProjectQuoteForm.IsQuotationOnOurFormat,
                        _ => _timeZoneConverter.Convert(_.ProjectQuoteForm.DateShownOnQuote, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectQuoteForm.OverAllProjectCost,
                        _ => _.ProjectQuoteForm.OverAllProjectSell,
                        _ => _timeZoneConverter.Convert(_.ProjectQuoteForm.SubmissionDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectQuoteForm.WinProbability,
                        _ => _.ProjectQuoteForm.IsCustomerWonOrGotOrderToPlace,
                        _ => _.ProjectQuoteForm.Notes,
                        _ => _.ProjectProjectName,
                        _ => _.UserName
                        );

                    for (var i = 1; i <= projectQuoteForms.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[8], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(8); for (var i = 1; i <= projectQuoteForms.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[11], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(11);
                });
        }
    }
}