﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectRulesExcelExporter : NpoiExcelExporterBase, IProjectRulesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectRulesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectRuleForViewDto> projectRules)
        {
            return CreateExcelPackage(
                "ProjectRules.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectRules"));

                    AddHeader(
                        sheet,
                        L("RuleCategory"),
                        L("RuleKey"),
                        L("RuleValue"),
                        L("MetaData"),
                        (L("Project")) + L("ProjectName"),
                        (L("ProjectAction")) + L("Status"),
                        (L("RuleFlag")) + L("Title")
                        );

                    AddObjects(
                        sheet, projectRules,
                        _ => _.ProjectRule.RuleCategory,
                        _ => _.ProjectRule.RuleKey,
                        _ => _.ProjectRule.RuleValue,
                        _ => _.ProjectRule.MetaData,
                        _ => _.ProjectProjectName,
                        _ => _.ProjectActionStatus,
                        _ => _.RuleFlagTitle
                        );

                });
        }
    }
}