﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectSalesToOpsHandsExcelExporter : NpoiExcelExporterBase, IProjectSalesToOpsHandsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectSalesToOpsHandsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectSalesToOpsHandForViewDto> projectSalesToOpsHands)
        {
            return CreateExcelPackage(
                "ProjectSalesToOpsHands.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectSalesToOpsHands"));

                    AddHeader(
                        sheet,
                        L("IsJobFilSetOnServ"),
                        L("JoFilPatInServ"),
                        L("DocumentList"),
                        L("ScheMeetWiOpe"),
                        L("ScheMeetWiOpeDate"),
                        L("Comment"),
                        L("ProjectId"),
                        L("DelOFAToSalLead")
                        );

                    AddObjects(
                        sheet, projectSalesToOpsHands,
                        _ => _.ProjectSalesToOpsHand.IsJobFilSetOnServ,
                        _ => _.ProjectSalesToOpsHand.JoFilPatInServ,
                        _ => _.ProjectSalesToOpsHand.DocumentList,
                        _ => _.ProjectSalesToOpsHand.ScheMeetWiOpe,
                        _ => _timeZoneConverter.Convert(_.ProjectSalesToOpsHand.ScheMeetWiOpeDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.ProjectSalesToOpsHand.Comment,
                        _ => _.ProjectSalesToOpsHand.ProjectId,
                         _ => _.ProjectSalesToOpsHand.DelOFAToSalLead
                        );

                    for (var i = 1; i <= projectSalesToOpsHands.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[5], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(5);
                });
        }
    }
}