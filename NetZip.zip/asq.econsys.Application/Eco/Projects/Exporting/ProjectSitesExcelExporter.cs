﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectSitesExcelExporter : NpoiExcelExporterBase, IProjectSitesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectSitesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectSiteForViewDto> projectSites)
        {
            return CreateExcelPackage(
                "ProjectSites.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectSites"));

                    AddHeader(
                        sheet,
                        L("SiteName"),
                        L("SiteAddress"),
                        L("SiteRef"),
                        L("Remark")
                        );

                    AddObjects(
                        sheet, projectSites,
                        _ => _.ProjectSite.SiteName,
                        _ => _.ProjectSite.SiteAddress1,
                        _ => _.ProjectSite.SiteRef,
                        _ => _.ProjectSite.Remark
                        );

                });
        }
    }
}