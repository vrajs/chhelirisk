﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectTypesExcelExporter : NpoiExcelExporterBase, IProjectTypesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectTypesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectTypeForViewDto> projectTypes)
        {
            return CreateExcelPackage(
                "ProjectTypes.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectTypes"));

                    AddHeader(
                        sheet,
                        L("Code"),
                        L("Title"),
                        L("Description"),
                        L("HexColor")
                        );

                    AddObjects(
                        sheet, projectTypes,
                        _ => _.ProjectType.Code,
                        _ => _.ProjectType.Title,
                        _ => _.ProjectType.Description,
                        _ => _.ProjectType.HexColor
                        );

                });
        }
    }
}