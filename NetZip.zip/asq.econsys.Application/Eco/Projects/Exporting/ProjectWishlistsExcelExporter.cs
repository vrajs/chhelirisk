﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectWishlistsExcelExporter : NpoiExcelExporterBase, IProjectWishlistsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectWishlistsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectWishlistForViewDto> projectWishlists)
        {
            return CreateExcelPackage(
                "ProjectWishlists.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("ProjectWishlists"));

                    AddHeader(
                        sheet,
                        L("Title")
                        );

                    AddObjects(
                        sheet, projectWishlists,
                        _ => _.ProjectWishlist.Title
                        );

                });
        }
    }
}