﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class ProjectsExcelExporter : NpoiExcelExporterBase, IProjectsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public ProjectsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectForViewDto> projects)
        {
            return CreateExcelPackage(
                "Projects.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("Projects"));

                    AddHeader(
                        sheet,
                        L("ProjectName"),
                        L("DescriptionOfWork"),
                        L("QRN"),
                        L("JRN"),
                        L("LeadSourceContextualData"),
                        L("Consultant"),
                        L("Status"),
                        L("Stage"),
                        L("Task"),
                        (L("OrganizationUnit")) + L("DisplayName"),
                        (L("ContactPerson")) + L("Name"),
                        (L("Customer")) + L("Name"),
                        (L("Lead")) + L("ProjectName"),
                        (L("LeadSource")) + L("Title"),
                        (L("ProjectSite")) + L("SiteName"),
                        (L("ProjectComment")) + L("Comment"),
                        (L("ProjectType")) + L("Code"),
                        (L("ProjectWishlist")) + L("Title")
                        );

                    AddObjects(
                        sheet, projects,
                        _ => _.Project.ProjectName,
                        _ => _.Project.DescriptionOfWork,
                        _ => _.Project.QRN,
                        _ => _.Project.JRN,
                        _ => _.Project.LeadSourceContextualData,
                        _ => _.Project.Consultant,
                        _ => _.Project.Status,
                        _ => _.Project.Stage,
                        _ => _.Project.Task,
                        _ => _.OrganizationUnitDisplayName,
                        _ => _.ContactPersonName,
                        _ => _.CustomerName,
                        _ => _.LeadProjectName,
                        _ => _.LeadSourceTitle,
                        _ => _.ProjectSiteSiteName,
                        _ => _.ProjectCommentComment,
                        _ => _.ProjectTypeCode,
                        _ => _.ProjectWishlistTitle
                        );

                });
        }
    }
}