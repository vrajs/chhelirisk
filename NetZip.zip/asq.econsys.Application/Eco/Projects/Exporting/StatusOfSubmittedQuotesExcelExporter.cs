﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects.Exporting
{
    public class StatusOfSubmittedQuotesExcelExporter : NpoiExcelExporterBase, IProjectStatusOfSubmittedQuotesExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public StatusOfSubmittedQuotesExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetProjectStatusOfSubmittedQuoteForViewDto> statusOfSubmittedQuotes)
        {
            return CreateExcelPackage(
                "StatusOfSubmittedQuotes.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("StatusOfSubmittedQuotes"));

                    AddHeader(
                        sheet,
                        L("StatusOfQuote"),
                        L("CustomerCommitmentType"),
                        L("ProposedOrderNumber"),
                        L("ValueOfCommitment"),
                        L("ReceiptMethod"),
                        L("ReceiptDate"),
                        L("CustomerCreditWorthy"),
                        L("CreditReason"),
                        L("OALetterGenerationDate"),
                        L("Company"),
                        L("Address"),
                        L("AttentionOf"),
                        L("Subject"),
                        L("ScopeOfWorks"),
                        L("AdviseToClient"),
                        L("CorrespondingEmail"),
                        L("PostalCode"),
                        (L("OrganizationUnit")) + L("DisplayName"),
                        (L("Project")) + L("ProjectName"),
                        (L("User")) + L("Name"),
                        (L("Role")) + L("Name")
                        );

                    AddObjects(
                        sheet, statusOfSubmittedQuotes,
                        _ => _.StatusOfSubmittedQuote.StatusOfQuote,
                        _ => _.StatusOfSubmittedQuote.CustomerCommitmentType,
                        _ => _.StatusOfSubmittedQuote.ProposedOrderNumber,
                        _ => _.StatusOfSubmittedQuote.ValueOfCommitment,
                        _ => _.StatusOfSubmittedQuote.ReceiptMethod,
                        _ => _timeZoneConverter.Convert(_.StatusOfSubmittedQuote.ReceiptDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.StatusOfSubmittedQuote.CustomerCreditWorthy,
                        _ => _.StatusOfSubmittedQuote.CreditReason,
                        _ => _timeZoneConverter.Convert(_.StatusOfSubmittedQuote.OALetterGenerationDate, _abpSession.TenantId, _abpSession.GetUserId()),
                        _ => _.StatusOfSubmittedQuote.Company,
                        _ => _.StatusOfSubmittedQuote.Address,
                        _ => _.StatusOfSubmittedQuote.AttentionOf,
                        _ => _.StatusOfSubmittedQuote.Subject,
                        _ => _.StatusOfSubmittedQuote.ScopeOfWorks,
                        _ => _.StatusOfSubmittedQuote.AdviseToClient,
                        _ => _.StatusOfSubmittedQuote.CorrespondingEmail,
                        _ => _.StatusOfSubmittedQuote.PostalCode,
                        _ => _.OrganizationUnitDisplayName,
                        _ => _.ProjectProjectName,
                        _ => _.UserName,
                        _ => _.RoleName
                        );

                    for (var i = 1; i <= statusOfSubmittedQuotes.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[6], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(6); for (var i = 1; i <= statusOfSubmittedQuotes.Count; i++)
                    {
                        SetCellDataFormat(sheet.GetRow(i).Cells[9], "yyyy-mm-dd");
                    }
                    sheet.AutoSizeColumn(9);
                });
        }
    }
}