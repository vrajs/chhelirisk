﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.NodeTasks;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Authorization.Users;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectActions)]
    public class ProjectActionsAppService : econsysAppServiceBase, IProjectActionsAppService
    {
        private readonly IRepository<ProjectAction, long> _projectActionRepository;
        private readonly IProjectActionsExcelExporter _projectActionsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<NodeAction, string> _lookup_nodeActionRepository;
        private readonly IRepository<NodeTask, string> _lookup_nodeTaskRepository;
        private readonly IRepository<User,long> _userRepository;
        private readonly IRepository<ProjectComment,long> _projectCommentRepository;

        public ProjectActionsAppService(IRepository<ProjectAction, long> projectActionRepository, IProjectActionsExcelExporter projectActionsExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<NodeAction, string> lookup_nodeActionRepository, IRepository<NodeTask, string> lookup_nodeTaskRepository, IRepository<User, long> userRepository, IRepository<ProjectComment, long> projectCommentRepository)
        {
            _projectActionRepository = projectActionRepository;
            _projectActionsExcelExporter = projectActionsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_nodeActionRepository = lookup_nodeActionRepository;
            _lookup_nodeTaskRepository = lookup_nodeTaskRepository;
            _userRepository = userRepository;
            _projectCommentRepository = projectCommentRepository;
        }

        public async Task<PagedResultDto<GetProjectActionForViewDto>> GetAll(GetAllProjectActionsInput input)
        {

            var filteredProjectActions = _projectActionRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.NodeActionFk)
                        .Include(e => e.NextActionFk)
                        .Include(e => e.NodeTaskFk)
                        .Include(e => e.NextNodeTaskFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Status.Contains(input.Filter) || e.MetaData.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StatusFilter), e => e.Status == input.StatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MetaDataFilter), e => e.MetaData == input.MetaDataFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeActionTitleFilter), e => e.NodeActionFk != null && e.NodeActionFk.Title == input.NodeActionTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeActionTitle2Filter), e => e.NextActionFk != null && e.NextActionFk.Title == input.NodeActionTitle2Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskName2Filter), e => e.NextNodeTaskFk != null && e.NextNodeTaskFk.TaskName == input.NodeTaskTaskName2Filter);

            var pagedAndFilteredProjectActions = filteredProjectActions
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectActions = from o in pagedAndFilteredProjectActions
                                 join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                 from s1 in j1.DefaultIfEmpty()

                                 join o2 in _lookup_nodeActionRepository.GetAll() on o.NodeActionId equals o2.Id into j2
                                 from s2 in j2.DefaultIfEmpty()

                                 join o3 in _lookup_nodeActionRepository.GetAll() on o.NextActionId equals o3.Id into j3
                                 from s3 in j3.DefaultIfEmpty()

                                 join o4 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o4.Id into j4
                                 from s4 in j4.DefaultIfEmpty()

                                 join o5 in _lookup_nodeTaskRepository.GetAll() on o.NextNodeTaskId equals o5.Id into j5
                                 from s5 in j5.DefaultIfEmpty()

                                 select new
                                 {

                                     o.Status,
                                     o.MetaData,
                                     Id = o.Id,
                                     ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                     NodeActionTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                                     NodeActionTitle2 = s3 == null || s3.Title == null ? "" : s3.Title.ToString(),
                                     NodeTaskTaskName = s4 == null || s4.TaskName == null ? "" : s4.TaskName.ToString(),
                                     NodeTaskTaskName2 = s5 == null || s5.TaskName == null ? "" : s5.TaskName.ToString()
                                 };

            var totalCount = await filteredProjectActions.CountAsync();

            var dbList = await projectActions.ToListAsync();
            var results = new List<GetProjectActionForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectActionForViewDto()
                {
                    ProjectAction = new ProjectActionDto
                    {

                        Status = o.Status,
                        MetaData = o.MetaData,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    NodeActionTitle = o.NodeActionTitle,
                    NodeActionTitle2 = o.NodeActionTitle2,
                    NodeTaskTaskName = o.NodeTaskTaskName,
                    NodeTaskTaskName2 = o.NodeTaskTaskName2
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectActionForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectActionForViewDto> GetProjectActionForView(long id)
        {
            var projectAction = await _projectActionRepository.GetAsync(id);

            var output = new GetProjectActionForViewDto { ProjectAction = ObjectMapper.Map<ProjectActionDto>(projectAction) };

            if (output.ProjectAction.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectAction.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectAction.NodeActionId != null)
            {
                var _lookupNodeAction = await _lookup_nodeActionRepository.FirstOrDefaultAsync((string)output.ProjectAction.NodeActionId);
                output.NodeActionTitle = _lookupNodeAction?.Title?.ToString();
            }

            if (output.ProjectAction.NextActionId != null)
            {
                var _lookupNodeAction = await _lookup_nodeActionRepository.FirstOrDefaultAsync((string)output.ProjectAction.NextActionId);
                output.NodeActionTitle2 = _lookupNodeAction?.Title?.ToString();
            }

            if (output.ProjectAction.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectAction.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            if (output.ProjectAction.NextNodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectAction.NextNodeTaskId);
                output.NodeTaskTaskName2 = _lookupNodeTask?.TaskName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectActions_Edit)]
        public async Task<GetProjectActionForEditOutput> GetProjectActionForEdit(EntityDto<long> input)
        {
            var projectAction = await _projectActionRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectActionForEditOutput { ProjectAction = ObjectMapper.Map<CreateOrEditProjectActionDto>(projectAction) };

            if (output.ProjectAction.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectAction.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectAction.NodeActionId != null)
            {
                var _lookupNodeAction = await _lookup_nodeActionRepository.FirstOrDefaultAsync((string)output.ProjectAction.NodeActionId);
                output.NodeActionTitle = _lookupNodeAction?.Title?.ToString();
            }

            if (output.ProjectAction.NextActionId != null)
            {
                var _lookupNodeAction = await _lookup_nodeActionRepository.FirstOrDefaultAsync((string)output.ProjectAction.NextActionId);
                output.NodeActionTitle2 = _lookupNodeAction?.Title?.ToString();
            }

            if (output.ProjectAction.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectAction.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            if (output.ProjectAction.NextNodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectAction.NextNodeTaskId);
                output.NodeTaskTaskName2 = _lookupNodeTask?.TaskName?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectActionDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectActions_Create)]
        protected virtual async Task Create(CreateOrEditProjectActionDto input)
        {
            var projectAction = ObjectMapper.Map<ProjectAction>(input);

            if (AbpSession.TenantId != null)
            {
                projectAction.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectActionRepository.InsertAsync(projectAction);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectActions_Edit)]
        protected virtual async Task Update(CreateOrEditProjectActionDto input)
        {
            var projectAction = await _projectActionRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectAction);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectActions_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectActionRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectActionsToExcel(GetAllProjectActionsForExcelInput input)
        {

            var filteredProjectActions = _projectActionRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.NodeActionFk)
                        .Include(e => e.NextActionFk)
                        .Include(e => e.NodeTaskFk)
                        .Include(e => e.NextNodeTaskFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Status.Contains(input.Filter) || e.MetaData.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StatusFilter), e => e.Status == input.StatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MetaDataFilter), e => e.MetaData == input.MetaDataFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeActionTitleFilter), e => e.NodeActionFk != null && e.NodeActionFk.Title == input.NodeActionTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeActionTitle2Filter), e => e.NextActionFk != null && e.NextActionFk.Title == input.NodeActionTitle2Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskName2Filter), e => e.NextNodeTaskFk != null && e.NextNodeTaskFk.TaskName == input.NodeTaskTaskName2Filter);

            var query = (from o in filteredProjectActions
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_nodeActionRepository.GetAll() on o.NodeActionId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_nodeActionRepository.GetAll() on o.NextActionId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         join o4 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o4.Id into j4
                         from s4 in j4.DefaultIfEmpty()

                         join o5 in _lookup_nodeTaskRepository.GetAll() on o.NextNodeTaskId equals o5.Id into j5
                         from s5 in j5.DefaultIfEmpty()

                         select new GetProjectActionForViewDto()
                         {
                             ProjectAction = new ProjectActionDto
                             {
                                 Status = o.Status,
                                 MetaData = o.MetaData,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             NodeActionTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                             NodeActionTitle2 = s3 == null || s3.Title == null ? "" : s3.Title.ToString(),
                             NodeTaskTaskName = s4 == null || s4.TaskName == null ? "" : s4.TaskName.ToString(),
                             NodeTaskTaskName2 = s5 == null || s5.TaskName == null ? "" : s5.TaskName.ToString()
                         });

            var projectActionListDtos = await query.ToListAsync();

            return _projectActionsExcelExporter.ExportToFile(projectActionListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectActions)]
        public async Task<List<ProjectActionProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectActionProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectActions)]
        public async Task<List<ProjectActionNodeActionLookupTableDto>> GetAllNodeActionForTableDropdown()
        {
            return await _lookup_nodeActionRepository.GetAll()
                .Select(nodeAction => new ProjectActionNodeActionLookupTableDto
                {
                    Id = nodeAction.Id,
                    DisplayName = nodeAction == null || nodeAction.Title == null ? "" : nodeAction.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectActions)]
        public async Task<List<ProjectActionNodeTaskLookupTableDto>> GetAllNodeTaskForTableDropdown()
        {
            return await _lookup_nodeTaskRepository.GetAll()
                .Select(nodeTask => new ProjectActionNodeTaskLookupTableDto
                {
                    Id = nodeTask.Id,
                    DisplayName = nodeTask == null || nodeTask.TaskName == null ? "" : nodeTask.TaskName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectActions)]
        public async Task<List<GetFilteredApprovalResultDto>> GetFilteredApprovalResult(int projectId)
        {
            try
            {
                var res = from o in _projectActionRepository.GetAll()
                          join u in _userRepository.GetAll()
                          on o.CreatorUserId equals u.Id

                          join c in _projectCommentRepository.GetAll()
                          on o.NodeTaskId equals c.NodeTaskId
                          where (o.ProjectId == projectId && c.ProjectId == projectId)
                          select new GetFilteredApprovalResultDto()
                          {
                              Status = o.Status,
                              NextNodeTaskId = o.NextNodeTaskId,
                              NodeTaskId = o.NodeTaskId,
                              CreationTime = o.CreationTime,
                              UserName = u.Name,
                              Comment = c.Content
                          };

                var result = await res.ToListAsync();
                return result;
            }
            catch (Exception ex)
            {

                throw;
            }

        }

    }
}