﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectBaselinePrograms)]
    public class ProjectBaselineProgramsAppService : econsysAppServiceBase, IProjectBaselineProgramsAppService
    {
        private readonly IRepository<ProjectBaselineProgram, long> _projectBaselineProgramRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectExReviewDetail, long> _lookup_projectExReviewDetailRepository;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly IRepository<ProjectExReview, long> _projectExReviewRepository;
        public ProjectBaselineProgramsAppService(IRepository<ProjectBaselineProgram, long> projectBaselineProgramRepository, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectExReviewDetail, long> lookup_projectExReviewDetailRepository, Utils.UtilsAppService utilsAppService, IRepository<ProjectExReview, long> projectExReviewRepository)
        {
            _projectBaselineProgramRepository = projectBaselineProgramRepository;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectExReviewDetailRepository = lookup_projectExReviewDetailRepository;
            _utilsAppService = utilsAppService;
            _projectExReviewRepository = projectExReviewRepository;
        }

        public async Task<PagedResultDto<GetProjectBaselineProgramForViewDto>> GetAll(GetAllProjectBaselineProgramsInput input)
        {

            var filteredProjectBaselinePrograms = _projectBaselineProgramRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        //.WhereIf(!string.IsNullOrWhiteSpace(input.ReviewTypeFilter), e => e.ReviewType == input.ReviewTypeFilter)
                        .WhereIf(input.MinStartDateFilter != null, e => e.StartDate >= input.MinStartDateFilter)
                        .WhereIf(input.MaxStartDateFilter != null, e => e.StartDate <= input.MaxStartDateFilter)
                        .WhereIf(input.MinEndDateFilter != null, e => e.EndDate >= input.MinEndDateFilter)
                        .WhereIf(input.MaxEndDateFilter != null, e => e.EndDate <= input.MaxEndDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        .WhereIf(input.ProjectId != 0, e => e.ProjectId != 0 && e.ProjectId == input.ProjectId)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter).Where(x => x.ProjectExReviewDetailId == input.ProjectExReviewDetailId);
            if (filteredProjectBaselinePrograms.Count() == 0 && input.ReviewTypeFilter == "delivery")
            {
                filteredProjectBaselinePrograms = _projectBaselineProgramRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        //.WhereIf(!string.IsNullOrWhiteSpace(input.ReviewTypeFilter), e => e.ReviewType == input.ReviewTypeFilter)
                        .WhereIf(input.MinStartDateFilter != null, e => e.StartDate >= input.MinStartDateFilter)
                        .WhereIf(input.MaxStartDateFilter != null, e => e.StartDate <= input.MaxStartDateFilter)
                        .WhereIf(input.MinEndDateFilter != null, e => e.EndDate >= input.MinEndDateFilter)
                        .WhereIf(input.MaxEndDateFilter != null, e => e.EndDate <= input.MaxEndDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        .WhereIf(input.ProjectId != 0, e => e.ProjectId != 0 && e.ProjectId == input.ProjectId)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);
            }
            var pagedAndFilteredProjectBaselinePrograms = filteredProjectBaselinePrograms
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectBaselinePrograms = from o in pagedAndFilteredProjectBaselinePrograms
                                          join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                          from s1 in j1.DefaultIfEmpty()

                                          join o2 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o2.Id into j2
                                          from s2 in j2.DefaultIfEmpty()

                                          select new
                                          {

                                              o.Title,
                                              o.StartDate,
                                              o.EndDate,
                                              o.Comment,
                                              o.ProjectId,
                                              o.ProjectExReviewDetailId,
                                              Id = o.Id,
                                              ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                              ProjectExReviewDetailTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
                                          };

            var totalCount = await filteredProjectBaselinePrograms.CountAsync();

            var dbList = await projectBaselinePrograms.ToListAsync();
            var results = new List<GetProjectBaselineProgramForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectBaselineProgramForViewDto()
                {
                    ProjectBaselineProgram = new ProjectBaselineProgramDto
                    {

                        Title = o.Title,
                        StartDate = o.StartDate,
                        EndDate = o.EndDate,
                        Comment = o.Comment,
                        ProjectId = o.ProjectId,
                        ProjectExReviewDetailId = o.ProjectExReviewDetailId,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectExReviewDetailTitle = o.ProjectExReviewDetailTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectBaselineProgramForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectBaselineProgramForViewDto> GetProjectBaselineProgramForView(long id)
        {
            var projectBaselineProgram = await _projectBaselineProgramRepository.GetAsync(id);

            var output = new GetProjectBaselineProgramForViewDto { ProjectBaselineProgram = ObjectMapper.Map<ProjectBaselineProgramDto>(projectBaselineProgram) };

            if (output.ProjectBaselineProgram.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectBaselineProgram.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectBaselineProgram.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectBaselineProgram.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectBaselinePrograms_Edit)]
        public async Task<GetProjectBaselineProgramForEditOutput> GetProjectBaselineProgramForEdit(EntityDto<long> input)
        {
            var projectBaselineProgram = await _projectBaselineProgramRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectBaselineProgramForEditOutput { ProjectBaselineProgram = ObjectMapper.Map<CreateOrEditProjectBaselineProgramDto>(projectBaselineProgram) };

            if (output.ProjectBaselineProgram.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectBaselineProgram.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectBaselineProgram.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectBaselineProgram.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(string data, ICollection<IFormFile> file)
        {
            var input = JsonConvert.DeserializeObject<CreateOrEditProjectBaselineProgramDto>(data);
            var isDelivery = _projectBaselineProgramRepository.FirstOrDefault(x => x.ReviewType == "delivery" && x.ProjectId == input.ProjectId);
            if (isDelivery == null)
            {
                input.Id = null;
            }
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
            //await _utilsAppService.UploadSection(file, (long)input.ProjectId, CNodeTasks.PrepareProjectDeliveryPlanBaseline, "Production Of Baseline Program");
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectBaselinePrograms_Create)]
        protected virtual async Task Create(CreateOrEditProjectBaselineProgramDto input)
        {
            var projectBaselineProgram = ObjectMapper.Map<ProjectBaselineProgram>(input);
            var projectBaselineDelivery = ObjectMapper.Map<ProjectBaselineProgram>(input);
            if (AbpSession.TenantId != null)
            {
                projectBaselineProgram.TenantId = (int?)AbpSession.TenantId;
            }
            var project = await _lookup_projectRepository.FirstOrDefaultAsync((long)input.ProjectId);
            var projectExReview = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync(x => x.ProjectExReviewId == project.ProjectExReviewId && x.ReviewType == input.ReviewType);

            projectBaselineProgram.ProjectExReviewDetailId = projectExReview.Id;
            await _projectBaselineProgramRepository.InsertAsync(projectBaselineProgram);
            if (input.ReviewType == "baseline")
            {
                projectBaselineDelivery.ReviewType = "delivery";
                await CreateDeliveryRecord(projectBaselineDelivery);
            }
        }
        protected virtual async Task CreateDeliveryRecord(ProjectBaselineProgram input)
        {
            if (AbpSession.TenantId != null)
            {
                input.TenantId = (int?)AbpSession.TenantId;
            }
            var project = await _lookup_projectRepository.FirstOrDefaultAsync((long)input.ProjectId);
            var projectExReview = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync(x => x.ProjectExReviewId == project.ProjectExReviewId && x.ReviewType == "delivery");

            input.ProjectExReviewDetailId = projectExReview.Id;
            await _projectBaselineProgramRepository.InsertAsync(input);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectBaselinePrograms_Edit)]
        protected virtual async Task Update(CreateOrEditProjectBaselineProgramDto input)
        {
            var projectBaselineProgram = await _projectBaselineProgramRepository.FirstOrDefaultAsync((long)input.Id);
            var projectBaselineReview = await _projectBaselineProgramRepository.FirstOrDefaultAsync((long)input.Id +1);
            ObjectMapper.Map(input, projectBaselineProgram);
            if (input.ReviewType == "baseline")
            {
                try
                {
                    projectBaselineReview.Title = projectBaselineProgram.Title;
                    projectBaselineReview.StartDate = projectBaselineProgram.StartDate;
                    projectBaselineReview.EndDate = projectBaselineProgram.EndDate;
                    projectBaselineReview.Comment = projectBaselineProgram.Comment;
                    
                    await _projectBaselineProgramRepository.UpdateAsync(projectBaselineReview);
                }
                catch (Exception e)
                {

                    throw;
                }
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectBaselinePrograms_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectBaselineProgramRepository.DeleteAsync(input.Id);
            await _projectBaselineProgramRepository.DeleteAsync(input.Id+1);
        }
        [AbpAuthorize(AppPermissions.Pages_ProjectBaselinePrograms)]
        public async Task<List<ProjectBaselineProgramProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectBaselineProgramProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectBaselinePrograms)]
        public async Task<List<ProjectBaselineProgramProjectExReviewDetailLookupTableDto>> GetAllProjectExReviewDetailForTableDropdown()
        {
            return await _lookup_projectExReviewDetailRepository.GetAll()
                .Select(projectExReviewDetail => new ProjectBaselineProgramProjectExReviewDetailLookupTableDto
                {
                    Id = projectExReviewDetail.Id,
                    DisplayName = projectExReviewDetail == null || projectExReviewDetail.Title == null ? "" : projectExReviewDetail.Title.ToString()
                }).ToListAsync();
        }

    }
}