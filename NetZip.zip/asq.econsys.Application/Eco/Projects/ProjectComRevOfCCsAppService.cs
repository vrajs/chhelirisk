﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Events.Bus;
using asq.econsys.Authorization.Roles;
using asq.econsys.Authorization.Users;
using System.IO;
using Syncfusion.DocIO.DLS;
using Syncfusion.DocIO;
using Microsoft.AspNetCore.Hosting;
using asq.econsys.Eco.Customers;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;
using asq.econsys.Eco.Utils.Storage;
using Newtonsoft.Json;
using System.Net;
using Syncfusion.DocIORenderer;
using Syncfusion.Pdf;
using System.Net.Mail;
using System.Net.Mime;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectComRevOfCCs)]
    public class ProjectComRevOfCCsAppService : econsysAppServiceBase, IProjectComRevOfCCsAppService
    {
        private readonly IRepository<ProjectComRevOfCC, long> _projectComRevOfCCRepository;
        private readonly IProjectComRevOfCCsExcelExporter _projectComRevOfCCsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectQuoteMeta, long> _lookup_quoteRepository;
        private readonly IRepository<ProjectQuoteForm, long> _lookup_quoteFormRepository;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly IRepository<User, long> _lookup_userRepository;
        private readonly IRepository<Role, int> _lookup_roleRepository;
        private readonly IRepository<Project, long> _projectRepository;
        private readonly IRepository<ProjectQuoteMeta, long> _projectQuoteMetaRepository;
        private readonly IRepository<ProjectStatusOfSubmittedQuote, long> _projectSSQuoteRepository;
        private readonly IWebHostEnvironment _env;
        private readonly IRepository<Customer, long> _customerRepository;
        private readonly StorageManager _storageManager;
        private readonly IRepository<ProjectOAReview, long> _projectOAReviewRepository;
        public IEventBus EventBus { get; set; }

        public ProjectComRevOfCCsAppService(IRepository<ProjectComRevOfCC, long> projectComRevOfCCRepository, IProjectComRevOfCCsExcelExporter projectComRevOfCCsExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectQuoteMeta, long> lookup_quoteRepository, Utils.UtilsAppService utilsAppService, ProjectPermissionManager projectPermissionManager, IRepository<ProjectQuoteForm, long> lookup_quoteFormRepository, IRepository<User, long> lookup_userRepository, IRepository<Role, int> lookup_roleRepository, IRepository<Project, long> projectRepository, IRepository<ProjectQuoteMeta, long> projectQuoteMetaRepository, IWebHostEnvironment env, IRepository<Customer, long> customerRepository, IRepository<ProjectStatusOfSubmittedQuote, long> projectSSQuoteRepository, StorageManager storageManager, IRepository<ProjectOAReview, long> projectOAReviewRepository)
        {
            EventBus = NullEventBus.Instance;
            _projectComRevOfCCRepository = projectComRevOfCCRepository;
            _projectComRevOfCCsExcelExporter = projectComRevOfCCsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _utilsAppService = utilsAppService;
            _lookup_quoteRepository = lookup_quoteRepository;
            _projectPermissionManager = projectPermissionManager;
            _lookup_quoteFormRepository = lookup_quoteFormRepository;
            _lookup_userRepository = lookup_userRepository;
            _lookup_roleRepository = lookup_roleRepository;
            _projectRepository = projectRepository;
            _projectQuoteMetaRepository = projectQuoteMetaRepository;
            _customerRepository = customerRepository;
            _projectOAReviewRepository = projectOAReviewRepository;

            _env = env;
            _projectSSQuoteRepository = projectSSQuoteRepository;
            _storageManager = storageManager;
        }
        public async Task<string> PreViewDoc(int ProjectId, string formData)
        {
            WordDocument document = new WordDocument();

            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            try
            {
                var ComRevOfCCQuoteData = JsonConvert.DeserializeObject<CreateOrEditProjectComRevOfCCDto>(formData);
                var ProjectInfo = await _projectRepository.FirstOrDefaultAsync(ProjectId);

                var ComRevOfCCInfo = _projectComRevOfCCRepository.GetAll().Where(x => x.Id == ComRevOfCCQuoteData.quoteData.ProjectComRevOfCCId).ToList();
                var CustInfo = await _customerRepository.FirstOrDefaultAsync((long)ProjectInfo.CustomerId);

                var date = DateTime.Now;
                //Opens the input Word document.
                string targetFilePath = Path.Combine(_env.WebRootPath, "template\\CReviewCommitment\\CommercialReviewCCommitment_Template.docx");
                FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                document = new WordDocument(fileStreamPath, FormatType.Docx);

                document.Replace("<<QuoteRefNo>>", ComRevOfCCQuoteData.quoteData.QuoteRefNo, true, true);
                document.Replace("<<TodayDate>>", Convert.ToDateTime(ComRevOfCCQuoteData.quoteData.EntryDate).ToString("dd/MM/yyyy"), true, true);
                document.Replace("<<CustomerName>>", CustInfo.Name, true, true);
                document.Replace("<<CustomerAddress1>>", CustInfo.Address1, true, true);
                document.Replace("<<CustomerAddress2>>", CustInfo.Address2, true, true);
                document.Replace("<<PostalCode>>", CustInfo.PostalCode, true, true);
                document.Replace("<<AttentionOf>>", ComRevOfCCQuoteData.quoteData.AttentionOf, true, true);
                document.Replace("<<ProjectName>>", ProjectInfo.ProjectName, true, true);
                document.Replace("<<ScopeOfWorks>>", ComRevOfCCQuoteData.quoteData.ScopeOfWorks, true, true);
                document.Replace("<<ProposedOrderNo>>", ComRevOfCCQuoteData.quoteData.ProposedOrderNumber, true, true);
                document.Replace("<<Dates>>", date.ToString("dd/MM/yyyy"), true, true);
                document.Replace("<<ProposedOrderDate>>", Convert.ToDateTime(ComRevOfCCQuoteData.quoteData.EntryDate).ToString("dd/MM/yyyy"), true, true);

                string targetFilePath2 = Path.Combine(_env.WebRootPath, "Temp\\CReviewCommitment\\ProjectOrderResponse_" + ComRevOfCCQuoteData.quoteData.QuoteRefNo + ".docx");
                string pdfPath = Path.Combine(_env.WebRootPath, "template\\CReviewCommitment\\FinalGenerated\\final.pdf");
                if (File.Exists(targetFilePath2))
                {
                    File.Delete(targetFilePath2);
                }
                if (File.Exists(pdfPath))
                {
                    File.Delete(pdfPath);
                }
                fileStreamPath = System.IO.File.Create(targetFilePath2);
                document.Save(fileStreamPath, FormatType.Docx);
                //WordDocument wordDocument = new WordDocument();
                //Add a section & a paragraph in the empty document.

                //Create instance for DocIORenderer for Word to PDF conversion
                DocIORenderer render = new DocIORenderer();
                //Converts Word document to PDF.
                PdfDocument pdfDocument = render.ConvertToPDF(document);
                //Release the resources used by the Word document and DocIO Renderer objects.
                render.Dispose();
                document.Dispose();
                string DirectoryExists = Path.Combine(_env.WebRootPath, "template\\CReviewCommitment\\FinalGenerated");
                if (!Directory.Exists(DirectoryExists))
                {
                    Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "template\\CReviewCommitment\\FinalGenerated"));
                }
                //Saves the PDF file.
                FileStream outputStream = new FileStream(pdfPath, FileMode.CreateNew, FileAccess.Write);
                pdfDocument.Save(outputStream);
                //Closes the instance of PDF document object.
                pdfDocument.Close();
                //Dispose the instance of FileStream.
                outputStream.Dispose();
                fileStreamPath.Dispose();
                byte[] bytes = File.ReadAllBytes(pdfPath);
                string docBase64 = "data: application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + Convert.ToBase64String(bytes);
                return docBase64;

            }
            catch (Exception e)
            {

                throw;
            }
            return "";
        }
        public void SendEMail(string formData)
        {
            //using (System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage())
            //{
            //    mail.From = new MailAddress("vraj.s@quadwave.com");
            //    mail.To.Add("vraj.s@quadwave.com");
            //    mail.Subject = "Customer Commitment Received";
            //    mail.Body = "<h1>Dear Customer, Please Find Your Commitment Received Document</h1>";
            //    mail.IsBodyHtml = true;
            //    var contentPath = Path.Combine(_env.WebRootPath, "template\\ComercialReviewOfCCommitment\\FinalGenerated\\FinalGenerated.docx");
            //    Attachment data = new Attachment(contentPath, MediaTypeNames.Application.Octet);
            //    mail.Attachments.Add(data);

            //    //mailMessage.Attachments.Add(data);

            //    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
            //    {
            //        smtp.Credentials = new NetworkCredential("vraj.s@quadwave.com", "ct##123456");
            //        smtp.EnableSsl = true;
            //        smtp.Send(mail);
            //    }
            //}
        }
        public async Task<string> GetDocument(int id, string qrnNumber, long ProjectId)
        {

            //To Do Check
            var ProjectMetaData = await _projectQuoteMetaRepository.GetAll().Where(x => x.ProjectId == ProjectId && x.ProjectStatusOfSubmittedQuoteId != null).OrderByDescending(x => x.Id).FirstOrDefaultAsync();

            var ProjectInfo = await _projectRepository.FirstOrDefaultAsync(ProjectId);
            var StatusOfSubmInfo = await _projectSSQuoteRepository.FirstOrDefaultAsync((long)ProjectMetaData.ProjectStatusOfSubmittedQuoteId);
            var CustInfo = await _customerRepository.FirstOrDefaultAsync((long)ProjectInfo.CustomerId);

            var QuoteRefNo = qrnNumber;

            var date = DateTime.Now;

            //Opens the input Word document.
            string DirectoryExists = Path.Combine(_env.WebRootPath, "template\\CReviewCommitment");
            if (!Directory.Exists(DirectoryExists))
            {
                Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "template\\CReviewCommitment"));
            }
            string targetFilePath = Path.Combine(_env.WebRootPath, "template\\CReviewCommitment\\CommercialReviewCCommitment_Template.docx");
            FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            WordDocument document = new WordDocument(fileStreamPath, FormatType.Docx);

            document.Open(fileStreamPath, FormatType.Docx);
            fileStreamPath.Dispose();

            document.Replace("<<QuoteRefNo>>", qrnNumber, true, true);
            document.Replace("<<TodayDate>>", date.ToString("dd/MM/yyyy"), true, true);
            document.Replace("<<CustomerName>>", CustInfo.Name, true, true);
            document.Replace("<<CustomerAddress1>>", CustInfo.Address1, true, true);
            document.Replace("<<CustomerAddress2>>", CustInfo.Address2, true, true);
            document.Replace("<<PostalCode>>", CustInfo.PostalCode, true, true);
            document.Replace("<<AttentionOf>>", ProjectMetaData.AttentionOf, true, true);
            document.Replace("<<ProjectName>>", ProjectInfo.ProjectName, true, true);
            document.Replace("<<ScopeOfWorks>>", ProjectMetaData.ScopeOfWorks, true, true);
            document.Replace("<<ProposedOrderNo>>", StatusOfSubmInfo.ProposedOrderNumber, true, true);
            document.Replace("<<Dates>>", date.ToString("dd/MM/yyyy"), true, true);
            document.Replace("<<ProposedOrderDate>>", Convert.ToDateTime(StatusOfSubmInfo.ReceiptDate).ToString("dd/MM/yyyy"), true, true);

            WordDocument tmpDoc = new WordDocument();

            string targetFilePath2 = Path.Combine(_env.WebRootPath, "Temp\\CReviewCommitment\\ProjectOrderResponse_" + qrnNumber + ".docx");
            if (!Directory.Exists(targetFilePath2))
            {
                Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "Temp\\CReviewCommitment"));
            }

            fileStreamPath = System.IO.File.Create(targetFilePath2);
            document.Save(fileStreamPath, FormatType.Docx);

            fileStreamPath.Dispose();

            byte[] bytes = File.ReadAllBytes(targetFilePath2);
            string docBase64 = "data: application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + Convert.ToBase64String(bytes);
            return docBase64;

            //var path = targetFilePath2;

            //var stream = new FileStream(path, FileMode.Open, FileAccess.Read);
            //result.Content = new StreamContent(stream);
            //result.Content.Headers.ContentType =
            //    new MediaTypeHeaderValue("application/octet-stream");
            //return result;

            //return null;
        }

        public async Task<GetProjectComRevOfCCForViewDto> GetQuoteMetaData(long projectid)
        {
            //var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            //{
            //    ProjectId = projectid
            //});

            //if (!check)
            //{
            //    throw new UserFriendlyException("Access Denied", "You do not have the required role for this project");
            //}
            var IdDetails = await _projectComRevOfCCRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
            var ProjectDetails = await _projectRepository.FirstOrDefaultAsync(projectid);
            //To Do Check
            if (IdDetails == null)
            {
                
                var quoteMeta = await _lookup_quoteRepository.GetAll().Where(x => x.ProjectId == projectid && x.ProjectStatusOfSubmittedQuoteId != null).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
                var output = new GetProjectComRevOfCCForViewDto { QuoteMeta = ObjectMapper.Map<QuoteMetaDto>(quoteMeta) };
                var quoteFormRep = await _lookup_quoteFormRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();

                var StatusOfSubRep = await _projectSSQuoteRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
                output.QuoteMeta.QuoteRefNo = quoteFormRep.QRN;
                output.QuoteMeta.QuotedDate = Convert.ToDateTime(quoteFormRep.SubmissionDate);
                output.QuoteMeta.ProjectComRevOfCCId = quoteMeta.ProjectComRevOfCCId;
                output.QuoteMeta.ProposedOrderNumber = StatusOfSubRep.ProposedOrderNumber;
                output.QuoteMeta.ValueOfCommitment = StatusOfSubRep.ValueOfCommitment == null ? 0 : Convert.ToDecimal(StatusOfSubRep.ValueOfCommitment);
                output.QuoteMeta.ProjectName = ProjectDetails.ProjectName;
                return output;

            }
            else
            {
                var StatusOfSubRep = await _projectSSQuoteRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
                var quoteMeta = await _lookup_quoteRepository.GetAll().Where(x => x.ProjectId == projectid && x.ProjectComRevOfCCId == IdDetails.Id).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
                var output = new GetProjectComRevOfCCForViewDto { QuoteMeta = ObjectMapper.Map<QuoteMetaDto>(quoteMeta) };
                var quoteFormRep = await _lookup_quoteFormRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
                output.QuoteMeta.QuoteRefNo = quoteFormRep.QRN;
                output.QuoteMeta.QuotedDate = Convert.ToDateTime(quoteFormRep.SubmissionDate);
                output.QuoteMeta.ProposedOrderNumber = StatusOfSubRep.ProposedOrderNumber;
                output.QuoteMeta.ValueOfCommitment = StatusOfSubRep.ValueOfCommitment == null ? 0 : Convert.ToDecimal(StatusOfSubRep.ValueOfCommitment);
                output.QuoteMeta.ProjectName = ProjectDetails.ProjectName;
                //output.QuoteMeta.ProjectComRevOfCCId = quoteMeta.ProjectQuoteFormId;
                return output;
            }
        }

        public async Task<PagedResultDto<GetProjectComRevOfCCForViewDto>> GetAll(GetAllProjectComRevOfCCsInput input)
        {

            var filteredProjectComRevOfCCs = _projectComRevOfCCRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Comment.Contains(input.Filter) || e.String1.Contains(input.Filter) || e.String2.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment.Contains(input.CommentFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.String1Filter), e => e.String1.Contains(input.String1Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.String2Filter), e => e.String2.Contains(input.String2Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var pagedAndFilteredProjectComRevOfCCs = filteredProjectComRevOfCCs
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectComRevOfCCs = from o in pagedAndFilteredProjectComRevOfCCs
                                     join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                     from s1 in j1.DefaultIfEmpty()

                                     select new
                                     {

                                         o.Comment,
                                         o.String1,
                                         o.String2,
                                         Id = o.Id,
                                         ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                                     };

            var totalCount = await filteredProjectComRevOfCCs.CountAsync();

            var dbList = await projectComRevOfCCs.ToListAsync();
            var results = new List<GetProjectComRevOfCCForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectComRevOfCCForViewDto()
                {
                    ProjectComRevOfCC = new ProjectComRevOfCCDto
                    {

                        Comment = o.Comment,
                        String1 = o.String1,
                        String2 = o.String2,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectComRevOfCCForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectComRevOfCCForViewDto> GetProjectComRevOfCCForView(long id)
        {
            var projectComRevOfCC = await _projectComRevOfCCRepository.GetAsync(id);
            var quoteMeta = _lookup_quoteRepository.GetAll().Where(x => x.ProjectComRevOfCCId == id);

            var output = new GetProjectComRevOfCCForViewDto { ProjectComRevOfCC = ObjectMapper.Map<ProjectComRevOfCCDto>(projectComRevOfCC) };
            output.QuoteMeta = ObjectMapper.Map<QuoteMetaDto>(quoteMeta);

            if (output.ProjectComRevOfCC.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectComRevOfCC.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        public async Task<GetProjectComRevOfCCForEditOutput> GetProjectComRevOfCCForEdit(EntityDto<long> input)
        {
            var projectComRevOfCC = await _projectComRevOfCCRepository.FirstOrDefaultAsync(input.Id);
            var quoteMeta = _lookup_quoteRepository.GetAll().Where(x => x.ProjectComRevOfCCId == input.Id);

            var output = new GetProjectComRevOfCCForEditOutput { ProjectComRevOfCC = ObjectMapper.Map<CreateOrEditProjectComRevOfCCDto>(projectComRevOfCC) };
            output.QuoteMeta = ObjectMapper.Map<QuoteMetaDto>(quoteMeta);

            if (output.ProjectComRevOfCC.CCRevOfCCData.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectComRevOfCC.CCRevOfCCData.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit([FromForm] CreateOrEditComRevOfCCDto data)
        {
            CreateOrEditProjectComRevOfCCDto input = new CreateOrEditProjectComRevOfCCDto();
            GetProjectForViewDto result = new GetProjectForViewDto();
            input.quoteData = JsonConvert.DeserializeObject<QuoteMetaDto>(data.quoteData);
            input.CCRevOfCCData = JsonConvert.DeserializeObject<CreateOrEditComCCDto>(data.CCRevOfCCData);
            var OAReview = _projectOAReviewRepository.GetAll().Where(x => x.ProjectId == input.CCRevOfCCData.ProjectId && x.IsCurrent == true);
            if (OAReview != null)
            {
                input.CCRevOfCCData.ProjectOAReviewId = OAReview.First().Id;
            }
            //var attachElements = JsonConvert.DeserializeObject<List<CreateOrEditProjectComRevOfCCDto>>(data.AttachmentElementData);

            var oaComRevCCDetails = new GetProjectComRevOfCCForViewDto();
                if (input.Id == null)
                {
                    oaComRevCCDetails = await Create(input);
                }
                else
                {
                    oaComRevCCDetails = await Update(input);
                }

                if (data.Attachments != null && data.Attachments.Count > 0)
                {
                    List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                    foreach (var file in data.Attachments)
                    {
                        projectFilesInput.Add(new ProjectFileInput()
                        {
                            File = file,
                            ProjectId = input.CCRevOfCCData.ProjectId,
                            TaskId = CNodeTasks.CommercialreviewofCustomerCommitment,
                            MetaData = "ComRevOfCC"
                        });
                    }

                    if (projectFilesInput.Count > 0)
                    {
                        var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                    }
                }

                var project = _lookup_projectRepository.FirstOrDefault((long)input.CCRevOfCCData.ProjectId);
                await EventBus.TriggerAsync(new EditProjectEventData()
                {
                    Project = project,
                    StageId = CNodeStages.OrderAcceptance,
                    TaskId = CNodeTasks.CommercialreviewofCustomerCommitment,
                    StatusId = input.CCRevOfCCData.Status,
                    LoggedInUserId = (long)AbpSession.UserId,
                    Comment = input.CCRevOfCCData.Comment,
                    ProjectId = input.CCRevOfCCData.ProjectId
                });

                project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.CCRevOfCCData.ProjectId));
                result.Project = ObjectMapper.Map<ProjectDto>(project);
                result.ProjectComRevOfCC = oaComRevCCDetails;
                return result;
        }
        protected virtual async Task<GetProjectComRevOfCCForViewDto> Create(CreateOrEditProjectComRevOfCCDto input)
        {
            if (AbpSession.TenantId != null)
            {
                input.quoteData.TenantId = (int?)AbpSession.TenantId;
            }
            ProjectComRevOfCC ComRevCCdto = new ProjectComRevOfCC();
            ComRevCCdto.Comment = input.CCRevOfCCData.Comment;
            ComRevCCdto.TenantId = input.quoteData.TenantId;
            ComRevCCdto.ProjectId = input.CCRevOfCCData.ProjectId;
            ComRevCCdto.ProjectOAReviewId = input.CCRevOfCCData.ProjectOAReviewId;
            var ProjectComRevOfCCId = _projectComRevOfCCRepository.InsertAndGetId(ComRevCCdto);

            var user = new User();
            var role = new Role();
            if (input.quoteData.CorrespondingUserId != null)
            {
                user = _lookup_userRepository.Get((long)input.quoteData.CorrespondingUserId);
            }
            if (input.quoteData.CorrespondingRoleId != null)
            {
                role = _lookup_roleRepository.Get((int)input.quoteData.CorrespondingRoleId);
            }

            
            var quote = ObjectMapper.Map<ProjectQuoteMeta>(input.quoteData);
            quote.TenantId = (int?)AbpSession.TenantId;
            quote.ProjectComRevOfCCId = ProjectComRevOfCCId;           
            quote.CorrespondWithName = user.Name;
            quote.CorrespondWithRole = role.DisplayName;
           
            var quoteId = await _lookup_quoteRepository.InsertAsync(quote);
            var output = new GetProjectComRevOfCCForViewDto { ProjectComRevOfCC = ObjectMapper.Map<ProjectComRevOfCCDto>(_projectComRevOfCCRepository.Get((long)quote.ProjectComRevOfCCId)) };

            return output;
        }

        protected virtual async Task<GetProjectComRevOfCCForViewDto> Update(CreateOrEditProjectComRevOfCCDto input)
        {
            var projectComRevOfCC = await _projectComRevOfCCRepository.FirstOrDefaultAsync((long)input.Id);
            input.quoteData.TenantId = (int?)AbpSession.TenantId;
            ObjectMapper.Map(input, projectComRevOfCC);
            return new GetProjectComRevOfCCForViewDto { ProjectComRevOfCC = ObjectMapper.Map<ProjectComRevOfCCDto>(_projectComRevOfCCRepository.Get((long)input.Id)) };

        }

        //[AbpAuthorize(AppPermissions.Pages_ProjectComRevOfCCs_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectComRevOfCCRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectComRevOfCCsToExcel(GetAllProjectComRevOfCCsForExcelInput input)
        {

            var filteredProjectComRevOfCCs = _projectComRevOfCCRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Comment.Contains(input.Filter) || e.String1.Contains(input.Filter) || e.String2.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment.Contains(input.CommentFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.String1Filter), e => e.String1.Contains(input.String1Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.String2Filter), e => e.String2.Contains(input.String2Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var query = (from o in filteredProjectComRevOfCCs
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetProjectComRevOfCCForViewDto()
                         {
                             ProjectComRevOfCC = new ProjectComRevOfCCDto
                             {
                                 Comment = o.Comment,
                                 String1 = o.String1,
                                 String2 = o.String2,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                         });

            var projectComRevOfCCListDtos = await query.ToListAsync();

            return _projectComRevOfCCsExcelExporter.ExportToFile(projectComRevOfCCListDtos);
        }

    }
}