﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.NodeTasks;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Authorization.Users;
using asq.econsys.Authorization.Users.Dto;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectComments)]
    public class ProjectCommentsAppService : econsysAppServiceBase, IProjectCommentsAppService
    {
        private readonly IRepository<ProjectComment, long> _projectCommentRepository;
        private readonly IProjectCommentsExcelExporter _projectCommentsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<NodeTask, string> _lookup_nodeTaskRepository;
        private readonly IRepository<ProjectComment, long> _lookup_projectCommentRepository;
        private readonly IRepository<User, long> _lookupUserRepository;
        public ProjectCommentsAppService(IRepository<ProjectComment, long> projectCommentRepository, IProjectCommentsExcelExporter projectCommentsExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<NodeTask, string> lookup_nodeTaskRepository, IRepository<ProjectComment, long> lookup_projectCommentRepository, IRepository<User, long> lookupUserRepository)
        {
            _projectCommentRepository = projectCommentRepository;
            _projectCommentsExcelExporter = projectCommentsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_nodeTaskRepository = lookup_nodeTaskRepository;
            _lookup_projectCommentRepository = lookup_projectCommentRepository;
            _lookupUserRepository = lookupUserRepository;
        }

        public async Task<PagedResultDto<GetProjectCommentForViewDto>> GetAll(GetAllProjectCommentsInput input)
        {

            var filteredProjectComments = _projectCommentRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.NodeTaskFk)
                        .Include(e => e.ParentFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.NodeAction.Contains(input.Filter) || e.Content.Contains(input.Filter) || e.MetaData.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeActionFilter), e => e.NodeAction == input.NodeActionFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ContentFilter), e => e.Content == input.ContentFilter)
                        .WhereIf(input.MinLevelFilter != null, e => e.Level >= input.MinLevelFilter)
                        .WhereIf(input.MaxLevelFilter != null, e => e.Level <= input.MaxLevelFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MetaDataFilter), e => e.MetaData == input.MetaDataFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectCommentCommentFilter), e => e.ParentFk != null && e.ParentFk.Content == input.ProjectCommentCommentFilter);

            var pagedAndFilteredProjectComments = filteredProjectComments
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectComments = from o in pagedAndFilteredProjectComments
                                  join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                  from s1 in j1.DefaultIfEmpty()

                                  join o2 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o2.Id into j2
                                  from s2 in j2.DefaultIfEmpty()

                                  join o3 in _lookup_projectCommentRepository.GetAll() on o.ParentId equals o3.Id into j3
                                  from s3 in j3.DefaultIfEmpty()

                                  select new
                                  {

                                      o.NodeAction,
                                      o.Content,
                                      o.Level,
                                      o.MetaData,
                                      Id = o.Id,
                                      ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                      NodeTaskTaskName = s2 == null || s2.TaskName == null ? "" : s2.TaskName.ToString(),
                                      ProjectCommentComment = s3 == null || s3.Content == null ? "" : s3.Content.ToString()
                                  };

            var totalCount = await filteredProjectComments.CountAsync();

            var dbList = await projectComments.ToListAsync();
            var results = new List<GetProjectCommentForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectCommentForViewDto()
                {
                    ProjectComment = new ProjectCommentDto
                    {

                        NodeAction = o.NodeAction,
                        Content = o.Content,
                        Level = o.Level,
                        MetaData = o.MetaData,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    NodeTaskTaskName = o.NodeTaskTaskName,
                    ProjectCommentComment = o.ProjectCommentComment
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectCommentForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectCommentForViewDto> GetProjectCommentForView(long id)
        {
            var projectComment = await _projectCommentRepository.GetAsync(id);

            var output = new GetProjectCommentForViewDto { ProjectComment = ObjectMapper.Map<ProjectCommentDto>(projectComment) };

            if (output.ProjectComment.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectComment.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectComment.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectComment.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            if (output.ProjectComment.ParentId != null)
            {
                var _lookupProjectComment = await _lookup_projectCommentRepository.FirstOrDefaultAsync((long)output.ProjectComment.ParentId);
                output.ProjectCommentComment = _lookupProjectComment?.Content?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectComments_Edit)]
        public async Task<GetProjectCommentForEditOutput> GetProjectCommentForEdit(EntityDto<long> input)
        {
            var projectComment = await _projectCommentRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectCommentForEditOutput { ProjectComment = ObjectMapper.Map<CreateOrEditProjectCommentDto>(projectComment) };

            if (output.ProjectComment.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectComment.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectComment.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectComment.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            if (output.ProjectComment.ParentId != null)
            {
                var _lookupProjectComment = await _lookup_projectCommentRepository.FirstOrDefaultAsync((long)output.ProjectComment.ParentId);
                output.ProjectCommentComment = _lookupProjectComment?.Content?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectCommentDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectComments_Create)]
        protected virtual async Task Create(CreateOrEditProjectCommentDto input)
        {
            var projectComment = ObjectMapper.Map<ProjectComment>(input);

            if (AbpSession.TenantId != null)
            {
                projectComment.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectCommentRepository.InsertAsync(projectComment);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectComments_Edit)]
        protected virtual async Task Update(CreateOrEditProjectCommentDto input)
        {
            var projectComment = await _projectCommentRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectComment);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectComments_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectCommentRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectCommentsToExcel(GetAllProjectCommentsForExcelInput input)
        {

            var filteredProjectComments = _projectCommentRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.NodeTaskFk)
                        .Include(e => e.ParentFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.NodeAction.Contains(input.Filter) || e.Content.Contains(input.Filter) || e.MetaData.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeActionFilter), e => e.NodeAction == input.NodeActionFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ContentFilter), e => e.Content == input.ContentFilter)
                        .WhereIf(input.MinLevelFilter != null, e => e.Level >= input.MinLevelFilter)
                        .WhereIf(input.MaxLevelFilter != null, e => e.Level <= input.MaxLevelFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MetaDataFilter), e => e.MetaData == input.MetaDataFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectCommentCommentFilter), e => e.ParentFk != null && e.ParentFk.Content == input.ProjectCommentCommentFilter);

            var query = (from o in filteredProjectComments
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_projectCommentRepository.GetAll() on o.ParentId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         select new GetProjectCommentForViewDto()
                         {
                             ProjectComment = new ProjectCommentDto
                             {
                                 NodeAction = o.NodeAction,
                                 Content = o.Content,
                                 Level = o.Level,
                                 MetaData = o.MetaData,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             NodeTaskTaskName = s2 == null || s2.TaskName == null ? "" : s2.TaskName.ToString(),
                             ProjectCommentComment = s3 == null || s3.Content == null ? "" : s3.Content.ToString()
                         });

            var projectCommentListDtos = await query.ToListAsync();

            return _projectCommentsExcelExporter.ExportToFile(projectCommentListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectComments)]
        public async Task<List<ProjectCommentProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectCommentProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectComments)]
        public async Task<List<ProjectCommentNodeTaskLookupTableDto>> GetAllNodeTaskForTableDropdown()
        {
            return await _lookup_nodeTaskRepository.GetAll()
                .Select(nodeTask => new ProjectCommentNodeTaskLookupTableDto
                {
                    Id = nodeTask.Id,
                    DisplayName = nodeTask == null || nodeTask.TaskName == null ? "" : nodeTask.TaskName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectComments)]
        public async Task<List<ProjectCommentProjectCommentLookupTableDto>> GetAllProjectCommentForTableDropdown()
        {
            return await _lookup_projectCommentRepository.GetAll()
                .Select(projectComment => new ProjectCommentProjectCommentLookupTableDto
                {
                    Id = projectComment.Id,
                    DisplayName = projectComment == null || projectComment.Content == null ? "" : projectComment.Content.ToString()
                }).ToListAsync();
        }
        public async Task<List<CommentHistoryDto>> GetProjectComments(long projectId)
        {
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var filteredProjectComments = await _projectCommentRepository.GetAll().Where(x => x.ProjectId == projectId).ToListAsync();

                    var query = (from o in filteredProjectComments
                                 join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                 from s1 in j1.DefaultIfEmpty()

                                 join o2 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o2.Id into j2
                                 from s2 in j2.DefaultIfEmpty()

                                 join o3 in _lookup_projectCommentRepository.GetAll() on o.ParentId equals o3.Id into j3
                                 from s3 in j3.DefaultIfEmpty()

                                 join o4 in UserManager.Users on o.CreatorUserId equals o4.Id into j4
                                 from s4 in j4.DefaultIfEmpty()

                                 select new CommentHistoryDto()
                                 {
                                     NodeAction = o.NodeAction,
                                     Content = o.Content,
                                     Level = o.Level,
                                     MetaData = o.MetaData,
                                     Id = o.Id,
                                     CreationTime = o.CreationTime,
                                     ParentComment = s3 == null ? null : new ProjectCommentDto
                                     {
                                         NodeAction = s3.NodeAction,
                                         Content = s3.Content,
                                         Level = s3.Level,
                                         MetaData = s3.MetaData,
                                         Id = s3.Id
                                     },
                                     ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                     NodeTaskTaskName = s2 == null || s2.TaskName == null ? "" : s2.TaskName.ToString(),
                                     ProjectCommentComment = s3 == null || s3.Content == null ? "" : s3.Content.ToString(),
                                     CreatorUser = s4 == null ? null : ObjectMapper.Map<UserListDto>(s4)
                                 });

                    var projectCommentListDtos = query.ToList();

                    return projectCommentListDtos;
                }
            }
            return null;
        }

    }
}