﻿using asq.econsys.Eco.Projects;
using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.Events.Bus;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace asq.econsys.Eco.Projects
{
    // [AbpAuthorize(AppPermissions.Pages_ProjectCommercialTasksPriorCommences)]
    public class ProjectCommercialTasksPriorCommencesAppService : econsysAppServiceBase, IProjectCommercialTasksPriorCommencesAppService
    {
        private readonly IRepository<ProjectCommercialTasksPriorCommence, long> _projectCommercialTasksPriorCommenceRepository;
        private readonly IProjectCommercialTasksPriorCommencesExcelExporter _projectCommercialTasksPriorCommencesExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly IRepository<ProjectOAReview, long> _projectOAReviewRepository;
        public IEventBus EventBus { get; set; }

        public ProjectCommercialTasksPriorCommencesAppService(IRepository<ProjectCommercialTasksPriorCommence, long> projectCommercialTasksPriorCommenceRepository, IProjectCommercialTasksPriorCommencesExcelExporter projectCommercialTasksPriorCommencesExcelExporter, IRepository<Project, long> lookup_projectRepository, Utils.UtilsAppService utilsAppService, IRepository<ProjectOAReview, long> projectOAReviewRepository)
        {
            _projectCommercialTasksPriorCommenceRepository = projectCommercialTasksPriorCommenceRepository;
            _projectCommercialTasksPriorCommencesExcelExporter = projectCommercialTasksPriorCommencesExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            EventBus = NullEventBus.Instance;
            _utilsAppService = utilsAppService;
            _projectOAReviewRepository = projectOAReviewRepository;
        }

        public async Task<PagedResultDto<GetProjectCommercialTasksPriorCommenceForViewDto>> GetAll(GetAllProjectCommercialTasksPriorCommencesInput input)
        {

            var filteredProjectCommercialTasksPriorCommences = _projectCommercialTasksPriorCommenceRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.JobReference.Contains(input.Filter) || e.IsProjAppInvoice.Contains(input.Filter) || e.DaysFrom.Contains(input.Filter) || e.PayCycTer.Contains(input.Filter) || e.IsTheDefLiaWhyNot.Contains(input.Filter) || e.Comments.Contains(input.Filter))
                        .WhereIf(input.MinProjectOAReviewIdFilter != null, e => e.ProjectOAReviewId >= input.MinProjectOAReviewIdFilter)
                        .WhereIf(input.MaxProjectOAReviewIdFilter != null, e => e.ProjectOAReviewId <= input.MaxProjectOAReviewIdFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.JobReferenceFilter), e => e.JobReference.Contains(input.JobReferenceFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsProjAppInvoiceFilter), e => e.IsProjAppInvoice.Contains(input.IsProjAppInvoiceFilter))
                        .WhereIf(input.ComRuleFoPayTermFilter.HasValue && input.ComRuleFoPayTermFilter > -1, e => (input.ComRuleFoPayTermFilter == 1 && e.ComRuleFoPayTerm == null) || (input.ComRuleFoPayTermFilter == 0 && !e.ComRuleFoPayTerm == null))
                        .WhereIf(input.MinPaymentTermFilter != null, e => e.PaymentTerm >= input.MinPaymentTermFilter)
                        .WhereIf(input.MaxPaymentTermFilter != null, e => e.PaymentTerm <= input.MaxPaymentTermFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DaysFromFilter), e => e.DaysFrom.Contains(input.DaysFromFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PayCycTerFilter), e => e.PayCycTer.Contains(input.PayCycTerFilter))
                        .WhereIf(input.DownPayCycTempExcFilter.HasValue && input.DownPayCycTempExcFilter > -1, e => (input.DownPayCycTempExcFilter == 1 && e.DownPayCycTempExc == null) || (input.DownPayCycTempExcFilter == 0 && !e.DownPayCycTempExc == null))
                        .WhereIf(input.MinNotInteSuspPerFilter != null, e => e.NotInteSuspPer >= input.MinNotInteSuspPerFilter)
                        .WhereIf(input.MaxNotInteSuspPerFilter != null, e => e.NotInteSuspPer <= input.MaxNotInteSuspPerFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsTheDefLiaPerAppToThJobFilter), e => e.IsTheDefLiaPerAppToThJob.Contains(input.IsTheDefLiaPerAppToThJobFilter))
                        .WhereIf(input.MinIsTheDefLiaHowManMonFilter != null, e => e.IsTheDefLiaHowManMon >= input.MinIsTheDefLiaHowManMonFilter)
                        .WhereIf(input.MaxIsTheDefLiaHowManMonFilter != null, e => e.IsTheDefLiaHowManMon <= input.MaxIsTheDefLiaHowManMonFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsTheDefLiaWhyNotFilter), e => e.IsTheDefLiaWhyNot.Contains(input.IsTheDefLiaWhyNotFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsTheRetenOnJobFilter), e => e.IsTheRetenOnJob.Contains(input.IsTheRetenOnJobFilter))
                        .WhereIf(input.MinRetenOnJobWhatPercentageFilter != null, e => e.RetenOnJobWhatPercentage >= input.MinRetenOnJobWhatPercentageFilter)
                        .WhereIf(input.MaxRetenOnJobWhatPercentageFilter != null, e => e.RetenOnJobWhatPercentage <= input.MaxRetenOnJobWhatPercentageFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.WhWilFinMoiReteBeDueSpeFilter), e => e.WhWilFinMoiReteBeDueSpe.Contains(input.WhWilFinMoiReteBeDueSpeFilter))
                        .WhereIf(input.MinWhWilFinMoiReteBeDueFilter != null, e => e.WhWilFinMoiReteBeDue >= input.MinWhWilFinMoiReteBeDueFilter)
                        .WhereIf(input.MaxWhWilFinMoiReteBeDueFilter != null, e => e.WhWilFinMoiReteBeDue <= input.MaxWhWilFinMoiReteBeDueFilter)
                        .WhereIf(input.MinWhWilFinMoiReteBeDueMonthFilter != null, e => e.WhWilFinMoiReteBeDueMonth >= input.MinWhWilFinMoiReteBeDueMonthFilter)
                        .WhereIf(input.MaxWhWilFinMoiReteBeDueMonthFilter != null, e => e.WhWilFinMoiReteBeDueMonth <= input.MaxWhWilFinMoiReteBeDueMonthFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsScheOfRatNeeOnThisProjFilter), e => e.IsScheOfRatNeeOnThisProj.Contains(input.IsScheOfRatNeeOnThisProjFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments.Contains(input.CommentsFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var pagedAndFilteredProjectCommercialTasksPriorCommences = filteredProjectCommercialTasksPriorCommences
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectCommercialTasksPriorCommences = from o in pagedAndFilteredProjectCommercialTasksPriorCommences
                                                       join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                                       from s1 in j1.DefaultIfEmpty()
                                                       select new
                                                       {
                                                           o.ProjectOAReviewId,
                                                           o.JobReference,
                                                           o.IsProjAppInvoice,
                                                           o.ComRuleFoPayTerm,
                                                           o.PaymentTerm,
                                                           o.DaysFrom,
                                                           o.PayCycTer,
                                                           o.DownPayCycTempExc,
                                                           o.NotInteSuspPer,
                                                           o.IsTheDefLiaPerAppToThJob,
                                                           o.IsTheDefLiaHowManMon,
                                                           o.IsTheDefLiaWhyNot,
                                                           o.IsTheRetenOnJob,
                                                           o.RetenOnJobWhatPercentage,
                                                           o.WhWilFinMoiReteBeDueSpe,
                                                           o.WhWilFinMoiReteBeDue,
                                                           o.WhWilFinMoiReteBeDueMonth,
                                                           o.IsScheOfRatNeeOnThisProj,
                                                           o.Comments,
                                                           Id = o.Id,
                                                           ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                                                       };

            var totalCount = await filteredProjectCommercialTasksPriorCommences.CountAsync();
            var dbList = await projectCommercialTasksPriorCommences.ToListAsync();
            var results = new List<GetProjectCommercialTasksPriorCommenceForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectCommercialTasksPriorCommenceForViewDto()
                {
                    ProjectCommercialTasksPriorCommence = new ProjectCommercialTasksPriorCommenceDto
                    {

                        ProjectOAReviewId = o.ProjectOAReviewId,
                        JobReference = o.JobReference,
                        IsProjAppInvoice = o.IsProjAppInvoice,
                        ComRuleFoPayTerm = o.ComRuleFoPayTerm,
                        PaymentTerm = o.PaymentTerm,
                        DaysFrom = o.DaysFrom,
                        PayCycTer = o.PayCycTer,
                        DownPayCycTempExc = o.DownPayCycTempExc,
                        NotInteSuspPer = o.NotInteSuspPer,
                        IsTheDefLiaPerAppToThJob = o.IsTheDefLiaPerAppToThJob,
                        IsTheDefLiaHowManMon = o.IsTheDefLiaHowManMon,
                        IsTheDefLiaWhyNot = o.IsTheDefLiaWhyNot,
                        IsTheRetenOnJob = o.IsTheRetenOnJob,
                        RetenOnJobWhatPercentage = o.RetenOnJobWhatPercentage,
                        WhWilFinMoiReteBeDueSpe = o.WhWilFinMoiReteBeDueSpe,
                        WhWilFinMoiReteBeDue = o.WhWilFinMoiReteBeDue,
                        WhWilFinMoiReteBeDueMonth = o.WhWilFinMoiReteBeDueMonth,
                        IsScheOfRatNeeOnThisProj = o.IsScheOfRatNeeOnThisProj,
                        Comments = o.Comments,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName
                };

                results.Add(res);
            }
            return new PagedResultDto<GetProjectCommercialTasksPriorCommenceForViewDto>(
                totalCount,
                results
            );
        }

        public async Task<GetProjectCommercialTasksPriorCommenceForViewDto> GetProjectCommercialTasksPriorCommenceForView(long id)
        {
            var projectCommercialTasksPriorCommence = await _projectCommercialTasksPriorCommenceRepository.GetAsync(id);

            var output = new GetProjectCommercialTasksPriorCommenceForViewDto { ProjectCommercialTasksPriorCommence = ObjectMapper.Map<ProjectCommercialTasksPriorCommenceDto>(projectCommercialTasksPriorCommence) };

            if (output.ProjectCommercialTasksPriorCommence.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectCommercialTasksPriorCommence.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        //[AbpAuthorize(AppPermissions.Pages_ProjectCommercialTasksPriorCommences_Edit)]
        public async Task<GetProjectCommercialTasksPriorCommenceForEditOutput> GetProjectCommercialTasksPriorCommenceForEdit(EntityDto<long> input)
        {
            var projectCommercialTasksPriorCommence = await _projectCommercialTasksPriorCommenceRepository.GetAllIncluding().Where(x => x.ProjectId == input.Id).FirstOrDefaultAsync();
            // var projectCommercialTasksPriorCommence = await _projectCommercialTasksPriorCommenceRepository.FirstOrDefaultAsync(input.Id);
            var output = new GetProjectCommercialTasksPriorCommenceForEditOutput { ProjectCommercialTasksPriorCommence = ObjectMapper.Map<CreateOrEditProjectCommercialTasksPriorCommenceDto>(projectCommercialTasksPriorCommence) };
            // var output = new GetProjectCommercialTasksPriorCommenceForEditOutput { ProjectCommercialTasksPriorCommence = ObjectMapper.Map<CreateOrEditProjectCommercialTasksPriorCommenceDto>(projectCommercialTasksPriorCommence) };

            if (output.ProjectCommercialTasksPriorCommence != null && output.ProjectCommercialTasksPriorCommence.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectCommercialTasksPriorCommence.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit(string data, ICollection<IFormFile> files)
        {
            GetProjectForViewDto result = new GetProjectForViewDto();
            var projectCommercialTasksPriorCommence = new GetProjectCommercialTasksPriorCommenceForViewDto();
            var input = JsonConvert.DeserializeObject<CreateOrEditProjectCommercialTasksPriorCommenceDto>(data);

            if (input.Id == null)
            {
                projectCommercialTasksPriorCommence = await Create(input);
            }
            else
            {
                projectCommercialTasksPriorCommence = await Update(input);
            }
            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.ProjectCommercialTasksPriorCommence = projectCommercialTasksPriorCommence;
            return result;
            //await _utilsAppService.UploadSection((IFormFile)files, (long)input.ProjectId, CNodeTasks.CommercialTasksPriortoCommencement, "Customer Prior");
            //await _utilsAppService.UploadSection((IFormFile)filesTwo, (long)input.ProjectId, CNodeTasks.CommercialTasksPriortoCommencement, "Commercial Tasks");
        }

        //  [AbpAuthorize(AppPermissions.Pages_ProjectCommercialTasksPriorCommences_Create)]
        protected virtual async Task<GetProjectCommercialTasksPriorCommenceForViewDto> Create(CreateOrEditProjectCommercialTasksPriorCommenceDto input)
        {
            var OAReview =  _projectOAReviewRepository.GetAll().Where(x => x.ProjectId == input.ProjectId && x.IsCurrent == true);
            if (OAReview != null)
            {
                input.ProjectOAReviewId = OAReview.First().Id;
            }
            var projectCommercialTasksPriorCommence = ObjectMapper.Map<ProjectCommercialTasksPriorCommence>(input);

            if (AbpSession.TenantId != null)
            {
                projectCommercialTasksPriorCommence.TenantId = (int?)AbpSession.TenantId;
            }

            //await _projectCommercialTasksPriorCommenceRepository.InsertAsync(projectCommercialTasksPriorCommence);

            var project = _lookup_projectRepository.FirstOrDefault((long)input.ProjectId);

            await EventBus.TriggerAsync(new EditProjectEventData()
            {
               Project = project,
               StageId = CNodeStages.OrderAcceptance,
               TaskId = CNodeTasks.CommercialTasksPriortoCommencement,
               StatusId = input.StatusId,
               Comment = input.Comments,
               LoggedInUserId = (long)AbpSession.UserId
            });

            long projectCommercialTaskid = 0;
            projectCommercialTaskid = await _projectCommercialTasksPriorCommenceRepository.InsertAndGetIdAsync(projectCommercialTasksPriorCommence);
            var output = new GetProjectCommercialTasksPriorCommenceForViewDto { ProjectCommercialTasksPriorCommence = ObjectMapper.Map<ProjectCommercialTasksPriorCommenceDto>(_projectCommercialTasksPriorCommenceRepository.Get(projectCommercialTaskid)) };
            return output;
        }

        // [AbpAuthorize(AppPermissions.Pages_ProjectCommercialTasksPriorCommences_Edit)]
        protected virtual async Task<GetProjectCommercialTasksPriorCommenceForViewDto> Update(CreateOrEditProjectCommercialTasksPriorCommenceDto input)
        {
            var OAReview = _projectOAReviewRepository.GetAll().Where(x => x.ProjectId == input.ProjectId && x.IsCurrent == true);
            if (OAReview != null)
            {
                input.ProjectOAReviewId = OAReview.First().Id;
            }
            var projectCommercialTasksPriorCommence = await _projectCommercialTasksPriorCommenceRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectCommercialTasksPriorCommence);

            var project = _lookup_projectRepository.FirstOrDefault((long)input.ProjectId);

            await EventBus.TriggerAsync(new EditProjectEventData()
            {
               Project = project,
               StageId = CNodeStages.OrderAcceptance,
               TaskId = CNodeTasks.CommercialTasksPriortoCommencement,
               StatusId = input.StatusId,
               Comment = input.Comments,
               LoggedInUserId = (long)AbpSession.UserId
            });
            var output = new GetProjectCommercialTasksPriorCommenceForViewDto { ProjectCommercialTasksPriorCommence = ObjectMapper.Map<ProjectCommercialTasksPriorCommenceDto>(_projectCommercialTasksPriorCommenceRepository.Get((long)input.Id)) };
            return output;
        }
        // [AbpAuthorize(AppPermissions.Pages_ProjectCommercialTasksPriorCommences_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectCommercialTasksPriorCommenceRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectCommercialTasksPriorCommencesToExcel(GetAllProjectCommercialTasksPriorCommencesForExcelInput input)
        {

            var filteredProjectCommercialTasksPriorCommences = _projectCommercialTasksPriorCommenceRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.JobReference.Contains(input.Filter) || e.IsProjAppInvoice.Contains(input.Filter) || e.DaysFrom.Contains(input.Filter) || e.PayCycTer.Contains(input.Filter) || e.IsTheDefLiaWhyNot.Contains(input.Filter) || e.Comments.Contains(input.Filter))
                        .WhereIf(input.MinProjectOAReviewIdFilter != null, e => e.ProjectOAReviewId >= input.MinProjectOAReviewIdFilter)
                        .WhereIf(input.MaxProjectOAReviewIdFilter != null, e => e.ProjectOAReviewId <= input.MaxProjectOAReviewIdFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.JobReferenceFilter), e => e.JobReference.Contains(input.JobReferenceFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsProjAppInvoiceFilter), e => e.IsProjAppInvoice.Contains(input.IsProjAppInvoiceFilter))
                         .WhereIf(input.ComRuleFoPayTermFilter.HasValue && input.ComRuleFoPayTermFilter > -1, e => (input.ComRuleFoPayTermFilter == 1 && e.ComRuleFoPayTerm == null) || (input.ComRuleFoPayTermFilter == 0 && !e.ComRuleFoPayTerm == null))
                        .WhereIf(input.MinPaymentTermFilter != null, e => e.PaymentTerm >= input.MinPaymentTermFilter)
                        .WhereIf(input.MaxPaymentTermFilter != null, e => e.PaymentTerm <= input.MaxPaymentTermFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DaysFromFilter), e => e.DaysFrom.Contains(input.DaysFromFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PayCycTerFilter), e => e.PayCycTer.Contains(input.PayCycTerFilter))
                        .WhereIf(input.DownPayCycTempExcFilter.HasValue && input.DownPayCycTempExcFilter > -1, e => (input.DownPayCycTempExcFilter == 1 && e.DownPayCycTempExc == null) || (input.DownPayCycTempExcFilter == 0 && !e.DownPayCycTempExc == null))
                        .WhereIf(input.MinNotInteSuspPerFilter != null, e => e.NotInteSuspPer >= input.MinNotInteSuspPerFilter)
                        .WhereIf(input.MaxNotInteSuspPerFilter != null, e => e.NotInteSuspPer <= input.MaxNotInteSuspPerFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsTheDefLiaPerAppToThJobFilter), e => e.IsTheDefLiaPerAppToThJob.Contains(input.IsTheDefLiaPerAppToThJobFilter))
                        .WhereIf(input.MinIsTheDefLiaHowManMonFilter != null, e => e.IsTheDefLiaHowManMon >= input.MinIsTheDefLiaHowManMonFilter)
                        .WhereIf(input.MaxIsTheDefLiaHowManMonFilter != null, e => e.IsTheDefLiaHowManMon <= input.MaxIsTheDefLiaHowManMonFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsTheDefLiaWhyNotFilter), e => e.IsTheDefLiaWhyNot.Contains(input.IsTheDefLiaWhyNotFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsTheRetenOnJobFilter), e => e.IsTheRetenOnJob.Contains(input.IsTheRetenOnJobFilter))
                        .WhereIf(input.MinRetenOnJobWhatPercentageFilter != null, e => e.RetenOnJobWhatPercentage >= input.MinRetenOnJobWhatPercentageFilter)
                        .WhereIf(input.MaxRetenOnJobWhatPercentageFilter != null, e => e.RetenOnJobWhatPercentage <= input.MaxRetenOnJobWhatPercentageFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.WhWilFinMoiReteBeDueSpeFilter), e => e.WhWilFinMoiReteBeDueSpe.Contains(input.WhWilFinMoiReteBeDueSpeFilter))
                        .WhereIf(input.MinWhWilFinMoiReteBeDueFilter != null, e => e.WhWilFinMoiReteBeDue >= input.MinWhWilFinMoiReteBeDueFilter)
                        .WhereIf(input.MaxWhWilFinMoiReteBeDueFilter != null, e => e.WhWilFinMoiReteBeDue <= input.MaxWhWilFinMoiReteBeDueFilter)
                        .WhereIf(input.MinWhWilFinMoiReteBeDueMonthFilter != null, e => e.WhWilFinMoiReteBeDueMonth >= input.MinWhWilFinMoiReteBeDueMonthFilter)
                        .WhereIf(input.MaxWhWilFinMoiReteBeDueMonthFilter != null, e => e.WhWilFinMoiReteBeDueMonth <= input.MaxWhWilFinMoiReteBeDueMonthFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.IsScheOfRatNeeOnThisProjFilter), e => e.IsScheOfRatNeeOnThisProj.Contains(input.IsScheOfRatNeeOnThisProjFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments.Contains(input.CommentsFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var query = (from o in filteredProjectCommercialTasksPriorCommences
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetProjectCommercialTasksPriorCommenceForViewDto()
                         {
                             ProjectCommercialTasksPriorCommence = new ProjectCommercialTasksPriorCommenceDto
                             {
                                 ProjectOAReviewId = o.ProjectOAReviewId,
                                 JobReference = o.JobReference,
                                 IsProjAppInvoice = o.IsProjAppInvoice,
                                 ComRuleFoPayTerm = o.ComRuleFoPayTerm,
                                 PaymentTerm = o.PaymentTerm,
                                 DaysFrom = o.DaysFrom,
                                 PayCycTer = o.PayCycTer,
                                 DownPayCycTempExc = o.DownPayCycTempExc,
                                 NotInteSuspPer = o.NotInteSuspPer,
                                 IsTheDefLiaPerAppToThJob = o.IsTheDefLiaPerAppToThJob,
                                 IsTheDefLiaHowManMon = o.IsTheDefLiaHowManMon,
                                 IsTheDefLiaWhyNot = o.IsTheDefLiaWhyNot,
                                 IsTheRetenOnJob = o.IsTheRetenOnJob,
                                 RetenOnJobWhatPercentage = o.RetenOnJobWhatPercentage,
                                 WhWilFinMoiReteBeDueSpe = o.WhWilFinMoiReteBeDueSpe,
                                 WhWilFinMoiReteBeDue = o.WhWilFinMoiReteBeDue,
                                 WhWilFinMoiReteBeDueMonth = o.WhWilFinMoiReteBeDueMonth,
                                 IsScheOfRatNeeOnThisProj = o.IsScheOfRatNeeOnThisProj,
                                 Comments = o.Comments,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                         });

            var projectCommercialTasksPriorCommenceListDtos = await query.ToListAsync();

            return _projectCommercialTasksPriorCommencesExcelExporter.ExportToFile(projectCommercialTasksPriorCommenceListDtos);
        }
        // [AbpAuthorize(AppPermissions.Pages_ProjectCommercialTasksPriorCommences)]
        public async Task<List<ProjectCommercialTasksPriorCommenceProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectCommercialTasksPriorCommenceProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }
    }
}