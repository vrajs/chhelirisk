﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.BusinessRules;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Flexi.Dtos;
using asq.econsys.Flexi;
using Abp.Events.Bus;
using Abp.Domain.Uow;
using Microsoft.AspNetCore.Mvc;
using System.Collections.ObjectModel;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using asq.econsys.Eco.Utils.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectCommercials)]
    public class ProjectCommercialsAppService : econsysAppServiceBase, IProjectCommercialsAppService
    {
        public IEventBus EventBus { get; set; }
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly IRepository<ProjectCommercial> _projectCommercialRepository;
        private readonly IProjectCommercialsExcelExporter _projectCommercialsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<RuleElement, long> _lookup_ruleElementRepository;
        private readonly IRepository<RuleValue, long> _lookup_ruleValueRepository;
        private readonly IRepository<RuleFlag, string> _lookup_ruleFlagRepository;
        private readonly IRepository<RevenueRange, long> _lookup_revenueRangeRepository;
        private readonly IRepository<RuleType, string> _lookup_ruleTypeRepository;
        private readonly IRepository<RuleConfiguration, long> _ruleConfigurationRepository;
        private readonly IRepository<FlexiField, long> _flexiFieldRepository;
        private readonly IProjectsAppService _projectAppService;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly StorageManager _storageManager;

        public ProjectCommercialsAppService(
            IUnitOfWorkManager unitOfWorkManager, 
            IRepository<ProjectCommercial> projectCommercialRepository, 
            IProjectCommercialsExcelExporter projectCommercialsExcelExporter, 
            IRepository<Project, long> lookup_projectRepository, 
            IRepository<RuleElement, long> lookup_ruleElementRepository, 
            IRepository<RuleValue, long> lookup_ruleValueRepository, 
            IRepository<RuleFlag, string> lookup_ruleFlagRepository, 
            IRepository<RevenueRange, long> lookup_revenueRangeRepository, 
            IRepository<RuleType, string> lookup_ruleTypeRepository, 
            IRepository<RuleConfiguration, long> ruleConfigurationRepository, 
            IRepository<FlexiField, long> flexiFieldRepository, 
            IProjectsAppService projectAppService, 
            Utils.UtilsAppService utilsAppService,
            StorageManager storageManager)
        {
            EventBus = NullEventBus.Instance;
            _unitOfWorkManager = unitOfWorkManager;
            _projectCommercialRepository = projectCommercialRepository;
            _projectCommercialsExcelExporter = projectCommercialsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_ruleElementRepository = lookup_ruleElementRepository;
            _lookup_ruleValueRepository = lookup_ruleValueRepository;
            _lookup_ruleFlagRepository = lookup_ruleFlagRepository;
            _lookup_revenueRangeRepository = lookup_revenueRangeRepository;
            _lookup_ruleTypeRepository = lookup_ruleTypeRepository;
            _ruleConfigurationRepository = ruleConfigurationRepository;
            _flexiFieldRepository = flexiFieldRepository;
            _projectAppService = projectAppService;
            _utilsAppService = utilsAppService;
            _storageManager = storageManager;
        }

        public async Task<PagedResultDto<GetProjectCommercialForViewDto>> GetAll(GetAllProjectCommercialsInput input)
        {

            var filteredProjectCommercials = _projectCommercialRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.RuleElementFk)
                        .Include(e => e.RuleValueFk)
                        .Include(e => e.RuleFlagFk)
                        .Include(e => e.RevenueRangeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleElementTitleFilter), e => e.RuleElementFk != null && e.RuleElementFk.Title == input.RuleElementTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleValueTitleFilter), e => e.RuleValueFk != null && e.RuleValueFk.Title == input.RuleValueTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagTitleFilter), e => e.RuleFlagFk != null && e.RuleFlagFk.Title == input.RuleFlagTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevenueRangeTitleFilter), e => e.RevenueRangeFk != null && e.RevenueRangeFk.Title == input.RevenueRangeTitleFilter);

            var pagedAndFilteredProjectCommercials = filteredProjectCommercials
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectCommercials = from o in pagedAndFilteredProjectCommercials
                                     join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                     from s1 in j1.DefaultIfEmpty()

                                     join o2 in _lookup_ruleElementRepository.GetAll() on o.RuleElementId equals o2.Id into j2
                                     from s2 in j2.DefaultIfEmpty()

                                     join o3 in _lookup_ruleValueRepository.GetAll() on o.RuleValueId equals o3.Id into j3
                                     from s3 in j3.DefaultIfEmpty()

                                     join o4 in _lookup_ruleFlagRepository.GetAll() on o.RuleFlagId equals o4.Id into j4
                                     from s4 in j4.DefaultIfEmpty()

                                     join o5 in _lookup_revenueRangeRepository.GetAll() on o.RevenueRangeId equals o5.Id into j5
                                     from s5 in j5.DefaultIfEmpty()

                                     select new
                                     {

                                         Id = o.Id,
                                         ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                         RuleElementTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                                         RuleValueTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString(),
                                         RuleFlagTitle = s4 == null || s4.Title == null ? "" : s4.Title.ToString(),
                                         RevenueRangeTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString()
                                     };

            var totalCount = await filteredProjectCommercials.CountAsync();

            var dbList = await projectCommercials.ToListAsync();
            var results = new List<GetProjectCommercialForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectCommercialForViewDto()
                {
                    ProjectCommercial = new ProjectCommercialDto
                    {

                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    RuleElementTitle = o.RuleElementTitle,
                    RuleValueTitle = o.RuleValueTitle,
                    RuleFlagTitle = o.RuleFlagTitle,
                    RevenueRangeTitle = o.RevenueRangeTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectCommercialForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectCommercialForViewDto> GetProjectCommercialForView(int id)
        {
            var projectCommercial = await _projectCommercialRepository.GetAsync(id);

            var output = new GetProjectCommercialForViewDto { ProjectCommercial = ObjectMapper.Map<ProjectCommercialDto>(projectCommercial) };

            if (output.ProjectCommercial.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectCommercial.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectCommercial.RuleElementId != null)
            {
                var _lookupRuleElement = await _lookup_ruleElementRepository.FirstOrDefaultAsync((long)output.ProjectCommercial.RuleElementId);
                output.RuleElementTitle = _lookupRuleElement?.Title?.ToString();
            }

            if (output.ProjectCommercial.RuleValueId != null)
            {
                var _lookupRuleValue = await _lookup_ruleValueRepository.FirstOrDefaultAsync((long)output.ProjectCommercial.RuleValueId);
                output.RuleValueTitle = _lookupRuleValue?.Title?.ToString();
            }

            if (output.ProjectCommercial.RuleFlagId != null)
            {
                var _lookupRuleFlag = await _lookup_ruleFlagRepository.FirstOrDefaultAsync((string)output.ProjectCommercial.RuleFlagId);
                output.RuleFlagTitle = _lookupRuleFlag?.Title?.ToString();
            }

            if (output.ProjectCommercial.RevenueRangeId != null)
            {
                var _lookupRevenueRange = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)output.ProjectCommercial.RevenueRangeId);
                output.RevenueRangeTitle = _lookupRevenueRange?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials_Edit)]
        public async Task<GetProjectCommercialForEditOutput> GetProjectCommercialForEdit(EntityDto input)
        {
            var projectCommercial = await _projectCommercialRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectCommercialForEditOutput { ProjectCommercial = ObjectMapper.Map<CreateOrEditProjectCommercialDto>(projectCommercial) };

            if (output.ProjectCommercial.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectCommercial.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectCommercial.RuleElementId != null)
            {
                var _lookupRuleElement = await _lookup_ruleElementRepository.FirstOrDefaultAsync((long)output.ProjectCommercial.RuleElementId);
                output.RuleElementTitle = _lookupRuleElement?.Title?.ToString();
            }

            if (output.ProjectCommercial.RuleValueId != null)
            {
                var _lookupRuleValue = await _lookup_ruleValueRepository.FirstOrDefaultAsync((long)output.ProjectCommercial.RuleValueId);
                output.RuleValueTitle = _lookupRuleValue?.Title?.ToString();
            }

            if (output.ProjectCommercial.RuleFlagId != null)
            {
                var _lookupRuleFlag = await _lookup_ruleFlagRepository.FirstOrDefaultAsync((string)output.ProjectCommercial.RuleFlagId);
                output.RuleFlagTitle = _lookupRuleFlag?.Title?.ToString();
            }

            if (output.ProjectCommercial.RevenueRangeId != null)
            {
                var _lookupRevenueRange = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)output.ProjectCommercial.RevenueRangeId);
                output.RevenueRangeTitle = _lookupRevenueRange?.Title?.ToString();
            }

            return output;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit([FromForm] CreateOrEditCommercialDto data)
        {
            var inputs = JsonConvert.DeserializeObject<List<CreateOrEditProjectCommercialDto>>(data.RuleData);
            var attachElements = JsonConvert.DeserializeObject<List<CreateOrEditProjectCommercialDto>>(data.AttachmentElementData);

            List<GetProjectCommercialForViewDto> projectCommercials = new List<GetProjectCommercialForViewDto>();
            await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        foreach (var input in inputs)
                        {
                            if (input.RuleElementId == null || input.RuleValueId == null)
                            {
                                continue;
                            }
                            ProjectCommercial commercial = new ProjectCommercial();
                            GetProjectCommercialForViewDto projectCommercial = new GetProjectCommercialForViewDto();

                            if (input.Id == null)
                            {
                                commercial = await Create(input);
                                projectCommercial = new GetProjectCommercialForViewDto { ProjectCommercial = ObjectMapper.Map<ProjectCommercialDto>(commercial) };
                                //projectCommercial.RuleElementTitle = _lookup_ruleElementRepository.Get(commercial.RuleElementId).Title;
                                //projectCommercial.RuleValueTitle = _lookup_ruleValueRepository.Get(commercial.RuleValueId).Title;

                                var ruleElement = _lookup_ruleElementRepository
                                   .FirstOrDefault(x => x.Id == commercial.RuleElementId);// && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                                projectCommercial.RuleElementTitle = ruleElement == null ? null : ruleElement.Title;
                                var ruleValue = _lookup_ruleValueRepository
                                    .FirstOrDefault(x => x.Id == commercial.RuleValueId && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                                projectCommercial.RuleValueTitle = ruleValue == null ? null : ruleValue.Title;

                                projectCommercials.Add(projectCommercial);
                            }
                            else
                            {
                                commercial = await Update(input);
                                projectCommercial = new GetProjectCommercialForViewDto { ProjectCommercial = ObjectMapper.Map<ProjectCommercialDto>(commercial) };
                                //projectCommercial.RuleElementTitle = _lookup_ruleElementRepository.Get(commercial.RuleElementId).Title;
                                //projectCommercial.RuleValueTitle = _lookup_ruleValueRepository.Get(commercial.RuleValueId).Title;

                                var ruleElement = _lookup_ruleElementRepository
                                    .FirstOrDefault(x => x.Id == commercial.RuleElementId);// && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                                projectCommercial.RuleElementTitle = ruleElement == null ? null : ruleElement.Title;
                                var ruleValue = _lookup_ruleValueRepository
                                    .FirstOrDefault(x => x.Id == commercial.RuleValueId && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                                projectCommercial.RuleValueTitle = ruleValue == null ? null : ruleValue.Title;

                                projectCommercials.Add(projectCommercial);
                            }

                            List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                            if (data.Files != null && data.Files.Count > 0)
                            {
                                for (var j = 0; j < attachElements.Count; j++)
                                {
                                    if (commercial.RuleElementId == attachElements[j].RuleElementId)
                                    {
                                        projectFilesInput.Add(new ProjectFileInput()
                                        {
                                            File = data.Files.ToList()[j],
                                            ProjectId = commercial.ProjectId,
                                            TaskId = CNodeTasks.AddCommercial,
                                            MetaData = JsonConvert.SerializeObject(commercial)
                                        });
                                    }
                                }
                            }

                            if(projectFilesInput.Count > 0)
                            {
                                var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                            }
                        }

                        var projectId = inputs.FirstOrDefault().ProjectId;
                        //var hasExisitng = _projectEngineeringRepository.GetAll().Where(x => x.ProjectId == projectId).ToList();
                        //var project = _lookup_projectRepository.FirstOrDefault(projectId);
                        await EventBus.TriggerAsync(new EditProjectEventData()
                        {
                            ProjectId = projectId,
                            StageId = CNodeStages.PreOrder,
                            TaskId = CNodeTasks.AddCommercial,
                            StatusId = CNodeStatuses.Save,
                            LoggedInUserId = (long)AbpSession.UserId
                        });
                    }
                }
            });

            var project = _lookup_projectRepository.FirstOrDefault(inputs.FirstOrDefault().ProjectId);
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.ProjectCommercials = projectCommercials;

            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials_Create)]
        protected virtual async Task<ProjectCommercial> Create(CreateOrEditProjectCommercialDto input)
        {
            if (input.RuleValueId != null)
            {
                var ruleConfig = this.GetRuleConfiguration(input.RuleElementId, (long)input.RuleValueId);
                if (ruleConfig != null && ruleConfig.Result != null)
                {
                    input.RuleFlagId = ruleConfig.Result.RuleConfiguration.RuleFlagId;
                }
            }
            var projectCommercial = ObjectMapper.Map<ProjectCommercial>(input);

            if (AbpSession.TenantId != null)
            {
                projectCommercial.TenantId = (int?)AbpSession.TenantId;
            }

            var commercialId = _projectCommercialRepository.InsertAndGetId(projectCommercial);
            return _projectCommercialRepository.Get(commercialId);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials_Edit)]
        protected virtual async Task<ProjectCommercial> Update(CreateOrEditProjectCommercialDto input)
        {
            if (input.RuleValueId != null)
            {
                var ruleConfig = this.GetRuleConfiguration(input.RuleElementId, (long)input.RuleValueId);
                if (ruleConfig != null && ruleConfig.Result != null)
                {
                    input.RuleFlagId = ruleConfig.Result.RuleConfiguration.RuleFlagId;
                }
            }
            var projectCommercial = await _projectCommercialRepository.FirstOrDefaultAsync((int)input.Id);
            ObjectMapper.Map(input, projectCommercial);
            return projectCommercial;

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials_Delete)]
        public async Task Delete(EntityDto input)
        {
            await _projectCommercialRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectCommercialsToExcel(GetAllProjectCommercialsForExcelInput input)
        {

            var filteredProjectCommercials = _projectCommercialRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.RuleElementFk)
                        .Include(e => e.RuleValueFk)
                        .Include(e => e.RuleFlagFk)
                        .Include(e => e.RevenueRangeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleElementTitleFilter), e => e.RuleElementFk != null && e.RuleElementFk.Title == input.RuleElementTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleValueTitleFilter), e => e.RuleValueFk != null && e.RuleValueFk.Title == input.RuleValueTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagTitleFilter), e => e.RuleFlagFk != null && e.RuleFlagFk.Title == input.RuleFlagTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevenueRangeTitleFilter), e => e.RevenueRangeFk != null && e.RevenueRangeFk.Title == input.RevenueRangeTitleFilter);

            var query = (from o in filteredProjectCommercials
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_ruleElementRepository.GetAll() on o.RuleElementId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_ruleValueRepository.GetAll() on o.RuleValueId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         join o4 in _lookup_ruleFlagRepository.GetAll() on o.RuleFlagId equals o4.Id into j4
                         from s4 in j4.DefaultIfEmpty()

                         join o5 in _lookup_revenueRangeRepository.GetAll() on o.RevenueRangeId equals o5.Id into j5
                         from s5 in j5.DefaultIfEmpty()

                         select new GetProjectCommercialForViewDto()
                         {
                             ProjectCommercial = new ProjectCommercialDto
                             {
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             RuleElementTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                             RuleValueTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString(),
                             RuleFlagTitle = s4 == null || s4.Title == null ? "" : s4.Title.ToString(),
                             RevenueRangeTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString()
                         });

            var projectCommercialListDtos = await query.ToListAsync();

            return _projectCommercialsExcelExporter.ExportToFile(projectCommercialListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials)]
        public async Task<List<ProjectCommercialProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectCommercialProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials)]
        public async Task<List<ProjectCommercialRuleElementLookupTableDto>> GetAllRuleElementForTableDropdown()
        {
            return await _lookup_ruleElementRepository.GetAll()
                .Select(ruleElement => new ProjectCommercialRuleElementLookupTableDto
                {
                    Id = ruleElement.Id,
                    DisplayName = ruleElement == null || ruleElement.Title == null ? "" : ruleElement.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials)]
        public async Task<List<ProjectCommercialRuleValueLookupTableDto>> GetAllRuleValueForTableDropdown()
        {
            return await _lookup_ruleValueRepository.GetAll()
                .Select(ruleValue => new ProjectCommercialRuleValueLookupTableDto
                {
                    Id = ruleValue.Id,
                    DisplayName = ruleValue == null || ruleValue.Title == null ? "" : ruleValue.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials)]
        public async Task<List<ProjectCommercialRuleFlagLookupTableDto>> GetAllRuleFlagForTableDropdown()
        {
            return await _lookup_ruleFlagRepository.GetAll()
                .Select(ruleFlag => new ProjectCommercialRuleFlagLookupTableDto
                {
                    Id = ruleFlag.Id,
                    DisplayName = ruleFlag == null || ruleFlag.Title == null ? "" : ruleFlag.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCommercials)]
        public async Task<List<ProjectCommercialRevenueRangeLookupTableDto>> GetAllRevenueRangeForTableDropdown()
        {
            return await _lookup_revenueRangeRepository.GetAll()
                .Select(revenueRange => new ProjectCommercialRevenueRangeLookupTableDto
                {
                    Id = revenueRange.Id,
                    DisplayName = revenueRange == null || revenueRange.Title == null ? "" : revenueRange.Title.ToString()
                }).ToListAsync();
        }

        public async Task<AllProjectCommercialDataDto> GetAllProjectCommercialData(int ProjectId)
        {
            var result = new AllProjectCommercialDataDto();
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var flags = await _lookup_ruleFlagRepository.GetAll()
                        .Select(x => new GetRuleFlagForViewDto()
                        {
                            RuleFlag = new RuleFlagDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                HexColor = x.HexColor
                            }
                        }).OrderBy(s => s.RuleFlag.DisplayOrder).ToListAsync();

                    result.RuleFlags = ObjectMapper.Map<List<GetRuleFlagForViewDto>>(flags);

                    //var types = _lookup_ruleTypeRepository.GetAll().ToList();
                    var types = await _lookup_ruleTypeRepository.GetAll()
                        .Select(x => new GetRuleTypeForViewDto()
                        {
                            RuleType = new RuleTypeDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                IsRangeSpecific = x.IsRangeSpecific,
                                OutputVariable = x.OutputVariable,
                                StatusDetailsVariable = x.StatusDetailsVariable
                            }
                        }).OrderBy(s => s.RuleType.DisplayOrder).ToListAsync();

                    result.RuleTypes = ObjectMapper.Map<List<GetRuleTypeForViewDto>>(types);

                    //var revenueRanges = _lookup_revenueRangeRepository.GetAll().ToList();
                    var revenueRanges = await _lookup_revenueRangeRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRevenueRangeForViewDto()
                        {
                            RevenueRange = new RevenueRangeDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                MinRange = x.MinRange,
                                MaxRange = x.MaxRange
                            }
                        }).OrderBy(s => s.RevenueRange.DisplayOrder).ToListAsync();

                    result.RevenueRanges = ObjectMapper.Map<List<GetRevenueRangeForViewDto>>(revenueRanges);

                    //var ruleElements = _lookup_ruleElementRepository.GetAll().ToList();
                    var ruleElements = await _lookup_ruleElementRepository.GetAll()
                        .Where(e => e.RuleTypeId == CRuleCategories.Commercial && e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRuleElementForViewDto()
                        {
                            RuleElement = new RuleElementDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                RuleTypeId = x.RuleTypeId,
                                VariableName = x.VariableName
                            }
                        }).OrderBy(s => s.RuleElement.DisplayOrder).ToListAsync();

                    result.RuleElements = ObjectMapper.Map<List<GetRuleElementForViewDto>>(ruleElements);

                    //var ruleValue = _lookup_ruleValueRepository.GetAll().ToList();
                    var ruleValues = await _lookup_ruleValueRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.RuleTypeId == CRuleCategories.Commercial && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRuleValueForViewDto()
                        {
                            RuleValue = new RuleValueDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                RuleTypeId = x.RuleTypeId,
                                RuleElementId = x.RuleElementId,
                                IsRangeSpecific = x.IsRangeSpecific
                            }
                        }).OrderBy(s => s.RuleValue.DisplayOrder).ToListAsync();

                    result.RuleValues = ObjectMapper.Map<List<GetRuleValueForViewDto>>(ruleValues);

                    //var ruleValue = _lookup_ruleValueRepository.GetAll().ToList();
                    var ProjectCommercial = await _projectCommercialRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.ProjectId == ProjectId && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetProjectCommercialForViewDto()
                        {
                            ProjectCommercial = new ProjectCommercialDto()
                            {
                                Id = x.Id,
                                RevenueRangeId = x.RevenueRangeId,
                                RuleElementId = (long)x.RuleElementId,
                                RuleFlagId = x.RuleFlagId,
                                RuleValueId = (long)x.RuleValueId,
                                ProjectId = x.ProjectId,

                            },
                            RuleElementTitle = _lookup_ruleElementRepository.FirstOrDefault((long)x.RuleElementId).Title,
                            RuleValueTitle = _lookup_ruleValueRepository.FirstOrDefault((long)x.RuleValueId).Title,

                }).ToListAsync();
                    
                    result.ProjectCommercial = ObjectMapper.Map<List<GetProjectCommercialForViewDto>>(ProjectCommercial);

                    var ruleConfiguration = await _ruleConfigurationRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                       .Select(x => new GetRuleConfigurationForViewDto()
                       {
                           RuleConfiguration = new RuleConfigurationDto()
                           {
                               Id = x.Id,
                               RevenueRangeId = x.RevenueRangeId,
                               RuleElementId = x.RuleElementId,
                               RuleFlagId = x.RuleFlagId,
                               RuleValueId = x.RuleValueId,
                               OrganizationUnitId = x.OrganizationUnitId,


                           }
                       }).ToListAsync();

                    result.RuleConfigurations = ObjectMapper.Map<List<GetRuleConfigurationForViewDto>>(ruleConfiguration);

                    var flexiFields = await _flexiFieldRepository.GetAll()
                        .Where(e => e.FlexiSectionId == "project-commercial" && e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                      .Select(x => new GetFlexiFieldForViewDto()
                      {
                          FlexiField = new FlexiFieldDto()
                          {
                              Id = x.Id,
                              FlexiSectionId = x.FlexiSectionId,
                              Code = x.Code,
                              DBType = x.DBType,
                              DisplayName = x.DisplayName,
                              FieldType = x.FieldType,
                              HTMLInputType = x.HTMLInputType,
                              HTMLType = x.HTMLType,
                              IsEnabled = x.IsEnabled,
                              SortOrder = x.SortOrder,
                              Validations = x.Validations,
                              MetaData = x.MetaData
                          }
                      }).ToListAsync();

                    result.FlexiFields = ObjectMapper.Map<List<GetFlexiFieldForViewDto>>(flexiFields);
                    if (result.ProjectCommercial.Count > 0)
                    {
                        result.CommercialFiles = await _projectAppService.GetProjectFileList(ProjectId, CNodeTasks.AddCommercial);
                    }
                }
            }
            return result;
        }

        public async Task<GetRuleConfigurationForViewDto> GetRuleConfiguration(long ruleElementId, long ruleValueId)
        {
            var ruleConfiguration = await _ruleConfigurationRepository.GetAll()
               .Select(x => new GetRuleConfigurationForViewDto()
               {
                   RuleConfiguration = new RuleConfigurationDto()
                   {
                       Id = x.Id,
                       RevenueRangeId = x.RevenueRangeId,
                       RuleElementId = x.RuleElementId,
                       RuleFlagId = x.RuleFlagId,
                       RuleValueId = x.RuleValueId,
                       OrganizationUnitId = x.OrganizationUnitId,


                   }
               }).Where(x => x.RuleConfiguration.RuleElementId == ruleElementId && x.RuleConfiguration.RuleValueId == ruleValueId).ToListAsync();

            return ruleConfiguration != null && ruleConfiguration.Count > 0 ? ruleConfiguration[0] : null;
        }

    }
}