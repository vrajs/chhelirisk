﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectCostDetails)]
    public class ProjectCostDetailsAppService : econsysAppServiceBase, IProjectCostDetailsAppService
    {
        private readonly IRepository<ProjectCostDetail, long> _projectCostDetailRepository;
        private readonly IProjectCostDetailsExcelExporter _projectCostDetailsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectAction, long> _lookup_projectActionRepository;
        private readonly IRepository<ProjectExReviewDetail, long> _lookup_projectExReviewDetailRepository;
        private readonly IRepository<ProjectQuoteForm, long> _lookup_projectQuoteFormRepository;

        public ProjectCostDetailsAppService(IRepository<ProjectCostDetail, long> projectCostDetailRepository, IProjectCostDetailsExcelExporter projectCostDetailsExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectAction, long> lookup_projectActionRepository, IRepository<ProjectExReviewDetail, long> lookup_projectExReviewDetailRepository, IRepository<ProjectQuoteForm, long> lookup_projectQuoteFormRepository)
        {
            _projectCostDetailRepository = projectCostDetailRepository;
            _projectCostDetailsExcelExporter = projectCostDetailsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectActionRepository = lookup_projectActionRepository;
            _lookup_projectExReviewDetailRepository = lookup_projectExReviewDetailRepository;
            _lookup_projectQuoteFormRepository = lookup_projectQuoteFormRepository;
        }

        public async Task<PagedResultDto<GetProjectCostDetailForViewDto>> GetAll(GetAllProjectCostDetailsInput input)
        {

            var filteredProjectCostDetails = _projectCostDetailRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectActionFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.Category.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CategoryFilter), e => e.Category == input.CategoryFilter)
                        .WhereIf(input.MinCostAmountApprovedFilter != null, e => e.CostAmountApproved >= input.MinCostAmountApprovedFilter)
                        .WhereIf(input.MaxCostAmountApprovedFilter != null, e => e.CostAmountApproved <= input.MaxCostAmountApprovedFilter)
                        .WhereIf(input.MinCostAmountFilter != null, e => e.CostAmount >= input.MinCostAmountFilter)
                        .WhereIf(input.MaxCostAmountFilter != null, e => e.CostAmount <= input.MaxCostAmountFilter)
                        .WhereIf(input.MinCostEstimateFilter != null, e => e.CostEstimate >= input.MinCostEstimateFilter)
                        .WhereIf(input.MaxCostEstimateFilter != null, e => e.CostEstimate <= input.MaxCostEstimateFilter)
                        .WhereIf(input.MinCostVarianceFilter != null, e => e.CostVariance >= input.MinCostVarianceFilter)
                        .WhereIf(input.MaxCostVarianceFilter != null, e => e.CostVariance <= input.MaxCostVarianceFilter)
                        .WhereIf(input.MinCostActualReceivedFilter != null, e => e.CostActualReceived >= input.MinCostActualReceivedFilter)
                        .WhereIf(input.MaxCostActualReceivedFilter != null, e => e.CostActualReceived <= input.MaxCostActualReceivedFilter)
                        .WhereIf(input.MinCostEstimatedToComeFilter != null, e => e.CostEstimatedToCome >= input.MinCostEstimatedToComeFilter)
                        .WhereIf(input.MaxCostEstimatedToComeFilter != null, e => e.CostEstimatedToCome <= input.MaxCostEstimatedToComeFilter)
                        .WhereIf(input.MinSellAmountApprovedFilter != null, e => e.SellAmountApproved >= input.MinSellAmountApprovedFilter)
                        .WhereIf(input.MaxSellAmountApprovedFilter != null, e => e.SellAmountApproved <= input.MaxSellAmountApprovedFilter)
                        .WhereIf(input.MinSellAmountFilter != null, e => e.SellAmount >= input.MinSellAmountFilter)
                        .WhereIf(input.MaxSellAmountFilter != null, e => e.SellAmount <= input.MaxSellAmountFilter)
                        .WhereIf(input.MinSellEstimateFilter != null, e => e.SellEstimate >= input.MinSellEstimateFilter)
                        .WhereIf(input.MaxSellEstimateFilter != null, e => e.SellEstimate <= input.MaxSellEstimateFilter)
                        .WhereIf(input.MinSellVarianceFilter != null, e => e.SellVariance >= input.MinSellVarianceFilter)
                        .WhereIf(input.MaxSellVarianceFilter != null, e => e.SellVariance <= input.MaxSellVarianceFilter)
                        .WhereIf(input.MinMarginAmountFilter != null, e => e.MarginAmount >= input.MinMarginAmountFilter)
                        .WhereIf(input.MaxMarginAmountFilter != null, e => e.MarginAmount <= input.MaxMarginAmountFilter)
                        .WhereIf(input.MinMarginPercFilter != null, e => e.MarginPerc >= input.MinMarginPercFilter)
                        .WhereIf(input.MaxMarginPercFilter != null, e => e.MarginPerc <= input.MaxMarginPercFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectActionStatusFilter), e => e.ProjectActionFk != null && e.ProjectActionFk.Status == input.ProjectActionStatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);

            var pagedAndFilteredProjectCostDetails = filteredProjectCostDetails
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectCostDetails = from o in pagedAndFilteredProjectCostDetails
                                     join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                     from s1 in j1.DefaultIfEmpty()

                                     join o2 in _lookup_projectActionRepository.GetAll() on o.ProjectActionId equals o2.Id into j2
                                     from s2 in j2.DefaultIfEmpty()

                                     join o3 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o3.Id into j3
                                     from s3 in j3.DefaultIfEmpty()

                                     select new
                                     {

                                         o.Title,
                                         o.Category,
                                         o.CostAmountApproved,
                                         o.CostAmount,
                                         o.CostEstimate,
                                         o.CostVariance,
                                         o.CostActualReceived,
                                         o.CostEstimatedToCome,
                                         o.SellAmountApproved,
                                         o.SellAmount,
                                         o.SellEstimate,
                                         o.SellVariance,
                                         o.MarginAmount,
                                         o.MarginPerc,
                                         o.Comment,
                                         Id = o.Id,
                                         ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                         ProjectActionStatus = s2 == null || s2.Status == null ? "" : s2.Status.ToString(),
                                         ProjectExReviewDetailTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
                                     };

            var totalCount = await filteredProjectCostDetails.CountAsync();

            var dbList = await projectCostDetails.ToListAsync();
            var results = new List<GetProjectCostDetailForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectCostDetailForViewDto()
                {
                    ProjectCostDetail = new ProjectCostDetailDto
                    {

                        Title = o.Title,
                        Category = o.Category,
                        CostAmountApproved = o.CostAmountApproved,
                        CostAmount = o.CostAmount,
                        CostEstimate = o.CostEstimate,
                        CostVariance = o.CostVariance,
                        CostActualReceived = o.CostActualReceived,
                        CostEstimatedToCome = o.CostEstimatedToCome,
                        SellAmountApproved = o.SellAmountApproved,
                        SellAmount = o.SellAmount,
                        SellEstimate = o.SellEstimate,
                        SellVariance = o.SellVariance,
                        MarginAmount = o.MarginAmount,
                        MarginPerc = o.MarginPerc,
                        Comment = o.Comment,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectActionStatus = o.ProjectActionStatus,
                    ProjectExReviewDetailTitle = o.ProjectExReviewDetailTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectCostDetailForViewDto>(
                totalCount,
                results
            );

        }
        public async Task<ProjectQuoteFormDto> GetTotalCostSell(long id)
        {
            try
            {
                var projectCostDetail = _lookup_projectQuoteFormRepository.GetAll().FirstOrDefault(x => x.ProjectId == id && x.Revision == null);
                var output = ObjectMapper.Map<ProjectQuoteFormDto>(projectCostDetail);

                return output;
            }
            catch (Exception e)
            {

                throw;
            }
        }
        public async Task<GetProjectCostDetailForViewDto> GetProjectCostDetailForView(long id)
        {
            var projectCostDetail = await _projectCostDetailRepository.GetAsync(id);

            var output = new GetProjectCostDetailForViewDto { ProjectCostDetail = ObjectMapper.Map<ProjectCostDetailDto>(projectCostDetail) };

            if (output.ProjectCostDetail.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectCostDetail.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectCostDetail.ProjectActionId != null)
            {
                var _lookupProjectAction = await _lookup_projectActionRepository.FirstOrDefaultAsync((long)output.ProjectCostDetail.ProjectActionId);
                output.ProjectActionStatus = _lookupProjectAction?.Status?.ToString();
            }

            if (output.ProjectCostDetail.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectCostDetail.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCostDetails_Edit)]
        public async Task<GetProjectCostDetailForEditOutput> GetProjectCostDetailForEdit(EntityDto<long> input)
        {
            var projectCostDetail = await _projectCostDetailRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectCostDetailForEditOutput { ProjectCostDetail = ObjectMapper.Map<CreateOrEditProjectCostDetailDto>(projectCostDetail) };

            if (output.ProjectCostDetail.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectCostDetail.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectCostDetail.ProjectActionId != null)
            {
                var _lookupProjectAction = await _lookup_projectActionRepository.FirstOrDefaultAsync((long)output.ProjectCostDetail.ProjectActionId);
                output.ProjectActionStatus = _lookupProjectAction?.Status?.ToString();
            }

            if (output.ProjectCostDetail.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectCostDetail.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        public async Task<ProjectCostDetailDto> CreateOrEdit(CreateOrEditProjectCostDetailDto input)
        {
            ProjectCostDetail costdetail = null;
            if (input.Id == null)
            {
                costdetail = await Create(input);
            }
            else
            {
                costdetail = await Update(input);
            }

            return costdetail == null ? null : ObjectMapper.Map<ProjectCostDetailDto>(costdetail);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCostDetails_Create)]
        protected virtual async Task<ProjectCostDetail> Create(CreateOrEditProjectCostDetailDto input)
        {
            var projectCostDetail = ObjectMapper.Map<ProjectCostDetail>(input);

            if (AbpSession.TenantId != null)
            {
                projectCostDetail.TenantId = (int?)AbpSession.TenantId;
            }

            var id = await _projectCostDetailRepository.InsertAndGetIdAsync(projectCostDetail);
            if (id > 0)
            {
                var result = await _projectCostDetailRepository.FirstOrDefaultAsync((long)id);
                return result;
            }
            return null;
        }

        public async Task CreateImportExcel(List<CreateOrEditProjectCostDetailDto> inputList)
        {
            inputList.ForEach(async data =>
            {
                var projectCostDetail = ObjectMapper.Map<ProjectCostDetail>(data);
                if (AbpSession.TenantId != null)
                {
                    projectCostDetail.TenantId = (int?)AbpSession.TenantId;
                }

                await _projectCostDetailRepository.InsertAsync(projectCostDetail);
            });
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCostDetails_Edit)]
        protected virtual async Task<ProjectCostDetail> Update(CreateOrEditProjectCostDetailDto input)
        {
            var projectCostDetail = await _projectCostDetailRepository.FirstOrDefaultAsync(x => x.Id == input.Id);
            ObjectMapper.Map(input, projectCostDetail);
            return projectCostDetail;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCostDetails_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectCostDetailRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectCostDetailsToExcel(GetAllProjectCostDetailsForExcelInput input)
        {

            var filteredProjectCostDetails = _projectCostDetailRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectActionFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.Category.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CategoryFilter), e => e.Category == input.CategoryFilter)
                        .WhereIf(input.MinCostAmountApprovedFilter != null, e => e.CostAmountApproved >= input.MinCostAmountApprovedFilter)
                        .WhereIf(input.MaxCostAmountApprovedFilter != null, e => e.CostAmountApproved <= input.MaxCostAmountApprovedFilter)
                        .WhereIf(input.MinCostAmountFilter != null, e => e.CostAmount >= input.MinCostAmountFilter)
                        .WhereIf(input.MaxCostAmountFilter != null, e => e.CostAmount <= input.MaxCostAmountFilter)
                        .WhereIf(input.MinCostEstimateFilter != null, e => e.CostEstimate >= input.MinCostEstimateFilter)
                        .WhereIf(input.MaxCostEstimateFilter != null, e => e.CostEstimate <= input.MaxCostEstimateFilter)
                        .WhereIf(input.MinCostVarianceFilter != null, e => e.CostVariance >= input.MinCostVarianceFilter)
                        .WhereIf(input.MaxCostVarianceFilter != null, e => e.CostVariance <= input.MaxCostVarianceFilter)
                        .WhereIf(input.MinCostActualReceivedFilter != null, e => e.CostActualReceived >= input.MinCostActualReceivedFilter)
                        .WhereIf(input.MaxCostActualReceivedFilter != null, e => e.CostActualReceived <= input.MaxCostActualReceivedFilter)
                        .WhereIf(input.MinCostEstimatedToComeFilter != null, e => e.CostEstimatedToCome >= input.MinCostEstimatedToComeFilter)
                        .WhereIf(input.MaxCostEstimatedToComeFilter != null, e => e.CostEstimatedToCome <= input.MaxCostEstimatedToComeFilter)
                        .WhereIf(input.MinSellAmountApprovedFilter != null, e => e.SellAmountApproved >= input.MinSellAmountApprovedFilter)
                        .WhereIf(input.MaxSellAmountApprovedFilter != null, e => e.SellAmountApproved <= input.MaxSellAmountApprovedFilter)
                        .WhereIf(input.MinSellAmountFilter != null, e => e.SellAmount >= input.MinSellAmountFilter)
                        .WhereIf(input.MaxSellAmountFilter != null, e => e.SellAmount <= input.MaxSellAmountFilter)
                        .WhereIf(input.MinSellEstimateFilter != null, e => e.SellEstimate >= input.MinSellEstimateFilter)
                        .WhereIf(input.MaxSellEstimateFilter != null, e => e.SellEstimate <= input.MaxSellEstimateFilter)
                        .WhereIf(input.MinSellVarianceFilter != null, e => e.SellVariance >= input.MinSellVarianceFilter)
                        .WhereIf(input.MaxSellVarianceFilter != null, e => e.SellVariance <= input.MaxSellVarianceFilter)
                        .WhereIf(input.MinMarginAmountFilter != null, e => e.MarginAmount >= input.MinMarginAmountFilter)
                        .WhereIf(input.MaxMarginAmountFilter != null, e => e.MarginAmount <= input.MaxMarginAmountFilter)
                        .WhereIf(input.MinMarginPercFilter != null, e => e.MarginPerc >= input.MinMarginPercFilter)
                        .WhereIf(input.MaxMarginPercFilter != null, e => e.MarginPerc <= input.MaxMarginPercFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectActionStatusFilter), e => e.ProjectActionFk != null && e.ProjectActionFk.Status == input.ProjectActionStatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);

            var query = (from o in filteredProjectCostDetails
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_projectActionRepository.GetAll() on o.ProjectActionId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         select new GetProjectCostDetailForViewDto()
                         {
                             ProjectCostDetail = new ProjectCostDetailDto
                             {
                                 Title = o.Title,
                                 Category = o.Category,
                                 CostAmountApproved = o.CostAmountApproved,
                                 CostAmount = o.CostAmount,
                                 CostEstimate = o.CostEstimate,
                                 CostVariance = o.CostVariance,
                                 CostActualReceived = o.CostActualReceived,
                                 CostEstimatedToCome = o.CostEstimatedToCome,
                                 SellAmountApproved = o.SellAmountApproved,
                                 SellAmount = o.SellAmount,
                                 SellEstimate = o.SellEstimate,
                                 SellVariance = o.SellVariance,
                                 MarginAmount = o.MarginAmount,
                                 MarginPerc = o.MarginPerc,
                                 Comment = o.Comment,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             ProjectActionStatus = s2 == null || s2.Status == null ? "" : s2.Status.ToString(),
                             ProjectExReviewDetailTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
                         });

            var projectCostDetailListDtos = await query.ToListAsync();

            return _projectCostDetailsExcelExporter.ExportToFile(projectCostDetailListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCostDetails)]
        public async Task<List<ProjectCostDetailProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectCostDetailProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCostDetails)]
        public async Task<List<ProjectCostDetailProjectActionLookupTableDto>> GetAllProjectActionForTableDropdown()
        {
            return await _lookup_projectActionRepository.GetAll()
                .Select(projectAction => new ProjectCostDetailProjectActionLookupTableDto
                {
                    Id = projectAction.Id,
                    DisplayName = projectAction == null || projectAction.Status == null ? "" : projectAction.Status.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectCostDetails)]
        public async Task<List<ProjectCostDetailProjectExReviewDetailLookupTableDto>> GetAllProjectExReviewDetailForTableDropdown()
        {
            return await _lookup_projectExReviewDetailRepository.GetAll()
                .Select(projectExReviewDetail => new ProjectCostDetailProjectExReviewDetailLookupTableDto
                {
                    Id = projectExReviewDetail.Id,
                    DisplayName = projectExReviewDetail == null || projectExReviewDetail.Title == null ? "" : projectExReviewDetail.Title.ToString()
                }).ToListAsync();
        }


        /// <summary>
        /// taskRefId can be: ProjectQuoteFormId, ProjectOACustCommAcceptanceId, ProjectExReviewDetailId
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="taskId"></param>
        /// <param name="taskRefId"></param>
        /// <returns></returns>
        public async Task<List<ProjectCostDetailDto>> GetCostDetails(long projectId, string taskId, long taskRefId = 0)
        {
            var results = new List<ProjectCostDetailDto>();
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    /// TODO: need to check this
                    var dbList = await _projectCostDetailRepository.GetAllIncluding(x => x.ProjectFk)
                        .Where(x => x.ProjectId == projectId && x.NodeTaskId.ToLower() == taskId.ToLower())
                        .WhereIf(taskId == CNodeTasks.PrepareQuote, x => x.ProjectQuoteFormId == (taskRefId == 0 ? null : taskRefId))
                        .WhereIf(taskId == CNodeTasks.PrepareRevisedQuote, x => x.ProjectQuoteFormId == (taskRefId == 0 ? null : taskRefId))
                        .WhereIf(taskId == CNodeTasks.SalesLeaderreviewofCustomerCommitment, x => x.ProjectOACustCommAcceptanceId == (taskRefId == 0 ? null : taskRefId))
                        .ToListAsync();

                    foreach (var o in dbList)
                    {
                        var res = new ProjectCostDetailDto
                        {
                            Title = o.Title,
                            Category = o.Category,
                            CostAmountApproved = o.CostAmountApproved,
                            CostAmount = o.CostAmount,
                            CostEstimate = o.CostEstimate,
                            CostVariance = o.CostVariance,
                            CostActualReceived = o.CostActualReceived,
                            CostEstimatedToCome = o.CostEstimatedToCome,
                            SellAmountApproved = o.SellAmountApproved,
                            SellAmount = o.SellAmount,
                            SellEstimate = o.SellEstimate,
                            SellVariance = o.SellVariance,
                            MarginAmount = o.MarginAmount,
                            MarginPerc = o.MarginPerc,
                            Comment = o.Comment,
                            ProjectId = o.ProjectId,
                            Id = o.Id,
                            ProjectActionId = o.ProjectActionId,
                            ProjectQuoteFormId = o.ProjectQuoteFormId,
                            ProjectOACustCommAcceptanceId = o.ProjectOACustCommAcceptanceId,
                            ProjectExReviewDetailId = o.ProjectExReviewDetailId,
                            NodeTaskId = o.NodeTaskId
                        };

                        results.Add(res);
                    }
                }
            }

            return results;
        }
        public async Task<List<ProjectCostDetailDto>> GetCostDetailsDeliveryBaseline(long projectId, string taskId, long taskRefId = 0)
        {
            var results = new List<ProjectCostDetailDto>();
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    /// TODO: need to check this
                    var dbList = await _projectCostDetailRepository.GetAllIncluding(x => x.ProjectFk)
                        .Where(x => x.ProjectId == projectId && x.NodeTaskId.ToLower() == taskId.ToLower())
                        .ToListAsync();

                    foreach (var o in dbList)
                    {
                        var res = new ProjectCostDetailDto
                        {
                            Title = o.Title,
                            Category = o.Category,
                            CostAmountApproved = o.CostAmountApproved,
                            CostAmount = o.CostAmount,
                            CostEstimate = (o.CostEstimate == null || o.CostEstimate == 0) ? o.CostAmount : o.CostEstimate,
                            CostVariance = o.CostEstimate - o.CostAmount,
                            SellAmount = o.SellAmount,
                            SellEstimate = (o.SellEstimate == null || o.SellEstimate == 0) ? o.SellAmount : o.SellEstimate,
                            SellVariance = o.SellEstimate - o.SellAmount,
                            MarginAmount = o.MarginAmount,
                            MarginPerc = o.MarginPerc,
                            Comment = o.Comment,
                            ProjectId = o.ProjectId,
                            Id = o.Id,
                            ProjectActionId = o.ProjectActionId,
                            ProjectQuoteFormId = o.ProjectQuoteFormId,
                            ProjectOACustCommAcceptanceId = o.ProjectOACustCommAcceptanceId,
                            ProjectExReviewDetailId = o.ProjectExReviewDetailId,
                            NodeTaskId = o.NodeTaskId,
                            CostAmountDR = o.CostAmount,
                            CostActualReceived = (o.CostActualReceived == null || o.CostActualReceived == 0) ? 0 : o.CostActualReceived,
                            CostEstimatedToCome = (o.CostEstimatedToCome == null || o.CostEstimatedToCome == 0) ? o.CostEstimate : o.CostEstimatedToCome,
                            RevisedCost = (o.RevisedCost == null || o.RevisedCost == 0) ? o.CostEstimate : o.CostActualReceived + o.CostEstimatedToCome,
                            CostVarianceDR = (o.RevisedCost == null || o.RevisedCost == 0) ? 0 : (o.RevisedCost - o.CostAmountDR),
                            SellAmountApproved = (o.SellAmountApproved == null || o.SellAmountApproved == 0) ? o.SellAmount : o.SellAmountApproved,
                            RevisedSell = (o.RevisedSell == null || o.RevisedSell == 0) ? o.SellAmount : o.RevisedSell,
                            PLForecastSell = (o.PLForecastSell == null || o.PLForecastSell == 0) ? o.SellAmount : o.PLForecastSell,
                            SellVarianceDR = (o.RevisedSell == null || o.RevisedSell == 0 || o.SellAmountApproved == 0 || o.SellAmountApproved == 0) ? 0 : (o.RevisedSell - o.SellAmountApproved),
                        };

                        results.Add(res);
                    }
                }
            }

            return results;
        }
        public async Task<List<ProjectCostDetailDto>> GetCostDetailsDeliveryReview(long projectId, string taskId, long taskRefId = 0)
        {
            var results = new List<ProjectCostDetailDto>();
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    /// TODO: need to check this
                    var dbList = await _projectCostDetailRepository.GetAllIncluding(x => x.ProjectFk)
                        .Where(x => x.ProjectId == projectId && x.NodeTaskId.ToLower() == taskId.ToLower())
                        .ToListAsync();

                    foreach (var o in dbList)
                    {
                        var res = new ProjectCostDetailDto
                        {
                            Title = o.Title,
                            Category = o.Category,
                            CostAmountApproved = o.CostAmountApproved,
                            CostAmount = o.CostAmount,
                            CostEstimate = (o.CostEstimate == null || o.CostEstimate == 0) ? o.CostAmount : o.CostEstimate,
                            SellAmount = o.SellAmount,
                            SellEstimate = (o.SellEstimate == null || o.SellEstimate == 0) ? o.SellAmount : o.SellEstimate,
                            CostAmountDR = o.CostAmount,
                            CostActualReceived = (o.CostActualReceived == null || o.CostActualReceived == 0) ? 0 : o.CostActualReceived,
                            CostEstimatedToCome = (o.CostEstimatedToCome == null || o.CostEstimatedToCome == 0) ? o.CostEstimate : o.CostEstimatedToCome,
                            RevisedCost = (o.RevisedCost == null || o.RevisedCost == 0) ? o.CostEstimate : o.CostActualReceived + o.CostEstimatedToCome,
                            CostVarianceDR = (o.RevisedCost == null || o.RevisedCost == 0) ? 0 : (o.RevisedCost - o.CostAmountDR),
                            SellAmountApproved = (o.SellAmountApproved == null || o.SellAmountApproved == 0) ? o.SellAmount : o.SellAmountApproved,
                            RevisedSell = (o.RevisedSell == null || o.RevisedSell == 0) ? o.SellAmount : o.RevisedSell,
                            PLForecastSell = (o.PLForecastSell == null || o.PLForecastSell == 0) ? o.SellAmount : o.PLForecastSell,
                            SellVarianceDR = (o.RevisedSell == null || o.RevisedSell == 0 || o.SellAmountApproved == 0 || o.SellAmountApproved == 0) ? 0 : (o.RevisedSell - o.SellAmountApproved),
                            Comment = o.Comment,
                            ProjectId = o.ProjectId,
                            Id = o.Id,
                            ProjectActionId = o.ProjectActionId,
                            ProjectQuoteFormId = o.ProjectQuoteFormId,
                            ProjectOACustCommAcceptanceId = o.ProjectOACustCommAcceptanceId,
                            ProjectExReviewDetailId = o.ProjectExReviewDetailId,
                            NodeTaskId = o.NodeTaskId
                        };

                        results.Add(res);
                    }
                }
            }

            return results;
        }
    }
}