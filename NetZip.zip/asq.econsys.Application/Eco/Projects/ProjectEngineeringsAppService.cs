﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.BusinessRules;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Flexi.Dtos;
using asq.econsys.Flexi;
using Abp.Events.Bus;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings)]
    public class ProjectEngineeringsAppService : econsysAppServiceBase, IProjectEngineeringsAppService
    {
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly IRepository<ProjectEngineering> _projectEngineeringRepository;
        private readonly IProjectEngineeringsExcelExporter _projectEngineeringsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<RuleElement, long> _lookup_ruleElementRepository;
        private readonly IRepository<RuleValue, long> _lookup_ruleValueRepository;
        private readonly IRepository<RuleFlag, string> _lookup_ruleFlagRepository;
        private readonly IRepository<RevenueRange, long> _lookup_revenueRangeRepository;
        private readonly IRepository<RuleType, string> _lookup_ruleTypeRepository;
        private readonly IRepository<RuleConfiguration, long> _ruleConfigurationRepository;
        private readonly IRepository<FlexiField, long> _flexiFieldRepository;
        public IEventBus EventBus { get; set; }

        public ProjectEngineeringsAppService(IUnitOfWorkManager unitOfWorkManager, IRepository<ProjectEngineering> projectEngineeringRepository, IProjectEngineeringsExcelExporter projectEngineeringsExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<RuleElement, long> lookup_ruleElementRepository, IRepository<RuleValue, long> lookup_ruleValueRepository, IRepository<RuleFlag, string> lookup_ruleFlagRepository, IRepository<RevenueRange, long> lookup_revenueRangeRepository, IRepository<RuleType, string> lookup_ruleTypeRepository, IRepository<RuleConfiguration, long> ruleConfigurationRepository, IRepository<FlexiField, long> flexiFieldRepository)
        {
            EventBus = NullEventBus.Instance;
            _unitOfWorkManager = unitOfWorkManager;

            _projectEngineeringRepository = projectEngineeringRepository;
            _projectEngineeringsExcelExporter = projectEngineeringsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_ruleElementRepository = lookup_ruleElementRepository;
            _lookup_ruleValueRepository = lookup_ruleValueRepository;
            _lookup_ruleFlagRepository = lookup_ruleFlagRepository;
            _lookup_revenueRangeRepository = lookup_revenueRangeRepository;
            _lookup_ruleTypeRepository = lookup_ruleTypeRepository;
            _ruleConfigurationRepository = ruleConfigurationRepository;
            _flexiFieldRepository = flexiFieldRepository;

        }

        public async Task<PagedResultDto<GetProjectEngineeringForViewDto>> GetAll(GetAllProjectEngineeringsInput input)
        {

            var filteredProjectEngineerings = _projectEngineeringRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.RuleElementFk)
                        .Include(e => e.RuleValueFk)
                        .Include(e => e.RuleFlagFk)
                        .Include(e => e.RevenueRangeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleElementTitleFilter), e => e.RuleElementFk != null && e.RuleElementFk.Title == input.RuleElementTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleValueTitleFilter), e => e.RuleValueFk != null && e.RuleValueFk.Title == input.RuleValueTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagTitleFilter), e => e.RuleFlagFk != null && e.RuleFlagFk.Title == input.RuleFlagTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevenueRangeTitleFilter), e => e.RevenueRangeFk != null && e.RevenueRangeFk.Title == input.RevenueRangeTitleFilter);

            var pagedAndFilteredProjectEngineerings = filteredProjectEngineerings
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectEngineerings = from o in pagedAndFilteredProjectEngineerings
                                      join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                      from s1 in j1.DefaultIfEmpty()

                                      join o2 in _lookup_ruleElementRepository.GetAll() on o.RuleElementId equals o2.Id into j2
                                      from s2 in j2.DefaultIfEmpty()

                                      join o3 in _lookup_ruleValueRepository.GetAll() on o.RuleValueId equals o3.Id into j3
                                      from s3 in j3.DefaultIfEmpty()

                                      join o4 in _lookup_ruleFlagRepository.GetAll() on o.RuleFlagId equals o4.Id into j4
                                      from s4 in j4.DefaultIfEmpty()

                                      join o5 in _lookup_revenueRangeRepository.GetAll() on o.RevenueRangeId equals o5.Id into j5
                                      from s5 in j5.DefaultIfEmpty()

                                      select new
                                      {

                                          Id = o.Id,
                                          o.ProjectId,

                                          ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                          RuleElementTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                                          RuleValueTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString(),
                                          RuleFlagTitle = s4 == null || s4.Title == null ? "" : s4.Title.ToString(),
                                          RevenueRangeTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString()
                                      };

            var totalCount = await filteredProjectEngineerings.CountAsync();

            var dbList = await projectEngineerings.ToListAsync();
            var results = new List<GetProjectEngineeringForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectEngineeringForViewDto()
                {
                    ProjectEngineering = new ProjectEngineeringDto
                    {

                        Id = o.Id,
                        ProjectId = o.ProjectId,

                    },
                    ProjectProjectName = o.ProjectProjectName,
                    RuleElementTitle = o.RuleElementTitle,
                    RuleValueTitle = o.RuleValueTitle,
                    RuleFlagTitle = o.RuleFlagTitle,
                    RevenueRangeTitle = o.RevenueRangeTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectEngineeringForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectEngineeringForViewDto> GetProjectEngineeringForView(int id)
        {
            var projectEngineering = await _projectEngineeringRepository.GetAsync(id);

            var output = new GetProjectEngineeringForViewDto { ProjectEngineering = ObjectMapper.Map<ProjectEngineeringDto>(projectEngineering) };

            if (output.ProjectEngineering.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectEngineering.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectEngineering.RuleElementId != null)
            {
                var _lookupRuleElement = await _lookup_ruleElementRepository.FirstOrDefaultAsync((long)output.ProjectEngineering.RuleElementId);
                output.RuleElementTitle = _lookupRuleElement?.Title?.ToString();
            }

            if (output.ProjectEngineering.RuleValueId != null)
            {
                var _lookupRuleValue = await _lookup_ruleValueRepository.FirstOrDefaultAsync((long)output.ProjectEngineering.RuleValueId);
                output.RuleValueTitle = _lookupRuleValue?.Title?.ToString();
            }

            if (output.ProjectEngineering.RuleFlagId != null)
            {
                var _lookupRuleFlag = await _lookup_ruleFlagRepository.FirstOrDefaultAsync((string)output.ProjectEngineering.RuleFlagId);
                output.RuleFlagTitle = _lookupRuleFlag?.Title?.ToString();
            }

            if (output.ProjectEngineering.RevenueRangeId != null)
            {
                var _lookupRevenueRange = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)output.ProjectEngineering.RevenueRangeId);
                output.RevenueRangeTitle = _lookupRevenueRange?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings_Edit)]
        public async Task<GetProjectEngineeringForEditOutput> GetProjectEngineeringForEdit(EntityDto input)
        {
            var projectEngineering = await _projectEngineeringRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectEngineeringForEditOutput { ProjectEngineering = ObjectMapper.Map<CreateOrEditProjectEngineeringDto>(projectEngineering) };

            if (output.ProjectEngineering.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectEngineering.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectEngineering.RuleElementId != null)
            {
                var _lookupRuleElement = await _lookup_ruleElementRepository.FirstOrDefaultAsync((long)output.ProjectEngineering.RuleElementId);
                output.RuleElementTitle = _lookupRuleElement?.Title?.ToString();
            }

            if (output.ProjectEngineering.RuleValueId != null)
            {
                var _lookupRuleValue = await _lookup_ruleValueRepository.FirstOrDefaultAsync((long)output.ProjectEngineering.RuleValueId);
                output.RuleValueTitle = _lookupRuleValue?.Title?.ToString();
            }

            if (output.ProjectEngineering.RuleFlagId != null)
            {
                var _lookupRuleFlag = await _lookup_ruleFlagRepository.FirstOrDefaultAsync((string)output.ProjectEngineering.RuleFlagId);
                output.RuleFlagTitle = _lookupRuleFlag?.Title?.ToString();
            }

            if (output.ProjectEngineering.RevenueRangeId != null)
            {
                var _lookupRevenueRange = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)output.ProjectEngineering.RevenueRangeId);
                output.RevenueRangeTitle = _lookupRevenueRange?.Title?.ToString();
            }

            return output;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit(IEnumerable<CreateOrEditProjectEngineeringDto> inputs)
        {
            List<GetProjectEngineeringForViewDto> projectEngineerings = new List<GetProjectEngineeringForViewDto>();
            await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        foreach (var input in inputs)
                        {
                            if(input.RuleElementId == null || input.RuleValueId == null)
                            {
                                continue;
                            }
                            /// TODO - check tenancy
                            if (input.Id == null)
                            {
                                var engineering = await Create(input);
                                var projectEngineering = new GetProjectEngineeringForViewDto { ProjectEngineering = ObjectMapper.Map<ProjectEngineeringDto>(engineering) };
                                //projectEngineering.RuleElementTitle = _lookup_ruleElementRepository.Get(engineering.RuleElementId).Title;
                                //projectEngineering.RuleValueTitle = _lookup_ruleValueRepository.Get(engineering.RuleValueId).Title;

                                var ruleElement = _lookup_ruleElementRepository
                                    .FirstOrDefault(x => x.Id == engineering.RuleElementId);// && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                                projectEngineering.RuleElementTitle = ruleElement == null ? null : ruleElement.Title;
                                var ruleValue = _lookup_ruleValueRepository
                                    .FirstOrDefault(x => x.Id == engineering.RuleValueId && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                                projectEngineering.RuleValueTitle = ruleValue == null ? null : ruleValue.Title;

                                projectEngineerings.Add(projectEngineering);
                            }
                            else
                            {

                                var engineering = await Update(input);
                                var projectEngineering = new GetProjectEngineeringForViewDto { ProjectEngineering = ObjectMapper.Map<ProjectEngineeringDto>(engineering) };
                                //projectEngineering.RuleElementTitle = _lookup_ruleElementRepository.Get(engineering.RuleElementId).Title;
                                //projectEngineering.RuleValueTitle = _lookup_ruleValueRepository.Get(engineering.RuleValueId).Title;
                                var ruleElement = _lookup_ruleElementRepository
                                    .FirstOrDefault(x => x.Id == engineering.RuleElementId);// && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                                projectEngineering.RuleElementTitle = ruleElement == null ? null : ruleElement.Title;
                                var ruleValue = _lookup_ruleValueRepository
                                    .FirstOrDefault(x => x.Id == engineering.RuleValueId && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                                projectEngineering.RuleValueTitle = ruleValue == null ? null : ruleValue.Title;

                                projectEngineerings.Add(projectEngineering);
                            }
                        }

                        var projectId = inputs.FirstOrDefault().ProjectId;
                        //var project = _lookup_projectRepository.FirstOrDefault(projectId);
                        await EventBus.TriggerAsync(new EditProjectEventData()
                        {
                            ProjectId = projectId,
                            StageId = CNodeStages.PreOrder,
                            TaskId = CNodeTasks.AddEngineering,
                            StatusId = CNodeStatuses.Save,
                            LoggedInUserId = (long)AbpSession.UserId
                        });
                    }
                }
            });

            var project = _lookup_projectRepository.FirstOrDefault(inputs.FirstOrDefault().ProjectId);
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.ProjectEngineerings = projectEngineerings;

            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings_Create)]
        protected virtual async Task<ProjectEngineering> Create(CreateOrEditProjectEngineeringDto input)
        {
            if (input.RuleValueId != null && input.RevenueRangeId != null)
            {
                var ruleConfig = this.GetRuleConfiguration(input.RuleElementId, (long)input.RuleValueId, (long)input.RevenueRangeId);
                if(ruleConfig != null && ruleConfig.Result != null)
                {
                    input.RuleFlagId = ruleConfig.Result.RuleConfiguration.RuleFlagId;
                }
            }
            var projectEngineering = ObjectMapper.Map<ProjectEngineering>(input);

            if (AbpSession.TenantId != null)
            {
                projectEngineering.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectEngineeringRepository.InsertAsync(projectEngineering);
            return projectEngineering;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings_Edit)]
        protected virtual async Task<ProjectEngineering> Update(CreateOrEditProjectEngineeringDto input)
        {
            if (input.RuleValueId != null && input.RevenueRangeId != null)
            {
                var ruleConfig = this.GetRuleConfiguration(input.RuleElementId, (long)input.RuleValueId, (long)input.RevenueRangeId);
                if(ruleConfig != null && ruleConfig.Result != null)
                {
                    input.RuleFlagId = ruleConfig.Result.RuleConfiguration.RuleFlagId;
                }
            }
            var projectEngineering = await _projectEngineeringRepository.FirstOrDefaultAsync((int)input.Id);
            ObjectMapper.Map(input, projectEngineering);

            return projectEngineering;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings_Delete)]
        public async Task Delete(EntityDto input)
        {
            await _projectEngineeringRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectEngineeringsToExcel(GetAllProjectEngineeringsForExcelInput input)
        {

            var filteredProjectEngineerings = _projectEngineeringRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.RuleElementFk)
                        .Include(e => e.RuleValueFk)
                        .Include(e => e.RuleFlagFk)
                        .Include(e => e.RevenueRangeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleElementTitleFilter), e => e.RuleElementFk != null && e.RuleElementFk.Title == input.RuleElementTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleValueTitleFilter), e => e.RuleValueFk != null && e.RuleValueFk.Title == input.RuleValueTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagTitleFilter), e => e.RuleFlagFk != null && e.RuleFlagFk.Title == input.RuleFlagTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevenueRangeTitleFilter), e => e.RevenueRangeFk != null && e.RevenueRangeFk.Title == input.RevenueRangeTitleFilter);

            var query = (from o in filteredProjectEngineerings
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_ruleElementRepository.GetAll() on o.RuleElementId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_ruleValueRepository.GetAll() on o.RuleValueId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         join o4 in _lookup_ruleFlagRepository.GetAll() on o.RuleFlagId equals o4.Id into j4
                         from s4 in j4.DefaultIfEmpty()

                         join o5 in _lookup_revenueRangeRepository.GetAll() on o.RevenueRangeId equals o5.Id into j5
                         from s5 in j5.DefaultIfEmpty()

                         select new GetProjectEngineeringForViewDto()
                         {
                             ProjectEngineering = new ProjectEngineeringDto
                             {
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             RuleElementTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                             RuleValueTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString(),
                             RuleFlagTitle = s4 == null || s4.Title == null ? "" : s4.Title.ToString(),
                             RevenueRangeTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString()
                         });

            var projectEngineeringListDtos = await query.ToListAsync();

            return _projectEngineeringsExcelExporter.ExportToFile(projectEngineeringListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings)]
        public async Task<List<ProjectEngineeringProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectEngineeringProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings)]
        public async Task<List<ProjectEngineeringRuleElementLookupTableDto>> GetAllRuleElementForTableDropdown()
        {
            return await _lookup_ruleElementRepository.GetAll()
                .Select(ruleElement => new ProjectEngineeringRuleElementLookupTableDto
                {
                    Id = ruleElement.Id,
                    DisplayName = ruleElement == null || ruleElement.Title == null ? "" : ruleElement.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings)]
        public async Task<List<ProjectEngineeringRuleValueLookupTableDto>> GetAllRuleValueForTableDropdown()
        {
            return await _lookup_ruleValueRepository.GetAll()
                .Select(ruleValue => new ProjectEngineeringRuleValueLookupTableDto
                {
                    Id = ruleValue.Id,
                    DisplayName = ruleValue == null || ruleValue.Title == null ? "" : ruleValue.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings)]
        public async Task<List<ProjectEngineeringRuleFlagLookupTableDto>> GetAllRuleFlagForTableDropdown()
        {
            return await _lookup_ruleFlagRepository.GetAll()
                .Select(ruleFlag => new ProjectEngineeringRuleFlagLookupTableDto
                {
                    Id = ruleFlag.Id,
                    DisplayName = ruleFlag == null || ruleFlag.Title == null ? "" : ruleFlag.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEngineerings)]
        public async Task<List<ProjectEngineeringRevenueRangeLookupTableDto>> GetAllRevenueRangeForTableDropdown()
        {
            return await _lookup_revenueRangeRepository.GetAll()
                .Select(revenueRange => new ProjectEngineeringRevenueRangeLookupTableDto
                {
                    Id = revenueRange.Id,
                    DisplayName = revenueRange == null || revenueRange.Title == null ? "" : revenueRange.Title.ToString()
                }).ToListAsync();
        }

        public async Task<AllProjectEngineeringDataDto> GetAllProjectEngineeringData()
        {
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var result = new AllProjectEngineeringDataDto();
                    var flags = await _lookup_ruleFlagRepository.GetAll()
                        .Select(x => new GetRuleFlagForViewDto()
                        {
                            RuleFlag = new RuleFlagDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                HexColor = x.HexColor
                            }
                        }).OrderBy(s => s.RuleFlag.DisplayOrder).ToListAsync();

                    result.RuleFlags = ObjectMapper.Map<List<GetRuleFlagForViewDto>>(flags);

                    //var types = _lookup_ruleTypeRepository.GetAll().ToList();
                    var types = await _lookup_ruleTypeRepository.GetAll()
                        .Select(x => new GetRuleTypeForViewDto()
                        {
                            RuleType = new RuleTypeDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                IsRangeSpecific = x.IsRangeSpecific,
                                OutputVariable = x.OutputVariable,
                                StatusDetailsVariable = x.StatusDetailsVariable
                            }
                        }).OrderBy(s => s.RuleType.DisplayOrder).ToListAsync();

                    result.RuleTypes = ObjectMapper.Map<List<GetRuleTypeForViewDto>>(types);

                    //var revenueRanges = _lookup_revenueRangeRepository.GetAll().ToList();
                    var revenueRanges = await _lookup_revenueRangeRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRevenueRangeForViewDto()
                        {
                            RevenueRange = new RevenueRangeDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                MinRange = x.MinRange,
                                MaxRange = x.MaxRange
                            }
                        }).OrderBy(s => s.RevenueRange.DisplayOrder).ToListAsync();

                    result.RevenueRanges = ObjectMapper.Map<List<GetRevenueRangeForViewDto>>(revenueRanges);

                    //var ruleElements = _lookup_ruleElementRepository.GetAll().ToList();
                    var ruleElements = await _lookup_ruleElementRepository.GetAll()
                        .Where(e => e.RuleTypeId == "engineering" && e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRuleElementForViewDto()
                        {
                            RuleElement = new RuleElementDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                RuleTypeId = x.RuleTypeId,
                                VariableName = x.VariableName
                            }
                        }).OrderBy(s => s.RuleElement.DisplayOrder).ToListAsync();

                    result.RuleElements = ObjectMapper.Map<List<GetRuleElementForViewDto>>(ruleElements);

                    //var ruleValue = _lookup_ruleValueRepository.GetAll().ToList();
                    var ruleValues = await _lookup_ruleValueRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetRuleValueForViewDto()
                        {
                            RuleValue = new RuleValueDto()
                            {
                                Id = x.Id,
                                Title = x.Title,
                                DisplayOrder = x.DisplayOrder,
                                RuleTypeId = x.RuleTypeId,
                                RuleElementId = x.RuleElementId,
                                IsRangeSpecific = x.IsRangeSpecific
                            }
                        }).OrderBy(s => s.RuleValue.DisplayOrder).ToListAsync();

                    result.RuleValues = ObjectMapper.Map<List<GetRuleValueForViewDto>>(ruleValues);

                    //var ruleValue = _lookup_ruleValueRepository.GetAll().ToList();
                    var ProjectEngineering = await _projectEngineeringRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .Select(x => new GetProjectEngineeringForViewDto()
                        {
                            ProjectEngineering = new ProjectEngineeringDto()
                            {
                                Id = x.Id,
                                RevenueRangeId = x.RevenueRangeId,
                                RuleElementId = x.RuleElementId,
                                RuleFlagId = x.RuleFlagId,
                                RuleValueId = x.RuleValueId,
                                ProjectId = x.ProjectId,

                            }
                        }).ToListAsync();

                    result.ProjectEngineering = ObjectMapper.Map<List<GetProjectEngineeringForViewDto>>(ProjectEngineering);

                    var ruleConfiguration = await _ruleConfigurationRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                       .Select(x => new GetRuleConfigurationForViewDto()
                       {
                           RuleConfiguration = new RuleConfigurationDto()
                           {
                               Id = x.Id,
                               RevenueRangeId = x.RevenueRangeId,
                               RuleElementId = x.RuleElementId,
                               RuleFlagId = x.RuleFlagId,
                               RuleValueId = x.RuleValueId,
                               OrganizationUnitId = x.OrganizationUnitId,


                           }
                       }).ToListAsync();

                    result.RuleConfigurations = ObjectMapper.Map<List<GetRuleConfigurationForViewDto>>(ruleConfiguration);

                    var flexiFields = await _flexiFieldRepository.GetAll()
                        .Where(e => e.FlexiSectionId == "project-engineering" && e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                      .Select(x => new GetFlexiFieldForViewDto()
                      {
                          FlexiField = new FlexiFieldDto()
                          {
                              Id = x.Id,
                              FlexiSectionId = x.FlexiSectionId,
                              Code = x.Code,
                              DBType = x.DBType,
                              DisplayName = x.DisplayName,
                              FieldType = x.FieldType,
                              HTMLInputType = x.HTMLInputType,
                              HTMLType = x.HTMLType,
                              IsEnabled = x.IsEnabled,
                              SortOrder = x.SortOrder,
                              Validations = x.Validations,
                              MetaData = x.MetaData,
                          }
                      }).ToListAsync();

                    result.FlexiFields = ObjectMapper.Map<List<GetFlexiFieldForViewDto>>(flexiFields);

                    return result;
                }
            }


            return null;
        }

        public async Task<GetRuleConfigurationForViewDto> GetRuleConfiguration(long ruleElementId, long ruleValueId, long? revenueRangeId)
        {
            var ruleConfiguration = await _ruleConfigurationRepository.GetAll()
               .Select(x => new GetRuleConfigurationForViewDto()
               {
                   RuleConfiguration = new RuleConfigurationDto()
                   {
                       Id = x.Id,
                       RevenueRangeId = x.RevenueRangeId,
                       RuleElementId = x.RuleElementId,
                       RuleFlagId = x.RuleFlagId,
                       RuleValueId = x.RuleValueId,
                       OrganizationUnitId = x.OrganizationUnitId,
                   }
               }).Where(x => x.RuleConfiguration.RuleElementId == ruleElementId && x.RuleConfiguration.RuleValueId == ruleValueId && x.RuleConfiguration.RevenueRangeId == revenueRangeId).ToListAsync();

            return ruleConfiguration != null && ruleConfiguration.Count > 0 ? ruleConfiguration[0] : null;
        }

    }
}