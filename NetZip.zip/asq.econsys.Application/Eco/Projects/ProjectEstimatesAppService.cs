﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.BusinessRules;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.BusinessRules.Dtos;
using Abp.Events.Bus;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectEstimates)]
    public class ProjectEstimatesAppService : econsysAppServiceBase, IProjectEstimatesAppService
    {
        private readonly IRepository<ProjectEstimate, long> _projectEstimateRepository;
        private readonly IProjectEstimatesExcelExporter _projectEstimatesExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<RevenueRange, long> _lookup_revenueRangeRepository;
        public IEventBus EventBus { get; set; }

        public ProjectEstimatesAppService(IRepository<ProjectEstimate, long> projectEstimateRepository, IProjectEstimatesExcelExporter projectEstimatesExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<RevenueRange, long> lookup_revenueRangeRepository)
        {
            EventBus = NullEventBus.Instance;
            _projectEstimateRepository = projectEstimateRepository;
            _projectEstimatesExcelExporter = projectEstimatesExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_revenueRangeRepository = lookup_revenueRangeRepository;

        }

        public async Task<PagedResultDto<GetProjectEstimateForViewDto>> GetAll(GetAllProjectEstimatesInput input)
        {

            var filteredProjectEstimates = _projectEstimateRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.RevenueRangeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Points.Contains(input.Filter) || e.ProposedSurvey.Contains(input.Filter))
                        .WhereIf(input.MinBidStartDateFilter != null, e => e.BidStartDate >= input.MinBidStartDateFilter)
                        .WhereIf(input.MaxBidStartDateFilter != null, e => e.BidStartDate <= input.MaxBidStartDateFilter)
                        .WhereIf(input.MinBidEndDateFilter != null, e => e.BidEndDate >= input.MinBidEndDateFilter)
                        .WhereIf(input.MaxBidEndDateFilter != null, e => e.BidEndDate <= input.MaxBidEndDateFilter)
                        .WhereIf(input.MinBidWeeksFilter != null, e => e.BidWeeks >= input.MinBidWeeksFilter)
                        .WhereIf(input.MaxBidWeeksFilter != null, e => e.BidWeeks <= input.MaxBidWeeksFilter)
                        //.WhereIf(input.RFIDeadlineFilter.HasValue && input.RFIDeadlineFilter > -1, e => (input.RFIDeadlineFilter == 1 && e.RFIDeadline) || (input.RFIDeadlineFilter == 0 && !e.RFIDeadline))
                        .WhereIf(input.MinRFIDeadlineDateFilter != null, e => e.RFIDeadlineDate >= input.MinRFIDeadlineDateFilter)
                        .WhereIf(input.MaxRFIDeadlineDateFilter != null, e => e.RFIDeadlineDate <= input.MaxRFIDeadlineDateFilter)
                        .WhereIf(input.MinAnticipatedOrderDateFilter != null, e => e.AnticipatedOrderDate >= input.MinAnticipatedOrderDateFilter)
                        .WhereIf(input.MaxAnticipatedOrderDateFilter != null, e => e.AnticipatedOrderDate <= input.MaxAnticipatedOrderDateFilter)
                        .WhereIf(input.MinProjectStartDateFilter != null, e => e.ProjectStartDate >= input.MinProjectStartDateFilter)
                        .WhereIf(input.MaxProjectStartDateFilter != null, e => e.ProjectStartDate <= input.MaxProjectStartDateFilter)
                        .WhereIf(input.MinProjectEndDateFilter != null, e => e.ProjectEndDate >= input.MinProjectEndDateFilter)
                        .WhereIf(input.MaxProjectEndDateFilter != null, e => e.ProjectEndDate <= input.MaxProjectEndDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PointsFilter), e => e.Points == input.PointsFilter)
                        //.WhereIf(input.SurveryReqFilter.HasValue && input.SurveryReqFilter > -1, e => (input.SurveryReqFilter == 1 && e.SurveryReq) || (input.SurveryReqFilter == 0 && !e.SurveryReq))
                        //.WhereIf(input.ExplicitSurveyReqmntsFilter.HasValue && input.ExplicitSurveyReqmntsFilter > -1, e => (input.ExplicitSurveyReqmntsFilter == 1 && e.ExplicitSurveyReqmnts) || (input.ExplicitSurveyReqmntsFilter == 0 && !e.ExplicitSurveyReqmnts))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProposedSurveyFilter), e => e.ProposedSurvey == input.ProposedSurveyFilter)
                        .WhereIf(input.MinProjectWeeksFilter != null, e => e.ProjectWeeks >= input.MinProjectWeeksFilter)
                        .WhereIf(input.MaxProjectWeeksFilter != null, e => e.ProjectWeeks <= input.MaxProjectWeeksFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevenueRangeTitleFilter), e => e.RevenueRangeFk != null && e.RevenueRangeFk.Title == input.RevenueRangeTitleFilter);

            var pagedAndFilteredProjectEstimates = filteredProjectEstimates
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectEstimates = from o in pagedAndFilteredProjectEstimates
                                   join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                   from s1 in j1.DefaultIfEmpty()

                                   join o2 in _lookup_revenueRangeRepository.GetAll() on o.RevenueRangeId equals o2.Id into j2
                                   from s2 in j2.DefaultIfEmpty()

                                   select new
                                   {

                                       o.BidStartDate,
                                       o.BidEndDate,
                                       o.BidWeeks,
                                       o.RFIDeadline,
                                       o.RFIDeadlineDate,
                                       o.AnticipatedOrderDate,
                                       o.ProjectStartDate,
                                       o.ProjectEndDate,
                                       o.Points,
                                       o.SurveryReq,
                                       o.ExplicitSurveyReqmnts,
                                       o.ProposedSurvey,
                                       o.ProjectWeeks,
                                       Id = o.Id,
                                       ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                       RevenueRangeTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
                                   };

            var totalCount = await filteredProjectEstimates.CountAsync();

            var dbList = await projectEstimates.ToListAsync();
            var results = new List<GetProjectEstimateForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectEstimateForViewDto()
                {
                    ProjectEstimate = new ProjectEstimateDto
                    {

                        BidStartDate = o.BidStartDate,
                        BidEndDate = o.BidEndDate,
                        BidWeeks = o.BidWeeks,
                        RFIDeadline = o.RFIDeadline,
                        RFIDeadlineDate = o.RFIDeadlineDate,
                        AnticipatedOrderDate = o.AnticipatedOrderDate,
                        ProjectStartDate = o.ProjectStartDate,
                        ProjectEndDate = o.ProjectEndDate,
                        Points = o.Points,
                        SurveryReq = o.SurveryReq,
                        ExplicitSurveyReqmnts = o.ExplicitSurveyReqmnts,
                        ProposedSurvey = o.ProposedSurvey,
                        ProjectWeeks = o.ProjectWeeks,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    RevenueRangeTitle = o.RevenueRangeTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectEstimateForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectEstimateForViewDto> GetProjectEstimateForView(long id)
        {
            var projectEstimate = await _projectEstimateRepository.GetAsync(id);

            var output = new GetProjectEstimateForViewDto { ProjectEstimate = ObjectMapper.Map<ProjectEstimateDto>(projectEstimate) };

            if (output.ProjectEstimate.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectEstimate.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectEstimate.RevenueRangeId != null)
            {
                var _lookupRevenueRange = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)output.ProjectEstimate.RevenueRangeId);
                output.RevenueRangeTitle = _lookupRevenueRange?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEstimates_Edit)]
        public async Task<GetProjectEstimateForEditOutput> GetProjectEstimateForEdit(EntityDto<long> input)
        {
            //var projectEstimate = await _projectEstimateRepository.FirstOrDefaultAsync(input.Id);
            var projectEstimate = await _projectEstimateRepository.GetAllIncluding(x => x.ProjectFk).Where(x => x.ProjectId == input.Id).FirstOrDefaultAsync();

            var output = new GetProjectEstimateForEditOutput { ProjectEstimate = ObjectMapper.Map<CreateOrEditProjectEstimateDto>(projectEstimate) };

            if (output.ProjectEstimate != null && output.ProjectEstimate.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectEstimate.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectEstimate != null && output.ProjectEstimate.RevenueRangeId != null)
            {
                var _lookupRevenueRange = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)output.ProjectEstimate.RevenueRangeId);
                output.RevenueRangeTitle = _lookupRevenueRange?.Title?.ToString();
            }

            return output;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit(CreateOrEditProjectEstimateDto input)
        {
            var estimateDetails = new GetProjectEstimateForViewDto();

            if (input.Id == null)
            {
                estimateDetails = await Create(input);
            }
            else
            {
                estimateDetails = await Update(input);
            }
            var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId.Value);

            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                ProjectId = input.ProjectId.Value,
                StageId = CNodeStages.PreOrder,
                TaskId = CNodeTasks.AddEstimated,
                StatusId = CNodeStatuses.Save,
                Project = project,
                LoggedInUserId = (long)AbpSession.UserId
            });

            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);

            if (estimateDetails.ProjectEstimate.RevenueRangeId != null)
            {
                var _lookupRevenue = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)estimateDetails.ProjectEstimate.RevenueRangeId);
                estimateDetails.RevenueDetails = ObjectMapper.Map<RevenueRangeDto>(_lookupRevenue);
            }
            result.ProjectEstimate = estimateDetails;

            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEstimates_Create)]
        protected virtual async Task<GetProjectEstimateForViewDto> Create(CreateOrEditProjectEstimateDto input)
        {
            var projectEstimate = ObjectMapper.Map<ProjectEstimate>(input);

            if (AbpSession.TenantId != null)
            {
                projectEstimate.TenantId = (int?)AbpSession.TenantId;
            }
            var estimateId = _projectEstimateRepository.InsertAndGetId(projectEstimate);
            var output = new GetProjectEstimateForViewDto { ProjectEstimate = ObjectMapper.Map<ProjectEstimateDto>(_projectEstimateRepository.Get(estimateId)) };
            
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEstimates_Edit)]
        protected virtual async Task<GetProjectEstimateForViewDto> Update(CreateOrEditProjectEstimateDto input)
        {
            var projectEstimate = await _projectEstimateRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectEstimate);
            return new GetProjectEstimateForViewDto { ProjectEstimate = ObjectMapper.Map<ProjectEstimateDto>(_projectEstimateRepository.Get((long)input.Id)) };
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEstimates_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectEstimateRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectEstimatesToExcel(GetAllProjectEstimatesForExcelInput input)
        {

            var filteredProjectEstimates = _projectEstimateRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.RevenueRangeFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Points.Contains(input.Filter) || e.ProposedSurvey.Contains(input.Filter))
                        .WhereIf(input.MinBidStartDateFilter != null, e => e.BidStartDate >= input.MinBidStartDateFilter)
                        .WhereIf(input.MaxBidStartDateFilter != null, e => e.BidStartDate <= input.MaxBidStartDateFilter)
                        .WhereIf(input.MinBidEndDateFilter != null, e => e.BidEndDate >= input.MinBidEndDateFilter)
                        .WhereIf(input.MaxBidEndDateFilter != null, e => e.BidEndDate <= input.MaxBidEndDateFilter)
                        .WhereIf(input.MinBidWeeksFilter != null, e => e.BidWeeks >= input.MinBidWeeksFilter)
                        .WhereIf(input.MaxBidWeeksFilter != null, e => e.BidWeeks <= input.MaxBidWeeksFilter)
                        //.WhereIf(input.RFIDeadlineFilter.HasValue && input.RFIDeadlineFilter > -1, e => (input.RFIDeadlineFilter == 1 && e.RFIDeadline) || (input.RFIDeadlineFilter == 0 && !e.RFIDeadline))
                        .WhereIf(input.MinRFIDeadlineDateFilter != null, e => e.RFIDeadlineDate >= input.MinRFIDeadlineDateFilter)
                        .WhereIf(input.MaxRFIDeadlineDateFilter != null, e => e.RFIDeadlineDate <= input.MaxRFIDeadlineDateFilter)
                        .WhereIf(input.MinAnticipatedOrderDateFilter != null, e => e.AnticipatedOrderDate >= input.MinAnticipatedOrderDateFilter)
                        .WhereIf(input.MaxAnticipatedOrderDateFilter != null, e => e.AnticipatedOrderDate <= input.MaxAnticipatedOrderDateFilter)
                        .WhereIf(input.MinProjectStartDateFilter != null, e => e.ProjectStartDate >= input.MinProjectStartDateFilter)
                        .WhereIf(input.MaxProjectStartDateFilter != null, e => e.ProjectStartDate <= input.MaxProjectStartDateFilter)
                        .WhereIf(input.MinProjectEndDateFilter != null, e => e.ProjectEndDate >= input.MinProjectEndDateFilter)
                        .WhereIf(input.MaxProjectEndDateFilter != null, e => e.ProjectEndDate <= input.MaxProjectEndDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PointsFilter), e => e.Points == input.PointsFilter)
                        //.WhereIf(input.SurveryReqFilter.HasValue && input.SurveryReqFilter > -1, e => (input.SurveryReqFilter == 1 && e.SurveryReq) || (input.SurveryReqFilter == 0 && !e.SurveryReq))
                        //.WhereIf(input.ExplicitSurveyReqmntsFilter.HasValue && input.ExplicitSurveyReqmntsFilter > -1, e => (input.ExplicitSurveyReqmntsFilter == 1 && e.ExplicitSurveyReqmnts) || (input.ExplicitSurveyReqmntsFilter == 0 && !e.ExplicitSurveyReqmnts))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProposedSurveyFilter), e => e.ProposedSurvey == input.ProposedSurveyFilter)
                        .WhereIf(input.MinProjectWeeksFilter != null, e => e.ProjectWeeks >= input.MinProjectWeeksFilter)
                        .WhereIf(input.MaxProjectWeeksFilter != null, e => e.ProjectWeeks <= input.MaxProjectWeeksFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevenueRangeTitleFilter), e => e.RevenueRangeFk != null && e.RevenueRangeFk.Title == input.RevenueRangeTitleFilter);

            var query = (from o in filteredProjectEstimates
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_revenueRangeRepository.GetAll() on o.RevenueRangeId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         select new GetProjectEstimateForViewDto()
                         {
                             ProjectEstimate = new ProjectEstimateDto
                             {
                                 BidStartDate = o.BidStartDate,
                                 BidEndDate = o.BidEndDate,
                                 BidWeeks = o.BidWeeks,
                                 RFIDeadline = o.RFIDeadline,
                                 RFIDeadlineDate = o.RFIDeadlineDate,
                                 AnticipatedOrderDate = o.AnticipatedOrderDate,
                                 ProjectStartDate = o.ProjectStartDate,
                                 ProjectEndDate = o.ProjectEndDate,
                                 Points = o.Points,
                                 SurveryReq = o.SurveryReq,
                                 ExplicitSurveyReqmnts = o.ExplicitSurveyReqmnts,
                                 ProposedSurvey = o.ProposedSurvey,
                                 ProjectWeeks = o.ProjectWeeks,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             RevenueRangeTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
                         });

            var projectEstimateListDtos = await query.ToListAsync();

            return _projectEstimatesExcelExporter.ExportToFile(projectEstimateListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEstimates)]
        public async Task<List<ProjectEstimateProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectEstimateProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectEstimates)]
        public async Task<List<ProjectEstimateRevenueRangeLookupTableDto>> GetAllRevenueRangeForTableDropdown()
        {
            return await _lookup_revenueRangeRepository.GetAll()
                .Select(revenueRange => new ProjectEstimateRevenueRangeLookupTableDto
                {
                    Id = revenueRange.Id,
                    DisplayName = revenueRange == null || revenueRange.Title == null ? "" : revenueRange.Title.ToString()
                }).ToListAsync();
        }

    }
}