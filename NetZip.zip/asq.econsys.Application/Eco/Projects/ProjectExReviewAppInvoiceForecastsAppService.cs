﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectExReviewAppInvoiceForecasts)]
    public class ProjectExReviewAppInvoiceForecastsAppService : econsysAppServiceBase, IProjectExReviewAppInvoiceForecastsAppService
    {
        private readonly IRepository<ProjectExReviewAppInvoiceForecast, long> _projectExReviewAppInvoiceForecastRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectExReviewDetail, long> _lookup_projectExReviewDetailRepository;
        private readonly IRepository<ProjectExReview, long> _projectExReviewRepository;
        public ProjectExReviewAppInvoiceForecastsAppService(IRepository<ProjectExReviewAppInvoiceForecast, long> projectExReviewAppInvoiceForecastRepository, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectExReviewDetail, long> lookup_projectExReviewDetailRepository, IRepository<ProjectExReview, long> projectExReviewRepository)
        {
            _projectExReviewAppInvoiceForecastRepository = projectExReviewAppInvoiceForecastRepository;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectExReviewDetailRepository = lookup_projectExReviewDetailRepository;
            _projectExReviewRepository = projectExReviewRepository;
        }

        public async Task<PagedResultDto<GetProjectExReviewAppInvoiceForecastForViewDto>> GetAll(GetAllProjectExReviewAppInvoiceForecastsInput input)
        {

            var filteredProjectExReviewAppInvoiceForecasts = _projectExReviewAppInvoiceForecastRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Category.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CategoryFilter), e => e.Category == input.CategoryFilter)
                        .WhereIf(input.MinSubmissionDateFilter != null, e => e.SubmissionDate >= input.MinSubmissionDateFilter)
                        .WhereIf(input.MaxSubmissionDateFilter != null, e => e.SubmissionDate <= input.MaxSubmissionDateFilter)
                        .WhereIf(input.MinFinalPaymentDateFilter != null, e => e.FinalPaymentDate >= input.MinFinalPaymentDateFilter)
                        .WhereIf(input.MaxFinalPaymentDateFilter != null, e => e.FinalPaymentDate <= input.MaxFinalPaymentDateFilter)
                        .WhereIf(input.MinContractWorksFilter != null, e => e.ContractWorks >= input.MinContractWorksFilter)
                        .WhereIf(input.MaxContractWorksFilter != null, e => e.ContractWorks <= input.MaxContractWorksFilter)
                        .WhereIf(input.MinRemainingFilter != null, e => e.Remaining >= input.MinRemainingFilter)
                        .WhereIf(input.MaxRemainingFilter != null, e => e.Remaining <= input.MaxRemainingFilter)
                        .WhereIf(input.MinVariationFilter != null, e => e.Variation >= input.MinVariationFilter)
                        .WhereIf(input.MaxVariationFilter != null, e => e.Variation <= input.MaxVariationFilter)
                        .WhereIf(input.MinClaimFilter != null, e => e.Claim >= input.MinClaimFilter)
                        .WhereIf(input.MaxClaimFilter != null, e => e.Claim <= input.MaxClaimFilter)
                        .WhereIf(input.MinTotalFilter != null, e => e.Total >= input.MinTotalFilter)
                        .WhereIf(input.MaxTotalFilter != null, e => e.Total <= input.MaxTotalFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        //.WhereIf(!string.IsNullOrWhiteSpace(input.ReviewTypeFilter), e => e.ReviewType == input.ReviewTypeFilter)
                        .WhereIf(input.ProjectId != 0, e => e.ProjectId != 0 && e.ProjectId == input.ProjectId)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter).Where(x => x.ProjectExReviewDetailId == input.ProjectExReviewDetailId);
            if (filteredProjectExReviewAppInvoiceForecasts.Count() == 0 && input.ReviewTypeFilter == "delivery")
            {
                filteredProjectExReviewAppInvoiceForecasts = _projectExReviewAppInvoiceForecastRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Category.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CategoryFilter), e => e.Category == input.CategoryFilter)
                        .WhereIf(input.MinSubmissionDateFilter != null, e => e.SubmissionDate >= input.MinSubmissionDateFilter)
                        .WhereIf(input.MaxSubmissionDateFilter != null, e => e.SubmissionDate <= input.MaxSubmissionDateFilter)
                        .WhereIf(input.MinFinalPaymentDateFilter != null, e => e.FinalPaymentDate >= input.MinFinalPaymentDateFilter)
                        .WhereIf(input.MaxFinalPaymentDateFilter != null, e => e.FinalPaymentDate <= input.MaxFinalPaymentDateFilter)
                        .WhereIf(input.MinContractWorksFilter != null, e => e.ContractWorks >= input.MinContractWorksFilter)
                        .WhereIf(input.MaxContractWorksFilter != null, e => e.ContractWorks <= input.MaxContractWorksFilter)
                        .WhereIf(input.MinRemainingFilter != null, e => e.Remaining >= input.MinRemainingFilter)
                        .WhereIf(input.MaxRemainingFilter != null, e => e.Remaining <= input.MaxRemainingFilter)
                        .WhereIf(input.MinVariationFilter != null, e => e.Variation >= input.MinVariationFilter)
                        .WhereIf(input.MaxVariationFilter != null, e => e.Variation <= input.MaxVariationFilter)
                        .WhereIf(input.MinClaimFilter != null, e => e.Claim >= input.MinClaimFilter)
                        .WhereIf(input.MaxClaimFilter != null, e => e.Claim <= input.MaxClaimFilter)
                        .WhereIf(input.MinTotalFilter != null, e => e.Total >= input.MinTotalFilter)
                        .WhereIf(input.MaxTotalFilter != null, e => e.Total <= input.MaxTotalFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        //.WhereIf(!string.IsNullOrWhiteSpace(input.ReviewTypeFilter), e => e.ReviewType == input.ReviewTypeFilter)
                        .WhereIf(input.ProjectId != 0, e => e.ProjectId != 0 && e.ProjectId == input.ProjectId)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);
            }
            var pagedAndFilteredProjectExReviewAppInvoiceForecasts = filteredProjectExReviewAppInvoiceForecasts
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectExReviewAppInvoiceForecasts = from o in pagedAndFilteredProjectExReviewAppInvoiceForecasts
                                                     join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                                     from s1 in j1.DefaultIfEmpty()

                                                     join o2 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o2.Id into j2
                                                     from s2 in j2.DefaultIfEmpty()

                                                     select new
                                                     {

                                                         o.Category,
                                                         o.SubmissionDate,
                                                         o.FinalPaymentDate,
                                                         o.ContractWorks,
                                                         o.Remaining,
                                                         o.Variation,
                                                         o.Claim,
                                                         o.Total,
                                                         o.Comment,
                                                         o.ProjectId,
                                                         o.ProjectExReviewDetailId,
                                                         Id = o.Id,
                                                         ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                                         ProjectExReviewDetailTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString(),
                                                         o.Status,
                                                         o.ReviewType,
                                                         o.GrossCertified
                                                     };

            var totalCount = await filteredProjectExReviewAppInvoiceForecasts.CountAsync();

            var dbList = await projectExReviewAppInvoiceForecasts.ToListAsync();
            var results = new List<GetProjectExReviewAppInvoiceForecastForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectExReviewAppInvoiceForecastForViewDto()
                {
                    ProjectExReviewAppInvoiceForecast = new ProjectExReviewAppInvoiceForecastDto
                    {

                        Category = o.Category,
                        SubmissionDate = o.SubmissionDate,
                        FinalPaymentDate = o.FinalPaymentDate,
                        ContractWorks = o.ContractWorks,
                        Remaining = o.Remaining,
                        Variation = o.Variation,
                        Claim = o.Claim,
                        Total = o.Total,
                        Comment = o.Comment,
                        ProjectId = o.ProjectId,
                        ReviewType = o.ReviewType,
                        Status = o.Status != null ? o.Status : "Forecast",
                        GrossCertified = o.GrossCertified,
                        ProjectExReviewDetailId = o.ProjectExReviewDetailId,
                        Id = o.Id,

                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectExReviewDetailTitle = o.ProjectExReviewDetailTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectExReviewAppInvoiceForecastForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectExReviewAppInvoiceForecastForViewDto> GetProjectExReviewAppInvoiceForecastForView(long id)
        {
            var projectExReviewAppInvoiceForecast = await _projectExReviewAppInvoiceForecastRepository.GetAsync(id);

            var output = new GetProjectExReviewAppInvoiceForecastForViewDto { ProjectExReviewAppInvoiceForecast = ObjectMapper.Map<ProjectExReviewAppInvoiceForecastDto>(projectExReviewAppInvoiceForecast) };

            if (output.ProjectExReviewAppInvoiceForecast.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectExReviewAppInvoiceForecast.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectExReviewAppInvoiceForecast.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectExReviewAppInvoiceForecast.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewAppInvoiceForecasts_Edit)]
        public async Task<GetProjectExReviewAppInvoiceForecastForEditOutput> GetProjectExReviewAppInvoiceForecastForEdit(EntityDto<long> input)
        {
            var projectExReviewAppInvoiceForecast = await _projectExReviewAppInvoiceForecastRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectExReviewAppInvoiceForecastForEditOutput { ProjectExReviewAppInvoiceForecast = ObjectMapper.Map<CreateOrEditProjectExReviewAppInvoiceForecastDto>(projectExReviewAppInvoiceForecast) };

            if (output.ProjectExReviewAppInvoiceForecast.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectExReviewAppInvoiceForecast.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectExReviewAppInvoiceForecast.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectExReviewAppInvoiceForecast.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectExReviewAppInvoiceForecastDto input)
        {
            var isDelivery = _projectExReviewAppInvoiceForecastRepository.FirstOrDefault(x=>x.ReviewType == "delivery" && x.ProjectId == input.ProjectId);
            if(isDelivery == null)
            {
                input.Id = null;
            }
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewAppInvoiceForecasts_Create)]
        protected virtual async Task Create(CreateOrEditProjectExReviewAppInvoiceForecastDto input)
        {
            var projectExReviewAppInvoiceForecast = ObjectMapper.Map<ProjectExReviewAppInvoiceForecast>(input);
            var projectExReviewAppInvoiceDelivery = ObjectMapper.Map<ProjectExReviewAppInvoiceForecast>(input);
            if (AbpSession.TenantId != null)
            {
                projectExReviewAppInvoiceForecast.TenantId = (int?)AbpSession.TenantId;
            }

            var project = await _lookup_projectRepository.FirstOrDefaultAsync((long)input.ProjectId);
            var projectExReview = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync(x => x.ProjectExReviewId == project.ProjectExReviewId && x.ReviewType == input.ReviewType);

            projectExReviewAppInvoiceForecast.ProjectExReviewDetailId = projectExReview.Id;
            await _projectExReviewAppInvoiceForecastRepository.InsertAsync(projectExReviewAppInvoiceForecast);
            if (input.ReviewType == "baseline")
            {
                projectExReviewAppInvoiceDelivery.ReviewType = "delivery";
                await CreateDeliveryRecord(projectExReviewAppInvoiceDelivery);
            }
        }
        protected virtual async Task CreateDeliveryRecord(ProjectExReviewAppInvoiceForecast input)
        {
            if (AbpSession.TenantId != null)
            {
                input.TenantId = (int?)AbpSession.TenantId;
            }
            var project = await _lookup_projectRepository.FirstOrDefaultAsync((long)input.ProjectId);
            var projectExReview = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync(x => x.ProjectExReviewId == project.ProjectExReviewId && x.ReviewType == "delivery");

            input.ProjectExReviewDetailId = projectExReview.Id;
            await _projectExReviewAppInvoiceForecastRepository.InsertAsync(input);

        }
        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewAppInvoiceForecasts_Edit)]
        protected virtual async Task Update(CreateOrEditProjectExReviewAppInvoiceForecastDto input)
        {
            var projectExReviewAppInvoiceForecast = await _projectExReviewAppInvoiceForecastRepository.FirstOrDefaultAsync((long)input.Id);
            var projectExReviewAppInvoiceReview = await _projectExReviewAppInvoiceForecastRepository.FirstOrDefaultAsync((long)input.Id+1);
            ObjectMapper.Map(input, projectExReviewAppInvoiceForecast);
            if (input.ReviewType == "baseline")
            {
                try
                {
                    projectExReviewAppInvoiceReview.Category = projectExReviewAppInvoiceForecast.Category;
                    projectExReviewAppInvoiceReview.SubmissionDate = projectExReviewAppInvoiceForecast.SubmissionDate;
                    projectExReviewAppInvoiceReview.FinalPaymentDate = projectExReviewAppInvoiceForecast.FinalPaymentDate;
                    projectExReviewAppInvoiceReview.ContractWorks = projectExReviewAppInvoiceForecast.ContractWorks;
                    projectExReviewAppInvoiceReview.Remaining = projectExReviewAppInvoiceForecast.Remaining;
                    projectExReviewAppInvoiceReview.Variation = projectExReviewAppInvoiceForecast.Variation;
                    projectExReviewAppInvoiceReview.Claim = projectExReviewAppInvoiceForecast.Claim;
                    projectExReviewAppInvoiceReview.Total = projectExReviewAppInvoiceForecast.Total;
                    projectExReviewAppInvoiceReview.Comment = projectExReviewAppInvoiceForecast.Comment;
                    projectExReviewAppInvoiceReview.Status = projectExReviewAppInvoiceForecast.Status;

                    await _projectExReviewAppInvoiceForecastRepository.UpdateAsync(projectExReviewAppInvoiceReview);
                }
                catch (Exception e)
                {

                    throw;
                }
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewAppInvoiceForecasts_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectExReviewAppInvoiceForecastRepository.DeleteAsync(input.Id);
            await _projectExReviewAppInvoiceForecastRepository.DeleteAsync(input.Id + 1);
        }
        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewAppInvoiceForecasts)]
        public async Task<List<ProjectExReviewAppInvoiceForecastProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectExReviewAppInvoiceForecastProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewAppInvoiceForecasts)]
        public async Task<PagedResultDto<ProjectExReviewAppInvoiceForecastProjectExReviewDetailLookupTableDto>> GetAllProjectExReviewDetailForLookupTable(GetAllForLookupTableInput input)
        {
            var query = _lookup_projectExReviewDetailRepository.GetAll().WhereIf(
                   !string.IsNullOrWhiteSpace(input.Filter),
                  e => e.Title != null && e.Title.Contains(input.Filter)
               );

            var totalCount = await query.CountAsync();

            var projectExReviewDetailList = await query
                .PageBy(input)
                .ToListAsync();

            var lookupTableDtoList = new List<ProjectExReviewAppInvoiceForecastProjectExReviewDetailLookupTableDto>();
            foreach (var projectExReviewDetail in projectExReviewDetailList)
            {
                lookupTableDtoList.Add(new ProjectExReviewAppInvoiceForecastProjectExReviewDetailLookupTableDto
                {
                    Id = projectExReviewDetail.Id,
                    DisplayName = projectExReviewDetail.Title?.ToString()
                });
            }

            return new PagedResultDto<ProjectExReviewAppInvoiceForecastProjectExReviewDetailLookupTableDto>(
                totalCount,
                lookupTableDtoList
            );
        }

    }
}