﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Newtonsoft.Json;
using asq.econsys.Eco.Settings.Dtos;
using asq.econsys.Configuration.Tenants.Dto;
using Org.BouncyCastle.Math.EC.Rfc7748;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Abp.Domain.Uow;
using Abp.Events.Bus;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectExReviewDetails)]
    public class ProjectExReviewDetailsAppService : econsysAppServiceBase, IProjectExReviewDetailsAppService
    {
        private readonly IRepository<ProjectExReviewDetail, long> _projectExReviewDetailRepository;
        private readonly IProjectExReviewDetailsExcelExporter _projectExReviewDetailsExcelExporter;
        private readonly IRepository<ProjectExReview, long> _lookup_projectExReviewRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectExReviewRiskOpp, long> _projectExReviewRiskOppRepository;
        private readonly IRepository<ProjectAction, long> _projectActionRepository;
        private readonly IRepository<ProjectComment, long> _projectCommentRepository;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        public IEventBus EventBus { get; set; }
        public ProjectExReviewDetailsAppService(
            IRepository<ProjectExReviewDetail, long> projectExReviewDetailRepository,
            IProjectExReviewDetailsExcelExporter projectExReviewDetailsExcelExporter,
            IRepository<ProjectExReview, long> lookup_projectExReviewRepository,
            IRepository<Project, long> lookup_projectRepository,
            IRepository<ProjectExReviewRiskOpp, long> projectExReviewRiskOppRepository,
            IRepository<ProjectAction, long> projectActionRepository,
            IRepository<ProjectComment, long> projectCommentRepository,
            Utils.UtilsAppService utilsAppService, IUnitOfWorkManager unitOfWorkManager)
        {
            _projectExReviewDetailRepository = projectExReviewDetailRepository;
            _projectExReviewDetailsExcelExporter = projectExReviewDetailsExcelExporter;
            _lookup_projectExReviewRepository = lookup_projectExReviewRepository;
            _lookup_projectRepository = lookup_projectRepository;
            _projectExReviewRiskOppRepository = projectExReviewRiskOppRepository;
            _projectActionRepository = projectActionRepository;
            _projectCommentRepository = projectCommentRepository;
            _utilsAppService = utilsAppService;
            _unitOfWorkManager = unitOfWorkManager;
            EventBus = NullEventBus.Instance;
        }

        public async Task<PagedResultDto<GetProjectExReviewDetailForViewDto>> GetAll(GetAllProjectExReviewDetailsInput input)
        {

            var filteredProjectExReviewDetails = _projectExReviewDetailRepository.GetAll()
                        .Include(e => e.ProjectExReviewFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.ReviewType.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ReviewTypeFilter), e => e.ReviewType == input.ReviewTypeFilter)
                        .WhereIf(input.IsSubcontractFilter.HasValue && input.IsSubcontractFilter > -1, e => (input.IsSubcontractFilter == 1 && e.IsSubcontract) || (input.IsSubcontractFilter == 0 && !e.IsSubcontract))
                        .WhereIf(input.IsCurrentFilter.HasValue && input.IsCurrentFilter > -1, e => (input.IsCurrentFilter == 1 && e.IsCurrent) || (input.IsCurrentFilter == 0 && !e.IsCurrent))
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewTitleFilter), e => e.ProjectExReviewFk != null && e.ProjectExReviewFk.Title == input.ProjectExReviewTitleFilter);

            var pagedAndFilteredProjectExReviewDetails = filteredProjectExReviewDetails
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectExReviewDetails = from o in pagedAndFilteredProjectExReviewDetails
                                         join o1 in _lookup_projectExReviewRepository.GetAll() on o.ProjectExReviewId equals o1.Id into j1
                                         from s1 in j1.DefaultIfEmpty()

                                         select new
                                         {

                                             o.Title,
                                             o.ReviewType,
                                             o.IsSubcontract,
                                             o.IsCurrent,
                                             o.DisplayOrder,
                                             o.ReportSetting,
                                             o.SubContractorInfo,
                                             o.KeyCriticalDeliverable,
                                             o.RiskOpportunity,
                                             o.ProjectExReviewId,
                                             Id = o.Id,
                                             ProjectExReviewTitle = s1 == null || s1.Title == null ? "" : s1.Title.ToString()
                                         };

            var totalCount = await filteredProjectExReviewDetails.CountAsync();

            var dbList = await projectExReviewDetails.ToListAsync();
            var results = new List<GetProjectExReviewDetailForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectExReviewDetailForViewDto()
                {
                    ProjectExReviewDetail = new ProjectExReviewDetailDto
                    {

                        Title = o.Title,
                        ReviewType = o.ReviewType,
                        IsSubcontract = o.IsSubcontract,
                        IsCurrent = o.IsCurrent,
                        DisplayOrder = o.DisplayOrder,
                        ReportSetting = o.ReportSetting,
                        SubContractorInfo = o.SubContractorInfo,
                        KeyCriticalDeliverable = o.KeyCriticalDeliverable,
                        RiskOpportunity = o.RiskOpportunity,
                        ProjectExReviewId = o.ProjectExReviewId,
                        Id = o.Id,
                    },
                    ProjectExReviewTitle = o.ProjectExReviewTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectExReviewDetailForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectExReviewDetailForViewDto> GetProjectExReviewDetailForView(long id)
        {
            var projectExReviewDetail = await _projectExReviewDetailRepository.GetAsync(id);

            var output = new GetProjectExReviewDetailForViewDto { ProjectExReviewDetail = ObjectMapper.Map<ProjectExReviewDetailDto>(projectExReviewDetail) };

            if (output.ProjectExReviewDetail.ProjectExReviewId != null)
            {
                var _lookupProjectExReview = await _lookup_projectExReviewRepository.FirstOrDefaultAsync((long)output.ProjectExReviewDetail.ProjectExReviewId);
                output.ProjectExReviewTitle = _lookupProjectExReview?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewDetails_Edit)]
        public async Task<GetProjectExReviewDetailForEditOutput> GetProjectExReviewDetailForEdit(EntityDto<long> input)
        {
            var projectExReviewDetail = await _projectExReviewDetailRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectExReviewDetailForEditOutput { ProjectExReviewDetail = ObjectMapper.Map<CreateOrEditProjectExReviewDetailDto>(projectExReviewDetail) };

            if (output.ProjectExReviewDetail.ProjectExReviewId != null)
            {
                var _lookupProjectExReview = await _lookup_projectExReviewRepository.FirstOrDefaultAsync((long)output.ProjectExReviewDetail.ProjectExReviewId);
                output.ProjectExReviewTitle = _lookupProjectExReview?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectExReviewDetailDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewDetails_Create)]
        protected virtual async Task Create(CreateOrEditProjectExReviewDetailDto input)
        {
            var projectExReviewDetail = ObjectMapper.Map<ProjectExReviewDetail>(input);

            if (AbpSession.TenantId != null)
            {
                projectExReviewDetail.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectExReviewDetailRepository.InsertAsync(projectExReviewDetail);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewDetails_Edit)]
        protected virtual async Task Update(CreateOrEditProjectExReviewDetailDto input)
        {
            var projectExReviewDetail = await _projectExReviewDetailRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectExReviewDetail);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewDetails_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectExReviewDetailRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectExReviewDetailsToExcel(GetAllProjectExReviewDetailsForExcelInput input)
        {

            var filteredProjectExReviewDetails = _projectExReviewDetailRepository.GetAll()
                        .Include(e => e.ProjectExReviewFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.ReviewType.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ReviewTypeFilter), e => e.ReviewType == input.ReviewTypeFilter)
                        .WhereIf(input.IsSubcontractFilter.HasValue && input.IsSubcontractFilter > -1, e => (input.IsSubcontractFilter == 1 && e.IsSubcontract) || (input.IsSubcontractFilter == 0 && !e.IsSubcontract))
                        .WhereIf(input.IsCurrentFilter.HasValue && input.IsCurrentFilter > -1, e => (input.IsCurrentFilter == 1 && e.IsCurrent) || (input.IsCurrentFilter == 0 && !e.IsCurrent))
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        //.WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewTitleFilter), e => e.ProjectExReviewFk != null && e.ProjectExReviewFk.Title == input.ProjectExReviewTitleFilter)
                        ;

            var query = (from o in filteredProjectExReviewDetails
                         join o1 in _lookup_projectExReviewRepository.GetAll() on o.ProjectExReviewId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetProjectExReviewDetailForViewDto()
                         {
                             ProjectExReviewDetail = new ProjectExReviewDetailDto
                             {
                                 Title = o.Title,
                                 ReviewType = o.ReviewType,
                                 IsSubcontract = o.IsSubcontract,
                                 IsCurrent = o.IsCurrent,
                                 DisplayOrder = o.DisplayOrder,
                                 ReportSetting = o.ReportSetting,
                                 SubContractorInfo = o.SubContractorInfo,
                                 KeyCriticalDeliverable = o.KeyCriticalDeliverable,
                                 RiskOpportunity = o.RiskOpportunity,
                                 Id = o.Id
                             },
                             ProjectExReviewTitle = s1 == null || s1.Title == null ? "" : s1.Title.ToString()
                         });

            var projectExReviewDetailListDtos = await query.ToListAsync();

            return _projectExReviewDetailsExcelExporter.ExportToFile(projectExReviewDetailListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewDetails)]
        public async Task<List<ProjectExReviewDetailProjectExReviewLookupTableDto>> GetAllProjectExReviewForTableDropdown()
        {
            return await _lookup_projectExReviewRepository.GetAll()
                .Select(projectExReview => new ProjectExReviewDetailProjectExReviewLookupTableDto
                {
                    Id = projectExReview.Id,
                    DisplayName = projectExReview == null || projectExReview.Title == null ? "" : projectExReview.Title.ToString()
                }).ToListAsync();
        }

        public async Task<CreateOrEditProjectKeyDeliverableDto> GetKeyCriticalForEdit(EntityDto<long> input, int projectId)
        {
            try
            {
                var projectExReviewDetail = _projectExReviewDetailRepository.GetAllIncluding(x => x.ProjectExReviewFk)
                    .FirstOrDefault(a => a.ProjectExReviewFk.ProjectId == projectId);

                var deserializeKeyDeliverable = JsonConvert.DeserializeObject<List<CreateOrEditProjectKeyDeliverableDto>>(projectExReviewDetail.KeyCriticalDeliverable);
                var createOrEditPKD = deserializeKeyDeliverable.Where(p => p.Id == input.Id).FirstOrDefault();

                if (createOrEditPKD.ProjectId != 0)
                {
                    var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)createOrEditPKD.ProjectId);
                    createOrEditPKD.ProjectName = _lookupProject?.ProjectName?.ToString();
                }
                return createOrEditPKD;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<CreateOrEditProjectSubcontractorDto> GetSubContractForEdit(EntityDto<long> input, int projectId)
        {
            try
            {
                var projectExReviewDetail = _projectExReviewDetailRepository.GetAllIncluding(x => x.ProjectExReviewFk).FirstOrDefault(a => a.ProjectExReviewFk.ProjectId == projectId);
                var subcontractors = JsonConvert.DeserializeObject<List<CreateOrEditProjectSubcontractorDto>>(projectExReviewDetail.SubContractorInfo);
                var subcontractor = subcontractors.Where(p => p.Id == input.Id).FirstOrDefault();

                if (subcontractor.ProjectId != 0)
                {
                    var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)subcontractor.ProjectId);
                    subcontractor.ProjectName = _lookupProject?.ProjectName?.ToString();
                }
                return subcontractor;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviews)]
        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewRiskOpps)]
        public async Task<List<ProjectExReviewProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectExReviewProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        public async Task CreateOrEditRiskOpp(string data, ICollection<IFormFile> RiskOppfile)
        {
            var input = JsonConvert.DeserializeObject<CreateOrEditProjectExReviewDetailDto>(data);
            try
            {
                if (!string.IsNullOrEmpty(input.RiskOpportunity))
                {
                    var projectExReviewDetail = await _projectExReviewDetailRepository.GetAllIncluding(x => x.ProjectExReviewFk).FirstOrDefaultAsync(a => a.Id == input.ProjectExReviewId);

                    var deserializeRiskOpp = JsonConvert.DeserializeObject<ProjectExReviewRiskOpp>(input.RiskOpportunity);
                    if (projectExReviewDetail != null)
                    {
                        if (!string.IsNullOrEmpty(projectExReviewDetail.RiskOpportunity))
                        {
                            var riskOpps = JsonConvert.DeserializeObject<List<ProjectExReviewRiskOpp>>(projectExReviewDetail.RiskOpportunity);
                            var updateRiskOpps = JsonConvert.DeserializeObject<ProjectExReviewRiskOpp>(input.RiskOpportunity);
                            if (deserializeRiskOpp.Id > 0)
                            {
                                //Update RiskOpp
                                foreach (var item in riskOpps.Where(x => x.Id == updateRiskOpps.Id))
                                {
                                    item.Category = updateRiskOpps.Category;
                                    item.Description = updateRiskOpps.Description;
                                    item.EffectOnProgram = updateRiskOpps.EffectOnProgram;
                                    item.ValueToMargin = updateRiskOpps.ValueToMargin;
                                    item.Mitigation = updateRiskOpps.Mitigation;
                                    item.LikeliHood = updateRiskOpps.LikeliHood;
                                    item.Responsibility = updateRiskOpps.Responsibility;
                                    item.Comment = updateRiskOpps.Comment;
                                    item.LoggedDate = updateRiskOpps.LoggedDate;
                                }

                                projectExReviewDetail.RiskOpportunity = JsonConvert.SerializeObject(riskOpps);
                            }
                            else
                            {
                                //Add Risk/Opp
                                deserializeRiskOpp.Id = (riskOpps?.OrderByDescending(x => x.Id)?.FirstOrDefault()?.Id ?? 0) + 1;
                                riskOpps.Add(deserializeRiskOpp);
                                projectExReviewDetail.RiskOpportunity = JsonConvert.SerializeObject(riskOpps);
                            }
                        }
                        else
                        {
                            //First Record
                            deserializeRiskOpp.Id = 1;
                            var riskOpps = new List<ProjectExReviewRiskOpp>() { deserializeRiskOpp };
                            projectExReviewDetail.RiskOpportunity = JsonConvert.SerializeObject(riskOpps);

                        }
                    }

                    _projectExReviewDetailRepository.UpdateAsync(projectExReviewDetail);
                }
                else
                {
                    if (input.Id == null)
                    {
                        await Create(input);
                    }
                    else
                    {
                        await Update(input);
                    }
                }
                //await _utilsAppService.UploadSection(RiskOppfile, (long)input.ProjectExReviewId, CNodeTasks.PrepareProjectDeliveryPlanBaseline, "Risk Opportunity");
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewRiskOpps_Delete)]
        public async Task DeleteRiskOpp(EntityDto<long> input, int projectExReviewId)
        {
            var projectExReviewDetail = await _projectExReviewDetailRepository.GetAsync(projectExReviewId);
            if (projectExReviewDetail.KeyCriticalDeliverable.Count() == 0)
            {
                projectExReviewDetail = await _projectExReviewDetailRepository.GetAsync(projectExReviewId - 1);
            }
            if (projectExReviewDetail is not null)
            {
                if (!string.IsNullOrEmpty(projectExReviewDetail.RiskOpportunity))
                {
                    var riskOpps = JsonConvert.DeserializeObject<List<CreateOrEditProjectExReviewRiskOppDto>>(projectExReviewDetail.RiskOpportunity);
                    var riskOpp = riskOpps.Where(p => p.Id == input.Id).FirstOrDefault();
                    if (riskOpp is not null)
                    {
                        riskOpps.Remove(riskOpp);
                        projectExReviewDetail.RiskOpportunity = JsonConvert.SerializeObject(riskOpps);
                        await _projectExReviewDetailRepository.UpdateAsync(projectExReviewDetail);
                    }
                }
            }
        }

        public async Task DeleteSubContractor(EntityDto<long> input, int projectExReviewId)
        {
            if (projectExReviewId != 0)
            {
                var projectExReviewDetail = await _projectExReviewDetailRepository.GetAsync(projectExReviewId);
                if (projectExReviewDetail.KeyCriticalDeliverable.Count() == 0)
                {
                    projectExReviewDetail = await _projectExReviewDetailRepository.GetAsync(projectExReviewId - 1);
                }
                if (projectExReviewDetail != null)
                {
                    if (!string.IsNullOrEmpty(projectExReviewDetail.SubContractorInfo))
                    {
                        var deserializeSubcontractor = JsonConvert.DeserializeObject<List<CreateOrEditProjectSubcontractorDto>>(projectExReviewDetail.SubContractorInfo);

                        if (deserializeSubcontractor is not null)
                        {
                            var subContract = deserializeSubcontractor.Where(p => p.Id == input.Id).FirstOrDefault();
                            if (subContract is not null)
                            {
                                deserializeSubcontractor.Remove(subContract);
                                projectExReviewDetail.SubContractorInfo = JsonConvert.SerializeObject(deserializeSubcontractor);
                                await _projectExReviewDetailRepository.UpdateAsync(projectExReviewDetail);
                            }
                        }
                    }
                }
            }
        }

        public async Task<List<ProjectExReviewRiskOppProjectExReviewDetailLookupTableDto>> GetAllProjectExReviewDetailForTableDropdown()
        {
            return await _projectExReviewDetailRepository.GetAll()
                .Select(projectExReviewDetail => new ProjectExReviewRiskOppProjectExReviewDetailLookupTableDto
                {
                    Id = projectExReviewDetail.Id,
                    DisplayName = projectExReviewDetail == null || projectExReviewDetail.Title == null ? "" : projectExReviewDetail.Title.ToString()
                }).ToListAsync();
        }

        public async Task CreateOrEditSubContractor(CreateOrEditProjectExReviewDetailDto input)
        {
            if (!string.IsNullOrEmpty(input.SubContractorInfo))
            {
                var projectExReviewDetail = await _projectExReviewDetailRepository.GetAllIncluding(x => x.ProjectExReviewFk).FirstOrDefaultAsync(a => a.Id == input.ProjectExReviewId);
                try
                {
                    var deserializeSubcontractor = JsonConvert.DeserializeObject<ProjectSubcontractor>(input.SubContractorInfo);

                    if (projectExReviewDetail != null)
                    {
                        if (!string.IsNullOrEmpty(projectExReviewDetail.SubContractorInfo))
                        {
                            var subcontractors = JsonConvert.DeserializeObject<List<ProjectSubcontractor>>(projectExReviewDetail.SubContractorInfo);
                            var updateSubContract = JsonConvert.DeserializeObject<ProjectSubcontractor>(input.SubContractorInfo);
                            if (deserializeSubcontractor.Id > 0)
                            {
                                //Update Subcontractor
                                foreach (var item in subcontractors.Where(x => x.Id == updateSubContract.Id))
                                {
                                    item.Name = updateSubContract.Name;
                                    item.SubContractTask = updateSubContract.SubContractTask;
                                    item.RequiredBy = updateSubContract.RequiredBy;
                                    item.ApproxValue = updateSubContract.ApproxValue;
                                    item.Comment = updateSubContract.Comment;
                                }
                                projectExReviewDetail.SubContractorInfo = JsonConvert.SerializeObject(subcontractors);
                            }
                            else
                            {
                                //Add SubContractor
                                deserializeSubcontractor.Id = (subcontractors?.OrderByDescending(x => x.Id)?.FirstOrDefault()?.Id ?? 0) + 1;
                                subcontractors.Add(deserializeSubcontractor);
                                projectExReviewDetail.SubContractorInfo = JsonConvert.SerializeObject(subcontractors);
                            }
                        }
                        else
                        {
                            //First Record
                            deserializeSubcontractor.Id = 1;
                            var lst = new List<ProjectSubcontractor>() { deserializeSubcontractor };
                            projectExReviewDetail.SubContractorInfo = JsonConvert.SerializeObject(lst);

                        }
                    }
                }
                catch (Exception e)
                {

                }
                _projectExReviewDetailRepository.UpdateAsync(projectExReviewDetail);
            }
            else
            {
                if (input.Id == null)
                {
                    await Create(input);
                }
                else
                {
                    await Update(input);
                }
            }
        }

        public async Task CreateOrEditKeyCritical(CreateOrEditProjectExReviewDetailDto input)
        {
            if (!string.IsNullOrEmpty(input.KeyCriticalDeliverable))
            {
                var projectExReviewDetail = await _projectExReviewDetailRepository.GetAllIncluding(x => x.ProjectExReviewFk)
                    .FirstOrDefaultAsync(a => a.Id == input.ProjectExReviewId);
                try
                {
                    var deserializeKeyCritical = JsonConvert.DeserializeObject<ProjectKeyDeliverable>(input.KeyCriticalDeliverable);

                    if (projectExReviewDetail != null)
                    {
                        if (!string.IsNullOrEmpty(projectExReviewDetail.KeyCriticalDeliverable))
                        {
                            var projectKeyDeliverables = JsonConvert.DeserializeObject<List<ProjectKeyDeliverable>>(projectExReviewDetail.KeyCriticalDeliverable);
                            var updatekeyCritical = JsonConvert.DeserializeObject<ProjectKeyDeliverable>(input.KeyCriticalDeliverable);
                            if (deserializeKeyCritical.Id > 0)
                            {
                                //Update KeyCritical
                                foreach (var item in projectKeyDeliverables.Where(x => x.Id == updatekeyCritical.Id))
                                {
                                    item.Title = updatekeyCritical.Title;
                                    item.ActionDate = updatekeyCritical.ActionDate;
                                    item.Comment = updatekeyCritical.Comment;
                                }

                                projectExReviewDetail.KeyCriticalDeliverable = JsonConvert.SerializeObject(projectKeyDeliverables);
                            }
                            else
                            {
                                //Add KeyCritical
                                deserializeKeyCritical.Id = (projectKeyDeliverables?.OrderByDescending(x => x.Id)?.FirstOrDefault()?.Id ?? 0) + 1;
                                projectKeyDeliverables.Add(deserializeKeyCritical);
                                projectExReviewDetail.KeyCriticalDeliverable = JsonConvert.SerializeObject(projectKeyDeliverables);
                            }
                        }
                        else
                        {
                            //First Record
                            deserializeKeyCritical.Id = 1;
                            var projectKeyDeliverables = new List<ProjectKeyDeliverable>() { deserializeKeyCritical };
                            projectExReviewDetail.KeyCriticalDeliverable = JsonConvert.SerializeObject(projectKeyDeliverables);

                        }
                    }
                }
                catch (Exception e)
                {

                }
                _projectExReviewDetailRepository.UpdateAsync(projectExReviewDetail);
            }
            else
            {
                if (input.Id == null)
                {
                    await Create(input);
                }
                else
                {
                    await Update(input);
                }
            }
        }

        public async Task DeleteKeyCritical(EntityDto<long> input, long projectExReviewId)
        {
            if (projectExReviewId != 0 && input.Id != 0)
            {
                var projectExReviewDetail = await _projectExReviewDetailRepository.GetAsync(projectExReviewId);
                if (projectExReviewDetail.KeyCriticalDeliverable.Count() == 0)
                {
                    projectExReviewDetail = await _projectExReviewDetailRepository.GetAsync(projectExReviewId - 1);
                }
                if (projectExReviewDetail != null)
                {
                    try
                    {
                        var deserializeKeyDeliverable = JsonConvert.DeserializeObject<List<CreateOrEditProjectKeyDeliverableDto>>(projectExReviewDetail.KeyCriticalDeliverable);
                        if (deserializeKeyDeliverable != null)
                        {
                            var keyCriticalinfo = deserializeKeyDeliverable.Where(p => p.Id == input.Id).FirstOrDefault();
                            deserializeKeyDeliverable.Remove(keyCriticalinfo);
                            projectExReviewDetail.KeyCriticalDeliverable = JsonConvert.SerializeObject(deserializeKeyDeliverable);
                            await _projectExReviewDetailRepository.UpdateAsync(projectExReviewDetail);
                        }
                    }
                    catch (Exception e)
                    {

                        throw;
                    }

                }
            }
        }

        public async Task CreateOrEditReportSetting(TenantSettingsEditDto input)
        {
            try
            {
                if (input != null && input.ReportGenIntervalSettings != null)
                {
                    var projectExReviewDetail = await _projectExReviewDetailRepository.FirstOrDefaultAsync(a => a.Id == input.ReportGenIntervalSettings.ProjectExReviewDetailId);

                    var reportGenIntervalSettings = input.ReportGenIntervalSettings;

                    if (projectExReviewDetail != null)
                    {
                        projectExReviewDetail.ReportSetting = JsonConvert.SerializeObject(reportGenIntervalSettings);
                        await _projectExReviewDetailRepository.UpdateAsync(projectExReviewDetail);
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<ReportGenerationIntervalSettingsEditDto> GetReportSettingByExReviewId(int projectExReviewId, string reviewType)
        {
            ReportGenerationIntervalSettingsEditDto reportSetting = new ReportGenerationIntervalSettingsEditDto();
            var projectExReviewDetail = await _projectExReviewDetailRepository.FirstOrDefaultAsync(x => x.Id == projectExReviewId && x.ReviewType == reviewType);
            if (projectExReviewDetail != null)
            {
                if (projectExReviewDetail.ReportSetting != null)
                {
                    reportSetting = JsonConvert.DeserializeObject<ReportGenerationIntervalSettingsEditDto>(projectExReviewDetail.ReportSetting);

                }
            }
            return reportSetting;
        }

        public async Task<List<ProjectExReviewDetailDto>> GetProjectExReviewDetailJsonByProjectId(int projectId, string reviewType)
        {
            List<ProjectExReviewDetailDto> projectExReviewDetailDtos = new List<ProjectExReviewDetailDto>();

            var projectExReviews = await _lookup_projectExReviewRepository.GetAllListAsync(x => x.ProjectId == projectId);

            if (projectExReviews != null)
            {
                foreach (var projectExReview in projectExReviews)
                {
                    var projectExReviewDetail = await _projectExReviewDetailRepository.GetAll().Where(x => x.ProjectExReviewId == projectExReview.Id).ToArrayAsync();
                    foreach (var item in projectExReviewDetail)
                    {
                        if (item != null)
                        {
                            var output = ObjectMapper.Map<ProjectExReviewDetailDto>(item);
                            projectExReviewDetailDtos.Add(output);
                        }
                    }
                }
            }


            return projectExReviewDetailDtos;
        }

        public async Task CreateProjectActionAndComments(string data, ICollection<IFormFile> fileBaseline,
            ICollection<IFormFile>? fileRiskOpps)
        {
            try
            {
                await _unitOfWorkManager.WithUnitOfWork(async () =>
                {
                    var tenantId = AbpSession.TenantId;
                    using (CurrentUnitOfWork.SetTenantId(tenantId))
                    {
                        using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                        {
                            var input = JsonConvert.DeserializeObject<CreateProjectActionAndCommentDto>(data);

                            if (input.CreateOrEditProjectActionDto is not null)
                            {
                                var projectAction = ObjectMapper.Map<ProjectAction>(input.CreateOrEditProjectActionDto);
                                if (AbpSession.TenantId != null)
                                {
                                    projectAction.TenantId = (int?)AbpSession.TenantId;
                                }
                                await _projectActionRepository.InsertAsync(projectAction);
                            }
                            if (input.CreateOrEditProjectCommentDto is not null)
                            {
                                var projectComment = ObjectMapper.Map<ProjectComment>(input.CreateOrEditProjectCommentDto);

                                if (AbpSession.TenantId != null)
                                {
                                    projectComment.TenantId = (int?)AbpSession.TenantId;
                                }

                                await _projectCommentRepository.InsertAsync(projectComment);
                            }
                            if (input.ReportGenIntervalSettings is not null)
                            {
                                var projectExReviewDetail = await _projectExReviewDetailRepository.FirstOrDefaultAsync(a => a.Id == input.ReportGenIntervalSettings.ProjectExReviewDetailId);

                                var reportGenIntervalSettings = input.ReportGenIntervalSettings;

                                if (projectExReviewDetail != null)
                                {
                                    projectExReviewDetail.ReportSetting = JsonConvert.SerializeObject(reportGenIntervalSettings);
                                    await _projectExReviewDetailRepository.UpdateAsync(projectExReviewDetail);
                                }
                            }
                            var project = _lookup_projectRepository.FirstOrDefault((long)input.CreateOrEditProjectActionDto.ProjectId);
                            await EventBus.TriggerAsync(new EditProjectEventData()
                            {
                                Project = project,
                                StageId = CNodeStages.Execution,
                                TaskId = CNodeTasks.PrepareProjectDeliveryPlanBaseline,
                                StatusId = input.CreateOrEditProjectActionDto.Status,
                                LoggedInUserId = (long)AbpSession.UserId,
                            });
                            //result.Project = ObjectMapper.Map<ProjectDto>(project);
                            //await _utilsAppService.UploadSection(fileBaseline.FirstOrDefault(), (long)input.CreateOrEditProjectActionDto.ProjectId, CNodeTasks.PrepareProjectDeliveryPlanBaseline, "Production Of Baseline Program");
                            //await _utilsAppService.UploadSection(fileRiskOpps.FirstOrDefault(), (long)input.CreateOrEditProjectActionDto.ProjectId, CNodeTasks.PrepareProjectDeliveryPlanBaseline, "Risk Opportunity");
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}