﻿//using asq.econsys.Eco.Projects;

//using System;
//using System.Linq;
//using System.Linq.Dynamic.Core;
//using Abp.Linq.Extensions;
//using System.Collections.Generic;
//using System.Threading.Tasks;
//using Abp.Domain.Repositories;
//using asq.econsys.Eco.Projects.Dtos;
//using asq.econsys.Dto;
//using Abp.Application.Services.Dto;
//using asq.econsys.Authorization;
//using Abp.Extensions;
//using Abp.Authorization;
//using Microsoft.EntityFrameworkCore;
//using Abp.UI;
//using asq.econsys.Storage;

//namespace asq.econsys.Eco.Projects
//{
//    [AbpAuthorize(AppPermissions.Pages_ProjectExReviewRiskOpps)]
//    public class ProjectExReviewRiskOppsAppService : econsysAppServiceBase, IProjectExReviewRiskOppsAppService
//    {
//        private readonly IRepository<ProjectExReviewRiskOpp, long> _projectExReviewRiskOppRepository;
//        private readonly IRepository<Project, long> _lookup_projectRepository;
//        private readonly IRepository<ProjectExReviewDetail, long> _lookup_projectExReviewDetailRepository;

//        public ProjectExReviewRiskOppsAppService(IRepository<ProjectExReviewRiskOpp, long> projectExReviewRiskOppRepository, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectExReviewDetail, long> lookup_projectExReviewDetailRepository)
//        {
//            _projectExReviewRiskOppRepository = projectExReviewRiskOppRepository;
//            _lookup_projectRepository = lookup_projectRepository;
//            _lookup_projectExReviewDetailRepository = lookup_projectExReviewDetailRepository;

//        }

//        public async Task<PagedResultDto<GetProjectExReviewRiskOppForViewDto>> GetAll(GetAllProjectExReviewRiskOppsInput input)
//        {

//            var filteredProjectExReviewRiskOpps = _projectExReviewRiskOppRepository.GetAll()
//                        .Include(e => e.ProjectFk)
//                        .Include(e => e.ProjectExReviewDetailFk)
//                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Description.Contains(input.Filter) || e.Category.Contains(input.Filter) || e.Mitigation.Contains(input.Filter) || e.Responsibility.Contains(input.Filter) || e.Comment.Contains(input.Filter))
//                        .WhereIf(!string.IsNullOrWhiteSpace(input.DescriptionFilter), e => e.Description == input.DescriptionFilter)
//                        .WhereIf(!string.IsNullOrWhiteSpace(input.CategoryFilter), e => e.Category == input.CategoryFilter)
//                        .WhereIf(input.MinValueToMarginFilter != null, e => e.ValueToMargin >= input.MinValueToMarginFilter)
//                        .WhereIf(input.MaxValueToMarginFilter != null, e => e.ValueToMargin <= input.MaxValueToMarginFilter)
//                        .WhereIf(input.MinEffectOnProgramFilter != null, e => e.EffectOnProgram >= input.MinEffectOnProgramFilter)
//                        .WhereIf(input.MaxEffectOnProgramFilter != null, e => e.EffectOnProgram <= input.MaxEffectOnProgramFilter)
//                        .WhereIf(!string.IsNullOrWhiteSpace(input.MitigationFilter), e => e.Mitigation == input.MitigationFilter)
//                        .WhereIf(input.MinLoggedDateFilter != null, e => e.LoggedDate >= input.MinLoggedDateFilter)
//                        .WhereIf(input.MaxLoggedDateFilter != null, e => e.LoggedDate <= input.MaxLoggedDateFilter)
//                        .WhereIf(!string.IsNullOrWhiteSpace(input.ResponsibilityFilter), e => e.Responsibility == input.ResponsibilityFilter)
//                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
//                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
//                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);

//            var pagedAndFilteredProjectExReviewRiskOpps = filteredProjectExReviewRiskOpps
//                .OrderBy(input.Sorting ?? "id asc")
//                .PageBy(input);

//            var projectExReviewRiskOpps = from o in pagedAndFilteredProjectExReviewRiskOpps
//                                          join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
//                                          from s1 in j1.DefaultIfEmpty()

//                                          join o2 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o2.Id into j2
//                                          from s2 in j2.DefaultIfEmpty()

//                                          select new
//                                          {

//                                              o.Description,
//                                              o.Category,
//                                              o.ValueToMargin,
//                                              o.EffectOnProgram,
//                                              o.Mitigation,
//                                              o.LoggedDate,
//                                              o.Responsibility,
//                                              o.Comment,
//                                              Id = o.Id,
//                                              ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
//                                              ProjectExReviewDetailTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
//                                          };

//            var totalCount = await filteredProjectExReviewRiskOpps.CountAsync();

//            var dbList = await projectExReviewRiskOpps.ToListAsync();
//            var results = new List<GetProjectExReviewRiskOppForViewDto>();

//            foreach (var o in dbList)
//            {
//                var res = new GetProjectExReviewRiskOppForViewDto()
//                {
//                    ProjectExReviewRiskOpp = new ProjectExReviewRiskOppDto
//                    {

//                        Description = o.Description,
//                        Category = o.Category,
//                        ValueToMargin = o.ValueToMargin,
//                        EffectOnProgram = o.EffectOnProgram,
//                        Mitigation = o.Mitigation,
//                        LoggedDate = o.LoggedDate,
//                        Responsibility = o.Responsibility,
//                        Comment = o.Comment,
//                        Id = o.Id,
//                    },
//                    ProjectProjectName = o.ProjectProjectName,
//                    ProjectExReviewDetailTitle = o.ProjectExReviewDetailTitle
//                };

//                results.Add(res);
//            }

//            return new PagedResultDto<GetProjectExReviewRiskOppForViewDto>(
//                totalCount,
//                results
//            );

//        }

//        public async Task<GetProjectExReviewRiskOppForViewDto> GetProjectExReviewRiskOppForView(long id)
//        {
//            var projectExReviewRiskOpp = await _projectExReviewRiskOppRepository.GetAsync(id);

//            var output = new GetProjectExReviewRiskOppForViewDto { ProjectExReviewRiskOpp = ObjectMapper.Map<ProjectExReviewRiskOppDto>(projectExReviewRiskOpp) };

//            if (output.ProjectExReviewRiskOpp.ProjectId != null)
//            {
//                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectExReviewRiskOpp.ProjectId);
//                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
//            }

//            if (output.ProjectExReviewRiskOpp.ProjectExReviewDetailId != null)
//            {
//                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectExReviewRiskOpp.ProjectExReviewDetailId);
//                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
//            }

//            return output;
//        }

//        [AbpAuthorize(AppPermissions.Pages_ProjectExReviewRiskOpps_Edit)]
//        public async Task<GetProjectExReviewRiskOppForEditOutput> GetProjectExReviewRiskOppForEdit(EntityDto<long> input)
//        {
//            var projectExReviewRiskOpp = await _projectExReviewRiskOppRepository.FirstOrDefaultAsync(input.Id);

//            var output = new GetProjectExReviewRiskOppForEditOutput { ProjectExReviewRiskOpp = ObjectMapper.Map<CreateOrEditProjectExReviewRiskOppDto>(projectExReviewRiskOpp) };

//            if (output.ProjectExReviewRiskOpp.ProjectId != null)
//            {
//                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectExReviewRiskOpp.ProjectId);
//                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
//            }

//            if (output.ProjectExReviewRiskOpp.ProjectExReviewDetailId != null)
//            {
//                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectExReviewRiskOpp.ProjectExReviewDetailId);
//                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
//            }

//            return output;
//        }

        

//    }
//}