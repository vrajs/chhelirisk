﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectExReviews)]
    public class ProjectExReviewsAppService : econsysAppServiceBase, IProjectExReviewsAppService
    {
        private readonly IRepository<ProjectExReview, long> _projectExReviewRepository;
        private readonly IProjectExReviewsExcelExporter _projectExReviewsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectExReviewDetail, long> _projectExReviewDetailRepository;
        private readonly IRepository<ProjectExReviewRiskOpp, long> _projectExReviewRiskOppRepository;

        public ProjectExReviewsAppService(
            IRepository<ProjectExReview, long> projectExReviewRepository,
            IProjectExReviewsExcelExporter projectExReviewsExcelExporter,
            IRepository<Project, long> lookup_projectRepository,
            IRepository<ProjectExReviewDetail, long> projectExReviewDetailRepository,
            IRepository<ProjectExReviewRiskOpp, long> projectExReviewRiskOppRepository)
        {
            _projectExReviewRepository = projectExReviewRepository;
            _projectExReviewsExcelExporter = projectExReviewsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _projectExReviewDetailRepository = projectExReviewDetailRepository;
            _projectExReviewRiskOppRepository = projectExReviewRiskOppRepository;

        }

        public async Task<PagedResultDto<GetProjectExReviewForViewDto>> GetAll(GetAllProjectExReviewsInput input)
        {

            var filteredProjectExReviews = _projectExReviewRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.IsCurrentFilter.HasValue && input.IsCurrentFilter > -1, e => (input.IsCurrentFilter == 1 && e.IsCurrent) || (input.IsCurrentFilter == 0 && !e.IsCurrent))
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var pagedAndFilteredProjectExReviews = filteredProjectExReviews
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectExReviews = from o in pagedAndFilteredProjectExReviews
                                   join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                   from s1 in j1.DefaultIfEmpty()

                                   select new
                                   {

                                       o.Title,
                                       o.IsCurrent,
                                       o.DisplayOrder,
                                       Id = o.Id,
                                       ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                                   };

            var totalCount = await filteredProjectExReviews.CountAsync();

            var dbList = await projectExReviews.ToListAsync();
            var results = new List<GetProjectExReviewForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectExReviewForViewDto()
                {
                    ProjectExReview = new ProjectExReviewDto
                    {

                        Title = o.Title,
                        IsCurrent = o.IsCurrent,
                        DisplayOrder = o.DisplayOrder,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectExReviewForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectExReviewForViewDto> GetProjectExReviewForView(long id)
        {
            var projectExReviewAll = await _projectExReviewRepository.GetAllListAsync();
            var projectExReview = projectExReviewAll.FirstOrDefault(a => a.ProjectId == id);

            var output = new GetProjectExReviewForViewDto { ProjectExReview = ObjectMapper.Map<ProjectExReviewDto>(projectExReview) };

            if (output.ProjectExReview.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectExReview.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviews_Edit)]
        public async Task<GetProjectExReviewForEditOutput> GetProjectExReviewForEdit(EntityDto<long> input)
        {
            var projectExReview = await _projectExReviewRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectExReviewForEditOutput { ProjectExReview = ObjectMapper.Map<CreateOrEditProjectExReviewDto>(projectExReview) };

            if (output.ProjectExReview.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectExReview.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviews_Edit)]
        public async Task<List<GetProjectExReviewForViewDto>> GetProjectExReviewsForProject(long projectId)
        {
            var projectExReviews = await _projectExReviewRepository.GetAllIncluding().Where(x => x.ProjectId == projectId).ToListAsync();

            /// TODO - put this in OrderAcceptance completion
            if (projectExReviews == null || projectExReviews.Count == 0)
            {
                var projectExReview = await _projectExReviewRepository.InsertAsync(new ProjectExReview()
                {
                    ProjectId = projectId,
                    Title = "Current Review",
                    DisplayOrder = 0,
                    IsCurrent = true,
                    CreatorUserId = (long)AbpSession.UserId,
                    TenantId = (int)AbpSession.TenantId != 0 ? (int)AbpSession.TenantId : 0,
                    CreationTime = DateTime.UtcNow
                });
                await CurrentUnitOfWork.SaveChangesAsync();

                projectExReviews = await _projectExReviewRepository.GetAllIncluding().Where(x => x.ProjectId == projectId).ToListAsync();

                var projectExReviewDetail = await _projectExReviewDetailRepository.InsertAsync(new ProjectExReviewDetail()
                {
                    ProjectExReviewId = projectExReview.Id,
                    DisplayOrder = 0,
                    IsCurrent = true,
                    IsSubcontract = false,
                    ReviewType = CProjectExReviewType.Baseline,
                    Title = "Project Delivery Plan Baseline",
                    CreatorUserId = (long)AbpSession.UserId,
                    TenantId = (int)AbpSession.TenantId != 0 ? (int)AbpSession.TenantId : 0,
                    CreationTime = DateTime.UtcNow
                });
                var projectExReviewDetailFor = await _projectExReviewDetailRepository.InsertAsync(new ProjectExReviewDetail()
                {
                    ProjectExReviewId = projectExReview.Id,
                    DisplayOrder = 0,
                    IsCurrent = true,
                    IsSubcontract = false,
                    ReviewType = CProjectExReviewType.Delivery,
                    Title = "Delivery Review",
                    CreatorUserId = (long)AbpSession.UserId,
                    TenantId = (int)AbpSession.TenantId != 0 ? (int)AbpSession.TenantId : 0,
                    CreationTime = DateTime.UtcNow
                });

                await CurrentUnitOfWork.SaveChangesAsync();
                var project = _lookup_projectRepository.FirstOrDefault(x => x.Id == projectId);

                if (project != null)
                {
                    project.ProjectExReviewId = projectExReviewDetail.ProjectExReviewId;
                    project.LastModificationTime = DateTime.UtcNow;
                    await _lookup_projectRepository.UpdateAsync(project);
                }

                await CurrentUnitOfWork.SaveChangesAsync();
            }


            List<GetProjectExReviewForViewDto> result = new List<GetProjectExReviewForViewDto>();
            foreach (var projectExReview in projectExReviews)
            {
                try
                {
                    var projectExReviewDetails = await _projectExReviewDetailRepository.GetAllIncluding().Where(x => x.ProjectExReviewId == projectExReview.Id).ToListAsync();

                    var output = new GetProjectExReviewForViewDto
                    {
                        ProjectExReview = ObjectMapper.Map<ProjectExReviewDto>(projectExReview),
                        ProjectExReviewDetails = ObjectMapper.Map<List<ProjectExReviewDetailDto>>(projectExReviewDetails)
                    };

                    if (output.ProjectExReview.ProjectId != null)
                    {
                        var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectExReview.ProjectId);
                        output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
                    }
                    result.Add(output);
                }
                catch (Exception e)
                {
                    return result;
                }
                return result;
            }
            return result;
        }

        public async Task<List<GetProjectExReviewDetailForViewDto>> GetProjectExReviewDetailsForReview(long projectExReviewId)
        {
            var projectExReviewDetails = await _projectExReviewDetailRepository.GetAllIncluding().Where(x => x.ProjectExReviewId == projectExReviewId).ToListAsync();

            List<GetProjectExReviewDetailForViewDto> result = new List<GetProjectExReviewDetailForViewDto>();
            foreach (var projectExReviewDetail in projectExReviewDetails)
            {
                var output = new GetProjectExReviewDetailForViewDto
                {
                    ProjectExReviewDetail = ObjectMapper.Map<ProjectExReviewDetailDto>(projectExReviewDetail)
                };
                result.Add(output);
            }

            return result;
        }

        public async Task<List<GetProjectExReviewRiskOppForViewDto>> GetProjectExReviewRiskOppsForReviewDetail(long projectExReviewDetailId)
        {
            var projectExReviewRiskOpps = await _projectExReviewRiskOppRepository.GetAllIncluding().Where(x => x.ProjectExReviewDetailId == projectExReviewDetailId).ToListAsync();

            List<GetProjectExReviewRiskOppForViewDto> result = new List<GetProjectExReviewRiskOppForViewDto>();
            foreach (var projectExReviewRiskOpp in projectExReviewRiskOpps)
            {
                var output = new GetProjectExReviewRiskOppForViewDto
                {
                    ProjectExReviewRiskOpp = ObjectMapper.Map<ProjectExReviewRiskOppDto>(projectExReviewRiskOpp)
                };
                result.Add(output);
            }

            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviews_Create)]
        protected virtual async Task Create(CreateOrEditProjectExReviewDto input)
        {
            var projectExReview = ObjectMapper.Map<ProjectExReview>(input);

            if (AbpSession.TenantId != null)
            {
                projectExReview.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectExReviewRepository.InsertAsync(projectExReview);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviews_Edit)]
        protected virtual async Task Update(CreateOrEditProjectExReviewDto input)
        {
            var projectExReview = await _projectExReviewRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectExReview);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviews_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectExReviewRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectExReviewsToExcel(GetAllProjectExReviewsForExcelInput input)
        {

            var filteredProjectExReviews = _projectExReviewRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.IsCurrentFilter.HasValue && input.IsCurrentFilter > -1, e => (input.IsCurrentFilter == 1 && e.IsCurrent) || (input.IsCurrentFilter == 0 && !e.IsCurrent))
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var query = (from o in filteredProjectExReviews
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetProjectExReviewForViewDto()
                         {
                             ProjectExReview = new ProjectExReviewDto
                             {
                                 Title = o.Title,
                                 IsCurrent = o.IsCurrent,
                                 DisplayOrder = o.DisplayOrder,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                         });

            var projectExReviewListDtos = await query.ToListAsync();

            return _projectExReviewsExcelExporter.ExportToFile(projectExReviewListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectExReviews)]
        public async Task<List<ProjectExReviewProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectExReviewProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        public async Task CreateOrEdit(CreateOrEditProjectExReviewDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }
    }
}