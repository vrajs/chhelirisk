﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectKeyDeliverables)]
    public class ProjectKeyDeliverablesAppService : econsysAppServiceBase, IProjectKeyDeliverablesAppService
    {
        private readonly IRepository<ProjectKeyDeliverable, long> _projectKeyDeliverableRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectExReviewDetail, long> _lookup_projectExReviewDetailRepository;

        public ProjectKeyDeliverablesAppService(IRepository<ProjectKeyDeliverable, long> projectKeyDeliverableRepository, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectExReviewDetail, long> lookup_projectExReviewDetailRepository)
        {
            _projectKeyDeliverableRepository = projectKeyDeliverableRepository;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectExReviewDetailRepository = lookup_projectExReviewDetailRepository;

        }

        public async Task<PagedResultDto<GetProjectKeyDeliverableForViewDto>> GetAll(GetAllProjectKeyDeliverablesInput input)
        {

            var filteredProjectKeyDeliverables = _projectKeyDeliverableRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(input.MinActionDateFilter != null, e => e.ActionDate >= input.MinActionDateFilter)
                        .WhereIf(input.MaxActionDateFilter != null, e => e.ActionDate <= input.MaxActionDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);

            var pagedAndFilteredProjectKeyDeliverables = filteredProjectKeyDeliverables
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectKeyDeliverables = from o in pagedAndFilteredProjectKeyDeliverables
                                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                         from s1 in j1.DefaultIfEmpty()

                                         join o2 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o2.Id into j2
                                         from s2 in j2.DefaultIfEmpty()

                                         select new
                                         {

                                             o.Title,
                                             o.ActionDate,
                                             o.Comment,
                                             Id = o.Id,
                                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                             ProjectExReviewDetailTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
                                         };

            var totalCount = await filteredProjectKeyDeliverables.CountAsync();

            var dbList = await projectKeyDeliverables.ToListAsync();
            var results = new List<GetProjectKeyDeliverableForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectKeyDeliverableForViewDto()
                {
                    ProjectKeyDeliverable = new ProjectKeyDeliverableDto
                    {

                        Title = o.Title,
                        ActionDate = o.ActionDate,
                        Comment = o.Comment,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectExReviewDetailTitle = o.ProjectExReviewDetailTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectKeyDeliverableForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectKeyDeliverableForViewDto> GetProjectKeyDeliverableForView(long id)
        {
            var projectKeyDeliverable = await _projectKeyDeliverableRepository.GetAsync(id);

            var output = new GetProjectKeyDeliverableForViewDto { ProjectKeyDeliverable = ObjectMapper.Map<ProjectKeyDeliverableDto>(projectKeyDeliverable) };

            if (output.ProjectKeyDeliverable.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectKeyDeliverable.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectKeyDeliverable.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectKeyDeliverable.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectKeyDeliverables_Edit)]
        public async Task<GetProjectKeyDeliverableForEditOutput> GetProjectKeyDeliverableForEdit(EntityDto<long> input)
        {
            var projectKeyDeliverable = await _projectKeyDeliverableRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectKeyDeliverableForEditOutput { ProjectKeyDeliverable = ObjectMapper.Map<CreateOrEditProjectKeyDeliverableDto>(projectKeyDeliverable) };

            if (output.ProjectKeyDeliverable.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectKeyDeliverable.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectKeyDeliverable.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectKeyDeliverable.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectKeyDeliverableDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectKeyDeliverables_Create)]
        protected virtual async Task Create(CreateOrEditProjectKeyDeliverableDto input)
        {
            var projectKeyDeliverable = ObjectMapper.Map<ProjectKeyDeliverable>(input);

            if (AbpSession.TenantId != null)
            {
                projectKeyDeliverable.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectKeyDeliverableRepository.InsertAsync(projectKeyDeliverable);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectKeyDeliverables_Edit)]
        protected virtual async Task Update(CreateOrEditProjectKeyDeliverableDto input)
        {
            var projectKeyDeliverable = await _projectKeyDeliverableRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectKeyDeliverable);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectKeyDeliverables_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectKeyDeliverableRepository.DeleteAsync(input.Id);
        }
        [AbpAuthorize(AppPermissions.Pages_ProjectKeyDeliverables)]
        public async Task<List<ProjectKeyDeliverableProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectKeyDeliverableProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectKeyDeliverables)]
        public async Task<List<ProjectKeyDeliverableProjectExReviewDetailLookupTableDto>> GetAllProjectExReviewDetailForTableDropdown()
        {
            return await _lookup_projectExReviewDetailRepository.GetAll()
                .Select(projectExReviewDetail => new ProjectKeyDeliverableProjectExReviewDetailLookupTableDto
                {
                    Id = projectExReviewDetail.Id,
                    DisplayName = projectExReviewDetail == null || projectExReviewDetail.Title == null ? "" : projectExReviewDetail.Title.ToString()
                }).ToListAsync();
        }

    }
}