﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Events.Bus;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectMRABPLs)]
    public class ProjectMRABPLsAppService : econsysAppServiceBase, IProjectMRABPLsAppService
    {
        private readonly IRepository<ProjectMRABPL, long> _ProjectMRABPLRepository;
        private readonly IProjectMRABPLsExcelExporter _ProjectMRABPLsExcelExporter;
        private readonly IRepository<ProjectSalesToOpsHand, long> _projectSalesToOpsHandRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectSalesToOpsHand, long> _lookup_projectSalesToOpsHandRepository;
        private readonly IProjectSalesToOpsHandsAppService _projectSalesToOpsHandsAppService;
        public IEventBus EventBus { get; set; }

        public ProjectMRABPLsAppService(
            IRepository<ProjectMRABPL, long> ProjectMRABPLRepository, 
            IProjectMRABPLsExcelExporter ProjectMRABPLsExcelExporter, 
            IRepository<Project, long> lookup_projectRepository, 
            IRepository<ProjectSalesToOpsHand, long> projectSalesToOpsHandRepository, 
            IProjectSalesToOpsHandsAppService projectSalesToOpsHandsAppService
)
        {
            _projectSalesToOpsHandRepository = projectSalesToOpsHandRepository;
            _ProjectMRABPLRepository = ProjectMRABPLRepository;
            _ProjectMRABPLsExcelExporter = ProjectMRABPLsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _projectSalesToOpsHandsAppService = projectSalesToOpsHandsAppService;
            EventBus = NullEventBus.Instance;


        }

        public async Task<PagedResultDto<GetProjectMRABPLForViewDto>> GetAll(GetAllProjectMRABPLsInput input)
        {

            var filteredProjectMRABPLs = _ProjectMRABPLRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectSalesToOpsHandFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ScheMeetWiOpe.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ScheMeetWiOpeFilter), e => e.ScheMeetWiOpe.Contains(input.ScheMeetWiOpeFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment.Contains(input.CommentFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectSalesToOpsHandScheMeetWiOpeFilter), e => e.ProjectSalesToOpsHandFk != null && e.ProjectSalesToOpsHandFk.ScheMeetWiOpe == input.ProjectSalesToOpsHandScheMeetWiOpeFilter);

            var pagedAndFilteredProjectMRABPLs = filteredProjectMRABPLs
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var ProjectMRABPLs = from o in pagedAndFilteredProjectMRABPLs
                                           join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                           from s1 in j1.DefaultIfEmpty()

                                           join o2 in _lookup_projectSalesToOpsHandRepository.GetAll() on o.ProjectSalesToOpsHandId equals o2.Id into j2
                                           from s2 in j2.DefaultIfEmpty()

                                           select new
                                           {

                                               o.ScheMeetWiOpe,
                                               o.Comment,
                                               Id = o.Id,
                                               ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                               ProjectSalesToOpsHandScheMeetWiOpe = s2 == null || s2.ScheMeetWiOpe == null ? "" : s2.ScheMeetWiOpe.ToString()
                                           };

            var totalCount = await filteredProjectMRABPLs.CountAsync();

            var dbList = await ProjectMRABPLs.ToListAsync();
            var results = new List<GetProjectMRABPLForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectMRABPLForViewDto()
                {
                    ProjectMRABPL = new ProjectMRABPLDto
                    {

                        ScheMeetWiOpe = o.ScheMeetWiOpe,
                        Comment = o.Comment,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectSalesToOpsHandScheMeetWiOpe = o.ProjectSalesToOpsHandScheMeetWiOpe
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectMRABPLForViewDto>(
                totalCount,
                results
            );

        }
        public async Task<GetProjectSalesToOpsHandForViewDto> Getsalestoopsdata(long projectid)
        {
            var ProjectSalesToOpsHandDto = await _projectSalesToOpsHandRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
            var output = new GetProjectSalesToOpsHandForViewDto { ProjectSalesToOpsHand = ObjectMapper.Map<ProjectSalesToOpsHandDto>(ProjectSalesToOpsHandDto) };
            return output;


        }
        public async Task<GetProjectMRABPLForViewDto> GetProjectMRABPLForView(int id)
        {
            var ProjectMRABPL = await _ProjectMRABPLRepository.GetAsync(id);

            var output = new GetProjectMRABPLForViewDto { ProjectMRABPL = ObjectMapper.Map<ProjectMRABPLDto>(ProjectMRABPL) };

            if (output.ProjectMRABPL.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectMRABPL.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMRABPLs_Edit)]
        public async Task<GetProjectMRABPLForEditOutput> GetProjectMRABPLForEdit(EntityDto input)
        {
            var ProjectMRABPL = await _ProjectMRABPLRepository.GetAllIncluding().Where(x => x.ProjectId == input.Id).FirstOrDefaultAsync();

            var output = new GetProjectMRABPLForEditOutput { ProjectMRABPL = ObjectMapper.Map<CreateOrEditProjectMRABPLDto>(ProjectMRABPL) };

            if (output.ProjectMRABPL.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectMRABPL.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }
            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectMRABPLDto input)
        {
            ProjectSalesToOpsHand abc = _projectSalesToOpsHandRepository.FirstOrDefault(x => x.ProjectId == input.ProjectId);
            if (abc != null)
            {
                   abc.ScheMeetWiOpeDate = input.ScheMeetWiOpeDate;
                   await _projectSalesToOpsHandRepository.UpdateAsync(abc);
            }
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
            var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.MeetingRequestAcceptanceBySL,
                StatusId = CNodeStatuses.Submit,
                Comment = input.Comment,
                LoggedInUserId = (long)AbpSession.UserId
            });
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMRABPLs_Create)]
        protected virtual async Task Create(CreateOrEditProjectMRABPLDto input)
        {
            var ProjectMRABPL = ObjectMapper.Map<ProjectMRABPL>(input);

            if (AbpSession.TenantId != null)
            {
                ProjectMRABPL.TenantId = (int?)AbpSession.TenantId;
            }

            await _ProjectMRABPLRepository.InsertAsync(ProjectMRABPL);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMRABPLs_Edit)]
        protected virtual async Task Update(CreateOrEditProjectMRABPLDto input)
        {
            var ProjectMRABPL = await _ProjectMRABPLRepository.FirstOrDefaultAsync((int)input.Id);
            ObjectMapper.Map(input, ProjectMRABPL);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMRABPLs_Delete)]
        public async Task Delete(EntityDto input)
        {
            await _ProjectMRABPLRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectMRABPLsToExcel(GetAllProjectMRABPLsForExcelInput input)
        {

            var filteredProjectMRABPLs = _ProjectMRABPLRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectSalesToOpsHandFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ScheMeetWiOpe.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ScheMeetWiOpeFilter), e => e.ScheMeetWiOpe.Contains(input.ScheMeetWiOpeFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment.Contains(input.CommentFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectSalesToOpsHandScheMeetWiOpeFilter), e => e.ProjectSalesToOpsHandFk != null && e.ProjectSalesToOpsHandFk.ScheMeetWiOpe == input.ProjectSalesToOpsHandScheMeetWiOpeFilter);

            var query = (from o in filteredProjectMRABPLs
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_projectSalesToOpsHandRepository.GetAll() on o.ProjectSalesToOpsHandId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         select new GetProjectMRABPLForViewDto()
                         {
                             ProjectMRABPL = new ProjectMRABPLDto
                             {
                                 ScheMeetWiOpe = o.ScheMeetWiOpe,
                                 Comment = o.Comment,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             ProjectSalesToOpsHandScheMeetWiOpe = s2 == null || s2.ScheMeetWiOpe == null ? "" : s2.ScheMeetWiOpe.ToString()
                         });

            var ProjectMRABPLListDtos = await query.ToListAsync();

            return _ProjectMRABPLsExcelExporter.ExportToFile(ProjectMRABPLListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMRABPLs)]
        public async Task<List<ProjectMRABPLProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectMRABPLProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMRABPLs)]
        public async Task<PagedResultDto<ProjectMRABPLProjectSalesToOpsHandLookupTableDto>> GetAllProjectSalesToOpsHandForLookupTable(GetAllForLookupTableInput input)
        {
            var query = _lookup_projectSalesToOpsHandRepository.GetAll().WhereIf(
                   !string.IsNullOrWhiteSpace(input.Filter),
                  e => e.ScheMeetWiOpe != null && e.ScheMeetWiOpe.Contains(input.Filter)
               );

            var totalCount = await query.CountAsync();

            var projectSalesToOpsHandList = await query
                .PageBy(input)
                .ToListAsync();

            var lookupTableDtoList = new List<ProjectMRABPLProjectSalesToOpsHandLookupTableDto>();
            foreach (var projectSalesToOpsHand in projectSalesToOpsHandList)
            {
                lookupTableDtoList.Add(new ProjectMRABPLProjectSalesToOpsHandLookupTableDto
                {
                    Id = projectSalesToOpsHand.Id,
                    DisplayName = projectSalesToOpsHand.ScheMeetWiOpe?.ToString()
                });
            }

            return new PagedResultDto<ProjectMRABPLProjectSalesToOpsHandLookupTableDto>(
                totalCount,
                lookupTableDtoList
            );
        }

    }
}