﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Microsoft.AspNetCore.Http;
using Abp.Events.Bus;
using Newtonsoft.Json;
using asq.econsys.Eco.Utils.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectMeetNotBySalLeads)]
    public class ProjectMeetNotBySalLeadsAppService : econsysAppServiceBase, IProjectMeetNotBySalLeadsAppService
    {
        public IEventBus EventBus { get; set; }
        private readonly IRepository<ProjectMeetNotBySalLead, long> _projectMeetNotBySalLeadRepository;
        private readonly IProjectMeetNotBySalLeadsExcelExporter _projectMeetNotBySalLeadsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly StorageManager _storageManager;

        public ProjectMeetNotBySalLeadsAppService(
            IRepository<ProjectMeetNotBySalLead, long> projectMeetNotBySalLeadRepository, 
            IProjectMeetNotBySalLeadsExcelExporter projectMeetNotBySalLeadsExcelExporter, 
            IRepository<Project, long> lookup_projectRepository, 
            Utils.UtilsAppService utilsAppService, 
            ProjectPermissionManager projectPermissionManager,
            StorageManager storageManager)
        {
            EventBus = NullEventBus.Instance;
            _projectMeetNotBySalLeadRepository = projectMeetNotBySalLeadRepository;
            _projectMeetNotBySalLeadsExcelExporter = projectMeetNotBySalLeadsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _utilsAppService = utilsAppService;
            _projectPermissionManager = projectPermissionManager;
            _storageManager = storageManager;
        }

        public async Task<PagedResultDto<GetProjectMeetNotBySalLeadForViewDto>> GetAll(GetAllProjectMeetNotBySalLeadsInput input)
        {

            var filteredProjectMeetNotBySalLeads = _projectMeetNotBySalLeadRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.MeetingNoteSL.Contains(input.Filter) || e.Comment.Contains(input.Filter) || e.MeetingNotePL.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MeetingNoteSLFilter), e => e.MeetingNoteSL.Contains(input.MeetingNoteSLFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment.Contains(input.CommentFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MeetingNotePLFilter), e => e.MeetingNotePL.Contains(input.MeetingNotePLFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var pagedAndFilteredProjectMeetNotBySalLeads = filteredProjectMeetNotBySalLeads
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectMeetNotBySalLeads = from o in pagedAndFilteredProjectMeetNotBySalLeads
                                           join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                           from s1 in j1.DefaultIfEmpty()

                                           select new
                                           {

                                               o.MeetingNoteSL,
                                               o.Comment,
                                               o.MeetingNotePL,
                                               Id = o.Id,
                                               ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                                           };

            var totalCount = await filteredProjectMeetNotBySalLeads.CountAsync();

            var dbList = await projectMeetNotBySalLeads.ToListAsync();
            var results = new List<GetProjectMeetNotBySalLeadForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectMeetNotBySalLeadForViewDto()
                {
                    ProjectMeetNotBySalLead = new ProjectMeetNotBySalLeadDto
                    {

                        MeetingNoteSL = o.MeetingNoteSL,
                        Comment = o.Comment,
                        MeetingNotePL = o.MeetingNotePL,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectMeetNotBySalLeadForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectMeetNotBySalLeadForViewDto> GetProjectMeetNotBySalLeadForView(int id)
        {
            var projectMeetNotBySalLead = await _projectMeetNotBySalLeadRepository.GetAsync(id);

            var output = new GetProjectMeetNotBySalLeadForViewDto { ProjectMeetNotBySalLead = ObjectMapper.Map<ProjectMeetNotBySalLeadDto>(projectMeetNotBySalLead) };

            if (output.ProjectMeetNotBySalLead.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectMeetNotBySalLead.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMeetNotBySalLeads_Edit)]
        public async Task<GetProjectMeetNotBySalLeadForEditOutput> GetProjectMeetNotBySalLeadForEdit(EntityDto input)
        {
            var projectMeetNotBySalLead = await _projectMeetNotBySalLeadRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectMeetNotBySalLeadForEditOutput { ProjectMeetNotBySalLead = ObjectMapper.Map<CreateOrEditProjectMeetNotBySalLeadDto>(projectMeetNotBySalLead) };

            if (output.ProjectMeetNotBySalLead.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectMeetNotBySalLead.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(string data, ICollection<IFormFile> files)
        {
            var input = JsonConvert.DeserializeObject<CreateOrEditProjectMeetNotBySalLeadDto>(data);
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = (long)input.ProjectId
            });
            if (!check)
            {
                throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            }
            var SalesToOpsHand = new GetProjectMeetNotBySalLeadForViewDto();

            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }

            if (files != null && files.Count > 0)
            {
                List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                foreach (var file in files)
                {
                    projectFilesInput.Add(new ProjectFileInput()
                    {
                        File = file,
                        ProjectId = input.ProjectId,
                        TaskId = CNodeTasks.MeetingNotesbySalesLeader,
                        MetaData = "meeting notes by sl"
                    });
                }
                if (projectFilesInput.Count > 0)
                {
                    var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                }
            }

            var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.MeetingNotesbySalesLeader,
                StatusId = CNodeStatuses.Submit,
                Comment = input.Comment,
                LoggedInUserId = (long)AbpSession.UserId
            });
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMeetNotBySalLeads_Create)]
        protected virtual async Task Create(CreateOrEditProjectMeetNotBySalLeadDto input)
        {
            var projectMeetNotBySalLead = ObjectMapper.Map<ProjectMeetNotBySalLead>(input);

            if (AbpSession.TenantId != null)
            {
                projectMeetNotBySalLead.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectMeetNotBySalLeadRepository.InsertAsync(projectMeetNotBySalLead);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMeetNotBySalLeads_Edit)]
        protected virtual async Task Update(CreateOrEditProjectMeetNotBySalLeadDto input)
        {
            var projectMeetNotBySalLead = await _projectMeetNotBySalLeadRepository.FirstOrDefaultAsync((int)input.Id);
            ObjectMapper.Map(input, projectMeetNotBySalLead);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMeetNotBySalLeads_Delete)]
        public async Task Delete(EntityDto input)
        {
            await _projectMeetNotBySalLeadRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectMeetNotBySalLeadsToExcel(GetAllProjectMeetNotBySalLeadsForExcelInput input)
        {

            var filteredProjectMeetNotBySalLeads = _projectMeetNotBySalLeadRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.MeetingNoteSL.Contains(input.Filter) || e.Comment.Contains(input.Filter) || e.MeetingNotePL.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MeetingNoteSLFilter), e => e.MeetingNoteSL.Contains(input.MeetingNoteSLFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment.Contains(input.CommentFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MeetingNotePLFilter), e => e.MeetingNotePL.Contains(input.MeetingNotePLFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var query = (from o in filteredProjectMeetNotBySalLeads
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetProjectMeetNotBySalLeadForViewDto()
                         {
                             ProjectMeetNotBySalLead = new ProjectMeetNotBySalLeadDto
                             {
                                 MeetingNoteSL = o.MeetingNoteSL,
                                 Comment = o.Comment,
                                 MeetingNotePL = o.MeetingNotePL,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                         });

            var projectMeetNotBySalLeadListDtos = await query.ToListAsync();

            return _projectMeetNotBySalLeadsExcelExporter.ExportToFile(projectMeetNotBySalLeadListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectMeetNotBySalLeads)]
        public async Task<List<ProjectMeetNotBySalLeadProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectMeetNotBySalLeadProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

    }
}