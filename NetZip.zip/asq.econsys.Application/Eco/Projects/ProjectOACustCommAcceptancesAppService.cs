﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.NodeTasks;
using asq.econsys.Eco.Projects;
using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Events.Bus;
using asq.econsys.Eco.Utils;
using asq.econsys.Eco.Utils.Storage;
using asq.econsys.Authorization.Users;
using asq.econsys.Eco.Dto;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances)]
    public class ProjectOACustCommAcceptancesAppService : econsysAppServiceBase, IProjectOACustCommAcceptancesAppService
    {
        private readonly IRepository<ProjectCostDetail, long> _projectCostDetailRepository;
        private readonly IRepository<Project, long> _projectRepository;
        private readonly IRepository<ProjectOACustCommAcceptance, long> _projectOACustCommAcceptanceRepository;
        private readonly IProjectOACustCommAcceptancesExcelExporter _projectOACustCommAcceptancesExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<NodeTask, string> _lookup_nodeTaskRepository;
        private readonly IRepository<ProjectOAReview, long> _lookup_projectOAReviewRepository;
        private readonly IRepository<ProjectQuoteForm, long> _projectQuoteFormRepository;
        private readonly IRepository<ProjectStatusOfSubmittedQuote, long> _projectStatusOfSubmittedQuoteRepository;
        private readonly IRepository<ProjectEstimate, long> _ProjectEstimates;
        private readonly IRepository<ProjectQuoteMeta, long> _lookup_quoteRepository;
        private readonly ProjectPermissionManager _projectPermissionManager;

        private readonly IRepository<ProjectFile, Guid> _repositoryProjectFile;
        private readonly IBlobMethods _blobMethods;
        private readonly IWebHostEnvironment _env;
        private readonly UserManager _userManager;
        private readonly StorageManager _storageManager;
        public IEventBus EventBus { get; set; }


        public ProjectOACustCommAcceptancesAppService(
            IRepository<ProjectOACustCommAcceptance, long> projectOACustCommAcceptanceRepository, 
            IProjectOACustCommAcceptancesExcelExporter projectOACustCommAcceptancesExcelExporter,
            IRepository<Project, long> lookup_projectRepository,
            IRepository<NodeTask, string> lookup_nodeTaskRepository,
            IRepository<ProjectOAReview, long> lookup_projectOAReviewRepository,
            IRepository<Project, long> projectRepository,
            IRepository<ProjectQuoteForm, long> projectQuoteFormRepository, UserManager userManager,
            IRepository<ProjectStatusOfSubmittedQuote, long> projectStatusOfSubmittedQuoteRepository,
            IWebHostEnvironment env,
            IRepository<ProjectFile, Guid> repositoryProjectFile,
            IBlobMethods blobMethods,
            IRepository<ProjectEstimate, long> projectEstimates,
            IRepository<ProjectQuoteMeta, long> lookup_quoteRepository,
            ProjectPermissionManager projectPermissionManager, IRepository<ProjectCostDetail, System.Int64> projectCostDetailRepository, StorageManager storageManager)
        {
            _projectOACustCommAcceptanceRepository = projectOACustCommAcceptanceRepository;
            _projectOACustCommAcceptancesExcelExporter = projectOACustCommAcceptancesExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_nodeTaskRepository = lookup_nodeTaskRepository;
            _lookup_projectOAReviewRepository = lookup_projectOAReviewRepository;

            EventBus = NullEventBus.Instance;
            _projectRepository = projectRepository;
            _projectQuoteFormRepository = projectQuoteFormRepository;
            _projectStatusOfSubmittedQuoteRepository = projectStatusOfSubmittedQuoteRepository;
            _repositoryProjectFile = repositoryProjectFile;
            _env = env;
            _userManager = userManager;
            _blobMethods = blobMethods;
            _ProjectEstimates = projectEstimates;
            _lookup_quoteRepository = lookup_quoteRepository;
            _projectPermissionManager = projectPermissionManager;
            _projectCostDetailRepository = projectCostDetailRepository;
            _storageManager = storageManager;
        }



        #region Upload File Started

        public async Task<string> DownloadRequestDocument(string azureFileUrl)
        {
            string linkWithToken = await _blobMethods.GenerateAzureSasTokenUrl(new Uri(azureFileUrl));
            return linkWithToken;
        }
        public async Task<string> GetDocument(Guid id)
        {
            try
            {
                ProjectFile projectFile = await _repositoryProjectFile.GetAsync(id);

                var loggedInUser = await _userManager.GetUserByIdAsync((long)AbpSession.UserId);
                bool isAdmin = await _userManager.IsInRoleAsync(loggedInUser, "Admin");
                //if (projectFile.User.Id == (long)AbpSession.UserId || isAdmin)
                //{
                var tenancyName = "stc-econsys";// await GetTenancyNameFromTenantId();
                var container = await _blobMethods.SetUpContainer(tenancyName);
                var blob = await _blobMethods.DownloadToByteArray(container, projectFile.MetaData, projectFile.Name);

                string pdfBase64 = "data:" + projectFile.Extension + ";base64," + Convert.ToBase64String(blob);
                return pdfBase64;
                //}
                //return null;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public async Task<List<ProjectFileDto>> GetProjectFileList(int ProjectId)
        {
            var ProjectListView = await _repositoryProjectFile.GetAll()
                .Where(x => x.ProjectId == ProjectId && x.ParentId == null && x.NodeAction == "uploadObj")
                .Select(projectFile => new ProjectFileDto
                {
                    Id = projectFile.Id,
                    Name = projectFile.Name,
                    FullPath = projectFile.FullPath,
                    Extension = projectFile.Extension
                }).ToListAsync();
            return ProjectListView;
        }
        public async Task<List<ProjectFileDto>> GetProjectFileListTwo(int ProjectId)
        {
            var ProjectListView = await _repositoryProjectFile.GetAll()
                .Where(x => x.ProjectId == ProjectId && x.ParentId == null && x.NodeAction == "uploadObj1")
                .Select(projectFile => new ProjectFileDto
                {
                    Id = projectFile.Id,
                    Name = projectFile.Name,
                    FullPath = projectFile.FullPath,
                    Extension = projectFile.Extension
                }).ToListAsync();
            return ProjectListView;
        }
        public async void UploadFileFromAzure(List<string> fileIdList)
        {
            if (fileIdList.Count > 0)
            {
                foreach (var item in fileIdList)
                {
                    ProjectFile file = _repositoryProjectFile.FirstOrDefault(x => x.Id.ToString() == item);
                    file.ParentId = file.Id;
                    file.Id = Guid.Empty;
                    file.CreationTime = DateTime.Now;
                    file.CreatorUserId = AbpSession.UserId;
                    await _repositoryProjectFile.InsertAsync(file);
                }
            }
        }

        #endregion Upload File End

        public async Task<GetProjectForViewDto> CreateOrEditPVCApproval(CreateOrEditProjectOACustCommAcceptancePVCApprovalDto input)
        {
            var oaCustComAcceptanceDetails = new GetProjectOACustCommAcceptanceForViewDto();
            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.ProjectProgramValueChangeApproval,
                StatusId = input.PVCStatus,
                Comment = input.Comments,
                LoggedInUserId = (long)AbpSession.UserId,
                ProjectId = input.ProjectId.Value
            });

            project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.projectOACustCommAcceptance = oaCustComAcceptanceDetails;
            return result;
        }
        public async Task<string> GetProjectQuoteProjectSellValue(long projectid)
        {
            //To Do Check
            string OverAllprojectSell;
            var Quotefrm = await _projectQuoteFormRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();

            var _lookupProject = await _projectQuoteFormRepository.FirstOrDefaultAsync((long)Quotefrm.Id);
            OverAllprojectSell = _lookupProject?.OverAllProjectSell.ToString();
            return OverAllprojectSell;
        }

        public async Task<OAPreSalesValueDisplayView> GetProjectTotalSellAndProposedDateValues(long projectid)
        {
            //To Do Check
            var estimatesform = _ProjectEstimates.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id);
            var Quotefrm = _projectQuoteFormRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id);
            var ProjectPresalesDetails = await (from estimateRepo in estimatesform
                                         join ProjectQuoteRepo in Quotefrm on estimateRepo.ProjectId equals ProjectQuoteRepo.ProjectId
                                         select new OAPreSalesValueDisplayView
                                         {
                                             ProposedStartDate = estimateRepo.ProjectStartDate,
                                             ProposedEndDate = estimateRepo.ProjectEndDate,
                                             ProposedContractValue = ProjectQuoteRepo.OverAllProjectSell
                                         }).FirstOrDefaultAsync();
            return ProjectPresalesDetails;
        }

        public async Task<GetProjectStatusOfSubmittedQuoteForViewDto> GetStatusOfSubmmitedQuoteData(long projectid)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = projectid
            });

            if (!check)
            {
                throw new UserFriendlyException("Access Denied", "You do not have the required role for this project");
            }
            //To Do Check
            var StatusOfSubmittedQuoteDto = await _projectStatusOfSubmittedQuoteRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();

             var output = new GetProjectStatusOfSubmittedQuoteForViewDto { StatusOfSubmittedQuote = ObjectMapper.Map<StatusOfSubmittedQuoteDto>(StatusOfSubmittedQuoteDto) }; 
             return output;

            /*
             var statusOfSubmitQuote = await _projectStatusOfSubmittedQuoteRepository.GetAll().Where(x => x.ProjectId == projectid).ToListAsync();
             ProjectQuoteMeta QuoteMeta = new ProjectQuoteMeta();
             if (statusOfSubmitQuote != null)
             {
                 List<CreateOrEditProjectStatusOfSubmittedQuoteDto> tprojectStatusOfSubmitQuotes = new List<CreateOrEditProjectStatusOfSubmittedQuoteDto>();

                 foreach (var item in statusOfSubmitQuote)
                 {
                     QuoteMeta = _lookup_quoteRepository.GetAll().Where(x => x.ProjectId == projectid && x.ProjectStatusOfSubmittedQuoteId == item.Id).ToList().FirstOrDefault();
                     var statusOfsubmittedQuote = ObjectMapper.Map<CreateOrEditProjectStatusOfSubmittedQuoteDto>(item);
                     var mappedQuoteMeta = ObjectMapper.Map<QuoteMetaDto>(QuoteMeta);
                     statusOfsubmittedQuote.QuoteMeta = mappedQuoteMeta;
                     tprojectStatusOfSubmitQuotes.Add(statusOfsubmittedQuote);
                 }
                 return tprojectStatusOfSubmitQuotes;
             }*/
        }

        public async Task<PagedResultDto<GetProjectOACustCommAcceptanceForViewDto>> GetAll(GetAllProjectOACustCommAcceptancesInput input)
        {
            var filteredProjectOACustCommAcceptances = _projectOACustCommAcceptanceRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.NodeTaskFk)
                        .Include(e => e.ProjectOAReviewFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ResponseText.Contains(input.Filter) || e.Comments.Contains(input.Filter) || e.Status.Contains(input.Filter))
                        .WhereIf(input.IsRecReqComOfWorkFilter.HasValue && input.IsRecReqComOfWorkFilter > -1, e => (input.IsRecReqComOfWorkFilter == 1 && e.IsRecReqComOfWork == null) || (input.IsRecReqComOfWorkFilter == 0 && !e.IsRecReqComOfWork == null))
                        .WhereIf(input.IsLimitFinalQuoteFilter.HasValue && input.IsLimitFinalQuoteFilter > -1, e => (input.IsLimitFinalQuoteFilter == 1 && e.IsLimitFinalQuote == null) || (input.IsLimitFinalQuoteFilter == 0 && !e.IsLimitFinalQuote == null))
                        .WhereIf(input.IsRecImpLimitExpFilter.HasValue && input.IsRecImpLimitExpFilter > -1, e => (input.IsRecImpLimitExpFilter == 1 && e.IsRecImpLimitExp == null) || (input.IsRecImpLimitExpFilter == 0 && !e.IsRecImpLimitExp == null))
                        .WhereIf(input.MinExpenditureLimitFilter != null, e => e.ExpenditureLimit >= input.MinExpenditureLimitFilter)
                        .WhereIf(input.MaxExpenditureLimitFilter != null, e => e.ExpenditureLimit <= input.MaxExpenditureLimitFilter)
                        .WhereIf(input.IsRecimpTimeLimitValidityFilter.HasValue && input.IsRecimpTimeLimitValidityFilter > -1, e => (input.IsRecimpTimeLimitValidityFilter == 1 && e.IsRecimpTimeLimitValidity == null) || (input.IsRecimpTimeLimitValidityFilter == 0 && !e.IsRecimpTimeLimitValidity == null))
                        .WhereIf(input.MinProposedStartDateFilter != null, e => e.ProposedStartDate >= input.MinProposedStartDateFilter)
                        .WhereIf(input.MaxProposedStartDateFilter != null, e => e.ProposedStartDate <= input.MaxProposedStartDateFilter)
                        .WhereIf(input.MinProposedEndDateFilter != null, e => e.ProposedEndDate >= input.MinProposedEndDateFilter)
                        .WhereIf(input.MaxProposedEndDateFilter != null, e => e.ProposedEndDate <= input.MaxProposedEndDateFilter)
                        .WhereIf(input.MinProposedStartDateCommitFilter != null, e => e.SlrProposedStartDateCommit >= input.MinProposedStartDateCommitFilter)
                        .WhereIf(input.MaxProposedStartDateCommitFilter != null, e => e.SlrProposedStartDateCommit <= input.MaxProposedStartDateCommitFilter)
                        .WhereIf(input.MinProposedEndDateCommitFilter != null, e => e.SlrProposedEndDateCommit >= input.MinProposedEndDateCommitFilter)
                        .WhereIf(input.MaxProposedEndDateCommitFilter != null, e => e.SlrProposedEndDateCommit <= input.MaxProposedEndDateCommitFilter)
                        .WhereIf(input.IsRecOtherItemFurtherReviewFilter.HasValue && input.IsRecOtherItemFurtherReviewFilter > -1, e => (input.IsRecOtherItemFurtherReviewFilter == 1 && e.IsRecOtherItemFurtherReview == null) || (input.IsRecOtherItemFurtherReviewFilter == 0 && !e.IsRecOtherItemFurtherReview == null))
                        .WhereIf(input.IsIntroTermsConditionFilter.HasValue && input.IsIntroTermsConditionFilter > -1, e => (input.IsIntroTermsConditionFilter == 1 && e.IsIntroTermsCondition == null) || (input.IsIntroTermsConditionFilter == 0 && !e.IsIntroTermsCondition == null))
                        .WhereIf(input.IsScopeDetClientComFinQuoteScopeFilter.HasValue && input.IsScopeDetClientComFinQuoteScopeFilter > -1, e => (input.IsScopeDetClientComFinQuoteScopeFilter == 1 && e.IsSlrScopeDetClientComFinQuoteScope == null) || (input.IsScopeDetClientComFinQuoteScopeFilter == 0 && !e.IsSlrScopeDetClientComFinQuoteScope == null))
                        .WhereIf(input.IsDocRefClientComQuoteBaseFilter.HasValue && input.IsDocRefClientComQuoteBaseFilter > -1, e => (input.IsDocRefClientComQuoteBaseFilter == 1 && e.IsSlrDocRefClientComQuoteBase == null) || (input.IsDocRefClientComQuoteBaseFilter == 0 && !e.IsSlrDocRefClientComQuoteBase == null))
                        .WhereIf(input.IsTermCondComQuoteBasedOnFilter.HasValue && input.IsTermCondComQuoteBasedOnFilter > -1, e => (input.IsTermCondComQuoteBasedOnFilter == 1 && e.IsSlrTermCondComQuoteBasedOn == null) || (input.IsTermCondComQuoteBasedOnFilter == 0 && !e.IsSlrTermCondComQuoteBasedOn == null))
                        .WhereIf(input.IsHappyCLAsExcKeyTechFinalQuoteFilter.HasValue && input.IsHappyCLAsExcKeyTechFinalQuoteFilter > -1, e => (input.IsHappyCLAsExcKeyTechFinalQuoteFilter == 1 && e.IsSlrHappyCLAsExcKeyTechFinalQuote == null) || (input.IsHappyCLAsExcKeyTechFinalQuoteFilter == 0 && !e.IsSlrHappyCLAsExcKeyTechFinalQuote == null))
                        .WhereIf(input.MinProposedContractValueFilter != null, e => e.SlrProposedContractValueCommit >= input.MinProposedContractValueFilter)
                        .WhereIf(input.MaxProposedContractValueFilter != null, e => e.SlrProposedContractValueCommit <= input.MaxProposedContractValueFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ResponseTextFilter), e => e.ResponseText == input.ResponseTextFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments == input.CommentsFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.statusFilter), e => e.Status == input.statusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectOAReviewTitleFilter), e => e.ProjectOAReviewFk != null && e.ProjectOAReviewFk.Title == input.ProjectOAReviewTitleFilter)
                        ;

            var pagedAndFilteredProjectOACustCommAcceptances = filteredProjectOACustCommAcceptances
                .OrderBy(input.Sorting ?? "Id asc")
                .PageBy(input);

            var projectOACustCommAcceptances = from o in pagedAndFilteredProjectOACustCommAcceptances
                                        join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                        from s1 in j1.DefaultIfEmpty()
                                        //To Do Check About
                                        //join o2 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o2.Id into j2
                                        //from s2 in j2.DefaultIfEmpty()

                                        //join o3 in _lookup_projectOAReviewRepository.GetAll() on o.ProjectOAReviewId equals o3.Id into j3
                                        //from s3 in j3.DefaultIfEmpty()

                                        select new
                                        {
                                            o.IsRecReqComOfWork,
                                            o.IsLimitFinalQuote,
                                            o.IsRecImpLimitExp,
                                            o.ExpenditureLimit,
                                            o.IsRecimpTimeLimitValidity,
                                            o.ProposedStartDate,
                                            o.ProposedEndDate,
                                            o.SlrProposedStartDateCommit,
                                            o.SlrProposedEndDateCommit,
                                            o.IsRecOtherItemFurtherReview,
                                            o.IsIntroTermsCondition,
                                            o.IsSlrScopeDetClientComFinQuoteScope,
                                            o.IsSlrDocRefClientComQuoteBase,
                                            o.IsSlrTermCondComQuoteBasedOn,
                                            o.IsSlrHappyCLAsExcKeyTechFinalQuote,
                                            o.IsSlrProposedContractValueAgreed,
                                            o.ResponseText,
                                            o.Comments,
                                            o.Status,
                                            Id = o.Id,
                                            ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                            NodeTaskTaskName = "",//s2 == null || s2.TaskName == null ? "" : s2.TaskName.ToString(),
                                            ProjectOAReviewTitle = "",//s3 == null || s3.Title == null ? "" : s3.Title.ToString()
                                            o.StringField1,
                                            o.StringField2,
                                            o.StringField3,
                                            o.StringField4,
                                            o.StringField5,
                                            o.DecimalField1,
                                            o.DecimalField2,
                                            o.DecimalField3,
                                            o.DecimalField4,
                                            o.DecimalField5,
                                            o.DateField1,
                                            o.DateField2,
                                            o.DateField3,
                                            o.DateField4,
                                            o.DateField5,
                                        };

            var totalCount = await filteredProjectOACustCommAcceptances.CountAsync();

            var dbList = await projectOACustCommAcceptances.ToListAsync();
            var results = new List<GetProjectOACustCommAcceptanceForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectOACustCommAcceptanceForViewDto()
                {
                    projectOACustCommAcceptance = new ProjectOACustCommAcceptanceDto
                    {
                        IsRecReqComOfWork = o.IsRecReqComOfWork,
                        IsLimitFinalQuote = o.IsLimitFinalQuote,
                        IsRecImpLimitExp = o.IsRecImpLimitExp,
                        ExpenditureLimit = o.ExpenditureLimit,
                        IsRecimpTimeLimitValidity = o.IsRecimpTimeLimitValidity,
                        ProposedStartDate = o.ProposedStartDate,
                        ProposedEndDate = o.ProposedEndDate,
                        SLRProposedStartDateCommit = o.SlrProposedStartDateCommit,
                        SLRProposedEndDateCommit = o.SlrProposedEndDateCommit,
                        IsRecOtherItemFurtherReview = o.IsRecOtherItemFurtherReview,
                        IsIntroTermsCondition = o.IsIntroTermsCondition,
                        IsSLRScopeDetClientComFinQuoteScope = o.IsSlrScopeDetClientComFinQuoteScope,
                        IsSLRDocRefClientComQuoteBase = o.IsSlrDocRefClientComQuoteBase,
                        IsSLRTermCondComQuoteBasedOn = o.IsSlrTermCondComQuoteBasedOn,
                        IsSLRHappyCLAsExcKeyTechFinalQuote = o.IsSlrHappyCLAsExcKeyTechFinalQuote,
                        IsSLRProposedContractValueAgreed = o.IsSlrProposedContractValueAgreed,
                        ResponseText = o.ResponseText,
                        Comments = o.Comments,
                        status = o.Status,
                        Id = o.Id,
                        StringField1 = o.StringField1,
                        StringField2 = o.StringField2,
                        StringField3 = o.StringField3,
                        StringField4 = o.StringField4,
                        StringField5 = o.StringField5,
                        DecimalField1 = o.DecimalField1,
                        DecimalField2 = o.DecimalField2,
                        DecimalField3 = o.DecimalField3,
                        DecimalField4 = o.DecimalField4,
                        DecimalField5 = o.DecimalField5,
                        DateField1 = o.DateField1,
                        DateField2 = o.DateField2,
                        DateField3 = o.DateField3,
                        DateField4 = o.DateField4,
                        DateField5 = o.DateField5,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    NodeTaskTaskName = o.NodeTaskTaskName,
                    ProjectOAReviewTitle = o.ProjectOAReviewTitle
                };
                results.Add(res);
            }

            return new PagedResultDto<GetProjectOACustCommAcceptanceForViewDto>(
                totalCount,
                results
            );
        }

        public async Task<GetProjectOACustCommAcceptanceForViewDto> GetProjectOACustCommAcceptanceForView(long id)
        {
            var projectOACustCommAcceptance = _projectOACustCommAcceptanceRepository.GetAll().Where(x=>x.ProjectId == (id));

            var output = new GetProjectOACustCommAcceptanceForViewDto { projectOACustCommAcceptance = ObjectMapper.Map<ProjectOACustCommAcceptanceDto>(projectOACustCommAcceptance) };

            if (output.projectOACustCommAcceptance.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.projectOACustCommAcceptance.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.projectOACustCommAcceptance.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.projectOACustCommAcceptance.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            if (output.projectOACustCommAcceptance.ProjectOAReviewId != null)
            {
                var _lookupProjectOAReview = await _lookup_projectOAReviewRepository.FirstOrDefaultAsync((long)output.projectOACustCommAcceptance.ProjectOAReviewId);
                output.ProjectOAReviewTitle = _lookupProjectOAReview?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances_Edit)]
        public async Task<GetProjectOACustCommAcceptanceForEditOutput> GetProjectOACustCommAcceptanceForEdit(EntityDto<long> input)
        {
            // TODO: get proper row
            var projectOACustCommAcceptance =await _projectOACustCommAcceptanceRepository.GetAll().Where(x=> x.ProjectId == input.Id).OrderByDescending(x=>x.Id).FirstOrDefaultAsync();
            
             var output =  new GetProjectOACustCommAcceptanceForEditOutput { ProjectOACustCommAcceptance = ObjectMapper.Map<CreateOrEditProjectOACustCommAcceptanceDto>(projectOACustCommAcceptance) };
            
            /*
            if (output.ProjectOACustCommAcceptance.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectOACustCommAcceptance.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            if (output.ProjectOACustCommAcceptance.ProjectOAReviewId != null)
            {
                var _lookupProjectOAReview = await _lookup_projectOAReviewRepository.FirstOrDefaultAsync((long)output.ProjectOACustCommAcceptance.ProjectOAReviewId);
                output.ProjectOAReviewTitle = _lookupProjectOAReview?.Title?.ToString();
            }*/

             return  output;
        }
        public async Task<bool> UploadFileCustomerCommitmentAcceptance([FromForm] OACustCommUploadFile input)
        {
            #region Upload Functionality
            var loggedInUser = await _userManager.GetUserByIdAsync((long)AbpSession.UserId);
            if (input.Attachments != null && input.Attachments.Count > 0)
            {
                /// TODO - upload documents
                /// 
                var tenancyName = "stc-econsys";// await GetTenancyNameFromTenantId();
                var container = await _blobMethods.SetUpContainer(tenancyName);
                //_blobMethods.CloudBlobContainer = container;

                string documentFolder = "Projects";
                //string NodeAction = "";
                foreach (var file in input.Attachments)
                {
                    //To Do Check because cannot get Node Task Action from IFileCollection
                    string[] words = file.FileName.Split(':');
                    string fileName = words[0];
                    string NodeTaskAction = words[1];
                        
                    string targetFilePath = Path.Combine(_env.WebRootPath, "UploadDocuments", fileName);
                    //var FileName1 = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Replace("\"", "");

                    //Uploading same file(s) to wwwroot folder
                    if (!Directory.Exists(targetFilePath))
                    {
                        Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "UploadDocuments"));
                    }
                    string strFileExt = Path.GetExtension(fileName);
                    //using (var stream = new FileStream(targetFilePath, FileMode.Create))
                    //{
                    //    //Upload the file to the specified path
                    //    file.CopyTo(stream);

                    //    stream.Position = 0;
                    //}

                    //process file
                    using (var ms = new MemoryStream())
                    {
                        //To Do Check because cannot get Node Task Action from IFileCollection
                        var FileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Split(':')[0].Replace("\"", "");
                        //take out the timestamp
                        //var Timestamp = FindTextBetween(FileName, "[", "]");
                        //FileName = FileName.Replace("[" + Timestamp + "]", "");

                        var FileNameWithoutExtension = Path.GetFileNameWithoutExtension(FileName);
                        var Extension = Path.GetExtension(FileName);
                        //put the timestamp back in
                        //FileName = documentFolder + "/" + FileNameWithoutExtension + "[" + GetTimestamp() + "]" + Extension;
                        FileName = documentFolder + "/" + FileNameWithoutExtension + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + Extension;

                        var DisplayString = L("DocumentUploadedBy", loggedInUser.FullName, DateTime.Now.ToLocalTime().ToString("ddd d MMM yyyy H:mm"));
                        var MediaType = file.ContentType;

                        file.CopyTo(ms);
                        var fileBytes = ms.ToArray();

                        // post to BlobStorage
                        var metaData = new Dictionary<string, string>();
                        metaData.Add("EntityType", "Project");
                        //metaData.Add("EntityType", typeof([ClassNameOfContext]).GetProperty(name));

                        metaData.Add("ProjectId", input.ProjectId.ToString());
                        metaData.Add("NodeTaskId", NodeTaskAction == "uploadObj2" ? CNodeTasks.SalesLeaderreviewofCustomerCommitment :  CNodeTasks.CustomerCommitmentAcceptance);
                        //metaData.Add("Nod")
                        metaData.Add("NodeActionId", NodeTaskAction);
                        metaData.Add("MediaType", MediaType);
                        //metaData.Add("TenantId", AbpSession.TenantId.ToString());
                        metaData.Add("UserId", AbpSession.UserId.ToString());
                        metaData.Add("DisplayString", DisplayString);
                        metaData.Add("DocumentFolder", documentFolder);

                        var blob = await _blobMethods.UploadFromByteArray(fileBytes, FileName, MediaType, metaData, "no-cache");

                        // Get a reference to a blob  
                        //CloudBlockBlob blockBlob = container.GetBlockBlobReference(file.FileName);
                        string URL = blob.Uri.ToString();
                    }
                }
            }
            #endregion
            return true;
        }
        public async Task<GetProjectCostDetailForViewDto> UpdateBidInfoCustCommAcceptance(CreateOrEditProjectCostDetailDto input)
        {
            var ProjectCostDetails =  _projectCostDetailRepository.GetAll().Where(x => x.ProjectId == input.ProjectId && x.NodeTaskId == CNodeTasks.CustomerCommitmentAcceptance
                                    && x.ProjectOACustCommAcceptanceId == null).ToList();

            ObjectMapper.Map(input, ProjectCostDetails);
            return new GetProjectCostDetailForViewDto { ProjectCostDetail = ObjectMapper.Map<ProjectCostDetailDto>(_projectCostDetailRepository.Get((long)input.Id)) };
        }

        [AbpAuthorize(AppPermissions.Pages_Projects_Create)]
        [HttpPost]
        public async Task<GetProjectForViewDto> CreateOrEdit([FromForm]CreateOrEditOACustCommAcceptanceDto data)
        {
            CreateOrEditProjectOACustCommAcceptanceDto input = new CreateOrEditProjectOACustCommAcceptanceDto();
            input = JsonConvert.DeserializeObject<CreateOrEditProjectOACustCommAcceptanceDto>(data.OAData);
            var oaCustComAcceptanceDetails = new GetProjectOACustCommAcceptanceForViewDto();

            if (input.Id == null)
            {
                var StatusOfSubmittedQuote = await _projectStatusOfSubmittedQuoteRepository.GetAll().Where(x => x.ProjectId == input.ProjectId).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
                input.ProjectStatusOfSubmittedId = StatusOfSubmittedQuote.Id;
                input.CreatorUserId = (long)AbpSession.UserId;
                input.CreationTime = DateTime.UtcNow;
                oaCustComAcceptanceDetails = await Create(input);

            }
            else
            {
                input.LastModifierUserId = (long)AbpSession.UserId;
                input.LastModificationTime = DateTime.UtcNow;
                oaCustComAcceptanceDetails = await Update(input);

            }

            if (data.Attachments != null && data.Attachments.Count > 0)
            {
                List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                foreach (var file in data.Attachments)
                {
                    projectFilesInput.Add(new ProjectFileInput()
                    {
                        File = file,
                        ProjectId = (long)input.ProjectId,
                        TaskId = (input.CustomerCommitmentType.ToLower() == CustomerCommitmentTypes.Po.ToLower() || input.CustomerCommitmentType.ToLower() == CustomerCommitmentTypes.Subcontract.ToLower()) ? CNodeTasks.SalesLeaderreviewofCustomerCommitment : (input.CustomerCommitmentType.ToLower() == CNodeTasks.CustomerCommitmentAcceptanceVerbalCLApproval.ToLower()) ? CNodeTasks.CustomerCommitmentAcceptanceVerbalCLApproval : CNodeTasks.CustomerCommitmentAcceptance,
                        MetaData = "CCAcceptance"
                    });
                }

                if (projectFilesInput.Count > 0)
                {
                    var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                }
            }

            //Comment History & Project Action Changes
            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                ProjectId = input.ProjectId.Value,
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = (input.CustomerCommitmentType.ToLower() ==  CustomerCommitmentTypes.Po.ToLower() || input.CustomerCommitmentType.ToLower() == CustomerCommitmentTypes.Subcontract.ToLower()) ? CNodeTasks.SalesLeaderreviewofCustomerCommitment : (input.CustomerCommitmentType.ToLower() == CNodeTasks.CustomerCommitmentAcceptanceVerbalCLApproval.ToLower()) ? CNodeTasks.CustomerCommitmentAcceptanceVerbalCLApproval : CNodeTasks.CustomerCommitmentAcceptance,
                StatusId = input.status,
                Comment = (input.CustomerCommitmentType.ToLower() == CustomerCommitmentTypes.Po.ToLower() || input.CustomerCommitmentType.ToLower() == CustomerCommitmentTypes.Subcontract.ToLower()) ? input.SlrComments : (input.CustomerCommitmentType.ToLower() == CNodeTasks.CustomerCommitmentAcceptanceVerbalCLApproval.ToLower()) ? input.Comments : input.Comments,
                LoggedInUserId = (long)AbpSession.UserId
            });
            //Update Bid Info ProjectOACustComId in Cost Details
            CreateOrEditProjectCostDetailDto inputCostDetails = new CreateOrEditProjectCostDetailDto();
            inputCostDetails.ProjectId = input.ProjectId;
            inputCostDetails.ProjectOACustCommAcceptanceId = oaCustComAcceptanceDetails.projectOACustCommAcceptance.Id;
            UpdateBidInfoCustCommAcceptance(inputCostDetails);

            project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.projectOACustCommAcceptance = oaCustComAcceptanceDetails;

            return result;
        }

        public async Task<GetProjectForViewDto> CreateOrEditVCApproval(CreateOrEditProjectOACustCommAcceptanceVCApprovalDto input)
        {

            var oaCustComAcceptanceDetails = new GetProjectOACustCommAcceptanceForViewDto(); ;
            input.VCApprovalCreatorUserId = (long)AbpSession.UserId;
            input.VCApprovalCreationTime = DateTime.UtcNow;
            oaCustComAcceptanceDetails = await UpdateVCApproval(input);

            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.CustomerCommitmentAcceptanceVerbalCLApproval,
                StatusId = input.VCApprovalstatus,
                Comment = input.VCApprovalComments,
                LoggedInUserId = (long)AbpSession.UserId,
                ProjectId = input.ProjectId.Value
            });

            project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.projectOACustCommAcceptance = oaCustComAcceptanceDetails;
            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances_Create)]
        protected virtual async Task<GetProjectOACustCommAcceptanceForViewDto> Create(CreateOrEditProjectOACustCommAcceptanceDto input)
        {
            int TenantId = 0;
            if (AbpSession.TenantId != null)
            {
                TenantId = (int)AbpSession.TenantId;
            }
            ProjectOAReview dtoReview = new ProjectOAReview();
            dtoReview.TenantId = TenantId;
            dtoReview.ProjectId = (long)input.ProjectId;
            dtoReview.Title = "Current";
            dtoReview.IsCurrent = true;
            dtoReview.DisplayOrder = 1;
            long ProjectOAReviewdet = await _lookup_projectOAReviewRepository.InsertAndGetIdAsync(dtoReview);
            input.ProjectOAReviewId = ProjectOAReviewdet;

            long projectOACustCommAcceptanceid = 0;
            var projectOACustCommAcceptance = ObjectMapper.Map<ProjectOACustCommAcceptance>(input);
            if (AbpSession.TenantId != null)
            {
                projectOACustCommAcceptance.TenantId = TenantId;
            }
            projectOACustCommAcceptanceid = await _projectOACustCommAcceptanceRepository.InsertAndGetIdAsync(projectOACustCommAcceptance);
            var output = new GetProjectOACustCommAcceptanceForViewDto { projectOACustCommAcceptance = ObjectMapper.Map<ProjectOACustCommAcceptanceDto>(_projectOACustCommAcceptanceRepository.Get(projectOACustCommAcceptanceid)) };

            return output;
        }

        public async Task<bool> ResetTask(CreateOrEditProjectOACustCommAcceptanceResetDto input)
        {
            
            //To Do Check About
            var IdDetails = await _projectOACustCommAcceptanceRepository.GetAll().Where(x => x.ProjectId == input.ProjectId).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
            if (IdDetails != null)
            {
                var projectOACustCommAcceptance = await _projectOACustCommAcceptanceRepository.FirstOrDefaultAsync((long)IdDetails.Id);
                input.LastModifierUserId = (long)AbpSession.UserId;
                input.LastModificationTime = DateTime.UtcNow;
                ObjectMapper.Map(input, projectOACustCommAcceptance);
            }
            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.CustomerCommitmentAcceptance,
                StatusId = input.status,
                Comment = input.Comments
            });
            return true;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances_Edit)]
        protected virtual async Task<GetProjectOACustCommAcceptanceForViewDto> Update(CreateOrEditProjectOACustCommAcceptanceDto input)
        {
            input.ExpenditureLimit = input.IsRecImpLimitExp ==false ? null : input.ExpenditureLimit;
            input.ProposedStartDate = input.IsRecimpTimeLimitValidity == false ? null : input.ProposedStartDate;
            input.ProposedEndDate = input.IsRecimpTimeLimitValidity == false ? null : input.ProposedEndDate;
            var projectOACustCommAcceptance = await _projectOACustCommAcceptanceRepository.FirstOrDefaultAsync((long)input.Id);
            input.ProjectOAReviewId = projectOACustCommAcceptance.ProjectOAReviewId;
            ObjectMapper.Map(input, projectOACustCommAcceptance);
            return new GetProjectOACustCommAcceptanceForViewDto { projectOACustCommAcceptance = ObjectMapper.Map<ProjectOACustCommAcceptanceDto>(_projectOACustCommAcceptanceRepository.Get((long)input.Id)) };
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances_Edit)]
        protected virtual async Task<GetProjectOACustCommAcceptanceForViewDto> UpdateVCApproval(CreateOrEditProjectOACustCommAcceptanceVCApprovalDto input)
        {
            //To Do Check About
            var IdDetails = await _projectOACustCommAcceptanceRepository.GetAll().Where(x => x.ProjectId == input.ProjectId).OrderByDescending(x => x.Id).FirstOrDefaultAsync();

            var projectOACustCommAcceptance = await _projectOACustCommAcceptanceRepository.FirstOrDefaultAsync((long)IdDetails.Id);
            ObjectMapper.Map(input, projectOACustCommAcceptance);
            return new GetProjectOACustCommAcceptanceForViewDto { projectOACustCommAcceptance = ObjectMapper.Map<ProjectOACustCommAcceptanceDto>(_projectOACustCommAcceptanceRepository.Get((long)IdDetails.Id)) };
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectOACustCommAcceptanceRepository.DeleteAsync(input.Id);
        }

        //public async Task<FileDto> GetProjectOACustCommAcceptancesToExcel(GetAllProjectOACustCommAcceptancesForExcelInput input)
        //{
        //    var filteredProjectOACustCommAcceptances = _projectOACustCommAcceptanceRepository.GetAll()
        //                .Include(e => e.ProjectFk)
        //                .Include(e => e.NodeTaskFk)
        //                .Include(e => e.ProjectOAReviewFk)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ResponseText.Contains(input.Filter) || e.Comments.Contains(input.Filter) || e.Status.Contains(input.Filter))
        //                .WhereIf(input.IsRecReqComOfWorkFilter.HasValue && input.IsRecReqComOfWorkFilter > -1, e => (input.IsRecReqComOfWorkFilter == 1 && e.IsRecReqComOfWork == null) || (input.IsRecReqComOfWorkFilter == 0 && !e.IsRecReqComOfWork == null))
        //                .WhereIf(input.IsLimitFinalQuoteFilter.HasValue && input.IsLimitFinalQuoteFilter > -1, e => (input.IsLimitFinalQuoteFilter == 1 && e.IsLimitFinalQuote == null) || (input.IsLimitFinalQuoteFilter == 0 && !e.IsLimitFinalQuote == null))
        //                .WhereIf(input.IsRecImpLimitExpFilter.HasValue && input.IsRecImpLimitExpFilter > -1, e => (input.IsRecImpLimitExpFilter == 1 && e.IsRecImpLimitExp == null) || (input.IsRecImpLimitExpFilter == 0 && !e.IsRecImpLimitExp == null))
        //                .WhereIf(input.MinExpenditureLimitFilter != null, e => e.ExpenditureLimit >= input.MinExpenditureLimitFilter)
        //                .WhereIf(input.MaxExpenditureLimitFilter != null, e => e.ExpenditureLimit <= input.MaxExpenditureLimitFilter)
        //                .WhereIf(input.IsRecimpTimeLimitValidityFilter.HasValue && input.IsRecimpTimeLimitValidityFilter > -1, e => (input.IsRecimpTimeLimitValidityFilter == 1 && e.IsRecimpTimeLimitValidity == null) || (input.IsRecimpTimeLimitValidityFilter == 0 && !e.IsRecimpTimeLimitValidity == null))
        //                .WhereIf(input.MinProposedStartDateFilter != null, e => e.ProposedStartDate >= input.MinProposedStartDateFilter)
        //                .WhereIf(input.MaxProposedStartDateFilter != null, e => e.ProposedStartDate <= input.MaxProposedStartDateFilter)
        //                .WhereIf(input.MinProposedEndDateFilter != null, e => e.ProposedEndDate >= input.MinProposedEndDateFilter)
        //                .WhereIf(input.MaxProposedEndDateFilter != null, e => e.ProposedEndDate <= input.MaxProposedEndDateFilter)
        //                .WhereIf(input.MinProposedStartDateCommitFilter != null, e => e.ProposedStartDateCommit >= input.MinProposedStartDateCommitFilter)
        //                .WhereIf(input.MaxProposedStartDateCommitFilter != null, e => e.ProposedStartDateCommit <= input.MaxProposedStartDateCommitFilter)
        //                .WhereIf(input.MinProposedEndDateCommitFilter != null, e => e.ProposedEndDateCommit >= input.MinProposedEndDateCommitFilter)
        //                .WhereIf(input.MaxProposedEndDateCommitFilter != null, e => e.ProposedEndDateCommit <= input.MaxProposedEndDateCommitFilter)
        //                .WhereIf(input.IsRecOtherItemFurtherReviewFilter.HasValue && input.IsRecOtherItemFurtherReviewFilter > -1, e => (input.IsRecOtherItemFurtherReviewFilter == 1 && e.IsRecOtherItemFurtherReview == null) || (input.IsRecOtherItemFurtherReviewFilter == 0 && !e.IsRecOtherItemFurtherReview == null))
        //                .WhereIf(input.IsIntroTermsConditionFilter.HasValue && input.IsIntroTermsConditionFilter > -1, e => (input.IsIntroTermsConditionFilter == 1 && e.IsIntroTermsCondition == null) || (input.IsIntroTermsConditionFilter == 0 && !e.IsIntroTermsCondition == null))
        //                .WhereIf(input.IsScopeDetClientComFinQuoteScopeFilter.HasValue && input.IsScopeDetClientComFinQuoteScopeFilter > -1, e => (input.IsScopeDetClientComFinQuoteScopeFilter == 1 && e.IsScopeDetClientComFinQuoteScope == null) || (input.IsScopeDetClientComFinQuoteScopeFilter == 0 && !e.IsScopeDetClientComFinQuoteScope == null))
        //                .WhereIf(input.IsDocRefClientComQuoteBaseFilter.HasValue && input.IsDocRefClientComQuoteBaseFilter > -1, e => (input.IsDocRefClientComQuoteBaseFilter == 1 && e.IsDocRefClientComQuoteBase == null) || (input.IsDocRefClientComQuoteBaseFilter == 0 && !e.IsDocRefClientComQuoteBase == null))
        //                .WhereIf(input.IsTermCondComQuoteBasedOnFilter.HasValue && input.IsTermCondComQuoteBasedOnFilter > -1, e => (input.IsTermCondComQuoteBasedOnFilter == 1 && e.IsTermCondComQuoteBasedOn == null) || (input.IsTermCondComQuoteBasedOnFilter == 0 && !e.IsTermCondComQuoteBasedOn == null))
        //                .WhereIf(input.IsHappyCLAsExcKeyTechFinalQuoteFilter.HasValue && input.IsHappyCLAsExcKeyTechFinalQuoteFilter > -1, e => (input.IsHappyCLAsExcKeyTechFinalQuoteFilter == 1 && e.IsHappyCLAsExcKeyTechFinalQuote == null) || (input.IsHappyCLAsExcKeyTechFinalQuoteFilter == 0 && !e.IsHappyCLAsExcKeyTechFinalQuote == null))
        //                .WhereIf(input.MinProposedContractValueFilter != null, e => e.ProposedContractValue >= input.MinProposedContractValueFilter)
        //                .WhereIf(input.MaxProposedContractValueFilter != null, e => e.ProposedContractValue <= input.MaxProposedContractValueFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ResponseTextFilter), e => e.ResponseText == input.ResponseTextFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments == input.CommentsFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.statusFilter), e => e.Status == input.statusFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectOAReviewTitleFilter), e => e.ProjectOAReviewFk != null && e.ProjectOAReviewFk.Title == input.ProjectOAReviewTitleFilter);

        //    var query = (from o in filteredProjectOACustCommAcceptances
        //                 join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
        //                 from s1 in j1.DefaultIfEmpty()

        //                 join o2 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o2.Id into j2
        //                 from s2 in j2.DefaultIfEmpty()

        //                 join o3 in _lookup_projectOAReviewRepository.GetAll() on o.ProjectOAReviewId equals o3.Id into j3
        //                 from s3 in j3.DefaultIfEmpty()

        //                 select new GetProjectOACustCommAcceptanceForViewDto()
        //                 {
        //                     projectOACustCommAcceptance = new ProjectOACustCommAcceptanceDto
        //                     {
        //                         IsRecReqComOfWork = o.IsRecReqComOfWork,
        //                         IsLimitFinalQuote = o.IsLimitFinalQuote,
        //                         IsRecImpLimitExp = o.IsRecImpLimitExp,
        //                         ExpenditureLimit = o.ExpenditureLimit,
        //                         IsRecimpTimeLimitValidity = o.IsRecimpTimeLimitValidity,
        //                         ProposedStartDate = o.ProposedStartDate,
        //                         ProposedEndDate = o.ProposedEndDate,
        //                         ProposedStartDateCommit = o.ProposedStartDateCommit,
        //                         ProposedEndDateCommit = o.ProposedEndDateCommit,
        //                         IsRecOtherItemFurtherReview = o.IsRecOtherItemFurtherReview,
        //                         IsIntroTermsCondition = o.IsIntroTermsCondition,
        //                         IsScopeDetClientComFinQuoteScope = o.IsScopeDetClientComFinQuoteScope,
        //                         IsDocRefClientComQuoteBase = o.IsDocRefClientComQuoteBase,
        //                         IsTermCondComQuoteBasedOn = o.IsTermCondComQuoteBasedOn,
        //                         IsHappyCLAsExcKeyTechFinalQuote = o.IsHappyCLAsExcKeyTechFinalQuote,
        //                         ProposedContractValue = o.ProposedContractValue,
        //                         ResponseText = o.ResponseText,
        //                         Comments = o.Comments,
        //                         status = o.Status,
        //                         Id = o.Id
        //                     },
        //                     ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
        //                     NodeTaskTaskName = s2 == null || s2.TaskName == null ? "" : s2.TaskName.ToString(),
        //                     ProjectOAReviewTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
        //                 });

        //    var projectOACustCommAcceptanceListDtos = await query.ToListAsync();

        //    return _projectOACustCommAcceptancesExcelExporter.ExportToFile(projectOACustCommAcceptanceListDtos);
        //}

        [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances)]
        public async Task<PagedResultDto<ProjectOACustCommAcceptanceProjectLookupTableDto>> GetAllProjectForLookupTable(GetAllForLookupTableInput input)
        {
            var query = _lookup_projectRepository.GetAll().WhereIf(
                   !string.IsNullOrWhiteSpace(input.Filter),
                  e => e.ProjectName != null && e.ProjectName.Contains(input.Filter)
               );

            var totalCount = await query.CountAsync();

            var projectList = await query
                .PageBy(input)
                .ToListAsync();

            var lookupTableDtoList = new List<ProjectOACustCommAcceptanceProjectLookupTableDto>();
            foreach (var project in projectList)
            {
                lookupTableDtoList.Add(new ProjectOACustCommAcceptanceProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project.ProjectName?.ToString()
                });
            }

            return new PagedResultDto<ProjectOACustCommAcceptanceProjectLookupTableDto>(
                totalCount,
                lookupTableDtoList
            );
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances)]
        public async Task<PagedResultDto<ProjectOACustCommAcceptanceNodeTaskLookupTableDto>> GetAllNodeTaskForLookupTable(GetAllForLookupTableInput input)
        {
            var query = _lookup_nodeTaskRepository.GetAll().WhereIf(
                   !string.IsNullOrWhiteSpace(input.Filter),
                  e => e.TaskName != null && e.TaskName.Contains(input.Filter)
               );

            var totalCount = await query.CountAsync();

            var nodeTaskList = await query
                .PageBy(input)
                .ToListAsync();

            var lookupTableDtoList = new List<ProjectOACustCommAcceptanceNodeTaskLookupTableDto>();
            foreach (var nodeTask in nodeTaskList)
            {
                lookupTableDtoList.Add(new ProjectOACustCommAcceptanceNodeTaskLookupTableDto
                {
                    Id = nodeTask.Id,
                    DisplayName = nodeTask.TaskName?.ToString()
                });
            }

            return new PagedResultDto<ProjectOACustCommAcceptanceNodeTaskLookupTableDto>(
                totalCount,
                lookupTableDtoList
            );
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOACustCommAcceptances)]
        public async Task<PagedResultDto<ProjectOACustCommAcceptanceProjectOAReviewLookupTableDto>> GetAllProjectOAReviewForLookupTable(GetAllForLookupTableInput input)
        {
            var query = _lookup_projectOAReviewRepository.GetAll().WhereIf(
                   !string.IsNullOrWhiteSpace(input.Filter),
                  e => e.Title != null && e.Title.Contains(input.Filter)
               );

            var totalCount = await query.CountAsync();

            var projectOAReviewList = await query
                .PageBy(input)
                .ToListAsync();

            var lookupTableDtoList = new List<ProjectOACustCommAcceptanceProjectOAReviewLookupTableDto>();
            foreach (var projectOAReview in projectOAReviewList)
            {
                lookupTableDtoList.Add(new ProjectOACustCommAcceptanceProjectOAReviewLookupTableDto
                {
                    Id = projectOAReview.Id,
                    DisplayName = projectOAReview.Title?.ToString()
                });
            }

            return new PagedResultDto<ProjectOACustCommAcceptanceProjectOAReviewLookupTableDto>(
                totalCount,
                lookupTableDtoList
            );
        }

    }
}