﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.BusinessRules;
using Abp.Events.Bus;
using Abp.UI;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectOpsConfirOfHands)]
    public class ProjectOpsConfirOfHandsAppService : econsysAppServiceBase, IProjectOpsConfirOfHandsAppService
    {
        private readonly IRepository<ProjectOpsConfirOfHand, long> _projectOpsConfirOfHandRepository;
        private readonly IProjectOpsConfirOfHandsExcelExporter _projectOpsConfirOfHandsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectSalesToOpsHand, long> _projectSalesToOpsHandRepository;
        private readonly IRepository<ProjectEngineering> _projectEngineeringRepository;
        private readonly IRepository<RuleValue, long> _ruleValueRepository;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly IProjectSalesToOpsHandsAppService _projectSalesToOpsHandsAppService;
        private readonly IRepository<ProjectOAReview, long> _projectOAReviewRepository;
        public IEventBus EventBus { get; set; }


        public ProjectOpsConfirOfHandsAppService(IRepository<ProjectOpsConfirOfHand, long> projectOpsConfirOfHandRepository,
            IRepository<ProjectSalesToOpsHand, long> projectSalesToOpsHandRepository, 
            IRepository<ProjectEngineering> projectEngineeringRepository,
            IProjectOpsConfirOfHandsExcelExporter projectOpsConfirOfHandsExcelExporter,
            IRepository<Project, long> lookup_projectRepository,
            IRepository<RuleValue, long> ruleValueRepository, ProjectPermissionManager projectPermissionManager, IProjectSalesToOpsHandsAppService projectSalesToOpsHandsAppService, IRepository<ProjectOAReview, long> projectOAReviewRepository)
        {
            _projectOpsConfirOfHandRepository = projectOpsConfirOfHandRepository;
            _projectOpsConfirOfHandsExcelExporter = projectOpsConfirOfHandsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _projectSalesToOpsHandRepository = projectSalesToOpsHandRepository;
            _projectEngineeringRepository = projectEngineeringRepository;
            _ruleValueRepository = ruleValueRepository;
            _projectPermissionManager = projectPermissionManager;
            EventBus = NullEventBus.Instance;
            _projectSalesToOpsHandsAppService = projectSalesToOpsHandsAppService;
            _projectOAReviewRepository = projectOAReviewRepository;
        }

        public async Task<PagedResultDto<GetProjectOpsConfirOfHandForViewDto>> GetAll(GetAllProjectOpsConfirOfHandsInput input)
        {

            var filteredProjectOpsConfirOfHands = _projectOpsConfirOfHandRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.DocumentList.Contains(input.Filter) || e.SalLeadreqmeet.Contains(input.Filter) || e.WhyNot.Contains(input.Filter) || e.Comments.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DocumentListFilter), e => e.DocumentList.Contains(input.DocumentListFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SalLeadreqmeetFilter), e => e.SalLeadreqmeet.Contains(input.SalLeadreqmeetFilter))
                        .WhereIf(input.ConfirmedFilter.HasValue && input.ConfirmedFilter > -1, e => (input.ConfirmedFilter == 1 && e.Confirmed) || (input.ConfirmedFilter == 0 && !e.Confirmed))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.WhyNotFilter), e => e.WhyNot.Contains(input.WhyNotFilter))
                        .WhereIf(input.SchedMeetWithSalesFilter.HasValue && input.SchedMeetWithSalesFilter > -1, e => (input.SchedMeetWithSalesFilter == 1 && e.SchedMeetWithSales) || (input.SchedMeetWithSalesFilter == 0 && !e.SchedMeetWithSales))
                        .WhereIf(input.MinSchedMeetWithSalesTimeFilter != null, e => e.SchedMeetWithSalesTime >= input.MinSchedMeetWithSalesTimeFilter)
                        .WhereIf(input.MaxSchedMeetWithSalesTimeFilter != null, e => e.SchedMeetWithSalesTime <= input.MaxSchedMeetWithSalesTimeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments.Contains(input.CommentsFilter))
                        .WhereIf(input.MinProjectIdFilter != null, e => e.ProjectId >= input.MinProjectIdFilter)
                        .WhereIf(input.MaxProjectIdFilter != null, e => e.ProjectId <= input.MaxProjectIdFilter);

            var pagedAndFilteredProjectOpsConfirOfHands = filteredProjectOpsConfirOfHands
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectOpsConfirOfHands = from o in pagedAndFilteredProjectOpsConfirOfHands
                                          select new
                                          {

                                              o.DocumentList,
                                              o.SalLeadreqmeet,
                                              o.Confirmed,
                                              o.WhyNot,
                                              o.SchedMeetWithSales,
                                              o.SchedMeetWithSalesTime,
                                              o.Comments,
                                              o.ProjectId,
                                              Id = o.Id
                                          };

            var totalCount = await filteredProjectOpsConfirOfHands.CountAsync();

            var dbList = await projectOpsConfirOfHands.ToListAsync();
            var results = new List<GetProjectOpsConfirOfHandForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectOpsConfirOfHandForViewDto()
                {
                    ProjectOpsConfirOfHand = new ProjectOpsConfirOfHandDto
                    {

                        DocumentList = o.DocumentList,
                        SalLeadreqmeet = o.SalLeadreqmeet,
                        Confirmed = o.Confirmed,
                        WhyNot = o.WhyNot,
                        SchedMeetWithSales = o.SchedMeetWithSales,
                        SchedMeetWithSalesTime = o.SchedMeetWithSalesTime,
                        Comments = o.Comments,
                        ProjectId = o.ProjectId,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectOpsConfirOfHandForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectOpsConfirOfHandForViewDto> GetProjectOpsConfirOfHandForView(int id)
        {
            var projectOpsConfirOfHand = await _projectOpsConfirOfHandRepository.GetAsync(id);

            var output = new GetProjectOpsConfirOfHandForViewDto { ProjectOpsConfirOfHand = ObjectMapper.Map<ProjectOpsConfirOfHandDto>(projectOpsConfirOfHand) };
            if (output.ProjectOpsConfirOfHand.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectOpsConfirOfHand.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }
            var salestoopshand = await _projectSalesToOpsHandRepository.FirstOrDefaultAsync(x => x.ProjectId == output.ProjectOpsConfirOfHand.ProjectId);
            if (salestoopshand != null)
            {
                output.ProjectSalesToOpsHand = new GetProjectSalesToOpsHandForViewDto() { ProjectSalesToOpsHand = ObjectMapper.Map<ProjectSalesToOpsHandDto>(salestoopshand) };
            }
            return output;
        }


        [AbpAuthorize(AppPermissions.Pages_ProjectOpsConfirOfHands_Edit)]
        public async Task<GetProjectOpsConfirOfHandForEditOutput> GetProjectOpsConfirOfHandForEdit(EntityDto input)
        {
            var projectOpsConfirOfHand = await _projectOpsConfirOfHandRepository.GetAllIncluding().Where(x => x.ProjectId == input.Id).FirstOrDefaultAsync();

            var output = new GetProjectOpsConfirOfHandForEditOutput { ProjectOpsConfirOfHand = ObjectMapper.Map<CreateOrEditProjectOpsConfirOfHandDto>(projectOpsConfirOfHand) };
            if (projectOpsConfirOfHand != null && output.ProjectOpsConfirOfHand != null && output.ProjectOpsConfirOfHand.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectOpsConfirOfHand.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }
            
            return output;
        }


        public async Task<GetProjectSalesToOpsHandForViewDto> Getsalestoopsdata(long projectid)
        {           
            var ProjectSalesToOpsHandDto = await _projectSalesToOpsHandRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
            var output = new GetProjectSalesToOpsHandForViewDto { ProjectSalesToOpsHand = ObjectMapper.Map<ProjectSalesToOpsHandDto>(ProjectSalesToOpsHandDto) };
            return output;
           

        }
        public async Task<GetProjectEngineeringForViewDto> Getengineeringdata(long projectid)
        {
            var EngineeringDto = await _projectEngineeringRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
             var RuleTitle = await _ruleValueRepository.FirstOrDefaultAsync(x => x.Id == EngineeringDto.RuleValueId);
            
            var output = new GetProjectEngineeringForViewDto { ProjectEngineering = ObjectMapper.Map<ProjectEngineeringDto>(EngineeringDto) };
            output.RuleValueTitle = RuleTitle.Title;
            return output;
        }


        public async Task<GetProjectForViewDto> CreateOrEdit(CreateOrEditProjectOpsConfirOfHandDto input)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = (long)input.ProjectId
            });
            if (!check)
            {
                throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            }
            var OAReview = _projectOAReviewRepository.GetAll().Where(x => x.ProjectId == input.ProjectId && x.IsCurrent == true);
            if (OAReview != null)
            {
                input.ProjectOAReviewId = OAReview.First().Id;
            }
            GetProjectForViewDto result = new GetProjectForViewDto();
            var projectOpsConfirOfHand = new GetProjectOpsConfirOfHandForViewDto();
            ProjectSalesToOpsHand abc = _projectSalesToOpsHandRepository.FirstOrDefault(x=> x.ProjectId == input.ProjectId);
            if (abc != null)
            {
                abc.ScheMeetWiOpeDate = input.SchedMeetWithSalesTime;
                await _projectSalesToOpsHandRepository.UpdateAsync(abc);
            }


            if (input.Id == null)
            {
                projectOpsConfirOfHand = await Create(input);
            }
            else
            {
                projectOpsConfirOfHand = await Update(input);
            }

            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.ProjectOpsConfirmOfHand = projectOpsConfirOfHand;
            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOpsConfirOfHands_Create)]
        protected virtual async Task<GetProjectOpsConfirOfHandForViewDto> Create(CreateOrEditProjectOpsConfirOfHandDto input)
        {
            input.CreatorUserId = (long)AbpSession.UserId;
            input.CreatedOn = DateTime.UtcNow;
            var projectOpsConfirOfHand = ObjectMapper.Map<ProjectOpsConfirOfHand>(input);

            if (AbpSession.TenantId != null)
            {
                projectOpsConfirOfHand.TenantId = (int?)AbpSession.TenantId;
            }
            var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);

            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.OperationsAcceptanceofHandover,
                StatusId = input.StatusId,
                Comment = input.Comments,
                LoggedInUserId = (long)AbpSession.UserId
            });

            long projectOpsToHandid = 0;
            projectOpsToHandid = await _projectOpsConfirOfHandRepository.InsertAndGetIdAsync(projectOpsConfirOfHand);
            var output = new GetProjectOpsConfirOfHandForViewDto { ProjectOpsConfirOfHand = ObjectMapper.Map<ProjectOpsConfirOfHandDto>(_projectOpsConfirOfHandRepository.Get(projectOpsToHandid)) };
            return output;

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOpsConfirOfHands_Edit)]
        protected virtual async Task<GetProjectOpsConfirOfHandForViewDto> Update(CreateOrEditProjectOpsConfirOfHandDto input)
        {
            input.LastModifierUserId = (long)AbpSession.UserId;
            input.UpdatedOn = DateTime.UtcNow;
            var projectOpsConfirOfHand = await _projectOpsConfirOfHandRepository.FirstOrDefaultAsync((int)input.Id);
            ObjectMapper.Map(input, projectOpsConfirOfHand);

            var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);

            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.OperationsAcceptanceofHandover,
                StatusId = input.StatusId,
                Comment = input.Comments,
                LoggedInUserId = (long)AbpSession.UserId
            });
            var output = new GetProjectOpsConfirOfHandForViewDto { ProjectOpsConfirOfHand = ObjectMapper.Map<ProjectOpsConfirOfHandDto>(_projectOpsConfirOfHandRepository.Get((long)input.Id)) };
            return output;

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectOpsConfirOfHands_Delete)]
        public async Task Delete(EntityDto input)
        {
            await _projectOpsConfirOfHandRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectOpsConfirOfHandsToExcel(GetAllProjectOpsConfirOfHandsForExcelInput input)
        {

            var filteredProjectOpsConfirOfHands = _projectOpsConfirOfHandRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.DocumentList.Contains(input.Filter) || e.SalLeadreqmeet.Contains(input.Filter) || e.WhyNot.Contains(input.Filter) || e.Comments.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DocumentListFilter), e => e.DocumentList.Contains(input.DocumentListFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SalLeadreqmeetFilter), e => e.SalLeadreqmeet.Contains(input.SalLeadreqmeetFilter))
                        .WhereIf(input.ConfirmedFilter.HasValue && input.ConfirmedFilter > -1, e => (input.ConfirmedFilter == 1 && e.Confirmed) || (input.ConfirmedFilter == 0 && !e.Confirmed))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.WhyNotFilter), e => e.WhyNot.Contains(input.WhyNotFilter))
                        .WhereIf(input.SchedMeetWithSalesFilter.HasValue && input.SchedMeetWithSalesFilter > -1, e => (input.SchedMeetWithSalesFilter == 1 && e.SchedMeetWithSales) || (input.SchedMeetWithSalesFilter == 0 && !e.SchedMeetWithSales))
                        .WhereIf(input.MinSchedMeetWithSalesTimeFilter != null, e => e.SchedMeetWithSalesTime >= input.MinSchedMeetWithSalesTimeFilter)
                        .WhereIf(input.MaxSchedMeetWithSalesTimeFilter != null, e => e.SchedMeetWithSalesTime <= input.MaxSchedMeetWithSalesTimeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments.Contains(input.CommentsFilter))
                        .WhereIf(input.MinProjectIdFilter != null, e => e.ProjectId >= input.MinProjectIdFilter)
                        .WhereIf(input.MaxProjectIdFilter != null, e => e.ProjectId <= input.MaxProjectIdFilter);

            var query = (from o in filteredProjectOpsConfirOfHands
                         select new GetProjectOpsConfirOfHandForViewDto()
                         {
                             ProjectOpsConfirOfHand = new ProjectOpsConfirOfHandDto
                             {
                                 DocumentList = o.DocumentList,
                                 SalLeadreqmeet = o.SalLeadreqmeet,
                                 Confirmed = o.Confirmed,
                                 WhyNot = o.WhyNot,
                                 SchedMeetWithSales = o.SchedMeetWithSales,
                                 SchedMeetWithSalesTime = o.SchedMeetWithSalesTime,
                                 Comments = o.Comments,
                                 ProjectId = o.ProjectId,
                                 Id = o.Id
                             }
                         });

            var projectOpsConfirOfHandListDtos = await query.ToListAsync();

            return _projectOpsConfirOfHandsExcelExporter.ExportToFile(projectOpsConfirOfHandListDtos);
        }

    }
}