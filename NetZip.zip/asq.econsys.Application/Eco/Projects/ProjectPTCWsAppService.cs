﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using asq.econsys.Eco.Customers;
using Abp.Zero.Configuration;
using asq.econsys.Authorization.Roles.Dto;
using asq.econsys.Authorization.Roles;
using Microsoft.AspNetCore.Identity;
using asq.econsys.Authorization.Users.Dto;
using asq.econsys.Authorization.Users;
using Abp.Authorization.Roles;
using Abp.Authorization.Users;
using Newtonsoft.Json;
using Syncfusion.DocIO.DLS;
using Syncfusion.DocIO;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using System.Net.Mail;
using System.Net;
using Abp.Domain.Uow;
using Abp.Events.Bus;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http;
using System.Net.Mime;
using System.Net.Mail;
using Microsoft.AspNetCore.Mvc;
using asq.econsys.Eco.Utils.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectPTCWs)]
    public class ProjectPTCWsAppService : econsysAppServiceBase, IProjectPTCWsAppService
    {
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly IRepository<ProjectPTCW, long> _projectPTCWRepository;
        private readonly IProjectPTCWsExcelExporter _projectPTCWsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly RoleManager _roleManager;
        private readonly IRoleManagementConfig _roleManagementConfig;
        private readonly IRepository<RolePermissionSetting, long> _rolePermissionRepository;
        private readonly IRepository<UserPermissionSetting, long> _userPermissionRepository;
        private readonly IRepository<UserRole, long> _userRoleRepository;
        private readonly IRepository<Role> _roleRepository;
        private readonly IRepository<Project, long> _projectRepository;
        private readonly IWebHostEnvironment _env;
        private readonly IRepository<ProjectQuoteForm, long> _projectQuoteFormRepository;
        private readonly IRepository<ProjectQuoteMeta, long> _quoteMetaRepository;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly IRepository<ProjectFile, Guid> _repositoryProjectFile;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly IRepository<ProjectOAReview, long> _projectOAReviewRepository;
        public IEventBus EventBus { get; set; }
        private readonly StorageManager _storageManager;

        public ProjectPTCWsAppService(
            IRepository<ProjectPTCW, long> projectPTCWRepository,
            IProjectPTCWsExcelExporter projectPTCWsExcelExporter,
            IRepository<Project, long> lookup_projectRepository,
            IRepository<ProjectStatusOfSubmittedQuote, long> projectStatusOfSubmittedQuoteRepository,
            IRepository<RolePermissionSetting, long> rolePermissionRepository, 
            IRepository<UserPermissionSetting, long> userPermissionRepository,
            IRepository<UserRole, long> userRoleRepository,
            RoleManager roleManager, IRoleManagementConfig roleManagementConfig,
            IRepository<Project, long> projectRepository,
            IRepository<ProjectQuoteForm, long> projectQuoteFormRepository,
            IWebHostEnvironment env,
            IRepository<ProjectQuoteMeta, long> quoteMetaRepository,
            IUnitOfWorkManager unitOfWorkManager, ProjectPermissionManager projectPermissionManager,
            IRepository<ProjectFile, Guid> repositoryProjectFile,
            Utils.UtilsAppService utilsAppService, IRepository<ProjectOAReview, long> projectOAReviewRepository,
            StorageManager storageManager)
        {
            _projectPTCWRepository = projectPTCWRepository;
            _projectPTCWsExcelExporter = projectPTCWsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _roleManager = roleManager;
            _roleManagementConfig = roleManagementConfig;
            _rolePermissionRepository = rolePermissionRepository;
            _userPermissionRepository = userPermissionRepository;
            _userRoleRepository = userRoleRepository;
            _projectRepository = projectRepository;
            _env = env;
            _projectQuoteFormRepository = projectQuoteFormRepository;
            _quoteMetaRepository = quoteMetaRepository;
            _unitOfWorkManager = unitOfWorkManager;
            _projectPermissionManager = projectPermissionManager;
            _repositoryProjectFile = repositoryProjectFile;
            _utilsAppService = utilsAppService;
            _projectOAReviewRepository = projectOAReviewRepository;
            _storageManager = storageManager;
        }

        public async Task<PagedResultDto<GetProjectPTCWForViewDto>> GetAll(GetAllProjectPTCWsInput input)
        {

            var filteredProjectPTCWs = _projectPTCWRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ClientOrderRefNo.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ClientOrderRefNoFilter), e => e.ClientOrderRefNo == input.ClientOrderRefNoFilter)
                        .WhereIf(input.MinBidStartDateFilter != null, e => e.BidStartDate >= input.MinBidStartDateFilter)
                        .WhereIf(input.MaxBidStartDateFilter != null, e => e.BidStartDate <= input.MaxBidStartDateFilter);

            var pagedAndFilteredProjectPTCWs = filteredProjectPTCWs
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectPTCWs = from o in pagedAndFilteredProjectPTCWs
                               select new
                               {

                                   o.ClientOrderRefNo,
                                   o.BidStartDate,
                                   Id = o.Id
                               };

            var totalCount = await filteredProjectPTCWs.CountAsync();

            var dbList = await projectPTCWs.ToListAsync();
            var results = new List<GetProjectPTCWForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectPTCWForViewDto()
                {
                    ProjectPTCW = new ProjectPTCWDto
                    {
                        ClientOrderRefNo = o.ClientOrderRefNo,
                        BidStartDate = o.BidStartDate,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectPTCWForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<CreateOrEditProjectPTCWDto> GetProjectPTCWForView(long id)
        {
            var projectPTCW = await _projectPTCWRepository.GetAsync(id);
            var quoteMeta = _quoteMetaRepository.GetAll().Where(x => x.ProjectPTCWId == id);

            var output = ObjectMapper.Map<CreateOrEditProjectPTCWDto>(projectPTCW);
            output.QuoteMeta = ObjectMapper.Map<QuoteMetaDto>(quoteMeta);

            if (output.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectId);
                output.ProjectName = _lookupProject?.ProjectName?.ToString();
            }
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPTCWs_Edit)]
        public async Task<CreateOrEditProjectPTCWDto> GetProjectPTCWForEdit(EntityDto<long> input)
        {
            CreateOrEditProjectPTCWDto result = new CreateOrEditProjectPTCWDto();
            // TODO: check which row to take
            var projectPTCW = await _projectPTCWRepository.GetAllIncluding(x => x.ProjectFk).Where(x => x.ProjectId == (int)input.Id).FirstOrDefaultAsync();
            if(projectPTCW != null)
            {
                var quoteMeta = await _quoteMetaRepository.FirstOrDefaultAsync(x => x.ProjectId == (int)input.Id && x.ProjectPTCWId == projectPTCW.Id);
                result = ObjectMapper.Map<CreateOrEditProjectPTCWDto>(projectPTCW);
                result.QuoteMeta = ObjectMapper.Map<QuoteMetaDto>(quoteMeta);
                result.ProjectName = projectPTCW.ProjectFk.ProjectName?.ToString();
            }

            return result;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit([FromForm] ProjectPTCWAttachmentsDto data)
        {
            var input = JsonConvert.DeserializeObject<CreateOrEditProjectPTCWDto>(data.ProjectPTCW);
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.ProjectPTCWs = new List<CreateOrEditProjectPTCWDto>();
            var projectPTCW = new GetProjectPTCWForViewDto();

            await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        var OAReview = await _projectOAReviewRepository.FirstOrDefaultAsync(x => x.ProjectId == input.ProjectId && x.IsCurrent == true);
                        if (OAReview != null)
                        {
                            input.ProjectOAReviewId = OAReview.Id;
                        }
                        if (input.Id == null)
                        {
                            projectPTCW = await Create(input);
                        }
                        else
                        {
                            projectPTCW = await Update(input);
                        }

                        if (projectPTCW != null && input.QuoteMeta != null)
                        {
                            var quoteMeta = ObjectMapper.Map<ProjectQuoteMeta>(input.QuoteMeta);
                            quoteMeta.ProjectId = projectPTCW.ProjectPTCW.ProjectId;
                            quoteMeta.ProjectPTCWId = projectPTCW.ProjectPTCW.Id;
                            quoteMeta.TenantId = tenantId;
                            var quoteMetaId = await _quoteMetaRepository.InsertOrUpdateAndGetIdAsync(quoteMeta);

                            CurrentUnitOfWork.SaveChanges();
                        }

                        //await _utilsAppService.UploadSection((IFormFile)files, (long)input.ProjectId, CNodeTasks.PermissiontoCommenceWorks, "PTCW");

                        List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                        if (data.Files != null && data.Files.Count > 0)
                        {
                            for (var j = 0; j < data.Files.Count; j++)
                            {
                                projectFilesInput.Add(new ProjectFileInput()
                                {
                                    File = data.Files.ToList()[j],
                                    ProjectId = projectPTCW.ProjectPTCW.ProjectId,
                                    TaskId = CNodeTasks.PermissiontoCommenceWorks,
                                    MetaData = "PTCW"
                                });
                            }
                        }

                        if (projectFilesInput.Count > 0)
                        {
                            var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                        }
                        
                        await EventBus.TriggerAsync(new EditProjectEventData()
                        {
                            StageId = CNodeStages.OrderAcceptance,
                            TaskId = CNodeTasks.PermissiontoCommenceWorks,
                            StatusId = input.StatusId,
                            Comment = input.Comments,
                            LoggedInUserId = (long)AbpSession.UserId,
                            ProjectId = input.ProjectId
                        });
                    }
                }
            });

            var project = _lookup_projectRepository.FirstOrDefault((long)input.ProjectId);
            project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.ProjectPTCWdto = projectPTCW;
            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPTCWs_Create)]
        protected virtual async Task<GetProjectPTCWForViewDto> Create(CreateOrEditProjectPTCWDto input)
        {
            var projectPTCW = ObjectMapper.Map<ProjectPTCW>(input);

            if (AbpSession.TenantId != null)
            {
                projectPTCW.TenantId = (int?)AbpSession.TenantId;
            }
            //var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);

            //await EventBus.TriggerAsync(new EditProjectEventData()
            //{
            //    Project = project,
            //    StageId = CNodeStages.OrderAcceptance,
            //    TaskId = CNodeTasks.PermissiontoCommenceWorks,
            //    StatusId = CNodeStatuses.Submit,
            //    Comment = input.Comments,
            //    LoggedInUserId = (long)AbpSession.UserId
            //});

            var ptcwId = await _projectPTCWRepository.InsertAndGetIdAsync(projectPTCW);
            return new GetProjectPTCWForViewDto { ProjectPTCW = ObjectMapper.Map<ProjectPTCWDto>(_projectPTCWRepository.Get(ptcwId)) };
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPTCWs_Edit)]
        protected virtual async Task<GetProjectPTCWForViewDto> Update(CreateOrEditProjectPTCWDto input)
        {
            var projectPTCW = await _projectPTCWRepository.FirstOrDefaultAsync((int)input.Id);

            ObjectMapper.Map(input, projectPTCW);
            //var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);

            //await EventBus.TriggerAsync(new EditProjectEventData()
            //{
            //    Project = project,
            //    StageId = CNodeStages.OrderAcceptance,
            //    TaskId = CNodeTasks.PermissiontoCommenceWorks,
            //    StatusId = CNodeStatuses.Submit,
            //    Comment = input.Comments,
            //    LoggedInUserId = (long)AbpSession.UserId
            //});
            return new GetProjectPTCWForViewDto { ProjectPTCW = ObjectMapper.Map<ProjectPTCWDto>(_projectPTCWRepository.Get((int)input.Id)) };
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPTCWs_Delete)]
        public async Task Delete(EntityDto input)
        {
            await _projectPTCWRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectPTCWsToExcel(GetAllProjectPTCWsForExcelInput input)
        {

            var filteredProjectPTCWs = _projectPTCWRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ClientOrderRefNo.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ClientOrderRefNoFilter), e => e.ClientOrderRefNo == input.ClientOrderRefNoFilter)
                        .WhereIf(input.MinBidStartDateFilter != null, e => e.BidStartDate >= input.MinBidStartDateFilter)
                        .WhereIf(input.MaxBidStartDateFilter != null, e => e.BidStartDate <= input.MaxBidStartDateFilter);

            var query = (from o in filteredProjectPTCWs
                         select new GetProjectPTCWForViewDto()
                         {
                             ProjectPTCW = new ProjectPTCWDto
                             {
                                 ClientOrderRefNo = o.ClientOrderRefNo,
                                 BidStartDate = o.BidStartDate,
                                 Id = o.Id
                             }
                         });

            var projectPTCWListDtos = await query.ToListAsync();

            return _projectPTCWsExcelExporter.ExportToFile(projectPTCWListDtos);
        }

        public async void UploadFileFromAzure(List<string> fileIdList)
        {
            if (fileIdList.Count > 0)
            {
                foreach (var item in fileIdList)
                {
                    ProjectFile file = _repositoryProjectFile.FirstOrDefault(x => x.Id.ToString() == item);
                    file.ParentId = file.Id;
                    file.Id = Guid.Empty;
                    file.CreationTime = DateTime.Now;
                    file.CreatorUserId = AbpSession.UserId;
                    await _repositoryProjectFile.InsertAsync(file);
                }
            }
        }
        public async Task<ListResultDto<RoleListDto>> GetRoles()
        {
            var query = _roleManager.Roles;

            var roles = await query.ToListAsync();

            return new ListResultDto<RoleListDto>(ObjectMapper.Map<List<RoleListDto>>(roles));
        }

        //this code for fetching the username from the user to Permis
        public async Task<PagedResultDto<UserListDto>> GetUsers(GetUsersInput input)
        {
            var query = GetUsersFilteredQuery(input);

            var userCount = await query.CountAsync();

            var users = await query
                .OrderBy(input.Sorting)
                .PageBy(input)
                .ToListAsync();

            var userListDtos = ObjectMapper.Map<List<UserListDto>>(users);
            await FillRoleNames(userListDtos);

            return new PagedResultDto<UserListDto>(
                userCount,
                userListDtos
            );
        }

        private async Task FillRoleNames(IReadOnlyCollection<UserListDto> userListDtos)
        {
            /* This method is optimized to fill role names to given list. */
            var userIds = userListDtos.Select(u => u.Id);

            var userRoles = await _userRoleRepository.GetAll()
                .Where(userRole => userIds.Contains(userRole.UserId))
                .Select(userRole => userRole).ToListAsync();

            var distinctRoleIds = userRoles.Select(userRole => userRole.RoleId).Distinct();

            foreach (var user in userListDtos)
            {
                var rolesOfUser = userRoles.Where(userRole => userRole.UserId == user.Id).ToList();
                user.Roles = ObjectMapper.Map<List<UserListRoleDto>>(rolesOfUser);
            }

            var roleNames = new Dictionary<int, string>();
            foreach (var roleId in distinctRoleIds)
            {
                var role = await _roleManager.FindByIdAsync(roleId.ToString());
                if (role != null)
                {
                    roleNames[roleId] = role.DisplayName;
                }
            }

            foreach (var userListDto in userListDtos)
            {
                foreach (var userListRoleDto in userListDto.Roles)
                {
                    if (roleNames.ContainsKey(userListRoleDto.RoleId))
                    {
                        userListRoleDto.RoleName = roleNames[userListRoleDto.RoleId];
                    }
                }

                userListDto.Roles = userListDto.Roles.Where(r => r.RoleName != null).OrderBy(r => r.RoleName).ToList();
            }
        }
        private IQueryable<User> GetUsersFilteredQuery(IGetUsersInput input)
        {
            var query = UserManager.Users
                .WhereIf(input.Role.HasValue, u => u.Roles.Any(r => r.RoleId == input.Role.Value))
                .WhereIf(input.OnlyLockedUsers,
                    u => u.LockoutEndDateUtc.HasValue && u.LockoutEndDateUtc.Value > DateTime.UtcNow)
                .WhereIf(
                    !input.Filter.IsNullOrWhiteSpace(),
                    u =>
                        u.Name.Contains(input.Filter) ||
                        u.Surname.Contains(input.Filter) ||
                        u.UserName.Contains(input.Filter) ||
                        u.EmailAddress.Contains(input.Filter)
                );

            if (input.Permissions != null && input.Permissions.Any(p => !p.IsNullOrWhiteSpace()))
            {
                var staticRoleNames = _roleManagementConfig.StaticRoles.Where(
                    r => r.GrantAllPermissionsByDefault &&
                         r.Side == AbpSession.MultiTenancySide
                ).Select(r => r.RoleName).ToList();

                input.Permissions = input.Permissions.Where(p => !string.IsNullOrEmpty(p)).ToList();

                var userIds = from user in query
                              join ur in _userRoleRepository.GetAll() on user.Id equals ur.UserId into urJoined
                              from ur in urJoined.DefaultIfEmpty()
                              join urr in _roleRepository.GetAll() on ur.RoleId equals urr.Id into urrJoined
                              from urr in urrJoined.DefaultIfEmpty()
                              join up in _userPermissionRepository.GetAll()
                                  .Where(userPermission => input.Permissions.Contains(userPermission.Name)) on user.Id equals up.UserId into upJoined
                              from up in upJoined.DefaultIfEmpty()
                              join rp in _rolePermissionRepository.GetAll()
                                  .Where(rolePermission => input.Permissions.Contains(rolePermission.Name)) on
                                  new { RoleId = ur == null ? 0 : ur.RoleId } equals new { rp.RoleId } into rpJoined
                              from rp in rpJoined.DefaultIfEmpty()
                              where (up != null && up.IsGranted) ||
                                    (up == null && rp != null && rp.IsGranted) ||
                                    (up == null && rp == null && staticRoleNames.Contains(urr.Name))
                              group user by user.Id
                    into userGrouped
                              select userGrouped.Key;

                query = UserManager.Users.Where(e => userIds.Contains(e.Id));
            }

            return query;
        }

        //private Task<CreateOrEditProjectPTCWDto> Update(CreateOrEditProjectPTCWDto input)
        //{
        //    throw new NotImplementedException();
        //}
        public async Task<HttpResponseMessage> PreViewDoc(int id, string templateName, string formData)
        {
            byte[] bytes = new byte[10];
            WordDocument document = new WordDocument();

            //var stream = new MemoryStream();

            //var result = new HttpResponseMessage(HttpStatusCode.OK)
            //{
            //    Content = new ByteArrayContent(stream.ToArray())
            //};
            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            try
            {
                var submitQuoteData = JsonConvert.DeserializeObject<CreateOrEditProjectPTCWDto>(formData);
                var ProjectInfo = await _projectRepository.FirstOrDefaultAsync(id);

                var QuoteInfo = await _projectQuoteFormRepository.FirstOrDefaultAsync(x => x.Id == ProjectInfo.ProjectQuoteFormId);

                if (templateName == "PermissionToCommence")
                {
                    var date = DateTime.Now;

                    //Opens the input Word document.
                    string targetFilePath = Path.Combine(_env.WebRootPath, "template\\PermissionToCommence\\PermissionToCommence_template.docx");
                    FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    //FileStream fileStreamPath = new FileStream(filename, FileMode.Open, FileAccess.Read);
                    document = new WordDocument(fileStreamPath, FormatType.Docx);
                    
                        document.Replace("<<ReceiptDate>>", submitQuoteData.BidStartDate.ToString(), true, true);
                        document.Replace("<<TodayDate>>", date.ToString("d"), true, true);
                        document.Replace("<<QuoteRefNo>>", (QuoteInfo != null ? QuoteInfo.QRN : ""), true, true);
                        document.Replace("<<CustomerName>>", submitQuoteData.QuoteMeta.CustomerName, true, true);
                        document.Replace("<<Address>>", submitQuoteData.QuoteMeta.Address1, true, true);
                        document.Replace("<<PostalCode>>", submitQuoteData.QuoteMeta.PostalCode, true, true);
                        //  document.Replace("<<ReciptMethod>>", submitQuoteData.ReceiptMethod != null ? submitQuoteData.ReceiptMethod : "", true, true);
                        document.Replace("<<ProjectName>>", ProjectInfo.ProjectName, true, true);
                        document.Replace("<<ScopeOfWorks>>", submitQuoteData.QuoteMeta.ScopeOfWorks, true, true);
                        document.Replace("<<ClientOrderRefNo>>", submitQuoteData.ClientOrderRefNo, true, true);
                        document.Replace("<<Subject>>", submitQuoteData.QuoteMeta.Subject != null ? submitQuoteData.QuoteMeta.Subject : "", true, true);
                        document.Replace("<<SiteName>>", submitQuoteData.QuoteMeta.ProposedWorks != null ? submitQuoteData.QuoteMeta.ProposedWorks : "", true, true);
                        document.Replace("<<WeWillAdviseYou>>", submitQuoteData.QuoteMeta.WeWillAdviseYou != null ? submitQuoteData.QuoteMeta.WeWillAdviseYou : "", true, true);
                        //document.Replace("<<OrganizationName>>", submitQuoteData.QuoteMeta.WeWillAdviseYou, true, true);
                        document.Replace("<<QuotedDate>>", submitQuoteData.QuoteMeta.QuotedDate.ToString(), true, true);
                        document.Replace("<<AttentionOf>>", submitQuoteData.QuoteMeta.AttentionOf, true, true);
                        document.Replace("<<ValueOfCommitment>>", submitQuoteData.QuoteMeta.ValueOfCommitment.ToString(), true, true);
                        document.Replace("<<UserName>>", submitQuoteData.QuoteMeta.CorrespondWithName != null ? submitQuoteData.QuoteMeta.CorrespondWithName : "", true, true);
                        document.Replace("<<UserEmail>>", submitQuoteData.QuoteMeta.CorrespondWithEmail != null ? submitQuoteData.QuoteMeta.CorrespondWithEmail : "", true, true);



                        string targetFilePath2 = Path.Combine(_env.WebRootPath, "template\\PermissionToCommence\\PermissionToCommence_template.docx");
                        if (!Directory.Exists(targetFilePath))
                        {
                            Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "Temp\\bidinfo"));
                        }

                        //fileStreamPath = System.IO.File.Create(targetFilePath2);
                        //document.Save(fileStreamPath, FormatType.Docx);

                        //fileStreamPath.Dispose();

                        //bytes = File.ReadAllBytes(targetFilePath2);
                        ////return JsonConvert.SerializeObject<byte>(bytes);
                        //string a = JsonConvert.SerializeObject(bytes);

                        // processing the stream.


                        //result.Content.Headers.ContentDisposition =
                        //    new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                        //    {
                        //        FileName = targetFilePath2
                        //    };
                        //result.Content.Headers.ContentType =
                        //    new MediaTypeHeaderValue("application/octet-stream");
                        var path = targetFilePath2;

                        var stream = new FileStream(path, FileMode.Open, FileAccess.Read);
                        result.Content = new StreamContent(stream);
                        result.Content.Headers.ContentType =
                            new MediaTypeHeaderValue("application/octet-stream");
                        return result;

                        //return result;
                    }
                
            }
            catch (Exception e)
            {

                throw;
            }
            return result;
        }


        /* code for the Generate Document*/
        public async Task<string> GenerateDocument(int id, string templateName, string formData)
        {
            try
            {
                var submitQuoteData = JsonConvert.DeserializeObject<CreateOrEditProjectPTCWDto>(formData);
                var ProjectInfo = await _projectRepository.FirstOrDefaultAsync(id);

                var quoteInfo = await _projectQuoteFormRepository.FirstOrDefaultAsync(x => x.Id == ProjectInfo.Id);

                if (templateName == "PermissionToCommence")
                {
                    var date = DateTime.Now;

                    //Opens the input Word document.
                    string targetFilePath = Path.Combine(_env.WebRootPath, "template\\PermissionToCommence\\PermissionToCommence_template.docx");
                    FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    //FileStream fileStreamPath = new FileStream(filename, FileMode.Open, FileAccess.Read);
                    WordDocument document = new WordDocument(fileStreamPath, FormatType.Docx);

                    document.Open(fileStreamPath, FormatType.Docx);
                    fileStreamPath.Dispose();

                    //DateTime dt = DateTime.ParseExact(submitQuoteData.QuoteMeta.EntryDate.ToString(), "dd/MM/yyyy", null);
                    //string entryDate = dt.ToString("dd/M/yyyy", CultureInfo.InvariantCulture);

                    //DateTime dt2 = DateTime.ParseExact(submitQuoteData.ReceiptDate.ToString(), "MM/dd/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                    //string reciptDate = dt2.ToString("dd/M/yyyy", CultureInfo.InvariantCulture);

                    //DateTime dt3 = DateTime.ParseExact(submitQuoteData.QuoteMeta.QuotedDate.ToString(), "MM/dd/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                    //string quotedDate = dt3.ToString("dd/M/yyyy", CultureInfo.InvariantCulture)
                    
                        document.Replace("<<ReceiptDate>>", submitQuoteData.BidStartDate.ToString(), true, true);
                        document.Replace("<<TodayDate>>", date.ToString("d"), true, true);
                        document.Replace("<<QuoteRefNo>>", (quoteInfo != null ? quoteInfo.QRN : ""), true, true);
                        document.Replace("<<CustomerName>>", submitQuoteData.QuoteMeta.CustomerName, true, true);
                        document.Replace("<<Address>>", submitQuoteData.QuoteMeta.Address1, true, true);
                        document.Replace("<<PostalCode>>", submitQuoteData.QuoteMeta.PostalCode, true, true);
                        //  document.Replace("<<ReciptMethod>>", submitQuoteData.ReceiptMethod != null ? submitQuoteData.ReceiptMethod : "", true, true);
                        document.Replace("<<ProjectName>>", ProjectInfo.ProjectName, true, true);
                        document.Replace("<<ScopeOfWorks>>", submitQuoteData.QuoteMeta.ScopeOfWorks, true, true);
                         document.Replace("<<ClientOrderRefNo>>", submitQuoteData.ClientOrderRefNo, true, true);
                        document.Replace("<<Subject>>", submitQuoteData.QuoteMeta.Subject != null ? submitQuoteData.QuoteMeta.Subject : "", true, true);
                        document.Replace("<<SiteName>>", submitQuoteData.QuoteMeta.ProposedWorks != null ? submitQuoteData.QuoteMeta.ProposedWorks : "", true, true);
                        document.Replace("<<WeWillAdviseYou>>", submitQuoteData.QuoteMeta.WeWillAdviseYou != null ? submitQuoteData.QuoteMeta.WeWillAdviseYou : "", true, true);
                        //document.Replace("<<OrganizationName>>", submitQuoteData.QuoteMeta.WeWillAdviseYou, true, true);
                        document.Replace("<<QuotedDate>>", submitQuoteData.QuoteMeta.QuotedDate.ToString(), true, true);
                        document.Replace("<<AttentionOf>>", submitQuoteData.QuoteMeta.AttentionOf, true, true);
                        document.Replace("<<ValueOfCommitment>>", submitQuoteData.QuoteMeta.ValueOfCommitment.ToString(), true, true);
                        document.Replace("<<UserName>>", submitQuoteData.QuoteMeta.CorrespondWithName != null ? submitQuoteData.QuoteMeta.CorrespondWithName : " ", true, true);
                        document.Replace("<<UserEmail>>", submitQuoteData.QuoteMeta.CorrespondWithEmail != null ? submitQuoteData.QuoteMeta.CorrespondWithEmail : "", true, true);

                        string targetFilePath2 = Path.Combine(_env.WebRootPath, "template\\PermissionToCommence\\PermissionToCommence_template.docx");
                        if (!Directory.Exists(targetFilePath))
                        {
                            Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "Temp\\bidinfo"));
                        }

                        fileStreamPath = System.IO.File.Create(targetFilePath2);
                        document.Save(fileStreamPath, FormatType.Docx);

                        fileStreamPath.Dispose();

                        byte[] bytes = File.ReadAllBytes(targetFilePath2);
                        string docBase64 = "data: application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + Convert.ToBase64String(bytes);
                        return docBase64;
                    }
                
            }
            catch (Exception e)
            {

                throw;
            }
            return "";
        }

        /* Code for the send mail*/
        public void SendEMail(string formData)
        {
                using (MailMessage mail = new MailMessage())
                {
                    mail.From = new MailAddress("vraj.s@quadwave.com");
                    mail.To.Add("vraj.s@quadwave.com");
                    mail.Subject = "Customer Commitment Received";
                    mail.Body = "<h1>Dear Customer, Please Find Your Commitment Received Document</h1>";
                    mail.IsBodyHtml = true;
                    var contentPath = Path.Combine(_env.WebRootPath, "template\\PermissionToCommence\\PermissionToCommence_template.docx");
                    Attachment data = new Attachment(contentPath, MediaTypeNames.Application.Octet);
                    mail.Attachments.Add(data);

                    //mailMessage.Attachments.Add(data);

                    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.Credentials = new NetworkCredential("juhi.t@quadwave.com", "ct##123456");
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                    }
                }
            
        }
        /*code for the reset task*/
        public async Task<bool> ResetTask(CreateOrEditProjectPTCWDto input)
        {

            //To Do Check About
            var IdDetails = await _projectPTCWRepository.GetAll().Where(x => x.ProjectId == input.ProjectId).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
            if (IdDetails != null)
            {
                var projectOACustCommAcceptance = await _projectPTCWRepository.FirstOrDefaultAsync((long)IdDetails.Id);
                input.LastModifierUserId = (long)AbpSession.UserId;
                input.LastModificationTime = DateTime.UtcNow;
                ObjectMapper.Map(input, projectOACustCommAcceptance);
            }
            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.CustomerCommitmentAcceptance,
                StatusId = input.StatusId,
                Comment = input.Comments
            });
            return true;
        }


    }
}