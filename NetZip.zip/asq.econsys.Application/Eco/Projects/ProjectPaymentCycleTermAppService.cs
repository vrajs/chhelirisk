﻿using asq.econsys.Eco.Projects;
using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.Projects
{
    //[AbpAuthorize(AppPermissions.Pages_ProjectPaymentCycleTerm)]
    public class ProjectPaymentCycleTermAppService : econsysAppServiceBase, IProjectPaymentCycleTermAppService
    {
        private readonly IRepository<ProjectPaymentCycleTerm, long> _projectPaymentCycleTermRepository;
        private readonly IProjectPaymentCycleTermExcelExporter _ProjectPaymentCycleTermExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectAction, long> _lookup_projectActionRepository;
        private readonly IRepository<ProjectExReviewDetail, long> _lookup_projectExReviewDetailRepository;

        public ProjectPaymentCycleTermAppService(IRepository<ProjectPaymentCycleTerm, long> projectPaymentCycleTermRepository, IProjectPaymentCycleTermExcelExporter ProjectPaymentCycleTermExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectAction, long> lookup_projectActionRepository, IRepository<ProjectExReviewDetail, long> lookup_projectExReviewDetailRepository)
        {
            _projectPaymentCycleTermRepository = projectPaymentCycleTermRepository;
            _ProjectPaymentCycleTermExcelExporter = ProjectPaymentCycleTermExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectActionRepository = lookup_projectActionRepository;
            _lookup_projectExReviewDetailRepository = lookup_projectExReviewDetailRepository;

        }

        public async Task<PagedResultDto<GetProjectPaymentCycleTermForViewDto>> GetAll(GetAllProjectPaymentCycleTermInput input)
        {

            var filteredProjectPaymentCycleTerm = _projectPaymentCycleTermRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectActionFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(input.MinSubmitByFilter != null, e => e.SubmitBy >= input.MinSubmitByFilter)
                        .WhereIf(input.MaxSubmitByFilter != null, e => e.SubmitBy <= input.MaxSubmitByFilter)

                        .WhereIf(input.MinValuedToFilter != null, e => e.ValuedTo >= input.MinValuedToFilter)
                        .WhereIf(input.MaxValuedToFilter != null, e => e.ValuedTo <= input.MaxValuedToFilter)

                        .WhereIf(input.MinDueDateFilter != null, e => e.DueDate >= input.MinDueDateFilter)
                        .WhereIf(input.MaxDueDateFilter != null, e => e.DueDate <= input.MaxDueDateFilter)

                        .WhereIf(input.MinPayNoticeByFilter != null, e => e.PayNoticeBy >= input.MinPayNoticeByFilter)
                        .WhereIf(input.MaxPayNoticeByFilter != null, e => e.PayNoticeBy <= input.MaxPayNoticeByFilter)

                        .WhereIf(input.MinPayLessNoticeByFilter != null, e => e.PayLessNoticeBy >= input.MinPayLessNoticeByFilter)
                        .WhereIf(input.MaxPayLessNoticeByFilter != null, e => e.PayLessNoticeBy <= input.MaxPayLessNoticeByFilter)

                        .WhereIf(input.MinFinalDateForPaymentFilter != null, e => e.FinalDateForPayment >= input.MinFinalDateForPaymentFilter)
                        .WhereIf(input.MaxFinalDateForPaymentFilter != null, e => e.FinalDateForPayment <= input.MaxFinalDateForPaymentFilter)

                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectActionStatusFilter), e => e.ProjectActionFk != null && e.ProjectActionFk.Status == input.ProjectActionStatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);

            var pagedAndFilteredProjectPaymentCycleTerm = filteredProjectPaymentCycleTerm
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var ProjectPaymentCycleTerm = from o in pagedAndFilteredProjectPaymentCycleTerm
                                     join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                     from s1 in j1.DefaultIfEmpty()

                                     join o2 in _lookup_projectActionRepository.GetAll() on o.ProjectActionId equals o2.Id into j2
                                     from s2 in j2.DefaultIfEmpty()

                                     join o3 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o3.Id into j3
                                     from s3 in j3.DefaultIfEmpty()

                                     select new
                                     {

                                         o.SubmitBy,
                                         o.ValuedTo,
                                         o.DueDate,
                                         o.PayNoticeBy,
                                         o.PayLessNoticeBy,
                                         o.FinalDateForPayment,
                                         Id = o.Id,
                                         ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                         ProjectActionStatus = s2 == null || s2.Status == null ? "" : s2.Status.ToString(),
                                         ProjectExReviewDetailTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
                                     };

            var totalCount = await filteredProjectPaymentCycleTerm.CountAsync();

            var dbList = await ProjectPaymentCycleTerm.ToListAsync();
            var results = new List<GetProjectPaymentCycleTermForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectPaymentCycleTermForViewDto()
                {
                    ProjectPaymentCycleTerm = new ProjectPaymentCycleTermDto
                    {

                        SubmitBy = o.SubmitBy,
                        ValuedTo = o.ValuedTo,
                        DueDate = o.DueDate,
                        PayNoticeBy = o.PayNoticeBy,
                        PayLessNoticeBy = o.PayLessNoticeBy,
                        FinalDateForPayment = o.FinalDateForPayment,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectActionStatus = o.ProjectActionStatus,
                    ProjectExReviewDetailTitle = o.ProjectExReviewDetailTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectPaymentCycleTermForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectPaymentCycleTermForViewDto> GetProjectPaymentCycleTermForView(long id)
        {
            var projectPaymentCycleTerm = await _projectPaymentCycleTermRepository.GetAsync(id);

            var output = new GetProjectPaymentCycleTermForViewDto { ProjectPaymentCycleTerm = ObjectMapper.Map<ProjectPaymentCycleTermDto>(projectPaymentCycleTerm) };

            if (output.ProjectPaymentCycleTerm.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectPaymentCycleTerm.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectPaymentCycleTerm.ProjectActionId != null)
            {
                var _lookupProjectAction = await _lookup_projectActionRepository.FirstOrDefaultAsync((long)output.ProjectPaymentCycleTerm.ProjectActionId);
                output.ProjectActionStatus = _lookupProjectAction?.Status?.ToString();
            }

            if (output.ProjectPaymentCycleTerm.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectPaymentCycleTerm.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPaymentCycleTerm_Edit)]
        public async Task<GetProjectPaymentCycleTermForEditOutput> GetProjectPaymentCycleTermForEdit(EntityDto<long> input)
        {
            var projectPaymentCycleTerm = await _projectPaymentCycleTermRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectPaymentCycleTermForEditOutput { ProjectPaymentCycleTerm = ObjectMapper.Map<CreateOrEditProjectPaymentCycleTermDto>(projectPaymentCycleTerm) };

            if (output.ProjectPaymentCycleTerm.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectPaymentCycleTerm.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectPaymentCycleTerm.ProjectActionId != null)
            {
                var _lookupProjectAction = await _lookup_projectActionRepository.FirstOrDefaultAsync((long)output.ProjectPaymentCycleTerm.ProjectActionId);
                output.ProjectActionStatus = _lookupProjectAction?.Status?.ToString();
            }

            if (output.ProjectPaymentCycleTerm.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectPaymentCycleTerm.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        public async Task<ProjectPaymentCycleTermDto> CreateOrEdit(CreateOrEditProjectPaymentCycleTermDto input)
        {
            ProjectPaymentCycleTerm PaymentCycleTerm = null;
            if (input.Id == null)
            {
                PaymentCycleTerm = await Create(input);
            }
            else
            {
                PaymentCycleTerm = await Update(input);
            }

            return PaymentCycleTerm == null ? null : ObjectMapper.Map<ProjectPaymentCycleTermDto>(PaymentCycleTerm);
        }

        //[AbpAuthorize(AppPermissions.Pages_ProjectPaymentCycleTerm_Create)]
        protected virtual async Task<ProjectPaymentCycleTerm> Create(CreateOrEditProjectPaymentCycleTermDto input)
        {
            var projectPaymentCycleTerm = ObjectMapper.Map<ProjectPaymentCycleTerm>(input);

            if (AbpSession.TenantId != null)
            {
                projectPaymentCycleTerm.TenantId = (int?)AbpSession.TenantId;
            }            

            var id = await _projectPaymentCycleTermRepository.InsertAndGetIdAsync(projectPaymentCycleTerm);
            if(id > 0)
            {
                var result = await _projectPaymentCycleTermRepository.FirstOrDefaultAsync((long)id);
                return result;
            }
            return null;
        }

        public async Task CreateImportExcel(List<CreateOrEditProjectPaymentCycleTermDto> inputList)
        {
            inputList.ForEach(async data =>
            {
                var projectPaymentCycleTerm = ObjectMapper.Map<ProjectPaymentCycleTerm>(data);
                if (AbpSession.TenantId != null)
                {
                    projectPaymentCycleTerm.TenantId = (int?)AbpSession.TenantId;
                }

                await _projectPaymentCycleTermRepository.InsertAsync(projectPaymentCycleTerm);
            });
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPaymentCycleTerm_Edit)]
        protected virtual async Task<ProjectPaymentCycleTerm> Update(CreateOrEditProjectPaymentCycleTermDto input)
        {
            var projectPaymentCycleTerm = await _projectPaymentCycleTermRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectPaymentCycleTerm);
            return projectPaymentCycleTerm;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPaymentCycleTerm_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectPaymentCycleTermRepository.DeleteAsync(input.Id);
        }

        //public async Task<FileDto> GetProjectPaymentCycleTermToExcel(GetAllProjectPaymentCycleTermForExcelInput input)
        //{

        //    var filteredProjectPaymentCycleTerm = _projectPaymentCycleTermRepository.GetAll()
        //                .Include(e => e.ProjectFk)
        //                .Include(e => e.ProjectActionFk)
        //                .Include(e => e.ProjectExReviewDetailFk)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter) || e.Category.Contains(input.Filter) || e.Comment.Contains(input.Filter))
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CategoryFilter), e => e.Category == input.CategoryFilter)
        //                .WhereIf(input.MinCostAmountApprovedFilter != null, e => e.CostAmountApproved >= input.MinCostAmountApprovedFilter)
        //                .WhereIf(input.MaxCostAmountApprovedFilter != null, e => e.CostAmountApproved <= input.MaxCostAmountApprovedFilter)
        //                .WhereIf(input.MinCostAmountFilter != null, e => e.CostAmount >= input.MinCostAmountFilter)
        //                .WhereIf(input.MaxCostAmountFilter != null, e => e.CostAmount <= input.MaxCostAmountFilter)
        //                .WhereIf(input.MinCostEstimateFilter != null, e => e.CostEstimate >= input.MinCostEstimateFilter)
        //                .WhereIf(input.MaxCostEstimateFilter != null, e => e.CostEstimate <= input.MaxCostEstimateFilter)
        //                .WhereIf(input.MinCostVarianceFilter != null, e => e.CostVariance >= input.MinCostVarianceFilter)
        //                .WhereIf(input.MaxCostVarianceFilter != null, e => e.CostVariance <= input.MaxCostVarianceFilter)
        //                .WhereIf(input.MinCostActualReceivedFilter != null, e => e.CostActualReceived >= input.MinCostActualReceivedFilter)
        //                .WhereIf(input.MaxCostActualReceivedFilter != null, e => e.CostActualReceived <= input.MaxCostActualReceivedFilter)
        //                .WhereIf(input.MinCostEstimatedToComeFilter != null, e => e.CostEstimatedToCome >= input.MinCostEstimatedToComeFilter)
        //                .WhereIf(input.MaxCostEstimatedToComeFilter != null, e => e.CostEstimatedToCome <= input.MaxCostEstimatedToComeFilter)
        //                .WhereIf(input.MinSellAmountApprovedFilter != null, e => e.SellAmountApproved >= input.MinSellAmountApprovedFilter)
        //                .WhereIf(input.MaxSellAmountApprovedFilter != null, e => e.SellAmountApproved <= input.MaxSellAmountApprovedFilter)
        //                .WhereIf(input.MinSellAmountFilter != null, e => e.SellAmount >= input.MinSellAmountFilter)
        //                .WhereIf(input.MaxSellAmountFilter != null, e => e.SellAmount <= input.MaxSellAmountFilter)
        //                .WhereIf(input.MinSellEstimateFilter != null, e => e.SellEstimate >= input.MinSellEstimateFilter)
        //                .WhereIf(input.MaxSellEstimateFilter != null, e => e.SellEstimate <= input.MaxSellEstimateFilter)
        //                .WhereIf(input.MinSellVarianceFilter != null, e => e.SellVariance >= input.MinSellVarianceFilter)
        //                .WhereIf(input.MaxSellVarianceFilter != null, e => e.SellVariance <= input.MaxSellVarianceFilter)
        //                .WhereIf(input.MinMarginAmountFilter != null, e => e.MarginAmount >= input.MinMarginAmountFilter)
        //                .WhereIf(input.MaxMarginAmountFilter != null, e => e.MarginAmount <= input.MaxMarginAmountFilter)
        //                .WhereIf(input.MinMarginPercFilter != null, e => e.MarginPerc >= input.MinMarginPercFilter)
        //                .WhereIf(input.MaxMarginPercFilter != null, e => e.MarginPerc <= input.MaxMarginPercFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectActionStatusFilter), e => e.ProjectActionFk != null && e.ProjectActionFk.Status == input.ProjectActionStatusFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);

        //    var query = (from o in filteredProjectPaymentCycleTerm
        //                 join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
        //                 from s1 in j1.DefaultIfEmpty()

        //                 join o2 in _lookup_projectActionRepository.GetAll() on o.ProjectActionId equals o2.Id into j2
        //                 from s2 in j2.DefaultIfEmpty()

        //                 join o3 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o3.Id into j3
        //                 from s3 in j3.DefaultIfEmpty()

        //                 select new GetProjectPaymentCycleTermForViewDto()
        //                 {
        //                     ProjectPaymentCycleTerm = new ProjectPaymentCycleTermDto
        //                     {
        //                         Title = o.Title,
        //                         Category = o.Category,
        //                         CostAmountApproved = o.CostAmountApproved,
        //                         CostAmount = o.CostAmount,
        //                         CostEstimate = o.CostEstimate,
        //                         CostVariance = o.CostVariance,
        //                         CostActualReceived = o.CostActualReceived,
        //                         CostEstimatedToCome = o.CostEstimatedToCome,
        //                         SellAmountApproved = o.SellAmountApproved,
        //                         SellAmount = o.SellAmount,
        //                         SellEstimate = o.SellEstimate,
        //                         SellVariance = o.SellVariance,
        //                         MarginAmount = o.MarginAmount,
        //                         MarginPerc = o.MarginPerc,
        //                         Comment = o.Comment,
        //                         Id = o.Id
        //                     },
        //                     ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
        //                     ProjectActionStatus = s2 == null || s2.Status == null ? "" : s2.Status.ToString(),
        //                     ProjectExReviewDetailTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
        //                 });

        //    var projectPaymentCycleTermListDtos = await query.ToListAsync();

        //    return _ProjectPaymentCycleTermExcelExporter.ExportToFile(projectPaymentCycleTermListDtos);
        //}

        [AbpAuthorize(AppPermissions.Pages_ProjectPaymentCycleTerm)]
        public async Task<List<ProjectPaymentCycleTermProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectPaymentCycleTermProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPaymentCycleTerm)]
        public async Task<List<ProjectPaymentCycleTermProjectActionLookupTableDto>> GetAllProjectActionForTableDropdown()
        {
            return await _lookup_projectActionRepository.GetAll()
                .Select(projectAction => new ProjectPaymentCycleTermProjectActionLookupTableDto
                {
                    Id = projectAction.Id,
                    DisplayName = projectAction == null || projectAction.Status == null ? "" : projectAction.Status.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPaymentCycleTerm)]
        public async Task<List<ProjectPaymentCycleTermProjectExReviewDetailLookupTableDto>> GetAllProjectExReviewDetailForTableDropdown()
        {
            return await _lookup_projectExReviewDetailRepository.GetAll()
                .Select(projectExReviewDetail => new ProjectPaymentCycleTermProjectExReviewDetailLookupTableDto
                {
                    Id = projectExReviewDetail.Id,
                    DisplayName = projectExReviewDetail == null || projectExReviewDetail.Title == null ? "" : projectExReviewDetail.Title.ToString()
                }).ToListAsync();
        }


        /// <summary>
        /// taskRefId can be: ProjectQuoteFormId, ProjectOACustCommAcceptanceId, ProjectExReviewDetailId
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="taskId"></param>
        /// <param name="taskRefId"></param>
        /// <returns></returns>
        public async Task<List<ProjectPaymentCycleTermDto>> GetPaymentCycleTerms(long projectId, string taskId, long taskRefId)
        {
            var results = new List<ProjectPaymentCycleTermDto>();
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    /// TODO: need to check this
                    var dbList = await _projectPaymentCycleTermRepository.GetAllIncluding(x => x.ProjectFk)
                        .Where(x => x.ProjectId == projectId && x.NodeTaskId.ToLower() == taskId.ToLower())
                        .WhereIf(taskId == CNodeTasks.CommercialTasksPriortoCommencement, x => x.ProjectCTPCId == (taskRefId == 0 ? null : taskRefId))
                        .ToListAsync();

                    foreach (var o in dbList)
                    {
                        var res = new ProjectPaymentCycleTermDto
                        {
                            SubmitBy = o.SubmitBy,
                            ValuedTo = o.ValuedTo,
                            DueDate = o.DueDate,
                            PayNoticeBy = o.PayNoticeBy,
                            PayLessNoticeBy = o.PayLessNoticeBy,
                            FinalDateForPayment = o.FinalDateForPayment,
                            ProjectId = o.ProjectId,
                            Id = o.Id,
                            ProjectActionId = o.ProjectActionId,
                            ProjectCTPCId = o.ProjectCTPCId,
                            ProjectExReviewDetailId = o.ProjectExReviewDetailId,
                            NodeTaskId = o.NodeTaskId
                        };

                        results.Add(res);
                    }
                }
            }

            return results;
        }

    }
}