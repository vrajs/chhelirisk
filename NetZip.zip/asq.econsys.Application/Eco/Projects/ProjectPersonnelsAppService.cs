﻿using Abp.Organizations;
using asq.econsys.Eco.Projects;
using asq.econsys.Authorization.Users;
using asq.econsys.Authorization.Roles;
using asq.econsys.Eco.NodeTasks;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Events.Bus;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels)]
    public class ProjectPersonnelsAppService : econsysAppServiceBase, IProjectPersonnelsAppService
    {
        private readonly IRepository<ProjectPersonnel, long> _projectPersonnelRepository;
        private readonly IProjectPersonnelsExcelExporter _projectPersonnelsExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<User, long> _lookup_userRepository;
        private readonly IRepository<Role, int> _lookup_roleRepository;
        private readonly IRepository<NodeStage, string> _lookup_nodeStageRepository;
        private readonly IRepository<NodeTask, string> _lookup_nodeTaskRepository;
        private readonly IRepository<ProjectComment, long> _projectCommentRepository;
        private readonly ProjectPermissionManager _projectPermissionManager;

        public IEventBus EventBus { get; set; }
        private readonly IUnitOfWorkManager _unitOfWorkManager;

        public ProjectPersonnelsAppService(IUnitOfWorkManager unitOfWorkManager, IRepository<ProjectPersonnel, long> projectPersonnelRepository, IProjectPersonnelsExcelExporter projectPersonnelsExcelExporter, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository, IRepository<Project, long> lookup_projectRepository, IRepository<User, long> lookup_userRepository, IRepository<Role, int> lookup_roleRepository, IRepository<NodeStage, string> lookup_nodeStageRepository, IRepository<NodeTask, string> lookup_nodeTaskRepository, IRepository<ProjectComment, long> projectCommentRepository, ProjectPermissionManager projectPermissionManager)
        {
            EventBus = NullEventBus.Instance;
            _unitOfWorkManager = unitOfWorkManager;
            _projectPersonnelRepository = projectPersonnelRepository;
            _projectPersonnelsExcelExporter = projectPersonnelsExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_userRepository = lookup_userRepository;
            _lookup_roleRepository = lookup_roleRepository;
            _lookup_nodeStageRepository = lookup_nodeStageRepository;
            _lookup_nodeTaskRepository = lookup_nodeTaskRepository;
            _projectCommentRepository = projectCommentRepository;
            _projectPermissionManager = projectPermissionManager;

        }

        public async Task<PagedResultDto<GetProjectPersonnelForViewDto>> GetAll(GetAllProjectPersonnelsInput input)
        {

            var filteredProjectPersonnels = _projectPersonnelRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.ProjectFk)
                        .Include(e => e.UserFk)
                        .Include(e => e.RoleFk)
                        .Include(e => e.NodeStageFk)
                        .Include(e => e.NodeTaskFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.UserNameFilter), e => e.UserFk != null && e.UserFk.Name == input.UserNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RoleNameFilter), e => e.RoleFk != null && e.RoleFk.Name == input.RoleNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeStageIdFilter), e => e.NodeStageFk != null && e.NodeStageFk.Id == input.NodeStageIdFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter);

            var pagedAndFilteredProjectPersonnels = filteredProjectPersonnels
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectPersonnels = from o in pagedAndFilteredProjectPersonnels
                                    join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                                    from s1 in j1.DefaultIfEmpty()

                                    join o2 in _lookup_projectRepository.GetAll() on o.ProjectId equals o2.Id into j2
                                    from s2 in j2.DefaultIfEmpty()

                                    join o3 in _lookup_userRepository.GetAll() on o.UserId equals o3.Id into j3
                                    from s3 in j3.DefaultIfEmpty()

                                    join o4 in _lookup_roleRepository.GetAll() on o.RoleId equals o4.Id into j4
                                    from s4 in j4.DefaultIfEmpty()

                                    join o5 in _lookup_nodeStageRepository.GetAll() on o.NodeStageId equals o5.Id into j5
                                    from s5 in j5.DefaultIfEmpty()

                                    join o6 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o6.Id into j6
                                    from s6 in j6.DefaultIfEmpty()

                                    select new
                                    {

                                        Id = o.Id,
                                        OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                                        ProjectProjectName = s2 == null || s2.ProjectName == null ? "" : s2.ProjectName.ToString(),
                                        UserName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
                                        RoleName = s4 == null || s4.Name == null ? "" : s4.Name.ToString(),
                                        NodeStageId = s5 == null || s5.Id == null ? "" : s5.Id.ToString(),
                                        NodeTaskTaskName = s6 == null || s6.TaskName == null ? "" : s6.TaskName.ToString(),
                                       o.ProjectId,
                                       o.RoleId,
                                       o.UserId
                                    };

            var totalCount = await filteredProjectPersonnels.CountAsync();

            var dbList = await projectPersonnels.ToListAsync();
            var results = new List<GetProjectPersonnelForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectPersonnelForViewDto()
                {
                    ProjectPersonnel = new ProjectPersonnelDto
                    {

                        Id = o.Id,
                        ProjectId=o.ProjectId,
                        RoleId=o.RoleId,
                        UserId=o.UserId
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
                    ProjectProjectName = o.ProjectProjectName,
                    UserName = o.UserName,
                    RoleName = o.RoleName,
                    NodeStageId = o.NodeStageId,
                    NodeTaskTaskName = o.NodeTaskTaskName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectPersonnelForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectPersonnelForViewDto> GetProjectPersonnelForView(long id)
        {
            var projectPersonnel = await _projectPersonnelRepository.GetAsync(id);

            var output = new GetProjectPersonnelForViewDto { ProjectPersonnel = ObjectMapper.Map<ProjectPersonnelDto>(projectPersonnel) };

            if (output.ProjectPersonnel.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.ProjectPersonnel.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.ProjectPersonnel.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectPersonnel.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectPersonnel.UserId != null)
            {
                var _lookupUser = await _lookup_userRepository.FirstOrDefaultAsync((long)output.ProjectPersonnel.UserId);
                output.UserName = _lookupUser?.Name?.ToString();
            }

            if (output.ProjectPersonnel.RoleId != null)
            {
                var _lookupRole = await _lookup_roleRepository.FirstOrDefaultAsync((int)output.ProjectPersonnel.RoleId);
                output.RoleName = _lookupRole?.Name?.ToString();
            }

            if (output.ProjectPersonnel.NodeStageId != null)
            {
                var _lookupNodeStage = await _lookup_nodeStageRepository.FirstOrDefaultAsync((string)output.ProjectPersonnel.NodeStageId);
                output.NodeStageId = _lookupNodeStage?.Id?.ToString();
            }

            if (output.ProjectPersonnel.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectPersonnel.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels_Edit)]
        public async Task<GetProjectPersonnelForEditOutput> GetProjectPersonnelForEdit(EntityDto<long> input)
        {
            var projectPersonnel = await _projectPersonnelRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectPersonnelForEditOutput { ProjectPersonnel = ObjectMapper.Map<CreateOrEditProjectPersonnelDto>(projectPersonnel) };

            if (output.ProjectPersonnel.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.ProjectPersonnel.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.ProjectPersonnel.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectPersonnel.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectPersonnel.UserId != null)
            {
                var _lookupUser = await _lookup_userRepository.FirstOrDefaultAsync((long)output.ProjectPersonnel.UserId);
                output.UserName = _lookupUser?.Name?.ToString();
            }

            if (output.ProjectPersonnel.RoleId != null)
            {
                var _lookupRole = await _lookup_roleRepository.FirstOrDefaultAsync((int)output.ProjectPersonnel.RoleId);
                output.RoleName = _lookupRole?.Name?.ToString();
            }

            if (output.ProjectPersonnel.NodeStageId != null)
            {
                var _lookupNodeStage = await _lookup_nodeStageRepository.FirstOrDefaultAsync((string)output.ProjectPersonnel.NodeStageId);
                output.NodeStageId = _lookupNodeStage?.Id?.ToString();
            }

            if (output.ProjectPersonnel.NodeTaskId != null)
            {
                var _lookupNodeTask = await _lookup_nodeTaskRepository.FirstOrDefaultAsync((string)output.ProjectPersonnel.NodeTaskId);
                output.NodeTaskTaskName = _lookupNodeTask?.TaskName?.ToString();
            }

            return output;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit(CreateOrEditProjectPersonnelDto input)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = input.ProjectId
            });
            if (!check)
            {
                throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            }

            await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        if (input.Id == null)
                        {
                            await Create(input);
                        }
                        else
                        {
                            await Update(input);
                        }

                        await EventBus.TriggerAsync(new EditProjectEventData()
                        {
                            ProjectId = input.ProjectId,
                            StageId = CNodeStages.PreOrder,
                            TaskId = CNodeTasks.AssignSalesLeader,
                            StatusId = input.StatusId,
                            Comment = input.Comment,
                            LoggedInUserId = (long)AbpSession.UserId
                        });
                    }
                }
            });

            var project = await _lookup_projectRepository.FirstOrDefaultAsync(input.ProjectId);
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);

            return result;
        }
        #region Appoint Key Staff
        public async Task<GetProjectForViewDto> CreateOrEditAppointKeyStaff(CreateOrEditProjectAppointKeyStaffDto input)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = input.ProjectId
            });
            if (!check)
            {
                throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            }


                await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        if (input.Id == null)
                        {
                            await CreateAppointKeyStaff(input);
                        }
                        else
                        {
                            await UpdateAppointKeyStaff(input);
                        }

                        await EventBus.TriggerAsync(new EditProjectEventData()
                        {
                            ProjectId = input.ProjectId,
                            StageId = CNodeStages.OrderAcceptance,
                            TaskId = CNodeTasks.AppointKeyStaff,
                            StatusId = input.StatusId,
                            Comment = input.Comment,
                            LoggedInUserId = (long)AbpSession.UserId
                        });
                    }
                }
            });
            var project = await _lookup_projectRepository.FirstOrDefaultAsync(input.ProjectId);
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);

            return result;
        }
        protected virtual async Task CreateAppointKeyStaff(CreateOrEditProjectAppointKeyStaffDto input)
        {
            foreach (var UsrRole in input.UserRoleList)
            {
                ProjectPersonnel projectPersonnel = new ProjectPersonnel();
                input.NodeStageId = CNodeStages.OrderAcceptance;
                if (AbpSession.TenantId != null)
                {
                    projectPersonnel.TenantId = (int?)AbpSession.TenantId;
                }
                projectPersonnel.UserId = UsrRole.userid;
                projectPersonnel.RoleId = UsrRole.roleid;
                projectPersonnel.NodeStageId = CNodeStages.OrderAcceptance;
                projectPersonnel.NodeTaskId = CNodeTasks.AppointKeyStaff;
                projectPersonnel.ProjectId = input.ProjectId;
                await _projectPersonnelRepository.InsertAsync(projectPersonnel);
            }
        }
        protected virtual async Task UpdateAppointKeyStaff(CreateOrEditProjectAppointKeyStaffDto input)
        {
            //For Transaction History maintain isdeleted
            var projectPersonnel = _projectPersonnelRepository.GetAll().Where(x => x.ProjectId == input.ProjectId
                                    && x.NodeTaskId == CNodeTasks.AppointKeyStaff 
                                    && x.IsDeleted == false).ToList();

            foreach (var UsrRole in input.UserRoleList)
            {
                foreach(var PP in projectPersonnel)
                {
                    if(PP.Id == UsrRole.Id)
                    {
                        if(UsrRole.userid != PP.UserId)
                        {
                            PP.IsDeleted = true;
                            ProjectPersonnel projectPersonnelInsert = new ProjectPersonnel();
                            input.NodeStageId = CNodeStages.OrderAcceptance;
                            if (AbpSession.TenantId != null)
                            {
                                projectPersonnelInsert.TenantId = (int?)AbpSession.TenantId;
                            }
                            projectPersonnelInsert.UserId = UsrRole.userid;
                            projectPersonnelInsert.RoleId = UsrRole.roleid;
                            projectPersonnelInsert.NodeStageId = CNodeStages.OrderAcceptance;
                            projectPersonnelInsert.NodeTaskId = CNodeTasks.AppointKeyStaff;
                            projectPersonnelInsert.ProjectId = input.ProjectId;
                            await _projectPersonnelRepository.InsertAsync(projectPersonnelInsert);
                        }
                    }
                }
            }
            //ObjectMapper.Map(input, projectPersonnel);
            //await CreateAppointKeyStaff(input);
        }
        #endregion

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels_Create)]
        protected virtual async Task Create(CreateOrEditProjectPersonnelDto input)
        {
            var projectPersonnel = ObjectMapper.Map<ProjectPersonnel>(input);

            if (AbpSession.TenantId != null)
            {
                projectPersonnel.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectPersonnelRepository.InsertAsync(projectPersonnel);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels_Edit)]
        protected virtual async Task Update(CreateOrEditProjectPersonnelDto input)
        {
            var projectPersonnel = await _projectPersonnelRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectPersonnel);
        }



        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectPersonnelRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectPersonnelsToExcel(GetAllProjectPersonnelsForExcelInput input)
        {

            var filteredProjectPersonnels = _projectPersonnelRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.ProjectFk)
                        .Include(e => e.UserFk)
                        .Include(e => e.RoleFk)
                        .Include(e => e.NodeStageFk)
                        .Include(e => e.NodeTaskFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.UserNameFilter), e => e.UserFk != null && e.UserFk.Name == input.UserNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RoleNameFilter), e => e.RoleFk != null && e.RoleFk.Name == input.RoleNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeStageIdFilter), e => e.NodeStageFk != null && e.NodeStageFk.Id == input.NodeStageIdFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter);

            var query = (from o in filteredProjectPersonnels
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_projectRepository.GetAll() on o.ProjectId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_userRepository.GetAll() on o.UserId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         join o4 in _lookup_roleRepository.GetAll() on o.RoleId equals o4.Id into j4
                         from s4 in j4.DefaultIfEmpty()

                         join o5 in _lookup_nodeStageRepository.GetAll() on o.NodeStageId equals o5.Id into j5
                         from s5 in j5.DefaultIfEmpty()

                         join o6 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o6.Id into j6
                         from s6 in j6.DefaultIfEmpty()

                         select new GetProjectPersonnelForViewDto()
                         {
                             ProjectPersonnel = new ProjectPersonnelDto
                             {
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                             ProjectProjectName = s2 == null || s2.ProjectName == null ? "" : s2.ProjectName.ToString(),
                             UserName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
                             RoleName = s4 == null || s4.Name == null ? "" : s4.Name.ToString(),
                             NodeStageId = s5 == null || s5.Id == null ? "" : s5.Id.ToString(),
                             NodeTaskTaskName = s6 == null || s6.TaskName == null ? "" : s6.TaskName.ToString()
                         });

            var projectPersonnelListDtos = await query.ToListAsync();

            return _projectPersonnelsExcelExporter.ExportToFile(projectPersonnelListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels)]
        public async Task<List<ProjectPersonnelOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new ProjectPersonnelOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels)]
        public async Task<List<ProjectPersonnelProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectPersonnelProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels)]
        public async Task<List<ProjectPersonnelUserLookupTableDto>> GetAllUserForTableDropdown()
        {
            return await _lookup_userRepository.GetAll()
                .Select(user => new ProjectPersonnelUserLookupTableDto
                {
                    Id = user.Id,
                    DisplayName = user == null || user.Name == null ? "" : user.Name.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels)]
        public async Task<List<ProjectPersonnelRoleLookupTableDto>> GetAllRoleForTableDropdown()
        {
            return await _lookup_roleRepository.GetAll()
                .Select(role => new ProjectPersonnelRoleLookupTableDto
                {
                    Id = role.Id,
                    DisplayName = role == null || role.Name == null ? "" : role.Name.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels)]
        public async Task<List<ProjectPersonnelNodeStageLookupTableDto>> GetAllNodeStageForTableDropdown()
        {
            return await _lookup_nodeStageRepository.GetAll()
                .Select(nodeStage => new ProjectPersonnelNodeStageLookupTableDto
                {
                    Id = nodeStage.Id,
                    DisplayName = nodeStage == null || nodeStage.Id == null ? "" : nodeStage.Id.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPersonnels)]
        public async Task<List<ProjectPersonnelNodeTaskLookupTableDto>> GetAllNodeTaskForTableDropdown()
        {
            return await _lookup_nodeTaskRepository.GetAll()
                .Select(nodeTask => new ProjectPersonnelNodeTaskLookupTableDto
                {
                    Id = nodeTask.Id,
                    DisplayName = nodeTask == null || nodeTask.TaskName == null ? "" : nodeTask.TaskName.ToString()
                }).ToListAsync();
        }

        public async Task<GetProjectForEditOutput> Allocate(long projectId)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = projectId
            });
            if (!check)
            {
                throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            }

            //var hasExisitng = _projectEngineeringRepository.GetAll().Where(x => x.ProjectId == projectId).ToList();
            var project = _lookup_projectRepository.FirstOrDefault(projectId);
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.PreOrder,
                TaskId = CNodeTasks.AssignSalesLeader,
                //ActionId = CNodeActions.AssignSalesLeader,
                StatusId = CNodeStatuses.Submit
            });
            project = await _lookup_projectRepository.FirstOrDefaultAsync(projectId);

            var output = new GetProjectForEditOutput { Project = ObjectMapper.Map<CreateOrEditProjectDto>(project) };

            return output;
        }
    }
}