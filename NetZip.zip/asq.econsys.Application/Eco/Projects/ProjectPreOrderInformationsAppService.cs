﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectPreOrderInformations)]
    public class ProjectPreOrderInformationsAppService : econsysAppServiceBase, IProjectPreOrderInformationsAppService
    {
        private readonly IRepository<ProjectPreOrderInformation, long> _projectPreOrderInformationRepository;
        private readonly IProjectPreOrderInformationsExcelExporter _projectPreOrderInformationsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;

        public ProjectPreOrderInformationsAppService(IRepository<ProjectPreOrderInformation, long> projectPreOrderInformationRepository, IProjectPreOrderInformationsExcelExporter projectPreOrderInformationsExcelExporter, IRepository<Project, long> lookup_projectRepository)
        {
            _projectPreOrderInformationRepository = projectPreOrderInformationRepository;
            _projectPreOrderInformationsExcelExporter = projectPreOrderInformationsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;

        }

        public async Task<PagedResultDto<GetProjectPreOrderInformationForViewDto>> GetAll(GetAllProjectPreOrderInformationsInput input)
        {

            var filteredProjectPreOrderInformations = _projectPreOrderInformationRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(input.MinInformationDateFilter != null, e => e.InformationDate >= input.MinInformationDateFilter)
                        .WhereIf(input.MaxInformationDateFilter != null, e => e.InformationDate <= input.MaxInformationDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var pagedAndFilteredProjectPreOrderInformations = filteredProjectPreOrderInformations
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectPreOrderInformations = from o in pagedAndFilteredProjectPreOrderInformations
                                              join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                              from s1 in j1.DefaultIfEmpty()

                                              select new
                                              {

                                                  o.InformationDate,
                                                  Id = o.Id,
                                                  ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                                              };

            var totalCount = await filteredProjectPreOrderInformations.CountAsync();

            var dbList = await projectPreOrderInformations.ToListAsync();
            var results = new List<GetProjectPreOrderInformationForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectPreOrderInformationForViewDto()
                {
                    ProjectPreOrderInformation = new ProjectPreOrderInformationDto
                    {

                        InformationDate = o.InformationDate,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectPreOrderInformationForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectPreOrderInformationForViewDto> GetProjectPreOrderInformationForView(long id)
        {
            var projectPreOrderInformation = await _projectPreOrderInformationRepository.GetAsync(id);

            var output = new GetProjectPreOrderInformationForViewDto { ProjectPreOrderInformation = ObjectMapper.Map<ProjectPreOrderInformationDto>(projectPreOrderInformation) };

            if (output.ProjectPreOrderInformation.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectPreOrderInformation.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPreOrderInformations_Edit)]
        public async Task<GetProjectPreOrderInformationForEditOutput> GetProjectPreOrderInformationForEdit(EntityDto<long> input)
        {
            var projectPreOrderInformation = await _projectPreOrderInformationRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectPreOrderInformationForEditOutput { ProjectPreOrderInformation = ObjectMapper.Map<CreateOrEditProjectPreOrderInformationDto>(projectPreOrderInformation) };

            if (output.ProjectPreOrderInformation.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectPreOrderInformation.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectPreOrderInformationDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPreOrderInformations_Create)]
        protected virtual async Task Create(CreateOrEditProjectPreOrderInformationDto input)
        {
            var projectPreOrderInformation = ObjectMapper.Map<ProjectPreOrderInformation>(input);

            if (AbpSession.TenantId != null)
            {
                projectPreOrderInformation.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectPreOrderInformationRepository.InsertAsync(projectPreOrderInformation);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPreOrderInformations_Edit)]
        protected virtual async Task Update(CreateOrEditProjectPreOrderInformationDto input)
        {
            var projectPreOrderInformation = await _projectPreOrderInformationRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectPreOrderInformation);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPreOrderInformations_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectPreOrderInformationRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectPreOrderInformationsToExcel(GetAllProjectPreOrderInformationsForExcelInput input)
        {

            var filteredProjectPreOrderInformations = _projectPreOrderInformationRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false)
                        .WhereIf(input.MinInformationDateFilter != null, e => e.InformationDate >= input.MinInformationDateFilter)
                        .WhereIf(input.MaxInformationDateFilter != null, e => e.InformationDate <= input.MaxInformationDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter);

            var query = (from o in filteredProjectPreOrderInformations
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetProjectPreOrderInformationForViewDto()
                         {
                             ProjectPreOrderInformation = new ProjectPreOrderInformationDto
                             {
                                 InformationDate = o.InformationDate,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString()
                         });

            var projectPreOrderInformationListDtos = await query.ToListAsync();

            return _projectPreOrderInformationsExcelExporter.ExportToFile(projectPreOrderInformationListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectPreOrderInformations)]
        public async Task<List<ProjectPreOrderInformationProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectPreOrderInformationProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

    }
}