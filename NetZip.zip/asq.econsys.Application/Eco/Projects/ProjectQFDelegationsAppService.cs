﻿using asq.econsys.Eco.Projects;
using asq.econsys.Authorization.Users;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Events.Bus;
using Microsoft.AspNetCore.Mvc;
using asq.econsys.Authorization.Users.Dto;
using Newtonsoft.Json;
using asq.econsys.Eco.Utils.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectQFDelegations)]
    public class ProjectQFDelegationsAppService : econsysAppServiceBase, IProjectQFDelegationsAppService
    {
        private readonly IRepository<ProjectQFDelegation, long> _projectQFDelegationRepository;
        private readonly IProjectQFDelegationsExcelExporter _projectQFDelegationsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<User, long> _lookup_userRepository;
        private readonly IRepository<ProjectQuoteForm, long> _lookup_projectQuoteFormRepository; 
        private readonly IRepository<User, long> _fillRoleNames;
        private readonly IRepository<User, long> _userRoleRepository;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly StorageManager _storageManager;
        public IEventBus EventBus { get; set; }

        public ProjectQFDelegationsAppService(IRepository<ProjectQFDelegation, long> projectQFDelegationRepository, IProjectQFDelegationsExcelExporter projectQFDelegationsExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<User, long> lookup_userRepository, IRepository<ProjectQuoteForm, long> lookup_projectQuoteFormRepository,
          IRepository<User, long> fillRoleNames, IRepository<User, long> userRoleRepository, Utils.UtilsAppService utilsAppService)
        {
            EventBus = NullEventBus.Instance;
            _projectQFDelegationRepository = projectQFDelegationRepository;
            _projectQFDelegationsExcelExporter = projectQFDelegationsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_userRepository = lookup_userRepository;
            _lookup_projectQuoteFormRepository = lookup_projectQuoteFormRepository;
            _fillRoleNames = fillRoleNames;
            _userRoleRepository = userRoleRepository;
            _utilsAppService = utilsAppService;
        }

        public async Task<PagedResultDto<GetProjectQFDelegationForViewDto>> GetAll(GetAllProjectQFDelegationsInput input)
        {
            input.MaxResultCount = 100;
            var filteredProjectQFDelegations = _projectQFDelegationRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.AssignToFk)
                        .Include(e => e.ProjectQuoteFormFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Category.Contains(input.Filter) || e.Revision.Contains(input.Filter) || e.RequestComments.Contains(input.Filter) || e.ResponseComments.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CategoryFilter), e => e.Category == input.CategoryFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevisionFilter), e => e.Revision == input.RevisionFilter)
                        .WhereIf(input.MinRequiredByDateFilter != null, e => e.RequiredByDate >= input.MinRequiredByDateFilter)
                        .WhereIf(input.MaxRequiredByDateFilter != null, e => e.RequiredByDate <= input.MaxRequiredByDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RequestCommentsFilter), e => e.RequestComments == input.RequestCommentsFilter)
                        .WhereIf(input.MinResponseDateFilter != null, e => e.ResponseDate >= input.MinResponseDateFilter)
                        .WhereIf(input.MaxResponseDateFilter != null, e => e.ResponseDate <= input.MaxResponseDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ResponseCommentsFilter), e => e.ResponseComments == input.ResponseCommentsFilter)
                        .WhereIf(input.IsCurrentFilter.HasValue && input.IsCurrentFilter > -1, e => (input.IsCurrentFilter == 1 && e.IsCurrent) || (input.IsCurrentFilter == 0 && !e.IsCurrent))
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.UserNameFilter), e => e.AssignToFk != null && e.AssignToFk.UserName == input.UserNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectQuoteFormQRNFilter), e => e.ProjectQuoteFormFk != null && e.ProjectQuoteFormFk.QRN == input.ProjectQuoteFormQRNFilter);

            var pagedAndFilteredProjectQFDelegations = filteredProjectQFDelegations
                .OrderBy(input.Sorting ?? "DisplayOrder desc")
                .PageBy(input);

            var projectQFDelegations = from o in pagedAndFilteredProjectQFDelegations
                                       join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                       from s1 in j1.DefaultIfEmpty()

                                       join o2 in _lookup_userRepository.GetAll() on o.AssignTo equals o2.Id into j2
                                       from s2 in j2.DefaultIfEmpty()

                                       join o3 in _lookup_projectQuoteFormRepository.GetAll() on o.ProjectQuoteFormId equals o3.Id into j3
                                       from s3 in j3.DefaultIfEmpty()

                                       select new
                                       {

                                           o.Category,
                                           o.Revision,
                                           o.RequiredByDate,
                                           o.RequestComments,
                                           o.ResponseDate,
                                           o.ResponseComments,
                                           o.IsCurrent,
                                           o.DisplayOrder,
                                           Id = o.Id,
                                           o.AssignTo,
                                           ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                           UserName = s2 == null || s2.Name == null ? "" : s2.Name.ToString(),
                                           ProjectQuoteFormQRN = s3 == null || s3.QRN == null ? "" : s3.QRN.ToString(),
                                           o.ProjectId
                                       };

            var totalCount = await filteredProjectQFDelegations.CountAsync();

            var dbList = await projectQFDelegations.ToListAsync();
            var results = new List<GetProjectQFDelegationForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectQFDelegationForViewDto()
                {
                    ProjectQFDelegation = new ProjectQFDelegationDto
                    {

                        Category = o.Category,
                        Revision = o.Revision,
                        RequiredByDate = o.RequiredByDate,
                        RequestComments = o.RequestComments,
                        ResponseDate = o.ResponseDate,
                        ResponseComments = o.ResponseComments,
                        IsCurrent = o.IsCurrent,
                        DisplayOrder = o.DisplayOrder,
                        AssignTo = o.AssignTo,
                        Id = o.Id,
                        ProjectId = o.ProjectId
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    UserName = o.UserName,
                    ProjectQuoteFormQRN = o.ProjectQuoteFormQRN
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectQFDelegationForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectQFDelegationForViewDto> GetProjectQFDelegationForView(long id)
        {
            var projectQFDelegation = await _projectQFDelegationRepository.GetAsync(id);

            var output = new GetProjectQFDelegationForViewDto { ProjectQFDelegation = ObjectMapper.Map<ProjectQFDelegationDto>(projectQFDelegation) };

            if (output.ProjectQFDelegation.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectQFDelegation.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectQFDelegation.AssignTo != null)
            {
                var _lookupUser = await _lookup_userRepository.FirstOrDefaultAsync((long)output.ProjectQFDelegation.AssignTo);
                output.UserName = _lookupUser?.Name?.ToString();
            }

            if (output.ProjectQFDelegation.ProjectQuoteFormId != null)
            {
                var _lookupProjectQuoteForm = await _lookup_projectQuoteFormRepository.FirstOrDefaultAsync((long)output.ProjectQFDelegation.ProjectQuoteFormId);
                output.ProjectQuoteFormQRN = _lookupProjectQuoteForm?.QRN?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQFDelegations_Edit)]
        public async Task<GetProjectQFDelegationForEditOutput> GetProjectQFDelegationForEdit(EntityDto<long> input)
        {
            var projectQFDelegation = await _projectQFDelegationRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectQFDelegationForEditOutput { ProjectQFDelegation = ObjectMapper.Map<CreateOrEditProjectQFDelegationDto>(projectQFDelegation) };

            if (output.ProjectQFDelegation.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectQFDelegation.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectQFDelegation.AssignTo != null)
            {
                var _lookupUser = await _lookup_userRepository.FirstOrDefaultAsync((long)output.ProjectQFDelegation.AssignTo);
                output.UserName = _lookupUser?.Name?.ToString();
            }

            if (output.ProjectQFDelegation.ProjectQuoteFormId != null)
            {
                var _lookupProjectQuoteForm = await _lookup_projectQuoteFormRepository.FirstOrDefaultAsync((long)output.ProjectQFDelegation.ProjectQuoteFormId);
                output.ProjectQuoteFormQRN = _lookupProjectQuoteForm?.QRN?.ToString();
            }

            return output;
        }

        public async Task<GetProjectQFDelegationForViewDto> CreateOrEdit([FromForm] CreateOrEditQFDelegationDto data)
        {
            var inputs = JsonConvert.DeserializeObject<List<CreateOrEditProjectQFDelegationDto>>(data.QfDelegationData);
            var result = new GetProjectQFDelegationForViewDto();
            foreach (var input in inputs)
            {
                if (data.Files != null && data.Files.Count > 0)
                {
                    List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                    foreach (var file in data.Files)
                    {
                        projectFilesInput.Add(new ProjectFileInput()
                        {
                            File = file,
                            ProjectId = input.ProjectId,
                            TaskId = CNodeTasks.DelegateRequest,
                            MetaData = "QfDelegation"
                        });
                    }

                    if (projectFilesInput.Count > 0)
                    {
                        var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                    }
                }

                if (input.Id == null)
                {
                    result = await Create(input);
                }
                else
                {
                    result = await Update(input);
                }

                var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);
                await EventBus.TriggerAsync(new EditProjectEventData()
                {
                    Project = project,
                    StageId = CNodeStages.PreOrder,
                    TaskId = CNodeTasks.DelegateRequest,
                    StatusId = CNodeStatuses.Submit,
                    Comment = input.ResponseComments
                });
            }

            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQFDelegations_Create)]
        protected virtual async Task<GetProjectQFDelegationForViewDto> Create(CreateOrEditProjectQFDelegationDto input)
        {
            CreateOrEditProjectQFDelegationDto updateInput = new CreateOrEditProjectQFDelegationDto();
            var filteredProjectQFDelegations = await _projectQFDelegationRepository.GetAll()
                .WhereIf(!string.IsNullOrWhiteSpace(input.Category), e => e.Category == input.Category)
                .OrderBy("DisplayOrder desc").FirstOrDefaultAsync();
            if (filteredProjectQFDelegations != null)
            {
                var displayOrder = filteredProjectQFDelegations.DisplayOrder;
                input.DisplayOrder = displayOrder + 1;
                filteredProjectQFDelegations.IsCurrent = false;
                if (input.Category == "estimation")
                    updateInput.Revision = "estimation " + input.DisplayOrder;
                else if (input.Category == "design")
                    updateInput.Revision = "design " + input.DisplayOrder;
                updateInput.DisplayOrder = filteredProjectQFDelegations.DisplayOrder;
                updateInput.IsCurrent = filteredProjectQFDelegations.IsCurrent;
                updateInput.AssignTo = filteredProjectQFDelegations.AssignTo;
                updateInput.Category = filteredProjectQFDelegations.Category;
                updateInput.Id = filteredProjectQFDelegations.Id;
                updateInput.ProjectId = filteredProjectQFDelegations.ProjectId;
                updateInput.ProjectQuoteFormId = filteredProjectQFDelegations.ProjectQuoteFormId;
                updateInput.RequestComments = filteredProjectQFDelegations.RequestComments;
                updateInput.RequiredByDate = filteredProjectQFDelegations.RequiredByDate;
                updateInput.ResponseComments = filteredProjectQFDelegations.ResponseComments;
                updateInput.ResponseDate = filteredProjectQFDelegations.ResponseDate;

                await Update(updateInput);
            }
            var projectQFDelegation = ObjectMapper.Map<ProjectQFDelegation>(input);
            projectQFDelegation.IsCurrent = true;
            projectQFDelegation.Revision = "current";

            if (AbpSession.TenantId != null)
            {
                projectQFDelegation.TenantId = (int?)AbpSession.TenantId;
            }

            //await _projectQFDelegationRepository.InsertAsync(projectQFDelegation);

            var resultId = _projectQFDelegationRepository.InsertAndGetId(projectQFDelegation);
            var output = new GetProjectQFDelegationForViewDto { ProjectQFDelegation = ObjectMapper.Map<ProjectQFDelegationDto>(_projectQFDelegationRepository.Get(resultId)) };
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQFDelegations_Edit)]
        protected virtual async Task<GetProjectQFDelegationForViewDto> Update(CreateOrEditProjectQFDelegationDto input)
        {
            var projectQFDelegation = await _projectQFDelegationRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectQFDelegation);
            return new GetProjectQFDelegationForViewDto { ProjectQFDelegation = ObjectMapper.Map<ProjectQFDelegationDto>(_projectQFDelegationRepository.Get((long)input.Id)) };
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQFDelegations_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectQFDelegationRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectQFDelegationsToExcel(GetAllProjectQFDelegationsForExcelInput input)
        {

            var filteredProjectQFDelegations = _projectQFDelegationRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.AssignToFk)
                        .Include(e => e.ProjectQuoteFormFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Category.Contains(input.Filter) || e.Revision.Contains(input.Filter) || e.RequestComments.Contains(input.Filter) || e.ResponseComments.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CategoryFilter), e => e.Category == input.CategoryFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevisionFilter), e => e.Revision == input.RevisionFilter)
                        .WhereIf(input.MinRequiredByDateFilter != null, e => e.RequiredByDate >= input.MinRequiredByDateFilter)
                        .WhereIf(input.MaxRequiredByDateFilter != null, e => e.RequiredByDate <= input.MaxRequiredByDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RequestCommentsFilter), e => e.RequestComments == input.RequestCommentsFilter)
                        .WhereIf(input.MinResponseDateFilter != null, e => e.ResponseDate >= input.MinResponseDateFilter)
                        .WhereIf(input.MaxResponseDateFilter != null, e => e.ResponseDate <= input.MaxResponseDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ResponseCommentsFilter), e => e.ResponseComments == input.ResponseCommentsFilter)
                        .WhereIf(input.IsCurrentFilter.HasValue && input.IsCurrentFilter > -1, e => (input.IsCurrentFilter == 1 && e.IsCurrent) || (input.IsCurrentFilter == 0 && !e.IsCurrent))
                        .WhereIf(input.MinDisplayOrderFilter != null, e => e.DisplayOrder >= input.MinDisplayOrderFilter)
                        .WhereIf(input.MaxDisplayOrderFilter != null, e => e.DisplayOrder <= input.MaxDisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.UserNameFilter), e => e.AssignToFk != null && e.AssignToFk.Name == input.UserNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectQuoteFormQRNFilter), e => e.ProjectQuoteFormFk != null && e.ProjectQuoteFormFk.QRN == input.ProjectQuoteFormQRNFilter);

            var query = (from o in filteredProjectQFDelegations
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_userRepository.GetAll() on o.AssignTo equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_projectQuoteFormRepository.GetAll() on o.ProjectQuoteFormId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         select new GetProjectQFDelegationForViewDto()
                         {
                             ProjectQFDelegation = new ProjectQFDelegationDto
                             {
                                 Category = o.Category,
                                 Revision = o.Revision,
                                 RequiredByDate = o.RequiredByDate,
                                 RequestComments = o.RequestComments,
                                 ResponseDate = o.ResponseDate,
                                 ResponseComments = o.ResponseComments,
                                 IsCurrent = o.IsCurrent,
                                 DisplayOrder = o.DisplayOrder,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             UserName = s2 == null || s2.Name == null ? "" : s2.Name.ToString(),
                             ProjectQuoteFormQRN = s3 == null || s3.QRN == null ? "" : s3.QRN.ToString()
                         });

            var projectQFDelegationListDtos = await query.ToListAsync();

            return _projectQFDelegationsExcelExporter.ExportToFile(projectQFDelegationListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQFDelegations)]
        public async Task<List<ProjectQFDelegationProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectQFDelegationProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQFDelegations)]
        public async Task<List<ProjectQFDelegationUserLookupTableDto>> GetAllUserForTableDropdown()
        {
            return await _lookup_userRepository.GetAll()
                .Select(user => new ProjectQFDelegationUserLookupTableDto
                {
                    Id = user.Id,
                    DisplayName = user == null || user.Name == null ? "" : user.Name.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQFDelegations)]
        public async Task<List<ProjectQFDelegationProjectQuoteFormLookupTableDto>> GetAllProjectQuoteFormForTableDropdown()
        {
            return await _lookup_projectQuoteFormRepository.GetAll()
                .Select(projectQuoteForm => new ProjectQFDelegationProjectQuoteFormLookupTableDto
                {
                    Id = projectQuoteForm.Id,
                    DisplayName = projectQuoteForm == null || projectQuoteForm.QRN == null ? "" : projectQuoteForm.QRN.ToString()
                }).ToListAsync();
        }

        public async Task<List<GetProjectQFDelegationForViewDto>> GetAllForCategory(string category, Int64 isCurrent, string projectName
            , Int64 creatorId)
        {
            var result = _projectQFDelegationRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.AssignToFk)
                        .Include(e => e.ProjectQuoteFormFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(category), e => e.Category == category)
                     //   .WhereIf(isCurrent > -1, e => (isCurrent == 1 && e.IsCurrent) || (isCurrent == 0 && !e.IsCurrent))
                        //.WhereIf(!string.IsNullOrWhiteSpace(userName), e => e.AssignToFk != null && e.AssignToFk.UserName == userName)
                        .WhereIf(!string.IsNullOrWhiteSpace(projectName), e => e.ProjectFk != null && e.ProjectFk.ProjectName == projectName)
                        .WhereIf(creatorId > -1, e => e.CreatorUserId != null && e.CreatorUserId == creatorId)

                        .Select(o => new GetProjectQFDelegationForViewDto()
                        {
                            ProjectQFDelegation = new ProjectQFDelegationDto
                            {

                                Category = o.Category,
                                Revision = o.Revision,
                                RequiredByDate = o.RequiredByDate,
                                RequestComments = o.RequestComments,
                                ResponseDate = o.ResponseDate,
                                ResponseComments = o.ResponseComments,
                                IsCurrent = o.IsCurrent,
                                DisplayOrder = o.DisplayOrder,
                                AssignTo = o.AssignTo,
                                Id = o.Id,
                                ProjectId = o.ProjectId,
                                CreatorUserId = o.CreatorUserId
                            },
                            ProjectProjectName = o.ProjectFk.ProjectName,
                            //UserName = o.AssignToFk.UserName,
                            UserName = o.AssignToFk.FullName + " (" + o.AssignToFk.UserName + ")",
                            ProjectQuoteFormQRN = o.ProjectQuoteFormFk.QRN
                        })
                        .OrderByDescending(x => x.ProjectQFDelegation.DisplayOrder)
                        .ToList();

            return result;
        }

        public async Task<List<GetProjectQFDelegationForViewDto>> GetAllForResponse(string category, Int64 isCurrent,string userName, string projectName)
            //, Int64 creatorId)
        {
            var result = _projectQFDelegationRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.AssignToFk)
                        .Include(e => e.ProjectQuoteFormFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(category), e => e.Category == category)
                        .WhereIf(isCurrent > -1, e => (isCurrent == 1 && e.IsCurrent) || (isCurrent == 0 && !e.IsCurrent))
                        .WhereIf(!string.IsNullOrWhiteSpace(userName), e => e.AssignToFk != null && e.AssignToFk.UserName == userName)
                        .WhereIf(!string.IsNullOrWhiteSpace(projectName), e => e.ProjectFk != null && e.ProjectFk.ProjectName == projectName)
                        //.WhereIf(creatorId > -1, e => e.CreatorUserId != null && e.CreatorUserId == creatorId)

                        .Select(o => new GetProjectQFDelegationForViewDto()
                        {
                            ProjectQFDelegation = new ProjectQFDelegationDto
                            {

                                Category = o.Category,
                                Revision = o.Revision,
                                RequiredByDate = o.RequiredByDate,
                                RequestComments = o.RequestComments,
                                ResponseDate = o.ResponseDate,
                                ResponseComments = o.ResponseComments,
                                IsCurrent = o.IsCurrent,
                                DisplayOrder = o.DisplayOrder,
                                AssignTo = o.AssignTo,
                                Id = o.Id,
                                ProjectId = o.ProjectId,
                                CreatorUserId = o.CreatorUserId
                            },
                            ProjectProjectName = o.ProjectFk.ProjectName,
                            UserName = o.AssignToFk.UserName,
                            ProjectQuoteFormQRN = o.ProjectQuoteFormFk.QRN
                        })
                        .OrderByDescending(x => x.ProjectQFDelegation.DisplayOrder)
                        .ToList();

            return result;
        }
        
    }
}