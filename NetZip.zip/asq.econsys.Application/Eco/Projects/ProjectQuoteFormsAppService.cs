﻿using asq.econsys.Eco.Projects;
using asq.econsys.Authorization.Users;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.RefNoConfig;
using asq.econsys.Eco.RefNoConfig.Dtos;
using System.IO;
using Syncfusion.DocIO.DLS;
using Syncfusion.DocIO;
using Syncfusion.Drawing;
using asq.econsys.Eco.Leads;
using Abp.Events.Bus;
using Microsoft.AspNetCore.Hosting;
using Abp.Domain.Uow;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using asq.econsys.Eco.Customers;
using asq.econsys.Eco.Utils.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectQuoteForms)]
    public class ProjectQuoteFormsAppService : econsysAppServiceBase, IProjectQuoteFormsAppService
    {
        private readonly IRepository<ProjectQuoteForm, long> _projectQuoteFormRepository;
        private readonly IProjectQuoteFormsExcelExporter _projectQuoteFormsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<User, long> _lookup_userRepository;
        private readonly IRefNoConfigsAppService _refNoConfigAppservice;
        private readonly IRefNoConfigDetailsAppService _refNoConfigDetailsAppservice;
        private readonly IRepository<Lead, long> _leadRepository;
        private readonly IRepository<LeadContact, long> _leadContactRepository;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly IRepository<Project, long> _projectRepository;
        private readonly IRepository<ProjectSite, long> _projectSiteRepository;
        private readonly IRepository<ProjectCostDetail, long> _projectCostDetailRepository;
        private readonly IWebHostEnvironment _env;
        private readonly IRepository<ProjectPersonnel, long> _projectPersonnelRepository;
        private readonly IRepository<User, long> _userRepository;
        private readonly RefNoConfigManager _refNoConfigManager;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly IRepository<ContactPerson, long> _contactPersonRepository;
        private readonly StorageManager _storageManager;
        public IEventBus EventBus { get; set; }
        private readonly IUnitOfWorkManager _unitOfWorkManager;

        public ProjectQuoteFormsAppService(IUnitOfWorkManager unitOfWorkManager, IRepository<ProjectQuoteForm, long> projectQuoteFormRepository, IProjectQuoteFormsExcelExporter projectQuoteFormsExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<User, long> lookup_userRepository,
            RefNoConfigsAppService refNoConfigAppservice,
            IRefNoConfigDetailsAppService refNoConfigDetailsAppService,
            IRepository<Lead, long> leadRepository, IRepository<LeadContact, long> leadContactRepository,
            ProjectPermissionManager projectPermissionManager, IRepository<Project, long> projectRepository, IRepository<ProjectSite, long> projectSiteRepository,
            IRepository<ProjectCostDetail, long> projectCostDetailRepository,
            IWebHostEnvironment env,
            IRepository<ProjectPersonnel, long> projectPersonnelRepository,
            IRepository<User, long> userRepository,
            RefNoConfigManager refNoConfigManager,
            Utils.UtilsAppService utilsAppService,
            IRepository<ContactPerson, long> contactPersonRepository,
            StorageManager storageManager)
        {
            _unitOfWorkManager = unitOfWorkManager;
            _projectQuoteFormRepository = projectQuoteFormRepository;
            _projectQuoteFormsExcelExporter = projectQuoteFormsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_userRepository = lookup_userRepository;
            _refNoConfigAppservice = refNoConfigAppservice;
            _refNoConfigDetailsAppservice = refNoConfigDetailsAppService;
            _leadRepository = leadRepository;
            _leadContactRepository = leadContactRepository;
            EventBus = NullEventBus.Instance;
            _projectPermissionManager = projectPermissionManager;
            _projectRepository = projectRepository;
            _projectSiteRepository = projectSiteRepository;
            _projectCostDetailRepository = projectCostDetailRepository;
            _env = env;
            _projectPersonnelRepository = projectPersonnelRepository;
            _userRepository = userRepository;
            _refNoConfigManager = refNoConfigManager;
            _utilsAppService = utilsAppService;
            _contactPersonRepository = contactPersonRepository;
            _storageManager = storageManager;
        }

        public async Task<PagedResultDto<GetProjectQuoteFormForViewDto>> GetAll(GetAllProjectQuoteFormsInput input)
        {

            var filteredProjectQuoteForms = _projectQuoteFormRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.SubmittedByFk)                        
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.QRN.Contains(input.Filter) || e.Bidinfo.Contains(input.Filter) || e.Notes.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.QRNFilter), e => e.QRN == input.QRNFilter)
                        .WhereIf(input.IsDelegateEstimationTaskFilter.HasValue && input.IsDelegateEstimationTaskFilter > -1, e => (input.IsDelegateEstimationTaskFilter == 1 && e.IsDelegateEstimationTask) || (input.IsDelegateEstimationTaskFilter == 0 && !e.IsDelegateEstimationTask))
                        .WhereIf(input.IsDelegateDesignTaskFilter.HasValue && input.IsDelegateDesignTaskFilter > -1, e => (input.IsDelegateDesignTaskFilter == 1 && e.IsDelegateDesignTask) || (input.IsDelegateDesignTaskFilter == 0 && !e.IsDelegateDesignTask))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.BidinfoFilter), e => e.Bidinfo == input.BidinfoFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RevisionFilter), e => e.Revision == input.RevisionFilter)
                        .WhereIf(input.IsCompanyAuthCriteriaFilter.HasValue && input.IsCompanyAuthCriteriaFilter > -1, e => (input.IsCompanyAuthCriteriaFilter == 1 && e.IsCompanyAuthCriteria) || (input.IsCompanyAuthCriteriaFilter == 0 && !e.IsCompanyAuthCriteria))
                        .WhereIf(input.IsPopulateFromBidSheetFilter.HasValue && input.IsPopulateFromBidSheetFilter > -1, e => (input.IsPopulateFromBidSheetFilter == 1 && e.IsPopulateFromBidSheet) || (input.IsPopulateFromBidSheetFilter == 0 && !e.IsPopulateFromBidSheet))
                        .WhereIf(input.IsQuotationOnOurFormatFilter.HasValue && input.IsQuotationOnOurFormatFilter > -1, e => (input.IsQuotationOnOurFormatFilter == 1 && e.IsQuotationOnOurFormat) || (input.IsQuotationOnOurFormatFilter == 0 && !e.IsQuotationOnOurFormat))
                        .WhereIf(input.RevisedFormIdFilter != null, e => e.RevisedFormId >= input.RevisedFormIdFilter)
                        .WhereIf(input.MinDateShownOnQuoteFilter != null, e => e.DateShownOnQuote >= input.MinDateShownOnQuoteFilter)
                        .WhereIf(input.MaxDateShownOnQuoteFilter != null, e => e.DateShownOnQuote <= input.MaxDateShownOnQuoteFilter)
                        .WhereIf(input.MinOverAllProjectCostFilter != null, e => e.OverAllProjectCost >= input.MinOverAllProjectCostFilter)
                        .WhereIf(input.MaxOverAllProjectCostFilter != null, e => e.OverAllProjectCost <= input.MaxOverAllProjectCostFilter)
                        .WhereIf(input.MinOverAllProjectSellFilter != null, e => e.OverAllProjectSell >= input.MinOverAllProjectSellFilter)
                        .WhereIf(input.MaxOverAllProjectSellFilter != null, e => e.OverAllProjectSell <= input.MaxOverAllProjectSellFilter)
                        .WhereIf(input.MinSubmissionDateFilter != null, e => e.SubmissionDate >= input.MinSubmissionDateFilter)
                        .WhereIf(input.MaxSubmissionDateFilter != null, e => e.SubmissionDate <= input.MaxSubmissionDateFilter)
                        .WhereIf(input.MinWinProbabilityFilter != null, e => e.WinProbability >= input.MinWinProbabilityFilter)
                        .WhereIf(input.MaxWinProbabilityFilter != null, e => e.WinProbability <= input.MaxWinProbabilityFilter)
                        .WhereIf(input.IsCustomerWonOrGotOrderToPlaceFilter.HasValue && input.IsCustomerWonOrGotOrderToPlaceFilter > -1, e => (input.IsCustomerWonOrGotOrderToPlaceFilter == 1 && e.IsCustomerWonOrGotOrderToPlace) || (input.IsCustomerWonOrGotOrderToPlaceFilter == 0 && !e.IsCustomerWonOrGotOrderToPlace))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NotesFilter), e => e.Notes == input.NotesFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.UserNameFilter), e => e.SubmittedByFk != null && e.SubmittedByFk.Name == input.UserNameFilter);

            var pagedAndFilteredProjectQuoteForms = filteredProjectQuoteForms
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectQuoteForms = from o in pagedAndFilteredProjectQuoteForms
                                    join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                    from s1 in j1.DefaultIfEmpty()

                                    join o2 in _lookup_userRepository.GetAll() on o.SubmittedBy equals o2.Id into j2
                                    from s2 in j2.DefaultIfEmpty()

                                    select new
                                    {

                                        o.QRN,
                                        o.IsDelegateEstimationTask,
                                        o.IsDelegateDesignTask,
                                        o.Bidinfo,
                                        o.IsCompanyAuthCriteria,
                                        o.IsPopulateFromBidSheet,
                                        o.IsQuotationOnOurFormat,
                                        o.DateShownOnQuote,
                                        o.OverAllProjectCost,
                                        o.OverAllProjectSell,
                                        o.SubmissionDate,
                                        o.WinProbability,
                                        o.IsCustomerWonOrGotOrderToPlace,
                                        o.Notes,
                                        o.RevisedFormId,
                                        o.Revision,
                                        Id = o.Id,
                                        ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                        UserName = s2 == null || s2.Name == null ? "" : s2.Name.ToString()
                                    };

            var totalCount = await filteredProjectQuoteForms.CountAsync();

            var dbList = await projectQuoteForms.ToListAsync();
            var results = new List<GetProjectQuoteFormForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectQuoteFormForViewDto()
                {
                    ProjectQuoteForm = new ProjectQuoteFormDto
                    {

                        QRN = o.QRN,
                        IsDelegateEstimationTask = o.IsDelegateEstimationTask,
                        IsDelegateDesignTask = o.IsDelegateDesignTask,
                        Bidinfo = o.Bidinfo,
                        IsCompanyAuthCriteria = o.IsCompanyAuthCriteria,
                        IsPopulateFromBidSheet = o.IsPopulateFromBidSheet,
                        IsQuotationOnOurFormat = o.IsQuotationOnOurFormat,
                        DateShownOnQuote = o.DateShownOnQuote,
                        OverAllProjectCost = o.OverAllProjectCost,
                        OverAllProjectSell = o.OverAllProjectSell,
                        SubmissionDate = o.SubmissionDate,
                        WinProbability = o.WinProbability,
                        IsCustomerWonOrGotOrderToPlace = o.IsCustomerWonOrGotOrderToPlace,
                        Notes = o.Notes,
                        RevisedFormId = o.RevisedFormId,
                        Revision = o.Revision,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    UserName = o.UserName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectQuoteFormForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectQuoteFormForViewDto> GetProjectQuoteFormForView(long id)
        {
            var projectQuoteForm = await _projectQuoteFormRepository.GetAsync(id);

            var output = new GetProjectQuoteFormForViewDto { ProjectQuoteForm = ObjectMapper.Map<ProjectQuoteFormDto>(projectQuoteForm) };

            if (output.ProjectQuoteForm.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectQuoteForm.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectQuoteForm.SubmittedBy != null)
            {
                var _lookupUser = await _lookup_userRepository.FirstOrDefaultAsync((long)output.ProjectQuoteForm.SubmittedBy);
                output.UserName = _lookupUser?.Name?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQuoteForms_Edit)]
        public async Task<GetProjectQuoteFormForEditOutput> GetProjectQuoteFormForEdit(EntityDto<long> input)
        {
            var projectQuoteForm = await _projectQuoteFormRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectQuoteFormForEditOutput { ProjectQuoteForm = ObjectMapper.Map<CreateOrEditProjectQuoteFormDto>(projectQuoteForm) };

            if (output.ProjectQuoteForm.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectQuoteForm.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectQuoteForm.SubmittedBy != null)
            {
                var _lookupUser = await _lookup_userRepository.FirstOrDefaultAsync((long)output.ProjectQuoteForm.SubmittedBy);
                output.UserName = _lookupUser?.Name?.ToString();
            }

            return output;
        }

        public async Task<GetProjectQuoteFormForViewDto> CreateOrEdit(CreateOrEditProjectQuoteFormDto input)
        {
            await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        var prepareQuoteDetails = new GetProjectQuoteFormForViewDto();
                        var quoteForm = new ProjectQuoteForm();
                        if (input.Id == null)
                        {
                            var newQuote = await Create(input);
                            quoteForm = newQuote;
                            //ObjectMapper.Map(newQuote , quoteForm);
                        }
                        else
                        {
                            var newQuote = await Update(input);
                            quoteForm = newQuote;
                            //ObjectMapper.Map(newQuote, quoteForm);
                        }
                        var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);
                        project.ProjectQuoteFormId = quoteForm.Id;
                        await EventBus.TriggerAsync(new EditProjectEventData()
                        {
                            Project = project,
                            StageId = CNodeStages.PreOrder,
                            TaskId = input.NodeTaskId,
                            StatusId = CNodeStatuses.Submit,
                            Comment = input.Comment,
                            LoggedInUserId = (long)AbpSession.UserId
                        });
                        prepareQuoteDetails.ProjectQuoteForm = ObjectMapper.Map<ProjectQuoteFormDto>(quoteForm);

                        //ObjectMapper.Map(quoteForm, prepareQuoteDetails.ProjectQuoteForm);
                        prepareQuoteDetails.Project = ObjectMapper.Map<ProjectDto>(project);
                        //ObjectMapper.Map(project, prepareQuoteDetails.Project);
                        return prepareQuoteDetails;
                    }
                }
            });

            return null;
        }

        public async Task<GetProjectForViewDto> CreateOrEditWithStatus([FromForm] CreateOrEditQuoteFormDto data)
        {
            var inputs = JsonConvert.DeserializeObject<List<CreateOrEditProjectQuoteFormDto>>(data.QuoteFormData);
            var inputAttachRef = JsonConvert.DeserializeObject<List<Object>>(data.AttachmentRef);

            GetProjectForViewDto result = new GetProjectForViewDto();
            foreach (var input in inputs)
            {
                if (data.Files != null && data.Files.Count > 0)
                {
                    List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                    foreach (var item in data.Files.Select((value, index) => new { value, index }))
                    {
                        projectFilesInput.Add(new ProjectFileInput()
                        {
                            File = item.value,
                            ProjectId = input.ProjectId,
                            TaskId = CNodeTasks.PrepareQuote,
                            //MetaData = JsonConvert.SerializeObject(inputAttachRef[item.index])
                            MetaData = "QuoteForm"
                        });
                    }

                    if (projectFilesInput.Count > 0)
                    {
                        var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                    }
                }
                await _unitOfWorkManager.WithUnitOfWork(async () =>
                {
                    var tenantId = AbpSession.TenantId;
                    using (CurrentUnitOfWork.SetTenantId(tenantId))
                    {
                        using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                        {
                            var quoteForm = new ProjectQuoteForm();
                            if (input.Id == null)
                            {
                                quoteForm = await Create(input);
                            }
                            else
                            {
                                quoteForm = await Update(input);
                            }

                            if (input.ProjectCostDetails != null && input.ProjectCostDetails.Count > 0)
                            {
                                foreach (var item in input.ProjectCostDetails)
                                {
                                    if (item.ProjectQuoteFormId == null)
                                    {
                                        item.ProjectQuoteFormId = quoteForm.Id;
                                        var pcd = await _projectCostDetailRepository.UpdateAsync(ObjectMapper.Map<ProjectCostDetail>(item));
                                    }
                                }
                            }

                            var projectCostDetails = _projectCostDetailRepository.GetAll().Where(x => x.ProjectId == quoteForm.ProjectId).ToList();
                            if (quoteForm.RevisedFormId != 0 && projectCostDetails != null && projectCostDetails.Count > 0)
                            {
                                foreach (var projectCostDetail in projectCostDetails)
                                {
                                    projectCostDetail.NodeTaskId = CNodeTasks.PrepareRevisedQuote;
                                    projectCostDetail.ProjectQuoteFormId = quoteForm.Id;
                                    await _projectCostDetailRepository.UpdateAsync(projectCostDetail);
                                }
                            }

                            var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);
                            project.ProjectQuoteFormId = quoteForm.Id;
                            await EventBus.TriggerAsync(new EditProjectEventData()
                            {
                                Project = project,
                                StageId = CNodeStages.PreOrder,
                                TaskId = input.NodeTaskId,
                                StatusId = input.StatusId,
                                Comment = input.Comment,
                                LoggedInUserId = (long)AbpSession.UserId
                            });

                            result.Project = ObjectMapper.Map<ProjectDto>(project);
                            result.ProjectQuoteForms = new List<GetProjectQuoteFormForViewDto>();
                            result.ProjectQuoteForms.Add(new GetProjectQuoteFormForViewDto { ProjectQuoteForm = ObjectMapper.Map<ProjectQuoteFormDto>(quoteForm), Project = result.Project });
                        }
                    }
                });
            }
            return result;
        }

        public async Task<GetProjectForViewDto> SubmitQuoteWithStatus(CreateOrEditProjectQuoteFormDto input)
        {
            GetProjectForViewDto result = new GetProjectForViewDto();
            // TODO : need to modify this. input holds all values. only accept require fields from frontend.
            await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        var quoteForm = new ProjectQuoteForm();
                        if (input.Id == null)
                        {
                            quoteForm = await Create(input);
                        }
                        else
                        {
                            quoteForm = await Update(input);
                        }

                        var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);
                        await EventBus.TriggerAsync(new EditProjectEventData()
                        {
                            Project = project,
                            StageId = CNodeStages.PreOrder,
                            TaskId = input.NodeTaskId,
                            StatusId = input.StatusId,
                            Comment = input.Comment,
                            LoggedInUserId = (long)AbpSession.UserId
                        });

                        result.Project = ObjectMapper.Map<ProjectDto>(project);
                        result.ProjectQuoteForms = new List<GetProjectQuoteFormForViewDto>();
                        //result.ProjectQuoteForms.Add(new GetProjectQuoteFormForViewDto { ProjectQuoteForm = ObjectMapper.Map<ProjectQuoteFormDto>(quoteForm), Project = result.Project });

                        var projectQuoteForms = await _projectQuoteFormRepository.GetAllIncluding(x => x.ProjectFk).Where(x => x.ProjectId == input.ProjectId).ToListAsync();
                        foreach (var item in projectQuoteForms)
                        {
                            result.ProjectQuoteForms.Add(new GetProjectQuoteFormForViewDto { ProjectQuoteForm = ObjectMapper.Map<ProjectQuoteFormDto>(item), Project = result.Project });
                        }
                    }
                }
            });

            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQuoteForms_Create)]
        protected virtual async Task<ProjectQuoteForm> Create(CreateOrEditProjectQuoteFormDto input)
        {
            var projectQuoteForm = ObjectMapper.Map<ProjectQuoteForm>(input);

            if (AbpSession.TenantId != null)
            {
                projectQuoteForm.TenantId = (int?)AbpSession.TenantId;
            }
            var projectQuotes = _projectQuoteFormRepository.GetAll().Where(x => x.ProjectId == input.ProjectId).ToList();
            //if (projectQuotes != null && projectQuotes.Count > 0)
            //{
            //    foreach (var projectQuote in projectQuotes)
            //    {
            //        projectQuote.Revision = null;
            //        await _projectQuoteFormRepository.UpdateAsync(projectQuote);
            //    }
            //}
            var id = await _projectQuoteFormRepository.InsertAndGetIdAsync(projectQuoteForm);
            return await _projectQuoteFormRepository.GetAsync(id);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQuoteForms_Edit)]
        protected virtual async Task<ProjectQuoteForm> Update(CreateOrEditProjectQuoteFormDto input)
        {
            var projectQuoteForm = await _projectQuoteFormRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectQuoteForm);
            return projectQuoteForm;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQuoteForms_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectQuoteFormRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectQuoteFormsToExcel(GetAllProjectQuoteFormsForExcelInput input)
        {

            var filteredProjectQuoteForms = _projectQuoteFormRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.SubmittedByFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.QRN.Contains(input.Filter) || e.Bidinfo.Contains(input.Filter) || e.Notes.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.QRNFilter), e => e.QRN == input.QRNFilter)
                        .WhereIf(input.IsDelegateEstimationTaskFilter.HasValue && input.IsDelegateEstimationTaskFilter > -1, e => (input.IsDelegateEstimationTaskFilter == 1 && e.IsDelegateEstimationTask) || (input.IsDelegateEstimationTaskFilter == 0 && !e.IsDelegateEstimationTask))
                        .WhereIf(input.IsDelegateDesignTaskFilter.HasValue && input.IsDelegateDesignTaskFilter > -1, e => (input.IsDelegateDesignTaskFilter == 1 && e.IsDelegateDesignTask) || (input.IsDelegateDesignTaskFilter == 0 && !e.IsDelegateDesignTask))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.BidinfoFilter), e => e.Bidinfo == input.BidinfoFilter)
                        .WhereIf(input.IsCompanyAuthCriteriaFilter.HasValue && input.IsCompanyAuthCriteriaFilter > -1, e => (input.IsCompanyAuthCriteriaFilter == 1 && e.IsCompanyAuthCriteria) || (input.IsCompanyAuthCriteriaFilter == 0 && !e.IsCompanyAuthCriteria))
                        .WhereIf(input.IsPopulateFromBidSheetFilter.HasValue && input.IsPopulateFromBidSheetFilter > -1, e => (input.IsPopulateFromBidSheetFilter == 1 && e.IsPopulateFromBidSheet) || (input.IsPopulateFromBidSheetFilter == 0 && !e.IsPopulateFromBidSheet))
                        .WhereIf(input.IsQuotationOnOurFormatFilter.HasValue && input.IsQuotationOnOurFormatFilter > -1, e => (input.IsQuotationOnOurFormatFilter == 1 && e.IsQuotationOnOurFormat) || (input.IsQuotationOnOurFormatFilter == 0 && !e.IsQuotationOnOurFormat))
                        .WhereIf(input.MinDateShownOnQuoteFilter != null, e => e.DateShownOnQuote >= input.MinDateShownOnQuoteFilter)
                        .WhereIf(input.MaxDateShownOnQuoteFilter != null, e => e.DateShownOnQuote <= input.MaxDateShownOnQuoteFilter)
                        .WhereIf(input.MinOverAllProjectCostFilter != null, e => e.OverAllProjectCost >= input.MinOverAllProjectCostFilter)
                        .WhereIf(input.MaxOverAllProjectCostFilter != null, e => e.OverAllProjectCost <= input.MaxOverAllProjectCostFilter)
                        .WhereIf(input.MinOverAllProjectSellFilter != null, e => e.OverAllProjectSell >= input.MinOverAllProjectSellFilter)
                        .WhereIf(input.MaxOverAllProjectSellFilter != null, e => e.OverAllProjectSell <= input.MaxOverAllProjectSellFilter)
                        .WhereIf(input.MinSubmissionDateFilter != null, e => e.SubmissionDate >= input.MinSubmissionDateFilter)
                        .WhereIf(input.MaxSubmissionDateFilter != null, e => e.SubmissionDate <= input.MaxSubmissionDateFilter)
                        .WhereIf(input.MinWinProbabilityFilter != null, e => e.WinProbability >= input.MinWinProbabilityFilter)
                        .WhereIf(input.MaxWinProbabilityFilter != null, e => e.WinProbability <= input.MaxWinProbabilityFilter)
                        .WhereIf(input.IsCustomerWonOrGotOrderToPlaceFilter.HasValue && input.IsCustomerWonOrGotOrderToPlaceFilter > -1, e => (input.IsCustomerWonOrGotOrderToPlaceFilter == 1 && e.IsCustomerWonOrGotOrderToPlace) || (input.IsCustomerWonOrGotOrderToPlaceFilter == 0 && !e.IsCustomerWonOrGotOrderToPlace))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NotesFilter), e => e.Notes == input.NotesFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.UserNameFilter), e => e.SubmittedByFk != null && e.SubmittedByFk.Name == input.UserNameFilter);

            var query = (from o in filteredProjectQuoteForms
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_userRepository.GetAll() on o.SubmittedBy equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         select new GetProjectQuoteFormForViewDto()
                         {
                             ProjectQuoteForm = new ProjectQuoteFormDto
                             {
                                 QRN = o.QRN,
                                 IsDelegateEstimationTask = o.IsDelegateEstimationTask,
                                 IsDelegateDesignTask = o.IsDelegateDesignTask,
                                 Bidinfo = o.Bidinfo,
                                 IsCompanyAuthCriteria = o.IsCompanyAuthCriteria,
                                 IsPopulateFromBidSheet = o.IsPopulateFromBidSheet,
                                 IsQuotationOnOurFormat = o.IsQuotationOnOurFormat,
                                 DateShownOnQuote = o.DateShownOnQuote,
                                 OverAllProjectCost = o.OverAllProjectCost,
                                 OverAllProjectSell = o.OverAllProjectSell,
                                 SubmissionDate = o.SubmissionDate,
                                 WinProbability = o.WinProbability,
                                 IsCustomerWonOrGotOrderToPlace = o.IsCustomerWonOrGotOrderToPlace,
                                 Notes = o.Notes,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             UserName = s2 == null || s2.Name == null ? "" : s2.Name.ToString()
                         });

            var projectQuoteFormListDtos = await query.ToListAsync();

            return _projectQuoteFormsExcelExporter.ExportToFile(projectQuoteFormListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQuoteForms)]
        public async Task<List<ProjectQuoteFormProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectQuoteFormProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQuoteForms)]
        public async Task<List<ProjectQuoteFormUserLookupTableDto>> GetAllUserForTableDropdown()
        {
            return await _lookup_userRepository.GetAll()
                .Select(user => new ProjectQuoteFormUserLookupTableDto
                {
                    Id = user.Id,
                    DisplayName = user == null || user.Name == null ? "" : user.Name.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectQuoteForms_Edit)]
        public async Task<List<GetProjectQuoteFormForEditOutput>> GetProjectQuoteFormForProject(long projectId)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = projectId
            }) ;

            if(!check)
            {
                throw new UserFriendlyException("Access Denied", "You do not have the required role for this project");
            }

            var project = await _lookup_projectRepository.FirstOrDefaultAsync(projectId);
            var quoteForms = await _projectQuoteFormRepository
                .GetAllIncluding(x => x.ProjectFk, x => x.SubmittedByFk)
                .Where(x => x.ProjectId == projectId).OrderByDescending(x => x.CreationTime).ToListAsync();

            List<GetProjectQuoteFormForEditOutput> result = new List<GetProjectQuoteFormForEditOutput>();

            foreach (var item in quoteForms)
            {
                result.Add(new GetProjectQuoteFormForEditOutput { 
                    ProjectQuoteForm = ObjectMapper.Map<CreateOrEditProjectQuoteFormDto>(item),
                    ProjectProjectName = item.ProjectFk == null ? null : item.ProjectFk.ProjectName,
                    UserName = item.SubmittedByFk == null ? null : item.SubmittedByFk.FullName,
                });
            }

            if(result == null || result.Count == 0)
            {
                CreateOrEditProjectQuoteFormDto quoteForm = new CreateOrEditProjectQuoteFormDto();

                if (project.QRN == null)
                {
                    project.QRN = await _refNoConfigManager.GenerateQRNAsync(project.Id);
                }
                quoteForm.QRN = project.QRN;
                result.Add(new GetProjectQuoteFormForEditOutput
                {
                    ProjectQuoteForm = ObjectMapper.Map<CreateOrEditProjectQuoteFormDto>(quoteForm),
                    ProjectProjectName = project == null ? null : project.ProjectName
                });
            }

            return result;
        }

        public async Task<string> GetDocument(int id, string templateName, float projectSell, string qrnNumber)
        {
            var Info = await _projectRepository.FirstOrDefaultAsync(id);
            var QuoteRefNo = qrnNumber;
            var ProjectSell = projectSell;

            //Project Site info
            var projectInfo = from f in _projectSiteRepository.GetAll()
                              join g in _projectRepository.GetAll() on f.Id equals g.ProjectSiteId

                              select new
                              {
                                  f.SiteName,
                                  g.CustomerFk.Name,
                                  g.CustomerFk.Address1,
                                  g.CustomerFk.PostalCode,
                                  g.ContactPersonFk.Email,
                                  //g.ContactPersonFk.Name
                              };
            var contactPersonName = _contactPersonRepository.FirstOrDefault((long)Info.ContactPersonId).Name;
            //Bid Sheet Info
            var sellInfo = from h in _projectCostDetailRepository.GetAll()
                           join i in _projectRepository.GetAll() on h.ProjectId equals i.Id
                           where i.Id == id
                           select new
                           {
                               h.Title,
                               h.SellAmount
                           };



            //Assign Sales leader
            var salesLeader = from k in _projectPersonnelRepository.GetAll()
                              join l in _userRepository.GetAll() on k.UserId equals l.Id

                              select new
                              {
                                  l.Name,
                                  l.EmailAddress
                              };

            var ppmTables = await _projectQuoteFormRepository.GetAll()
                .Where(x => x.ProjectId == id && x.Id == Info.ProjectQuoteFormId)
                .Select(x => new
                {
                    x.EquipmentSchedule,
                    x.Services
                }).FirstOrDefaultAsync();

            if (templateName == "ProjectQuotation")
            {
                var date = DateTime.Now;

                //Opens the input Word document.
                string targetFilePath = Path.Combine(_env.WebRootPath, "template\\bidinfo\\Quote_document_ProjectQuotation_template.docx");
                FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                //FileStream fileStreamPath = new FileStream(filename, FileMode.Open, FileAccess.Read);
                WordDocument document = new WordDocument(fileStreamPath, FormatType.Docx);

                document.Open(fileStreamPath, FormatType.Docx);
                fileStreamPath.Dispose();

                document.Replace("<<TodayDate>>", date.ToString("d"), true, true);

                foreach (var contactName in salesLeader)
                {
                    document.Replace("<<ContactName>>", contactName.Name, true, true);
                    document.Replace("<<EmailAddress>>", contactName.EmailAddress, true, true);
                }
                document.Replace("<<ProjectName>>", Info.ProjectName, true, true);

                document.Replace("<<QuoteRefNo>>", qrnNumber, true, true);

                foreach (var addSite in projectInfo)
                {
                    document.Replace("<<Location>>", String.IsNullOrEmpty(addSite.SiteName) ? "" : addSite.SiteName, true, true); //ProjectSite Db
                }

                string targetFilePath3 = Path.Combine(_env.WebRootPath, "template\\bidinfo\\Quote_document_ProjectQuotation_template.docx");
                FileStream fileStreamPath3 = new FileStream(targetFilePath3, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite);
                WordDocument tmpDoc = new WordDocument();
                tmpDoc.Open(fileStreamPath3, FormatType.Docx);


                IWSection section = tmpDoc.AddSection();
                section.PageSetup.Margins.All = 72;
                section.PageSetup.PageSize = new Syncfusion.Drawing.SizeF(612, 792);

                IWTextRange textRange = section.AddParagraph().AppendText("");
                textRange.CharacterFormat.FontSize = 19;
                IWTable table = new WTable(document);

                var Count = 1;
                var endCount = 2;
                if (id != null)
                {

                    textRange.CharacterFormat.FontSize = 19;
                    table.TableFormat.Borders.LineWidth = 1f;
                    WTableRow row = table.AddRow();
                    WTableCell cell = row.AddCell();
                    cell.Width = 270;
                    cell.AddParagraph().AppendText("Item Description");
                    textRange.CharacterFormat.FontSize = 19;
                    cell = row.AddCell();
                    cell.Width = 180;
                    cell.AddParagraph().AppendText("Cost");

                    foreach (var group in sellInfo)
                    {
                        row = table.AddRow(true, false);
                        cell = row.AddCell();
                        cell.Width = 270;
                        cell.AddParagraph().AppendText(group.Title);
                        cell = row.AddCell();
                        cell.Width = 180;
                        cell.AddParagraph().AppendText("£ " + group.SellAmount);
                    }
                    row = table.AddRow(true, false);

                    cell = row.AddCell();
                    cell.CellFormat.BackColor = Color.FromArgb(227, 218, 48);
                    cell.Width = 270;
                    cell.AddParagraph().AppendText("Total");
                    cell = row.AddCell();
                    cell.CellFormat.BackColor = Color.FromArgb(227, 218, 48);
                    cell.Width = 180;
                    // TODO: get currency code from tenant settings
                    cell.AddParagraph().AppendText(" £ " + projectSell);

                    row = table.AddRow(true, false);

                }

                TextBodyPart replacePart = new TextBodyPart(document);
                replacePart.BodyItems.Add(table);
                //Replace Text.
                document.Replace("<<Proposal_Cost_Table>>", replacePart, false, true);

                string targetFilePath2 = Path.Combine(_env.WebRootPath, "Temp\\bidinfo\\ProjectQuotation_" + qrnNumber + ".docx");
                if (!Directory.Exists(targetFilePath))
                {
                    Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "Temp\\bidinfo"));
                }

                fileStreamPath = System.IO.File.Create(targetFilePath2);
                document.Save(fileStreamPath, FormatType.Docx);

                fileStreamPath.Dispose();

                byte[] bytes = File.ReadAllBytes(targetFilePath2);
                string docBase64 = "data: application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + Convert.ToBase64String(bytes);
                return docBase64;
            }

            else if (templateName == "ShortQuotation")
            {
                var date = DateTime.Now;
                string targetFilePath = Path.Combine(_env.WebRootPath, "template\\bidinfo\\Quote_document_ShortQuotation_template.docx");
                FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                WordDocument document = new WordDocument(fileStreamPath, FormatType.Docx);
                document.Open(fileStreamPath, FormatType.Docx);
                fileStreamPath.Dispose();

                document.Replace("<<TodayDate>>", date.ToString("d"), true, true);

                foreach (var user in salesLeader)
                {
                    document.Replace("<<UserName>>", user.Name, true, true);
                    document.Replace("<<UserEmailAddress>>", user.EmailAddress, true, true);
                }
                document.Replace("<<ProjectName>>", Info.ProjectName, true, true);
                document.Replace("<<ProjectDescription>>", Info.DescriptionOfWork, true, true);
                document.Replace("<<ContactName>>", contactPersonName, true, true);
                document.Replace("<<QuoteRefNo>>", qrnNumber, true, true);

                foreach (var addSite in projectInfo)
                {
                    document.Replace("<<Location>>", String.IsNullOrEmpty(addSite.SiteName) ? "" : addSite.SiteName, true, true); //ProjectSite Db
                    document.Replace("<<CustomerName>>", String.IsNullOrEmpty(addSite.Name) ? "" : addSite.Name, true, true);
                    document.Replace("<<CustomerAddress>>", String.IsNullOrEmpty(addSite.Address1) ? "" : addSite.Address1, true, true);
                    document.Replace("<<EmailAddress>>", addSite.Email, true, true);
                }

                string targetFilePath3 = Path.Combine(_env.WebRootPath, "template\\bidinfo\\Quote_document_ShortQuotation_template.docx");
                FileStream fileStreamPath3 = new FileStream(targetFilePath3, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite);
                WordDocument tmpDoc = new WordDocument();
                tmpDoc.Open(fileStreamPath3, FormatType.Docx);


                IWSection section = tmpDoc.AddSection();
                section.PageSetup.Margins.All = 72;
                section.PageSetup.PageSize = new Syncfusion.Drawing.SizeF(612, 792);

                IWTextRange textRange = section.AddParagraph().AppendText("");
                textRange.CharacterFormat.FontSize = 19;
                IWTable table = new WTable(document);

                if (id != 0)
                {

                    textRange.CharacterFormat.FontSize = 19;
                    table.TableFormat.Borders.LineWidth = 1f;
                    WTableRow row = table.AddRow();
                    WTableCell cell = row.AddCell();
                    cell.Width = 270;
                    cell.AddParagraph().AppendText("Item Description");
                    textRange.CharacterFormat.FontSize = 19;
                    cell = row.AddCell();
                    cell.Width = 180;
                    cell.AddParagraph().AppendText("Cost");

                    foreach (var group in sellInfo)
                    {
                        row = table.AddRow(true, false);
                        cell = row.AddCell();
                        cell.Width = 270;
                        cell.AddParagraph().AppendText(group.Title);
                        cell = row.AddCell();
                        cell.Width = 180;
                        cell.AddParagraph().AppendText("£ " + group.SellAmount);
                    }
                    row = table.AddRow(true, false);

                    cell = row.AddCell();
                    cell.CellFormat.BackColor = Color.FromArgb(227, 218, 48);
                    cell.Width = 270;
                    cell.AddParagraph().AppendText("Total");
                    cell = row.AddCell();
                    cell.CellFormat.BackColor = Color.FromArgb(227, 218, 48);
                    cell.Width = 180;
                    // TODO: get currency code from tenant settings
                    cell.AddParagraph().AppendText(" £ " + projectSell);

                    row = table.AddRow(true, false);

                }

                TextBodyPart replacePart = new TextBodyPart(document);
                replacePart.BodyItems.Add(table);
                document.Replace("<<Proposal_Cost_Table>>", replacePart, false, true);

                string targetFilePath2 = Path.Combine(_env.WebRootPath, "Temp\\bidinfo\\ShortQuotation_" + qrnNumber + ".docx");
                if (!Directory.Exists(targetFilePath))
                {
                    Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "Temp\\bidinfo"));
                }

                fileStreamPath = System.IO.File.Create(targetFilePath2);
                document.Save(fileStreamPath, FormatType.Docx);

                fileStreamPath.Dispose();

                byte[] bytes = File.ReadAllBytes(targetFilePath2);
                string docBase64 = "data: application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + Convert.ToBase64String(bytes);
                return docBase64;
            }

            else if (templateName == "S&MQuotation")
            {
                var date = DateTime.Now;
                string targetFilePath = Path.Combine(_env.WebRootPath, "template\\bidinfo\\Quote_document_S&MQuotation_template.docx");
                FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                WordDocument document = new WordDocument(fileStreamPath, FormatType.Docx);
                document.Open(fileStreamPath, FormatType.Docx);
                fileStreamPath.Dispose();

                document.Replace("<<TodayDate>>", date.ToString("d"), true, true);

                foreach (var contactName in salesLeader)
                {
                    document.Replace("<<ContactName>>", contactName.Name, true, true);
                    document.Replace("<<EmailAddress>>", contactName.EmailAddress, true, true);
                }
                document.Replace("<<ProjectName>>", Info.ProjectName, true, true);
                document.Replace("<<QuoteRefNo>>", qrnNumber, true, true);
                foreach (var addSite in projectInfo)
                {
                    document.Replace("<<Location>>", String.IsNullOrEmpty(addSite.SiteName) ? "" : addSite.SiteName, true, true); //ProjectSite Db
                    document.Replace("<<CustomerName>>", String.IsNullOrEmpty(addSite.Name) ? "" : addSite.Name, true, true);
                    document.Replace("<<CustomerAddress>>", String.IsNullOrEmpty(addSite.Address1) ? "" : addSite.Address1, true, true);
                    document.Replace("<<CustomerPostalCode>>", String.IsNullOrEmpty(addSite.PostalCode) ? "" : addSite.PostalCode, true, true);
                }

                string targetFilePath3 = Path.Combine(_env.WebRootPath, "template\\bidinfo\\Quote_document_S&MQuotation_template.docx");
                FileStream fileStreamPath3 = new FileStream(targetFilePath3, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite);
                WordDocument tmpDoc = new WordDocument();
                tmpDoc.Open(fileStreamPath3, FormatType.Docx);

                IWSection section = tmpDoc.AddSection();
                section.PageSetup.Margins.All = 72;
                section.PageSetup.PageSize = new Syncfusion.Drawing.SizeF(612, 792);

                IWTextRange textRange = section.AddParagraph().AppendText("");
                textRange.CharacterFormat.FontSize = 19;
                IWTable table = new WTable(document);

                if (id != 0)
                {
                    textRange.CharacterFormat.FontSize = 19;
                    table.TableFormat.Borders.LineWidth = 1f;
                    WTableRow row = table.AddRow();
                    WTableCell cell = row.AddCell();
                    cell.Width = 150;
                    //cell.CellFormat.BackColor = Color.Gray;
                    cell.AddParagraph().AppendText("Item");
                    textRange.CharacterFormat.FontSize = 19;
                    cell = row.AddCell();
                    //cell.CellFormat.BackColor = Color.Gray;
                    cell.Width = 150;
                    cell.AddParagraph().AppendText("Service");
                    textRange.CharacterFormat.FontSize = 19;
                    cell = row.AddCell();
                    //cell.CellFormat.BackColor = Color.Gray;
                    cell.Width = 150;
                    cell.AddParagraph().AppendText("Description");
                    //var str2 = "[{'Item' : 'Item1','Service' : 'Type1','Description' : 'Description for Item 1','Comment' : 'Address' },{'Item' : 'Item2','Service' : 'Type1','Description' : 'Description for Item 1','Comment' : 'Address' }]";
                    var serviceJson = ppmTables != null ? ppmTables.Services : null;
                    var servicesData = serviceJson != null ? JsonConvert.DeserializeObject<List<Services>>(serviceJson) : null;
                    if (servicesData != null && servicesData.Count > 0)
                    {
                        foreach (var x in servicesData)
                        {
                            row = table.AddRow(true, false);
                            cell = row.AddCell();
                            cell.Width = 150;
                            cell.AddParagraph().AppendText(x.Item);
                            cell = row.AddCell();
                            cell.Width = 150;
                            cell.AddParagraph().AppendText(x.Service);
                            cell = row.AddCell();
                            cell.Width = 150;
                            cell.AddParagraph().AppendText(x.Description);
                        }
                    }
                    TextBodyPart replacePart = new TextBodyPart(document);
                    replacePart.BodyItems.Add(table);
                    document.Replace("<<Services_Table>>", replacePart, false, true);

                    IWTable tableEquipments = new WTable(document);
                    textRange.CharacterFormat.FontSize = 19;
                    tableEquipments.TableFormat.Borders.LineWidth = 1f;
                    WTableRow rowEquipments = tableEquipments.AddRow();
                    WTableCell cellEquipments = rowEquipments.AddCell();
                    cellEquipments.Width = 120;
                    cellEquipments.AddParagraph().AppendText("Item");
                    textRange.CharacterFormat.FontSize = 19;
                    cellEquipments = rowEquipments.AddCell();
                    cellEquipments.Width = 120;
                    cellEquipments.AddParagraph().AppendText("Type");
                    textRange.CharacterFormat.FontSize = 19;
                    cellEquipments = rowEquipments.AddCell();
                    cellEquipments.Width = 120;
                    cellEquipments.AddParagraph().AppendText("Description");
                    textRange.CharacterFormat.FontSize = 19;
                    cellEquipments = rowEquipments.AddCell();
                    cellEquipments.Width = 120;
                    cellEquipments.AddParagraph().AppendText("Quantity");
                    //var str1 = "[{'Item' : 'Item1','Type' : 'Type1','Description' : 'Description for Item 1','Quantity' : 10,'Comment' : 'Address' },{'Item' : 'Item2','Type' : 'Type1','Description' : 'Description for Item 1','Quantity' : 10,'Comment' : 'Address' }]";
                    var equipmentsJson = ppmTables != null ? ppmTables.EquipmentSchedule : null;
                    var equipmentScheduleData = equipmentsJson != null ? JsonConvert.DeserializeObject<List<Equipments>>(equipmentsJson) : null;
                    if (equipmentScheduleData != null && equipmentScheduleData.Count > 0)
                    {
                        foreach (var x in equipmentScheduleData)
                        {
                            rowEquipments = tableEquipments.AddRow(true, false);
                            cellEquipments = rowEquipments.AddCell();
                            cellEquipments.Width = 120;
                            cellEquipments.AddParagraph().AppendText(x.Item);
                            cellEquipments = rowEquipments.AddCell();
                            cellEquipments.Width = 120;
                            cellEquipments.AddParagraph().AppendText(x.type);
                            cellEquipments = rowEquipments.AddCell();
                            cellEquipments.Width = 120;
                            cellEquipments.AddParagraph().AppendText(x.Description);
                            cellEquipments = rowEquipments.AddCell();
                            cellEquipments.Width = 120;
                            cellEquipments.AddParagraph().AppendText(x.Quantity);
                        }
                    }
                    TextBodyPart replacePartEquipments = new TextBodyPart(document);
                    replacePartEquipments.BodyItems.Add(tableEquipments);
                    document.Replace("<<Equipments_Table>>", replacePartEquipments, false, true);

                    string targetFilePath2 = Path.Combine(_env.WebRootPath, "Temp\\bidinfo\\S&MQuotation_" + qrnNumber + ".docx");
                    if (!Directory.Exists(targetFilePath))
                    {
                        Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "Temp\\bidinfo"));
                    }
                    fileStreamPath = System.IO.File.Create(targetFilePath2);
                    document.Save(fileStreamPath, FormatType.Docx);
                    fileStreamPath.Dispose();
                    byte[] bytes = File.ReadAllBytes(targetFilePath2);
                    string docBase64 = "data: application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + Convert.ToBase64String(bytes);
                    return docBase64;
                }
            }

            return null;
        }

    }
}