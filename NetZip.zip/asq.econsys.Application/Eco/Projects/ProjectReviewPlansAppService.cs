﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectReviewPlans)]
    public class ProjectReviewPlansAppService : econsysAppServiceBase, IProjectReviewPlansAppService
    {
        private readonly IRepository<ProjectReviewPlan, long> _projectReviewPlanRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectExReviewDetail, long> _lookup_projectExReviewDetailRepository;

        public ProjectReviewPlansAppService(IRepository<ProjectReviewPlan, long> projectReviewPlanRepository, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectExReviewDetail, long> lookup_projectExReviewDetailRepository)
        {
            _projectReviewPlanRepository = projectReviewPlanRepository;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectExReviewDetailRepository = lookup_projectExReviewDetailRepository;

        }

        public async Task<PagedResultDto<GetProjectReviewPlanForViewDto>> GetAll(GetAllProjectReviewPlansInput input)
        {

            var filteredProjectReviewPlans = _projectReviewPlanRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Description.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DescriptionFilter), e => e.Description == input.DescriptionFilter)
                        .WhereIf(input.MinActionDateFilter != null, e => e.ActionDate >= input.MinActionDateFilter)
                        .WhereIf(input.MaxActionDateFilter != null, e => e.ActionDate <= input.MaxActionDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter)
                        .WhereIf(input.ProjectIdFilter != 0, e => e.ProjectId == input.ProjectIdFilter);

            var pagedAndFilteredProjectReviewPlans = filteredProjectReviewPlans
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectReviewPlans = from o in pagedAndFilteredProjectReviewPlans
                                     join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                     from s1 in j1.DefaultIfEmpty()

                                     join o2 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o2.Id into j2
                                     from s2 in j2.DefaultIfEmpty()

                                     select new
                                     {

                                         o.Description,
                                         o.ActionDate,
                                         o.Comment,
                                         Id = o.Id,
                                         ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                         ProjectExReviewDetailTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
                                     };

            var totalCount = await filteredProjectReviewPlans.CountAsync();

            var dbList = await projectReviewPlans.ToListAsync();
            var results = new List<GetProjectReviewPlanForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectReviewPlanForViewDto()
                {
                    ProjectReviewPlan = new ProjectReviewPlanDto
                    {

                        Description = o.Description,
                        ActionDate = o.ActionDate,
                        Comment = o.Comment,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectExReviewDetailTitle = o.ProjectExReviewDetailTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectReviewPlanForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectReviewPlanForViewDto> GetProjectReviewPlanForView(long id)
        {
            var projectReviewPlan = await _projectReviewPlanRepository.GetAsync(id);

            var output = new GetProjectReviewPlanForViewDto { ProjectReviewPlan = ObjectMapper.Map<ProjectReviewPlanDto>(projectReviewPlan) };

            if (output.ProjectReviewPlan.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectReviewPlan.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectReviewPlan.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectReviewPlan.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectReviewPlans_Edit)]
        public async Task<GetProjectReviewPlanForEditOutput> GetProjectReviewPlanForEdit(EntityDto<long> input)
        {
            var projectReviewPlan = await _projectReviewPlanRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectReviewPlanForEditOutput { ProjectReviewPlan = ObjectMapper.Map<CreateOrEditProjectReviewPlanDto>(projectReviewPlan) };

            if (output.ProjectReviewPlan.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectReviewPlan.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectReviewPlan.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectReviewPlan.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectReviewPlanDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectReviewPlans_Create)]
        protected virtual async Task Create(CreateOrEditProjectReviewPlanDto input)
        {
            var projectReviewPlan = ObjectMapper.Map<ProjectReviewPlan>(input);

            if (AbpSession.TenantId != null)
            {
                projectReviewPlan.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectReviewPlanRepository.InsertAsync(projectReviewPlan);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectReviewPlans_Edit)]
        protected virtual async Task Update(CreateOrEditProjectReviewPlanDto input)
        {
            var projectReviewPlan = await _projectReviewPlanRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectReviewPlan);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectReviewPlans_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectReviewPlanRepository.DeleteAsync(input.Id);
        }
        [AbpAuthorize(AppPermissions.Pages_ProjectReviewPlans)]
        public async Task<List<ProjectReviewPlanProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectReviewPlanProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectReviewPlans)]
        public async Task<List<ProjectReviewPlanProjectExReviewDetailLookupTableDto>> GetAllProjectExReviewDetailForTableDropdown()
        {
            return await _lookup_projectExReviewDetailRepository.GetAll()
                .Select(projectExReviewDetail => new ProjectReviewPlanProjectExReviewDetailLookupTableDto
                {
                    Id = projectExReviewDetail.Id,
                    DisplayName = projectExReviewDetail == null || projectExReviewDetail.Title == null ? "" : projectExReviewDetail.Title.ToString()
                }).ToListAsync();
        }

    }
}