﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.BusinessRules;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectRules)]
    public class ProjectRulesAppService : econsysAppServiceBase, IProjectRulesAppService
    {
        private readonly IRepository<ProjectRule, long> _projectRuleRepository;
        private readonly IProjectRulesExcelExporter _projectRulesExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectAction, long> _lookup_projectActionRepository;
        private readonly IRepository<RuleFlag, string> _lookup_ruleFlagRepository;

        public ProjectRulesAppService(IRepository<ProjectRule, long> projectRuleRepository, IProjectRulesExcelExporter projectRulesExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectAction, long> lookup_projectActionRepository, IRepository<RuleFlag, string> lookup_ruleFlagRepository)
        {
            _projectRuleRepository = projectRuleRepository;
            _projectRulesExcelExporter = projectRulesExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectActionRepository = lookup_projectActionRepository;
            _lookup_ruleFlagRepository = lookup_ruleFlagRepository;

        }

        public async Task<PagedResultDto<GetProjectRuleForViewDto>> GetAll(GetAllProjectRulesInput input)
        {

            var filteredProjectRules = _projectRuleRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectActionFk)
                        .Include(e => e.RuleFlagFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.RuleCategory.Contains(input.Filter) || e.RuleKey.Contains(input.Filter) || e.RuleValue.Contains(input.Filter) || e.MetaData.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleCategoryFilter), e => e.RuleCategory == input.RuleCategoryFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleKeyFilter), e => e.RuleKey == input.RuleKeyFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleValueFilter), e => e.RuleValue == input.RuleValueFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MetaDataFilter), e => e.MetaData == input.MetaDataFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectActionStatusFilter), e => e.ProjectActionFk != null && e.ProjectActionFk.Status == input.ProjectActionStatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagTitleFilter), e => e.RuleFlagFk != null && e.RuleFlagFk.Title == input.RuleFlagTitleFilter);

            var pagedAndFilteredProjectRules = filteredProjectRules
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectRules = from o in pagedAndFilteredProjectRules
                               join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                               from s1 in j1.DefaultIfEmpty()

                               join o2 in _lookup_projectActionRepository.GetAll() on o.ProjectActionId equals o2.Id into j2
                               from s2 in j2.DefaultIfEmpty()

                               join o3 in _lookup_ruleFlagRepository.GetAll() on o.RuleFlagId equals o3.Id into j3
                               from s3 in j3.DefaultIfEmpty()

                               select new
                               {

                                   o.RuleCategory,
                                   o.RuleKey,
                                   o.RuleValue,
                                   o.MetaData,
                                   Id = o.Id,
                                   ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                   ProjectActionStatus = s2 == null || s2.Status == null ? "" : s2.Status.ToString(),
                                   RuleFlagTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
                               };

            var totalCount = await filteredProjectRules.CountAsync();

            var dbList = await projectRules.ToListAsync();
            var results = new List<GetProjectRuleForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectRuleForViewDto()
                {
                    ProjectRule = new ProjectRuleDto
                    {

                        RuleCategory = o.RuleCategory,
                        RuleKey = o.RuleKey,
                        RuleValue = o.RuleValue,
                        MetaData = o.MetaData,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectActionStatus = o.ProjectActionStatus,
                    RuleFlagTitle = o.RuleFlagTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectRuleForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectRuleForViewDto> GetProjectRuleForView(long id)
        {
            var projectRule = await _projectRuleRepository.GetAsync(id);

            var output = new GetProjectRuleForViewDto { ProjectRule = ObjectMapper.Map<ProjectRuleDto>(projectRule) };

            if (output.ProjectRule.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectRule.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectRule.ProjectActionId != null)
            {
                var _lookupProjectAction = await _lookup_projectActionRepository.FirstOrDefaultAsync((long)output.ProjectRule.ProjectActionId);
                output.ProjectActionStatus = _lookupProjectAction?.Status?.ToString();
            }

            if (output.ProjectRule.RuleFlagId != null)
            {
                var _lookupRuleFlag = await _lookup_ruleFlagRepository.FirstOrDefaultAsync((string)output.ProjectRule.RuleFlagId);
                output.RuleFlagTitle = _lookupRuleFlag?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectRules_Edit)]
        public async Task<GetProjectRuleForEditOutput> GetProjectRuleForEdit(EntityDto<long> input)
        {
            var projectRule = await _projectRuleRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectRuleForEditOutput { ProjectRule = ObjectMapper.Map<CreateOrEditProjectRuleDto>(projectRule) };

            if (output.ProjectRule.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectRule.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectRule.ProjectActionId != null)
            {
                var _lookupProjectAction = await _lookup_projectActionRepository.FirstOrDefaultAsync((long)output.ProjectRule.ProjectActionId);
                output.ProjectActionStatus = _lookupProjectAction?.Status?.ToString();
            }

            if (output.ProjectRule.RuleFlagId != null)
            {
                var _lookupRuleFlag = await _lookup_ruleFlagRepository.FirstOrDefaultAsync((string)output.ProjectRule.RuleFlagId);
                output.RuleFlagTitle = _lookupRuleFlag?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectRuleDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectRules_Create)]
        protected virtual async Task Create(CreateOrEditProjectRuleDto input)
        {
            var projectRule = ObjectMapper.Map<ProjectRule>(input);

            if (AbpSession.TenantId != null)
            {
                projectRule.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectRuleRepository.InsertAsync(projectRule);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectRules_Edit)]
        protected virtual async Task Update(CreateOrEditProjectRuleDto input)
        {
            var projectRule = await _projectRuleRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectRule);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectRules_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectRuleRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectRulesToExcel(GetAllProjectRulesForExcelInput input)
        {

            var filteredProjectRules = _projectRuleRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectActionFk)
                        .Include(e => e.RuleFlagFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.RuleCategory.Contains(input.Filter) || e.RuleKey.Contains(input.Filter) || e.RuleValue.Contains(input.Filter) || e.MetaData.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleCategoryFilter), e => e.RuleCategory == input.RuleCategoryFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleKeyFilter), e => e.RuleKey == input.RuleKeyFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleValueFilter), e => e.RuleValue == input.RuleValueFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MetaDataFilter), e => e.MetaData == input.MetaDataFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectActionStatusFilter), e => e.ProjectActionFk != null && e.ProjectActionFk.Status == input.ProjectActionStatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RuleFlagTitleFilter), e => e.RuleFlagFk != null && e.RuleFlagFk.Title == input.RuleFlagTitleFilter);

            var query = (from o in filteredProjectRules
                         join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_projectActionRepository.GetAll() on o.ProjectActionId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_ruleFlagRepository.GetAll() on o.RuleFlagId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         select new GetProjectRuleForViewDto()
                         {
                             ProjectRule = new ProjectRuleDto
                             {
                                 RuleCategory = o.RuleCategory,
                                 RuleKey = o.RuleKey,
                                 RuleValue = o.RuleValue,
                                 MetaData = o.MetaData,
                                 Id = o.Id
                             },
                             ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                             ProjectActionStatus = s2 == null || s2.Status == null ? "" : s2.Status.ToString(),
                             RuleFlagTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
                         });

            var projectRuleListDtos = await query.ToListAsync();

            return _projectRulesExcelExporter.ExportToFile(projectRuleListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectRules)]
        public async Task<List<ProjectRuleProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectRuleProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectRules)]
        public async Task<List<ProjectRuleProjectActionLookupTableDto>> GetAllProjectActionForTableDropdown()
        {
            return await _lookup_projectActionRepository.GetAll()
                .Select(projectAction => new ProjectRuleProjectActionLookupTableDto
                {
                    Id = projectAction.Id,
                    DisplayName = projectAction == null || projectAction.Status == null ? "" : projectAction.Status.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectRules)]
        public async Task<List<ProjectRuleRuleFlagLookupTableDto>> GetAllRuleFlagForTableDropdown()
        {
            return await _lookup_ruleFlagRepository.GetAll()
                .Select(ruleFlag => new ProjectRuleRuleFlagLookupTableDto
                {
                    Id = ruleFlag.Id,
                    DisplayName = ruleFlag == null || ruleFlag.Title == null ? "" : ruleFlag.Title.ToString()
                }).ToListAsync();
        }

        public async Task<List<ProjectRule>> GetAllByProjectId(int id)
        {
            return await _projectRuleRepository.GetAll().Where(x => x.ProjectId == id).ToListAsync();
        }
    }
}