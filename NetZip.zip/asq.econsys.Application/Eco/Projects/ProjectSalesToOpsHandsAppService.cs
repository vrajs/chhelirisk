﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Newtonsoft.Json;
using Abp.Runtime.Session;
using asq.econsys.Eco.BusinessRules;
using Abp.Events.Bus;
using Abp.UI;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectSalesToOpsHands)]
    public class ProjectSalesToOpsHandsAppService : econsysAppServiceBase, IProjectSalesToOpsHandsAppService
    {
        private readonly IRepository<ProjectSalesToOpsHand, long> _projectSalesToOpsHandRepository;
        private readonly IProjectSalesToOpsHandsExcelExporter _projectSalesToOpsHandsExcelExporter;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectEngineering> _projectEngineeringRepository;
        private readonly IRepository<RuleValue, long> _ruleValueRepository;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly IRepository<ProjectOAReview, long> _projectOAReviewRepository;
        public IEventBus EventBus { get; set; }


        public ProjectSalesToOpsHandsAppService(IRepository<ProjectSalesToOpsHand, long> projectSalesToOpsHandRepository, IProjectSalesToOpsHandsExcelExporter projectSalesToOpsHandsExcelExporter, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectEngineering> projectEngineeringRepository, IRepository<RuleValue, long> ruleValueRepository, ProjectPermissionManager projectPermissionManager, IRepository<ProjectOAReview, long> projectOAReviewRepository)
        {
            _projectSalesToOpsHandRepository = projectSalesToOpsHandRepository;
            _projectSalesToOpsHandsExcelExporter = projectSalesToOpsHandsExcelExporter;
            _lookup_projectRepository = lookup_projectRepository;
            _projectEngineeringRepository = projectEngineeringRepository;
            _ruleValueRepository = ruleValueRepository;
            _projectPermissionManager = projectPermissionManager;
            EventBus = NullEventBus.Instance;
            _projectOAReviewRepository = projectOAReviewRepository;
        }

        public async Task<PagedResultDto<GetProjectSalesToOpsHandForViewDto>> GetAll(GetAllProjectSalesToOpsHandsInput input)
        {

            var filteredProjectSalesToOpsHands = _projectSalesToOpsHandRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.JoFilPatInServ.Contains(input.Filter) || e.DocumentList.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(input.IsJobFilSetOnServFilter.HasValue && input.IsJobFilSetOnServFilter > -1, e => (input.IsJobFilSetOnServFilter == 1 && e.IsJobFilSetOnServ) || (input.IsJobFilSetOnServFilter == 0 && !e.IsJobFilSetOnServ))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.JoFilPatInServFilter), e => e.JoFilPatInServ.Contains(input.JoFilPatInServFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DocumentListFilter), e => e.DocumentList.Contains(input.DocumentListFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ScheMeetWiOpeFilter), e => e.ScheMeetWiOpe.Contains(input.ScheMeetWiOpeFilter))
                      //  .WhereIf(input.ScheMeetWiOpeFilter.HasValue && input.ScheMeetWiOpeFilter > -1, e => (input.ScheMeetWiOpeFilter == 1 && e.ScheMeetWiOpe) || (input.ScheMeetWiOpeFilter == 0 && !e.ScheMeetWiOpe))
                        .WhereIf(input.MinScheMeetWiOpeDateFilter != null, e => e.ScheMeetWiOpeDate >= input.MinScheMeetWiOpeDateFilter)
                        .WhereIf(input.MaxScheMeetWiOpeDateFilter != null, e => e.ScheMeetWiOpeDate <= input.MaxScheMeetWiOpeDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment.Contains(input.CommentFilter))
                        .WhereIf(input.MinProjectIdFilter != null, e => e.ProjectId >= input.MinProjectIdFilter)
                        .WhereIf(input.MaxProjectIdFilter != null, e => e.ProjectId <= input.MaxProjectIdFilter)
                        .WhereIf(input.DelOFAToSalLeadFilter.HasValue && input.DelOFAToSalLeadFilter > -1, e => (input.DelOFAToSalLeadFilter == 1 && e.DelOFAToSalLead) || (input.DelOFAToSalLeadFilter == 0 && !e.DelOFAToSalLead));
               
                var pagedAndFilteredProjectSalesToOpsHands = filteredProjectSalesToOpsHands
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectSalesToOpsHands = from o in pagedAndFilteredProjectSalesToOpsHands
                                  select new
                                  {

                                      o.IsJobFilSetOnServ,
                                      o.JoFilPatInServ,
                                      o.DocumentList,
                                      o.ScheMeetWiOpe,
                                      o.ScheMeetWiOpeDate,
                                      o.Comment,
                                      o.ProjectId,
                                      o.DelOFAToSalLead,
                                      Id = o.Id
                                  };

            var totalCount = await filteredProjectSalesToOpsHands.CountAsync();

            var dbList = await projectSalesToOpsHands.ToListAsync();
            var results = new List<GetProjectSalesToOpsHandForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectSalesToOpsHandForViewDto()
                {
                    ProjectSalesToOpsHand = new ProjectSalesToOpsHandDto
                    {

                        IsJobFilSetOnServ = o.IsJobFilSetOnServ,
                        JoFilPatInServ = o.JoFilPatInServ,
                        DocumentList = o.DocumentList,
                        ScheMeetWiOpe = o.ScheMeetWiOpe,
                        ScheMeetWiOpeDate = o.ScheMeetWiOpeDate,
                        Comment = o.Comment,
                        ProjectId = o.ProjectId,
                        DelOFAToSalLead = o.DelOFAToSalLead,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectSalesToOpsHandForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectSalesToOpsHandForViewDto> GetProjectSalesToOpsHandForView(int id)
        {
            
            var projectSalesToOpsHand = await _projectSalesToOpsHandRepository.GetAsync(id);

            var output = new GetProjectSalesToOpsHandForViewDto { ProjectSalesToOpsHand = ObjectMapper.Map<ProjectSalesToOpsHandDto>(projectSalesToOpsHand) };
            if (output.ProjectSalesToOpsHand.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectSalesToOpsHand.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }
            //if (output.ProjectSalesToOpsHand.DocumentList != null)
            //{
            //    projectSalesToOpsHand.DocumentList = JsonConvert.DeserializeObject(output.ProjectSalesToOpsHand.DocumentList);
            //}


            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSalesToOpsHands_Edit)]
        public async Task<GetProjectSalesToOpsHandForEditOutput> GetProjectSalesToOpsHandForEdit(EntityDto input)
        {
          //  var projectSalesToOpsHand = await _salesToOpsHandRepository.FirstOrDefaultAsync(input.Id);
            var projectSalesToOpsHand = await _projectSalesToOpsHandRepository.GetAllIncluding().Where(x => x.ProjectId == input.Id).FirstOrDefaultAsync();

            var output = new GetProjectSalesToOpsHandForEditOutput { ProjectSalesToOpsHand = ObjectMapper.Map<CreateOrEditProjectSalesToOpsHandDto>(projectSalesToOpsHand) };
             if ( output.ProjectSalesToOpsHand.ProjectId !=null)
                {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectSalesToOpsHand.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
                }
            

            //  projectSalesToOpsHand.DocumentList = JsonConvert.SerializeObject(output.DocumentList);


            return output;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit(CreateOrEditProjectSalesToOpsHandDto input)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = (long)input.ProjectId
            });
            if (!check)
            {
                throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            }
            GetProjectForViewDto result = new GetProjectForViewDto();
            var projectSalesToHand = new GetProjectSalesToOpsHandForViewDto();
            var SalesToOpsHand = new GetProjectSalesToOpsHandForViewDto();
            var OAReview = await _projectOAReviewRepository.FirstOrDefaultAsync(x => x.ProjectId == input.ProjectId && x.IsCurrent == true);
            if (OAReview != null)
            {
                input.ProjectOAReviewId = OAReview.Id;
            }
            if (input.Id == null)
            {
                projectSalesToHand = await Create(input);
            }
            else
            {
                projectSalesToHand = await Update(input);
            }

            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                ProjectId = input.ProjectId,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.SalestoOperationsHandover,
                StatusId = CNodeStatuses.Submit,
                Comment = input.Comment,
                LoggedInUserId = (long)AbpSession.UserId
            });

            var project = await _lookup_projectRepository.FirstOrDefaultAsync(Convert.ToInt64(input.ProjectId));
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.ProjectSalesToOpsHand = projectSalesToHand;
            return result;


        }
        public async Task<GetProjectEngineeringForViewDto> Getengineeringdata(long projectid)
        {
            var EngineeringDto = await _projectEngineeringRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
            var RuleTitle = await _ruleValueRepository.FirstOrDefaultAsync(x => x.Id == EngineeringDto.RuleValueId);

            var output = new GetProjectEngineeringForViewDto { ProjectEngineering = ObjectMapper.Map<ProjectEngineeringDto>(EngineeringDto) };
            output.RuleValueTitle = RuleTitle.Title;
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSalesToOpsHands_Create)]
        protected virtual async Task<GetProjectSalesToOpsHandForViewDto> Create(CreateOrEditProjectSalesToOpsHandDto input)
        {
            var projectSalesToOpsHand = ObjectMapper.Map<ProjectSalesToOpsHand>(input);

            if (AbpSession.TenantId != null)
            {
                projectSalesToOpsHand.TenantId = (int?)AbpSession.TenantId;
            }
            input.CreatorUserId = (long)AbpSession.UserId;
            input.CreatedOn = DateTime.UtcNow;

            long projectSalesToOpsId = await _projectSalesToOpsHandRepository.InsertAndGetIdAsync(projectSalesToOpsHand);

            //var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);
          
            //await EventBus.TriggerAsync(new EditProjectEventData()
            //{
            //    Project = project,
            //    StageId = CNodeStages.OrderAcceptance,
            //    TaskId = CNodeTasks.SalestoOperationsHandover,
            //    StatusId = CNodeStatuses.Submit,
            //    Comment = input.Comment,
            //    LoggedInUserId = (long)AbpSession.UserId
            //});

            var projectSalesToOp = await _projectSalesToOpsHandRepository.GetAsync(projectSalesToOpsId);
            var output = new GetProjectSalesToOpsHandForViewDto { ProjectSalesToOpsHand = ObjectMapper.Map<ProjectSalesToOpsHandDto>(projectSalesToOp) };
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSalesToOpsHands_Edit)]
        protected virtual async Task<GetProjectSalesToOpsHandForViewDto> Update(CreateOrEditProjectSalesToOpsHandDto input)
        {
            input.LastModifierUserId = (long)AbpSession.UserId;
            input.UpdatedOn = DateTime.UtcNow;
            var projectSalesToOpsHand = await _projectSalesToOpsHandRepository.FirstOrDefaultAsync((int)input.Id);

            if (input.DocumentList != null)
            {
                projectSalesToOpsHand.DocumentList = JsonConvert.SerializeObject(input.DocumentList);
            }
            ObjectMapper.Map(input, projectSalesToOpsHand);

            //var project = _lookup_projectRepository.FirstOrDefault(input.ProjectId);

            //await EventBus.TriggerAsync(new EditProjectEventData()
            //{
            //    Project = project,
            //    StageId = CNodeStages.OrderAcceptance,
            //    TaskId = CNodeTasks.SalestoOperationsHandover,
            //    StatusId = CNodeStatuses.Submit,
            //    Comment = input.Comment,
            //    LoggedInUserId = (long)AbpSession.UserId
            //});
            var output = new GetProjectSalesToOpsHandForViewDto { ProjectSalesToOpsHand = ObjectMapper.Map<ProjectSalesToOpsHandDto>(_projectSalesToOpsHandRepository.Get((long)input.Id)) };
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSalesToOpsHands_Delete)]
        public async Task Delete(EntityDto input)
        {
            await _projectSalesToOpsHandRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectSalesToOpsHandsToExcel(GetAllProjectSalesToOpsHandsForExcelInput input)
        {

            var filteredProjectSalesToOpsHands = _projectSalesToOpsHandRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.JoFilPatInServ.Contains(input.Filter) || e.DocumentList.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(input.IsJobFilSetOnServFilter.HasValue && input.IsJobFilSetOnServFilter > -1, e => (input.IsJobFilSetOnServFilter == 1 && e.IsJobFilSetOnServ) || (input.IsJobFilSetOnServFilter == 0 && !e.IsJobFilSetOnServ))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.JoFilPatInServFilter), e => e.JoFilPatInServ.Contains(input.JoFilPatInServFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DocumentListFilter), e => e.DocumentList.Contains(input.DocumentListFilter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ScheMeetWiOpeFilter), e => e.ScheMeetWiOpe.Contains(input.ScheMeetWiOpeFilter))

                       // .WhereIf(input.ScheMeetWiOpeFilter.HasValue && input.ScheMeetWiOpeFilter > -1, e => (input.ScheMeetWiOpeFilter == 1 && e.ScheMeetWiOpe) || (input.ScheMeetWiOpeFilter == 0 && !e.ScheMeetWiOpe))
                        .WhereIf(input.MinScheMeetWiOpeDateFilter != null, e => e.ScheMeetWiOpeDate >= input.MinScheMeetWiOpeDateFilter)
                        .WhereIf(input.MaxScheMeetWiOpeDateFilter != null, e => e.ScheMeetWiOpeDate <= input.MaxScheMeetWiOpeDateFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment.Contains(input.CommentFilter))
                        .WhereIf(input.MinProjectIdFilter != null, e => e.ProjectId >= input.MinProjectIdFilter)
                        .WhereIf(input.MaxProjectIdFilter != null, e => e.ProjectId <= input.MaxProjectIdFilter)
                        .WhereIf(input.DelOFAToSalLeadFilter.HasValue && input.DelOFAToSalLeadFilter > -1, e => (input.DelOFAToSalLeadFilter == 1 && e.DelOFAToSalLead) || (input.DelOFAToSalLeadFilter == 0 && !e.DelOFAToSalLead));


            var query = (from o in filteredProjectSalesToOpsHands
                         select new GetProjectSalesToOpsHandForViewDto()
                         {
                             ProjectSalesToOpsHand = new ProjectSalesToOpsHandDto
                             {
                                 IsJobFilSetOnServ = o.IsJobFilSetOnServ,
                                 JoFilPatInServ = o.JoFilPatInServ,
                                 DocumentList = o.DocumentList,
                                 ScheMeetWiOpe = o.ScheMeetWiOpe,
                                 ScheMeetWiOpeDate = o.ScheMeetWiOpeDate,
                                 Comment = o.Comment,
                                 ProjectId = o.ProjectId,
                                 DelOFAToSalLead = o.DelOFAToSalLead,
                                 Id = o.Id
                             }
                         });

            var projectSalesToOpsHandListDtos = await query.ToListAsync();

            return _projectSalesToOpsHandsExcelExporter.ExportToFile(projectSalesToOpsHandListDtos);
        }

    }
}