﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.SiteRefConfig.Dtos;
using asq.econsys.Eco.SiteRefConfig;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectSites)]
    public class ProjectSitesAppService : econsysAppServiceBase, IProjectSitesAppService
    {
        private readonly IRepository<ProjectSite, long> _projectSiteRepository;
        private readonly IProjectSitesExcelExporter _projectSitesExcelExporter;
        private readonly ISiteRefConfigsAppService _siteRefConfigsAppService;
        private readonly ISiteRefConfigDetailsAppService _siteRefConfigDetailsAppService;

        public ProjectSitesAppService(IRepository<ProjectSite, long> projectSiteRepository,
            IProjectSitesExcelExporter projectSitesExcelExporter,
            ISiteRefConfigsAppService siteRefConfigsAppService,
            ISiteRefConfigDetailsAppService siteRefConfigDetailsAppService
            )
        {
            _projectSiteRepository = projectSiteRepository;
            _projectSitesExcelExporter = projectSitesExcelExporter;
            _siteRefConfigsAppService = siteRefConfigsAppService;
            _siteRefConfigDetailsAppService = siteRefConfigDetailsAppService;
        }
        public async Task<List<GetProjectSiteForViewDto>> GetAllSites()
        {
            var results = new List<GetProjectSiteForViewDto>();
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var projectSites = _projectSiteRepository.GetAll().Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));
                    var allProjectSites = from o in projectSites
                                          select new
                                          {
                                              o.SiteName,
                                              o.SiteAddress1,
                                              o.SiteAddress2,
                                              o.SiteRef,
                                              o.SitePostCode,
                                              o.Remark,
                                              Id = o.Id
                                          };

                    var totalCount = await projectSites.CountAsync();

                    var dbList = await allProjectSites.ToListAsync();

                    foreach (var o in dbList)
                    {
                        var res = new GetProjectSiteForViewDto()
                        {
                            ProjectSite = new ProjectSiteDto
                            {
                                SiteName = o.SiteName,
                                SiteAddress1 = o.SiteAddress1,
                                SiteAddress2 = o.SiteAddress2,
                                SiteRef = o.SiteRef,
                                SitePostCode = o.SitePostCode,
                                Remark = o.Remark,
                                Id = o.Id,
                            }
                        };

                        results.Add(res);
                    }
                }
            }

            return results;
        }

        public async Task<PagedResultDto<GetProjectSiteForViewDto>> GetAll(GetAllProjectSitesInput input)
        {
            var filteredProjectSites = _projectSiteRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.SiteName.Contains(input.Filter) || e.SiteAddress1.Contains(input.Filter) || e.SiteRef.Contains(input.Filter) || e.Remark.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SiteNameFilter), e => e.SiteName == input.SiteNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SiteAddress1Filter), e => e.SiteAddress1 == input.SiteAddress1Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SiteRefFilter), e => e.SiteRef == input.SiteRefFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RemarkFilter), e => e.Remark == input.RemarkFilter);

            var pagedAndFilteredProjectSites = filteredProjectSites
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectSites = from o in pagedAndFilteredProjectSites
                               select new
                               {

                                   o.SiteName,
                                   o.SiteAddress1,
                                   o.SiteAddress2,
                                   o.SiteRef,
                                   o.Remark,
                                   Id = o.Id
                               };

            var totalCount = await filteredProjectSites.CountAsync();

            var dbList = await projectSites.ToListAsync();
            var results = new List<GetProjectSiteForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectSiteForViewDto()
                {
                    ProjectSite = new ProjectSiteDto
                    {

                        SiteName = o.SiteName,
                        SiteAddress1 = o.SiteAddress1,
                        SiteAddress2 = o.SiteAddress2,
                        SiteRef = o.SiteRef,
                        Remark = o.Remark,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectSiteForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectSiteForViewDto> GetProjectSiteForView(long id)
        {
            var projectSite = await _projectSiteRepository.GetAsync(id);

            var output = new GetProjectSiteForViewDto { ProjectSite = ObjectMapper.Map<ProjectSiteDto>(projectSite) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSites_Edit)]
        public async Task<GetProjectSiteForEditOutput> GetProjectSiteForEdit(EntityDto<long> input)
        {
            var projectSite = await _projectSiteRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectSiteForEditOutput { ProjectSite = ObjectMapper.Map<CreateOrEditProjectSiteDto>(projectSite) };

            return output;
        }

        public async Task<CreateOrEditProjectSiteOutputDto> CreateOrEdit(CreateOrEditProjectSiteDto input)
        {
            var createOrUpdateSite = new CreateOrEditProjectSiteOutputDto();
            if (input.Id == null)
            {
                createOrUpdateSite = await Create(input);
            }
            else
            {
                await Update(input);
            }
            return createOrUpdateSite;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSites_Create)]
        protected virtual async Task<CreateOrEditProjectSiteOutputDto> Create(CreateOrEditProjectSiteDto input)
        {
            var projectSite = ObjectMapper.Map<ProjectSite>(input);

            if (AbpSession.TenantId != null)
            {
                projectSite.TenantId = (int?)AbpSession.TenantId;
            }
            var updateRecord = new CreateOrEditSiteRefConfigDetailsDto();

            var siteConfigDetails = await GetSiteRefConfigDetails();
            if (siteConfigDetails.SRNAutoGenerate)
            {

                if (siteConfigDetails.SiteRefNumberRecords != null)
                {
                    foreach (var record in siteConfigDetails.SiteRefNumberRecords)
                    {
                        var currentRefDigit = record.CurrentDigit;
 
                        if (record.ValueType == "String")
                        {
                            projectSite.SiteRef = projectSite.SiteRef + record.Prefix;
                        }
                        else if (record.ValueType == "Year")
                        {
                            projectSite.SiteRef = projectSite.SiteRef + record.StartingFrom;
                        }
                        else if (record.ValueType == "Number")
                        {
                            record.CurrentDigit = record.CurrentDigit + 1;
                            updateRecord = record;
                            projectSite.SiteRef = projectSite.SiteRef + record.CurrentDigit.ToString().PadRight(record.MinDigits - currentRefDigit.ToString().Length, '0');
                        }
                    }
                }
            }
            var projectSiteId = _projectSiteRepository.InsertAndGetId(projectSite);
            if (updateRecord.Id != null)
            {
                await _siteRefConfigDetailsAppService.CreateOrEdit(updateRecord);
            }
            var output = ObjectMapper.Map<CreateOrEditProjectSiteOutputDto>(await _projectSiteRepository.GetAsync(projectSiteId));
            var allSites = await GetAllSites();
            output.AllSites = allSites;
            return output;
        }

        private async Task<SiteRefConfigDto> GetSiteRefConfigDetails()
        {
            var siteConfiguration = await _siteRefConfigsAppService.GetAll();

            return siteConfiguration;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSites_Edit)]
        protected virtual async Task Update(CreateOrEditProjectSiteDto input)
        {
            var projectSite = await _projectSiteRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectSite);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSites_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectSiteRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectSitesToExcel(GetAllProjectSitesForExcelInput input)
        {

            var filteredProjectSites = _projectSiteRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.SiteName.Contains(input.Filter) || e.SiteAddress1.Contains(input.Filter) || e.SiteRef.Contains(input.Filter) || e.Remark.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SiteNameFilter), e => e.SiteName == input.SiteNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SiteAddress1Filter), e => e.SiteAddress1 == input.SiteAddress1Filter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SiteRefFilter), e => e.SiteRef == input.SiteRefFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RemarkFilter), e => e.Remark == input.RemarkFilter);

            var query = (from o in filteredProjectSites
                         select new GetProjectSiteForViewDto()
                         {
                             ProjectSite = new ProjectSiteDto
                             {
                                 SiteName = o.SiteName,
                                 SiteAddress1 = o.SiteAddress1,
                                 SiteAddress2 = o.SiteAddress2,
                                 SiteRef = o.SiteRef,
                                 Remark = o.Remark,
                                 Id = o.Id
                             }
                         });

            var projectSiteListDtos = await query.ToListAsync();

            return _projectSitesExcelExporter.ExportToFile(projectSiteListDtos);
        }

    }
}