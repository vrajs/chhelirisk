﻿using Abp.Organizations;
using asq.econsys.Authorization.Users;
using asq.econsys.Authorization.Roles;
using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Dtos;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.Events.Bus;
using System.IO;
using Syncfusion.DocIO.DLS;
using Syncfusion.DocIO;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System.Net.Mail;
using System.Net.Mime;
using System.Net;
using Abp.Domain.Uow;
using System.Net.Http;
using Abp.UI;
using Syncfusion.DocIO.DLS;
using Syncfusion.DocIORenderer;
using Syncfusion.Pdf;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using asq.econsys.Eco.Utils.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes)]
    public class ProjectStatusOfSubmittedQuotesAppService : econsysAppServiceBase, IProjectStatusOfSubmittedQuotesAppService
    {
        private readonly IRepository<ProjectStatusOfSubmittedQuote, long> _statusOfSubmittedQuoteRepository;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<User, long> _lookup_userRepository;
        private readonly IRepository<Role, int> _lookup_roleRepository;
        private readonly IRepository<ProjectQuoteMeta, long> _lookup_quoteRepository;
        public IEventBus EventBus { get; set; }
        private readonly IRepository<Project, long> _projectRepository;
        private readonly IWebHostEnvironment _env;
        private readonly IRepository<ProjectQuoteForm, long> _projectQuoteFormRepository;
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly StorageManager _storageManager;

        public ProjectStatusOfSubmittedQuotesAppService(IRepository<ProjectStatusOfSubmittedQuote, long> statusOfSubmittedQuoteRepository, IRepository<OrganizationUnit, long> lookup_organizationUnitRepository, IRepository<Project, long> lookup_projectRepository, IRepository<User, long> lookup_userRepository, IRepository<Role, int> lookup_roleRepository, IRepository<ProjectQuoteMeta, long> lookup_quoteRepository, IRepository<Project, long> projectRepository, IWebHostEnvironment env, IRepository<ProjectQuoteForm, long> projectQuoteFormRepository, IUnitOfWorkManager unitOfWorkManager, ProjectPermissionManager projectPermissionManager, Utils.UtilsAppService utilsAppService, StorageManager storageManager)
        {
            EventBus = NullEventBus.Instance;
            _statusOfSubmittedQuoteRepository = statusOfSubmittedQuoteRepository;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_userRepository = lookup_userRepository;
            _lookup_roleRepository = lookup_roleRepository;
            _lookup_quoteRepository = lookup_quoteRepository;
            _projectRepository = projectRepository;
            _env = env;
            _projectQuoteFormRepository = projectQuoteFormRepository;
            _unitOfWorkManager = unitOfWorkManager;
            _projectPermissionManager = projectPermissionManager;
            _utilsAppService = utilsAppService;
            _storageManager = storageManager;
        }

        //public async Task<PagedResultDto<GetStatusOfSubmittedQuoteForViewDto>> GetAll(GetAllStatusOfSubmittedQuotesInput input)
        //{

        //    var filteredStatusOfSubmittedQuotes = _statusOfSubmittedQuoteRepository.GetAll()
        //                .Include(e => e.OrganizationUnitFk)
        //                .Include(e => e.ProjectFk)
        //                .Include(e => e.CorrespondingUserFk)
        //                .Include(e => e.CorrespondingRoleFk)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.StatusOfQuote.Contains(input.Filter) || e.CustomerCommitmentType.Contains(input.Filter) || e.ProposedOrderNumber.Contains(input.Filter) || e.ReceiptMethod.Contains(input.Filter) || e.CreditReason.Contains(input.Filter) || e.Company.Contains(input.Filter) || e.Address.Contains(input.Filter) || e.AttentionOf.Contains(input.Filter) || e.Subject.Contains(input.Filter) || e.ScopeOfWorks.Contains(input.Filter) || e.AdviseToClient.Contains(input.Filter) || e.CorrespondingEmail.Contains(input.Filter) || e.PostalCode.Contains(input.Filter))
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.StatusOfQuoteFilter), e => e.StatusOfQuote == input.StatusOfQuoteFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerCommitmentTypeFilter), e => e.CustomerCommitmentType == input.CustomerCommitmentTypeFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProposedOrderNumberFilter), e => e.ProposedOrderNumber == input.ProposedOrderNumberFilter)
        //                .WhereIf(input.MinValueOfCommitmentFilter != null, e => e.ValueOfCommitment >= input.MinValueOfCommitmentFilter)
        //                .WhereIf(input.MaxValueOfCommitmentFilter != null, e => e.ValueOfCommitment <= input.MaxValueOfCommitmentFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ReceiptMethodFilter), e => e.ReceiptMethod == input.ReceiptMethodFilter)
        //                .WhereIf(input.MinReceiptDateFilter != null, e => e.ReceiptDate >= input.MinReceiptDateFilter)
        //                .WhereIf(input.MaxReceiptDateFilter != null, e => e.ReceiptDate <= input.MaxReceiptDateFilter)
        //                .WhereIf(input.CustomerCreditWorthyFilter.HasValue && input.CustomerCreditWorthyFilter > -1, e => (input.CustomerCreditWorthyFilter == 1 && e.CustomerCreditWorthy) || (input.CustomerCreditWorthyFilter == 0 && !e.CustomerCreditWorthy))
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CreditReasonFilter), e => e.CreditReason == input.CreditReasonFilter)
        //                .WhereIf(input.MinOALetterGenerationDateFilter != null, e => e.OALetterGenerationDate >= input.MinOALetterGenerationDateFilter)
        //                .WhereIf(input.MaxOALetterGenerationDateFilter != null, e => e.OALetterGenerationDate <= input.MaxOALetterGenerationDateFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CompanyFilter), e => e.Company == input.CompanyFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.AddressFilter), e => e.Address == input.AddressFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.AttentionOfFilter), e => e.AttentionOf == input.AttentionOfFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.SubjectFilter), e => e.Subject == input.SubjectFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ScopeOfWorksFilter), e => e.ScopeOfWorks == input.ScopeOfWorksFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.AdviseToClientFilter), e => e.AdviseToClient == input.AdviseToClientFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CorrespondingEmailFilter), e => e.CorrespondingEmail == input.CorrespondingEmailFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.PostalCodeFilter), e => e.PostalCode == input.PostalCodeFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.UserNameFilter), e => e.CorrespondingUserFk != null && e.CorrespondingUserFk.Name == input.UserNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.RoleNameFilter), e => e.CorrespondingRoleFk != null && e.CorrespondingRoleFk.Name == input.RoleNameFilter);

        //    var pagedAndFilteredStatusOfSubmittedQuotes = filteredStatusOfSubmittedQuotes
        //        .OrderBy(input.Sorting ?? "id asc")
        //        .PageBy(input);

        //    var statusOfSubmittedQuotes = from o in pagedAndFilteredStatusOfSubmittedQuotes
        //                                  join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
        //                                  from s1 in j1.DefaultIfEmpty()

        //                                  join o2 in _lookup_projectRepository.GetAll() on o.ProjectId equals o2.Id into j2
        //                                  from s2 in j2.DefaultIfEmpty()

        //                                  join o3 in _lookup_userRepository.GetAll() on o.CorrespondingUserId equals o3.Id into j3
        //                                  from s3 in j3.DefaultIfEmpty()

        //                                  join o4 in _lookup_roleRepository.GetAll() on o.CorrespondingRoleId equals o4.Id into j4
        //                                  from s4 in j4.DefaultIfEmpty()

        //                                  select new
        //                                  {

        //                                      o.StatusOfSubmitQuoteValue,
        //                                      o.CustomerCommitmentType,
        //                                      o.ProposedOrderNumber,
        //                                      o.ValueOfCommitment,
        //                                      o.ReceiptMethod,
        //                                      o.ReceiptDate,
        //                                      o.CustomerCreditWorthy,
        //                                      o.CreditReason,
        //                                      o.OALetterGenerationDate,
        //                                      o.Company,
        //                                      o.Address,
        //                                      o.AttentionOf,
        //                                      o.Subject,
        //                                      o.ScopeOfWorks,
        //                                      o.AdviseToClient,
        //                                      o.CorrespondingEmail,
        //                                      o.PostalCode,
        //                                      Id = o.Id,
        //                                      OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
        //                                      ProjectProjectName = s2 == null || s2.ProjectName == null ? "" : s2.ProjectName.ToString(),
        //                                      UserName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
        //                                      RoleName = s4 == null || s4.Name == null ? "" : s4.Name.ToString()
        //                                  };

        //    var totalCount = await filteredStatusOfSubmittedQuotes.CountAsync();

        //    var dbList = await statusOfSubmittedQuotes.ToListAsync();
        //    var results = new List<GetStatusOfSubmittedQuoteForViewDto>();

        //    foreach (var o in dbList)
        //    {
        //        var res = new GetStatusOfSubmittedQuoteForViewDto()
        //        {
        //            StatusOfSubmittedQuote = new StatusOfSubmittedQuoteDto
        //            {

        //                StatusOfQuote = o.StatusOfQuote,
        //                CustomerCommitmentType = o.CustomerCommitmentType,
        //                ProposedOrderNumber = o.ProposedOrderNumber,
        //                ValueOfCommitment = o.ValueOfCommitment,
        //                ReceiptMethod = o.ReceiptMethod,
        //                ReceiptDate = o.ReceiptDate,
        //                CustomerCreditWorthy = o.CustomerCreditWorthy,
        //                CreditReason = o.CreditReason,
        //                OALetterGenerationDate = o.OALetterGenerationDate,
        //                Company = o.Company,
        //                Address = o.Address,
        //                AttentionOf = o.AttentionOf,
        //                Subject = o.Subject,
        //                ScopeOfWorks = o.ScopeOfWorks,
        //                AdviseToClient = o.AdviseToClient,
        //                CorrespondingEmail = o.CorrespondingEmail,
        //                PostalCode = o.PostalCode,
        //                Id = o.Id,
        //            },
        //            OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
        //            ProjectProjectName = o.ProjectProjectName,
        //            UserName = o.UserName,
        //            RoleName = o.RoleName
        //        };

        //        results.Add(res);
        //    }

        //    return new PagedResultDto<GetStatusOfSubmittedQuoteForViewDto>(
        //        totalCount,
        //        results
        //    );

        //}

        public async Task<CreateOrEditProjectStatusOfSubmittedQuoteDto> GetStatusOfSubmittedQuoteForView(long id)
        {
            var statusOfSubmittedQuote = _statusOfSubmittedQuoteRepository.GetAllIncluding(x => x.ProjectFk).Where(x => x.ProjectId == id && x.ProjectQuoteFormId == x.ProjectFk.ProjectQuoteFormId).FirstOrDefault();

            if (statusOfSubmittedQuote != null)
            {
                var quoteMeta = _lookup_quoteRepository.GetAll().Where(x => x.ProjectStatusOfSubmittedQuoteId == statusOfSubmittedQuote.Id).FirstOrDefault();

                var output = ObjectMapper.Map<CreateOrEditProjectStatusOfSubmittedQuoteDto>(statusOfSubmittedQuote);
                try
                {
                    output.QuoteMeta = ObjectMapper.Map<QuoteMetaDto>(quoteMeta);
                }
                catch (Exception e)
                {

                    throw;
                }
                //if (output.StatusOfSubmittedQuote.OrganizationUnitId != null)
                //{
                //    var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.StatusOfSubmittedQuote.OrganizationUnitId);
                //    output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
                //}

                if (output.ProjectId != null)
                {
                    var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectId);
                    output.ProjectName = _lookupProject?.ProjectName?.ToString();
                }

                if (output.CorrespondingUserId != null)
                {
                    var _lookupUser = await _lookup_userRepository.FirstOrDefaultAsync((long)output.CorrespondingUserId);
                    output.UserName = _lookupUser?.Name?.ToString();
                }

                if (output.CorrespondingRoleId != null)
                {
                    var _lookupRole = await _lookup_roleRepository.FirstOrDefaultAsync((int)output.CorrespondingRoleId);
                    output.RoleName = _lookupRole?.Name?.ToString();
                }

                return output;
            }
            return new CreateOrEditProjectStatusOfSubmittedQuoteDto();
        }

        [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes_Edit)]
        public async Task<CreateOrEditProjectStatusOfSubmittedQuoteDto> GetStatusOfSubmittedQuoteForEdit(EntityDto<long> input)
        {
            var statusOfSubmittedQuote = await _statusOfSubmittedQuoteRepository.FirstOrDefaultAsync(input.Id);
            var quoteMeta = _lookup_quoteRepository.GetAll().Where(x => x.ProjectStatusOfSubmittedQuoteId == input.Id);
            var output = ObjectMapper.Map<CreateOrEditProjectStatusOfSubmittedQuoteDto>(statusOfSubmittedQuote);
            output.QuoteMeta = ObjectMapper.Map<QuoteMetaDto>(quoteMeta);
            //if (output.StatusOfSubmittedQuote.OrganizationUnitId != null)
            //{
            //    var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.StatusOfSubmittedQuote.OrganizationUnitId);
            //    output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            //}

            if (output.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectId);
                output.ProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.CorrespondingUserId != null)
            {
                var _lookupUser = await _lookup_userRepository.FirstOrDefaultAsync((long)output.CorrespondingUserId);
                output.UserName = _lookupUser?.Name?.ToString();
            }

            if (output.CorrespondingRoleId != null)
            {
                var _lookupRole = await _lookup_roleRepository.FirstOrDefaultAsync((int)output.CorrespondingRoleId);
                output.RoleName = _lookupRole?.Name?.ToString();
            }

            return output;
        }

        public async Task<GetProjectForViewDto> CreateOrEdit(string data, ICollection<IFormFile> files, ICollection<IFormFile> filesEvidence)
        {
            var input = JsonConvert.DeserializeObject<CreateOrEditProjectStatusOfSubmittedQuoteDto>(data);
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = (long)input.ProjectId
            });
            if (!check)
            {
                throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            }
            var project = _projectRepository.FirstOrDefault(x => x.Id == input.ProjectId);
            input.ProjectQuoteFormId = project.ProjectQuoteFormId;

            GetProjectForViewDto result = new GetProjectForViewDto();
            result.StatusOfSubmittedQuotes = new List<CreateOrEditProjectStatusOfSubmittedQuoteDto>();
            await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        var statusOfSubmittedQuoteDetails = new CreateOrEditProjectStatusOfSubmittedQuoteDto();
                        if (input.Id == null)
                        {
                            statusOfSubmittedQuoteDetails = await Create(input);
                        }
                        else
                        {
                            statusOfSubmittedQuoteDetails = await Update(input);
                        }
                        if (files != null && files.Count > 0)
                        {
                            List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                            foreach (var item in files.Select((value, index) => new { value, index }))
                            {
                                projectFilesInput.Add(new ProjectFileInput()
                                {
                                    File = item.value,
                                    ProjectId = (long)input.ProjectId,
                                    TaskId = CNodeTasks.PrepareQuote,
                                    //MetaData = JsonConvert.SerializeObject(inputAttachRef[item.index])
                                    MetaData = "Customer Commitment"
                                }); ;
                            }
                            foreach (var item in filesEvidence.Select((value, index) => new { value, index }))
                            {
                                projectFilesInput.Add(new ProjectFileInput()
                                {
                                    File = item.value,
                                    ProjectId = (long)input.ProjectId,
                                    TaskId = CNodeTasks.PrepareQuote,
                                    //MetaData = JsonConvert.SerializeObject(inputAttachRef[item.index])
                                    MetaData = "Order Acknowledgement & Submission Evidence"
                                }); ;
                            }
                            if (projectFilesInput.Count > 0)
                            {
                                var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                            }
                        }
                        //if (filesEvidence != null && filesEvidence.Count > 0)
                        //{
                        //    foreach (var file in filesEvidence)
                        //    {
                        //        //await _utilsAppService.UploadSection(file, (long)input.ProjectId, CNodeTasks.StatusofSubmittedQuote, "Order Acknowledgement & Submission Evidence");
                        //    }
                        //}
                        var project = _lookup_projectRepository.FirstOrDefault((long)input.ProjectId);
                        await EventBus.TriggerAsync(new EditProjectEventData()
                        {
                            Project = project,
                            StageId = CNodeStages.PreOrder,
                            TaskId = CNodeTasks.StatusofSubmittedQuote,
                            StatusId = input.StatusId,
                            LoggedInUserId = (long)AbpSession.UserId,
                            Comment = input.Comment,
                            TaskValue = input.StatusOfSubmitQuoteValue
                        });
                        result.Project = ObjectMapper.Map<ProjectDto>(project);
                        result.StatusOfSubmittedQuote = statusOfSubmittedQuoteDetails;
                    }
                }
            });
            return result;

        }

        [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes_Create)]
        protected virtual async Task<CreateOrEditProjectStatusOfSubmittedQuoteDto> Create(CreateOrEditProjectStatusOfSubmittedQuoteDto input)
        {
            try
            {
                var statusOfSubmittedQuote = ObjectMapper.Map<ProjectStatusOfSubmittedQuote>(input);

                if (AbpSession.TenantId != null)
                {
                    statusOfSubmittedQuote.TenantId = (int?)AbpSession.TenantId;
                    input.QuoteMeta.TenantId = (int?)AbpSession.TenantId;
                }
                //input.QuoteMeta.StatusOfSubmittedQuoteId = statusOfSubmittedQuote.id
                if (input.StatusOfSubmitQuoteValue == CStatusOfSubmittedQuotes.CUSTOMER_COMMEITMENT_RECEIVED)
                {
                    var user = new User();
                    var role = new Role();
                    if (input.QuoteMeta.CorrespondingUserId != null)
                    {
                        user = _lookup_userRepository.Get((long)input.QuoteMeta.CorrespondingUserId);
                    }
                    if (input.QuoteMeta.CorrespondingRoleId != null)
                    {
                        role = _lookup_roleRepository.Get((int)input.QuoteMeta.CorrespondingRoleId);
                    }
                    try
                    {

                        var quote = ObjectMapper.Map<ProjectQuoteMeta>(input.QuoteMeta);
                        var id = _statusOfSubmittedQuoteRepository.InsertAndGetId(statusOfSubmittedQuote);
                        quote.ProjectStatusOfSubmittedQuoteId = id;
                        quote.CorrespondWithName = user.Name;
                        quote.CorrespondWithRole = role.DisplayName;
                        var quoteId = _lookup_quoteRepository.InsertAndGetId(quote);

                        var output = ObjectMapper.Map<CreateOrEditProjectStatusOfSubmittedQuoteDto>(_statusOfSubmittedQuoteRepository.Get(id));
                        return output;
                    }
                    catch (Exception e)
                    {

                        throw;
                    }
                    //var quoteReturn = ObjectMapper.Map<QuoteMetaDto>(_lookup_quoteRepository.Get(quoteId));
                    //output.QuoteMeta = quoteReturn;

                }
                else
                {
                    var id = _statusOfSubmittedQuoteRepository.InsertAndGetId(statusOfSubmittedQuote);
                    var output = ObjectMapper.Map<CreateOrEditProjectStatusOfSubmittedQuoteDto>(_statusOfSubmittedQuoteRepository.Get(id));
                    return output;
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes_Edit)]
        protected virtual async Task<CreateOrEditProjectStatusOfSubmittedQuoteDto> Update(CreateOrEditProjectStatusOfSubmittedQuoteDto input)
        {
            if (AbpSession.TenantId != null)
            {
                input.TenantId = (int?)AbpSession.TenantId;
                input.QuoteMeta.TenantId = (int?)AbpSession.TenantId;
            }
            var statusOfSubmittedQuote = await _statusOfSubmittedQuoteRepository.FirstOrDefaultAsync((long)input.Id);
            if (input.StatusOfSubmitQuoteValue == CStatusOfSubmittedQuotes.CUSTOMER_COMMEITMENT_RECEIVED)
            {
                ObjectMapper.Map(input, statusOfSubmittedQuote);

                var output = ObjectMapper.Map<CreateOrEditProjectStatusOfSubmittedQuoteDto>(_statusOfSubmittedQuoteRepository.Get((long)input.Id));
                if (input.QuoteMeta.Id != null)
                {
                    var user = new User();
                    var role = new Role();
                    if (input.QuoteMeta.CorrespondingUserId != null)
                    {
                        user = _lookup_userRepository.Get((long)input.QuoteMeta.CorrespondingUserId);
                    }
                    if (input.QuoteMeta.CorrespondingRoleId != null)
                    {
                        role = _lookup_roleRepository.Get((int)input.QuoteMeta.CorrespondingRoleId);
                    }
                    var quote = await _lookup_quoteRepository.FirstOrDefaultAsync((long)input.QuoteMeta.Id);
                    ObjectMapper.Map(input.QuoteMeta, quote);
                    quote.CorrespondWithName = user.Name;
                    quote.CorrespondWithRole = role.DisplayName;
                    var quoteReturn = ObjectMapper.Map<QuoteMetaDto>(_lookup_quoteRepository.Get((long)input.QuoteMeta.Id));
                    output.QuoteMeta = quoteReturn;

                }
                if (input.QuoteMeta.Id == null)
                {
                    var quote = ObjectMapper.Map<ProjectQuoteMeta>(input.QuoteMeta);
                    quote.ProjectStatusOfSubmittedQuoteId = input.Id;
                    var quoteId = _lookup_quoteRepository.InsertAndGetId(quote);
                    var quoteReturn = ObjectMapper.Map<QuoteMetaDto>(_lookup_quoteRepository.Get(quoteId));
                    output.QuoteMeta = quoteReturn;

                }
                return output;
            }
            else
            {
                ObjectMapper.Map(input, statusOfSubmittedQuote);
                var output = ObjectMapper.Map<CreateOrEditProjectStatusOfSubmittedQuoteDto>(_statusOfSubmittedQuoteRepository.Get((long)input.Id));
                return output;
            }
        }

        [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes_Delete)]
        public async System.Threading.Tasks.Task Delete(EntityDto<long> input)
        {
            var statusOfSubmittedQuote = await _statusOfSubmittedQuoteRepository.FirstOrDefaultAsync((long)input.Id);
            //var quoteMeta = _lookup_quoteRepository.GetAll().Where(x => x.StatusOfSubmittedQuoteId == input.Id);
            var quote = _lookup_quoteRepository.GetAll().Where(x => x.ProjectStatusOfSubmittedQuoteId == statusOfSubmittedQuote.Id);
            var quote2 = ObjectMapper.Map<QuoteMetaDto>(quote);

            await _lookup_quoteRepository.DeleteAsync((long)quote2.Id);
            await _statusOfSubmittedQuoteRepository.DeleteAsync(input.Id);
        }

        //public async Task<FileDto> GetStatusOfSubmittedQuotesToExcel(GetAllStatusOfSubmittedQuotesForExcelInput input)
        //{

        //    var filteredStatusOfSubmittedQuotes = _statusOfSubmittedQuoteRepository.GetAll()
        //                .Include(e => e.OrganizationUnitFk)
        //                .Include(e => e.ProjectFk)
        //                .Include(e => e.CorrespondingUserFk)
        //                .Include(e => e.CorrespondingRoleFk)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.StatusOfQuote.Contains(input.Filter) || e.CustomerCommitmentType.Contains(input.Filter) || e.ProposedOrderNumber.Contains(input.Filter) || e.ReceiptMethod.Contains(input.Filter) || e.CreditReason.Contains(input.Filter) || e.Company.Contains(input.Filter) || e.Address.Contains(input.Filter) || e.AttentionOf.Contains(input.Filter) || e.Subject.Contains(input.Filter) || e.ScopeOfWorks.Contains(input.Filter) || e.AdviseToClient.Contains(input.Filter) || e.CorrespondingEmail.Contains(input.Filter) || e.PostalCode.Contains(input.Filter))
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.StatusOfQuoteFilter), e => e.StatusOfQuote == input.StatusOfQuoteFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerCommitmentTypeFilter), e => e.CustomerCommitmentType == input.CustomerCommitmentTypeFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProposedOrderNumberFilter), e => e.ProposedOrderNumber == input.ProposedOrderNumberFilter)
        //                .WhereIf(input.MinValueOfCommitmentFilter != null, e => e.ValueOfCommitment >= input.MinValueOfCommitmentFilter)
        //                .WhereIf(input.MaxValueOfCommitmentFilter != null, e => e.ValueOfCommitment <= input.MaxValueOfCommitmentFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ReceiptMethodFilter), e => e.ReceiptMethod == input.ReceiptMethodFilter)
        //                .WhereIf(input.MinReceiptDateFilter != null, e => e.ReceiptDate >= input.MinReceiptDateFilter)
        //                .WhereIf(input.MaxReceiptDateFilter != null, e => e.ReceiptDate <= input.MaxReceiptDateFilter)
        //                .WhereIf(input.CustomerCreditWorthyFilter.HasValue && input.CustomerCreditWorthyFilter > -1, e => (input.CustomerCreditWorthyFilter == 1 && e.CustomerCreditWorthy) || (input.CustomerCreditWorthyFilter == 0 && !e.CustomerCreditWorthy))
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CreditReasonFilter), e => e.CreditReason == input.CreditReasonFilter)
        //                .WhereIf(input.MinOALetterGenerationDateFilter != null, e => e.OALetterGenerationDate >= input.MinOALetterGenerationDateFilter)
        //                .WhereIf(input.MaxOALetterGenerationDateFilter != null, e => e.OALetterGenerationDate <= input.MaxOALetterGenerationDateFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CompanyFilter), e => e.Company == input.CompanyFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.AddressFilter), e => e.Address == input.AddressFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.AttentionOfFilter), e => e.AttentionOf == input.AttentionOfFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.SubjectFilter), e => e.Subject == input.SubjectFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ScopeOfWorksFilter), e => e.ScopeOfWorks == input.ScopeOfWorksFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.AdviseToClientFilter), e => e.AdviseToClient == input.AdviseToClientFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CorrespondingEmailFilter), e => e.CorrespondingEmail == input.CorrespondingEmailFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.PostalCodeFilter), e => e.PostalCode == input.PostalCodeFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.UserNameFilter), e => e.CorrespondingUserFk != null && e.CorrespondingUserFk.Name == input.UserNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.RoleNameFilter), e => e.CorrespondingRoleFk != null && e.CorrespondingRoleFk.Name == input.RoleNameFilter);

        //    var query = (from o in filteredStatusOfSubmittedQuotes
        //                 join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
        //                 from s1 in j1.DefaultIfEmpty()

        //                 join o2 in _lookup_projectRepository.GetAll() on o.ProjectId equals o2.Id into j2
        //                 from s2 in j2.DefaultIfEmpty()

        //                 join o3 in _lookup_userRepository.GetAll() on o.CorrespondingUserId equals o3.Id into j3
        //                 from s3 in j3.DefaultIfEmpty()

        //                 join o4 in _lookup_roleRepository.GetAll() on o.CorrespondingRoleId equals o4.Id into j4
        //                 from s4 in j4.DefaultIfEmpty()

        //                 select new GetStatusOfSubmittedQuoteForViewDto()
        //                 {
        //                     StatusOfSubmittedQuote = new StatusOfSubmittedQuoteDto
        //                     {
        //                         StatusOfQuote = o.StatusOfQuote,
        //                         CustomerCommitmentType = o.CustomerCommitmentType,
        //                         ProposedOrderNumber = o.ProposedOrderNumber,
        //                         ValueOfCommitment = o.ValueOfCommitment,
        //                         ReceiptMethod = o.ReceiptMethod,
        //                         ReceiptDate = o.ReceiptDate,
        //                         CustomerCreditWorthy = o.CustomerCreditWorthy,
        //                         CreditReason = o.CreditReason,
        //                         OALetterGenerationDate = o.OALetterGenerationDate,
        //                         Company = o.Company,
        //                         Address = o.Address,
        //                         AttentionOf = o.AttentionOf,
        //                         Subject = o.Subject,
        //                         ScopeOfWorks = o.ScopeOfWorks,
        //                         AdviseToClient = o.AdviseToClient,
        //                         CorrespondingEmail = o.CorrespondingEmail,
        //                         PostalCode = o.PostalCode,
        //                         Id = o.Id
        //                     },
        //                     OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
        //                     ProjectProjectName = s2 == null || s2.ProjectName == null ? "" : s2.ProjectName.ToString(),
        //                     UserName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
        //                     RoleName = s4 == null || s4.Name == null ? "" : s4.Name.ToString()
        //                 });

        //    var statusOfSubmittedQuoteListDtos = await query.ToListAsync();

        //    return _statusOfSubmittedQuotesExcelExporter.ExportToFile(statusOfSubmittedQuoteListDtos);
        //}
        public void SendEMail(string formData)
        {
            using (System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage())
            {
                mail.From = new MailAddress("vraj.s@quadwave.com");
                mail.To.Add("vraj.s@quadwave.com");
                mail.Subject = "Customer Commitment Received";
                mail.Body = "<h1>Dear Customer, Please Find Your Commitment Received Document</h1>";
                mail.IsBodyHtml = true;
                var contentPath = Path.Combine(_env.WebRootPath, "template\\StatusOfSubmittedQuote\\FinalGenerated\\FinalGenerated.docx");
                Attachment data = new Attachment(contentPath, MediaTypeNames.Application.Octet);
                mail.Attachments.Add(data);

                //mailMessage.Attachments.Add(data);

                using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                {
                    smtp.Credentials = new NetworkCredential("vraj.s@quadwave.com", "ct##123456");
                    smtp.EnableSsl = true;
                    smtp.Send(mail);
                }
            }
        }
        public async Task<string> PreViewDoc(int id, string templateName, string formData)
        {
            WordDocument document = new WordDocument();

            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            try
            {
                var submitQuoteData = JsonConvert.DeserializeObject<CreateOrEditProjectStatusOfSubmittedQuoteDto>(formData);
                var ProjectInfo = await _projectRepository.FirstOrDefaultAsync(id);

                var QuoteInfo = _projectQuoteFormRepository.GetAll().Where(x => x.Id == submitQuoteData.ProjectQuoteFormId).ToList();

                if (templateName == "StatusOfSubmittedQuote")
                {
                    var date = DateTime.Now;
                    //Opens the input Word document.
                    string targetFilePath = Path.Combine(_env.WebRootPath, "template\\StatusOfSubmittedQuote\\StatusOfSubmitQuote_template.docx");
                    FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    document = new WordDocument(fileStreamPath, FormatType.Docx);

                    document.Replace("<<ReceiptDate>>", submitQuoteData.ReceiptDate.ToString(), true, true);
                    document.Replace("<<Date>>", submitQuoteData.QuoteMeta.EntryDate.ToString(), true, true);
                    document.Replace("<<QuoteRefNo>>", QuoteInfo[0].QRN, true, true);
                    document.Replace("<<Company>>", submitQuoteData.QuoteMeta.CustomerName, true, true);
                    document.Replace("<<Address>>", submitQuoteData.QuoteMeta.Address1, true, true);
                    document.Replace("<<PostalCode>>", submitQuoteData.QuoteMeta.PostalCode, true, true);
                    document.Replace("<<ReciptMethod>>", submitQuoteData.ReceiptMethod != null ? submitQuoteData.ReceiptMethod : "", true, true);
                    document.Replace("<<ProjectName>>", ProjectInfo.ProjectName, true, true);
                    document.Replace("<<ScopeOfWorks>>", submitQuoteData.QuoteMeta.ScopeOfWorks, true, true);
                    document.Replace("<<ProposedOrderNo>>", submitQuoteData.ProposedOrderNumber, true, true);
                    document.Replace("<<Subject>>", submitQuoteData.QuoteMeta.Subject != null ? submitQuoteData.QuoteMeta.Subject : "", true, true);
                    document.Replace("<<SiteName>>", submitQuoteData.QuoteMeta.ProposedWorks != null ? submitQuoteData.QuoteMeta.ProposedWorks : "", true, true);
                    document.Replace("<<WeWillAdviseYou>>", submitQuoteData.QuoteMeta.WeWillAdviseYou != null ? submitQuoteData.QuoteMeta.WeWillAdviseYou : "", true, true);
                    //document.Replace("<<OrganizationName>>", submitQuoteData.QuoteMeta.WeWillAdviseYou, true, true);
                    document.Replace("<<QuotedDate>>", submitQuoteData.QuoteMeta.QuotedDate.ToString(), true, true);
                    document.Replace("<<AttentionOf>>", submitQuoteData.QuoteMeta.AttentionOf, true, true);
                    document.Replace("<<SellValue>>", submitQuoteData.ValueOfCommitment.ToString(), true, true);
                    document.Replace("<<UserName>>", submitQuoteData.QuoteMeta.CorrespondWithName != null ? submitQuoteData.QuoteMeta.CorrespondWithName : "", true, true);
                    document.Replace("<<UserEmail>>", submitQuoteData.QuoteMeta.CorrespondWithEmail != null ? submitQuoteData.QuoteMeta.CorrespondWithEmail : "", true, true);
                    //string json = "";
                    //using (WebClient client = new WebClient())
                    //{
                    //    json = JsonConvert.SerializeObject(document, Formatting.Indented,
                    //     new JsonSerializerSettings
                    //        {
                    //             ReferenceLoopHandling = ReferenceLoopHandling.Serialize
                    //        });
                    //    //json = Newtonsoft.Json.JsonConvert.SerializeObject(document);
                    //}
                    //document.Dispose();
                    //stream.Dispose();
                    string targetFilePath2 = Path.Combine(_env.WebRootPath, "template\\StatusOfSubmittedQuote\\FinalGenerated\\FinalGenerated.docx");
                    string pdfPath = Path.Combine(_env.WebRootPath, "template\\StatusOfSubmittedQuote\\FinalGenerated\\final.pdf");
                    if (File.Exists(targetFilePath2))
                    {
                        File.Delete(targetFilePath2);
                    }
                    if (File.Exists(pdfPath))
                    {
                        File.Delete(pdfPath);
                    }
                    fileStreamPath = System.IO.File.Create(targetFilePath2);
                    document.Save(fileStreamPath, FormatType.Docx);
                    //WordDocument wordDocument = new WordDocument();
                    //Add a section & a paragraph in the empty document.

                    //Create instance for DocIORenderer for Word to PDF conversion
                    DocIORenderer render = new DocIORenderer();
                    //Converts Word document to PDF.
                    PdfDocument pdfDocument = render.ConvertToPDF(document);
                    //Release the resources used by the Word document and DocIO Renderer objects.
                    render.Dispose();
                    document.Dispose();
                    //Saves the PDF file.
                    FileStream outputStream = new FileStream(pdfPath, FileMode.CreateNew, FileAccess.Write);
                    pdfDocument.Save(outputStream);
                    //Closes the instance of PDF document object.
                    pdfDocument.Close();
                    //Dispose the instance of FileStream.
                    outputStream.Dispose();
                    fileStreamPath.Dispose();
                    byte[] bytes = File.ReadAllBytes(pdfPath);
                    string docBase64 = "data: application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + Convert.ToBase64String(bytes);
                    return docBase64;

                }
            }
            catch (Exception e)
            {

                throw;
            }
            return "";
        }

        //[AcceptVerbs("Post")]
        //public string ImportFileURL([FromBody] FileUrlInfo param)
        //{
        //    try
        //    {
        //        using (WebClient client = new WebClient())
        //        {
        //            MemoryStream stream = new MemoryStream(client.DownloadData(param.fileUrl));
        //            WordDocument document = WordDocument.Load(stream, FormatType.Docx);
        //            string json = Newtonsoft.Json.JsonConvert.SerializeObject(document);
        //            document.Dispose();
        //            stream.Dispose();
        //            return json;
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        return "";
        //    }
        //}
        public class FileUrlInfo
        {
            public string fileUrl { get; set; }
            public string Content { get; set; }
        }
        public async Task<string> GenerateDocument(int id, string templateName, string formData)
        {
            try
            {
                var submitQuoteData = JsonConvert.DeserializeObject<CreateOrEditProjectStatusOfSubmittedQuoteDto>(formData);
                var ProjectInfo = await _projectRepository.FirstOrDefaultAsync(id);

                var QuoteInfo = _projectQuoteFormRepository.GetAll().Where(x => x.Id == ProjectInfo.ProjectQuoteFormId).ToList();

                if (templateName == "StatusOfSubmittedQuote")
                {
                    var date = DateTime.Now;

                    //Opens the input Word document.
                    string targetFilePath = Path.Combine(_env.WebRootPath, "template\\StatusOfSubmittedQuote\\StatusOfSubmitQuote_template.docx");
                    FileStream fileStreamPath = new FileStream(targetFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    //FileStream fileStreamPath = new FileStream(filename, FileMode.Open, FileAccess.Read);
                    WordDocument document = new WordDocument(fileStreamPath, FormatType.Docx);

                    document.Open(fileStreamPath, FormatType.Docx);
                    fileStreamPath.Dispose();

                    //DateTime dt = DateTime.ParseExact(submitQuoteData.QuoteMeta.EntryDate.ToString(), "dd/MM/yyyy", null);
                    //string entryDate = dt.ToString("dd/M/yyyy", CultureInfo.InvariantCulture);

                    //DateTime dt2 = DateTime.ParseExact(submitQuoteData.ReceiptDate.ToString(), "MM/dd/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                    //string reciptDate = dt2.ToString("dd/M/yyyy", CultureInfo.InvariantCulture);

                    //DateTime dt3 = DateTime.ParseExact(submitQuoteData.QuoteMeta.QuotedDate.ToString(), "MM/dd/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                    //string quotedDate = dt3.ToString("dd/M/yyyy", CultureInfo.InvariantCulture);

                    document.Replace("<<ReceiptDate>>", submitQuoteData.ReceiptDate.ToString(), true, true);
                    document.Replace("<<Date>>", submitQuoteData.QuoteMeta.EntryDate.ToString(), true, true);
                    document.Replace("<<QuoteRefNo>>", QuoteInfo[0].QRN, true, true);
                    document.Replace("<<Company>>", submitQuoteData.QuoteMeta.CustomerName, true, true);
                    document.Replace("<<Address>>", submitQuoteData.QuoteMeta.Address1, true, true);
                    document.Replace("<<PostalCode>>", submitQuoteData.QuoteMeta.PostalCode, true, true);
                    document.Replace("<<ReciptMethod>>", submitQuoteData.ReceiptMethod != null ? submitQuoteData.ReceiptMethod : "", true, true);
                    document.Replace("<<ProjectName>>", ProjectInfo.ProjectName, true, true);
                    document.Replace("<<ScopeOfWorks>>", submitQuoteData.QuoteMeta.ScopeOfWorks, true, true);
                    document.Replace("<<ProposedOrderNo>>", submitQuoteData.ProposedOrderNumber, true, true);
                    document.Replace("<<Subject>>", submitQuoteData.QuoteMeta.Subject != null ? submitQuoteData.QuoteMeta.Subject : "", true, true);
                    document.Replace("<<SiteName>>", submitQuoteData.QuoteMeta.ProposedWorks != null ? submitQuoteData.QuoteMeta.ProposedWorks : "", true, true);
                    document.Replace("<<WeWillAdviseYou>>", submitQuoteData.QuoteMeta.WeWillAdviseYou != null ? submitQuoteData.QuoteMeta.WeWillAdviseYou : "", true, true);
                    //document.Replace("<<OrganizationName>>", submitQuoteData.QuoteMeta.WeWillAdviseYou, true, true);
                    document.Replace("<<QuotedDate>>", submitQuoteData.QuoteMeta.QuotedDate.ToString(), true, true);
                    document.Replace("<<AttentionOf>>", submitQuoteData.QuoteMeta.AttentionOf, true, true);
                    document.Replace("<<SellValue>>", submitQuoteData.ValueOfCommitment.ToString(), true, true);
                    document.Replace("<<UserName>>", submitQuoteData.QuoteMeta.CorrespondWithName != null ? submitQuoteData.QuoteMeta.CorrespondWithName : "", true, true);
                    document.Replace("<<UserEmail>>", submitQuoteData.QuoteMeta.CorrespondWithEmail != null ? submitQuoteData.QuoteMeta.CorrespondWithEmail : "", true, true);

                    string targetFilePath2 = Path.Combine(_env.WebRootPath, "template\\StatusOfSubmittedQuote\\FinalGenerated\\FinalGenerated.docx");
                    if (!Directory.Exists(targetFilePath))
                    {
                        Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "Temp\\bidinfo"));
                    }

                    fileStreamPath = System.IO.File.Create(targetFilePath2);
                    document.Save(fileStreamPath, FormatType.Docx);

                    fileStreamPath.Dispose();

                    byte[] bytes = File.ReadAllBytes(targetFilePath2);
                    string docBase64 = "data: application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + Convert.ToBase64String(bytes);
                    return docBase64;
                }
            }
            catch (Exception e)
            {

                throw;
            }
            return "";
        }
        [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes)]
        public async Task<List<StatusOfSubmittedQuoteOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new StatusOfSubmittedQuoteOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes)]
        public async Task<List<StatusOfSubmittedQuoteProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new StatusOfSubmittedQuoteProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes)]
        public async Task<List<StatusOfSubmittedQuoteUserLookupTableDto>> GetAllUserForTableDropdown()
        {
            return await _lookup_userRepository.GetAll()
                .Select(user => new StatusOfSubmittedQuoteUserLookupTableDto
                {
                    Id = user.Id,
                    DisplayName = user == null || user.Name == null ? "" : user.Name.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_StatusOfSubmittedQuotes)]
        public async Task<List<StatusOfSubmittedQuoteRoleLookupTableDto>> GetAllRoleForTableDropdown()
        {
            return await _lookup_roleRepository.GetAll()
                .Select(role => new StatusOfSubmittedQuoteRoleLookupTableDto
                {
                    Id = role.Id,
                    DisplayName = role == null || role.Name == null ? "" : role.Name.ToString()
                }).ToListAsync();
        }

        public Task<string> GetDocument(int id, string templateName, object formData)
        {
            throw new NotImplementedException();
        }
    }
}