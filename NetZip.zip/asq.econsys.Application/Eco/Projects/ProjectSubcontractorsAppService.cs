﻿using asq.econsys.Eco.Projects;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectSubcontractors)]
    public class ProjectSubcontractorsAppService : econsysAppServiceBase, IProjectSubcontractorsAppService
    {
        private readonly IRepository<ProjectSubcontractor, long> _projectSubcontractorRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectExReviewDetail, long> _lookup_projectExReviewDetailRepository;

        public ProjectSubcontractorsAppService(IRepository<ProjectSubcontractor, long> projectSubcontractorRepository, IRepository<Project, long> lookup_projectRepository, IRepository<ProjectExReviewDetail, long> lookup_projectExReviewDetailRepository)
        {
            _projectSubcontractorRepository = projectSubcontractorRepository;
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectExReviewDetailRepository = lookup_projectExReviewDetailRepository;

        }

        public async Task<PagedResultDto<GetProjectSubcontractorForViewDto>> GetAll(GetAllProjectSubcontractorsInput input)
        {

            var filteredProjectSubcontractors = _projectSubcontractorRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.ProjectExReviewDetailFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.SubContractTask.Contains(input.Filter) || e.Name.Contains(input.Filter) || e.Comment.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SubContractTaskFilter), e => e.SubContractTask == input.SubContractTaskFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(input.MinRequiredByFilter != null, e => e.RequiredBy >= input.MinRequiredByFilter)
                        .WhereIf(input.MaxRequiredByFilter != null, e => e.RequiredBy <= input.MaxRequiredByFilter)
                        .WhereIf(input.MinApproxValueFilter != null, e => e.ApproxValue >= input.MinApproxValueFilter)
                        .WhereIf(input.MaxApproxValueFilter != null, e => e.ApproxValue <= input.MaxApproxValueFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CommentFilter), e => e.Comment == input.CommentFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectExReviewDetailTitleFilter), e => e.ProjectExReviewDetailFk != null && e.ProjectExReviewDetailFk.Title == input.ProjectExReviewDetailTitleFilter);

            var pagedAndFilteredProjectSubcontractors = filteredProjectSubcontractors
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectSubcontractors = from o in pagedAndFilteredProjectSubcontractors
                                        join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
                                        from s1 in j1.DefaultIfEmpty()

                                        join o2 in _lookup_projectExReviewDetailRepository.GetAll() on o.ProjectExReviewDetailId equals o2.Id into j2
                                        from s2 in j2.DefaultIfEmpty()

                                        select new
                                        {

                                            o.SubContractTask,
                                            o.Name,
                                            o.RequiredBy,
                                            o.ApproxValue,
                                            o.Comment,
                                            Id = o.Id,
                                            ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
                                            ProjectExReviewDetailTitle = s2 == null || s2.Title == null ? "" : s2.Title.ToString()
                                        };

            var totalCount = await filteredProjectSubcontractors.CountAsync();

            var dbList = await projectSubcontractors.ToListAsync();
            var results = new List<GetProjectSubcontractorForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectSubcontractorForViewDto()
                {
                    ProjectSubcontractor = new ProjectSubcontractorDto
                    {

                        SubContractTask = o.SubContractTask,
                        Name = o.Name,
                        RequiredBy = o.RequiredBy,
                        ApproxValue = o.ApproxValue,
                        Comment = o.Comment,
                        Id = o.Id,
                    },
                    ProjectProjectName = o.ProjectProjectName,
                    ProjectExReviewDetailTitle = o.ProjectExReviewDetailTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectSubcontractorForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectSubcontractorForViewDto> GetProjectSubcontractorForView(long id)
        {
            var projectSubcontractor = await _projectSubcontractorRepository.GetAsync(id);

            var output = new GetProjectSubcontractorForViewDto { ProjectSubcontractor = ObjectMapper.Map<ProjectSubcontractorDto>(projectSubcontractor) };

            if (output.ProjectSubcontractor.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectSubcontractor.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectSubcontractor.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectSubcontractor.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSubcontractors_Edit)]
        public async Task<GetProjectSubcontractorForEditOutput> GetProjectSubcontractorForEdit(EntityDto<long> input)
        {
            var projectSubcontractor = await _projectSubcontractorRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectSubcontractorForEditOutput { ProjectSubcontractor = ObjectMapper.Map<CreateOrEditProjectSubcontractorDto>(projectSubcontractor) };

            if (output.ProjectSubcontractor.ProjectId != null)
            {
                var _lookupProject = await _lookup_projectRepository.FirstOrDefaultAsync((long)output.ProjectSubcontractor.ProjectId);
                output.ProjectProjectName = _lookupProject?.ProjectName?.ToString();
            }

            if (output.ProjectSubcontractor.ProjectExReviewDetailId != null)
            {
                var _lookupProjectExReviewDetail = await _lookup_projectExReviewDetailRepository.FirstOrDefaultAsync((long)output.ProjectSubcontractor.ProjectExReviewDetailId);
                output.ProjectExReviewDetailTitle = _lookupProjectExReviewDetail?.Title?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectSubcontractorDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSubcontractors_Create)]
        protected virtual async Task Create(CreateOrEditProjectSubcontractorDto input)
        {
            var projectSubcontractor = ObjectMapper.Map<ProjectSubcontractor>(input);

            if (AbpSession.TenantId != null)
            {
                projectSubcontractor.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectSubcontractorRepository.InsertAsync(projectSubcontractor);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSubcontractors_Edit)]
        protected virtual async Task Update(CreateOrEditProjectSubcontractorDto input)
        {
            var projectSubcontractor = await _projectSubcontractorRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectSubcontractor);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSubcontractors_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectSubcontractorRepository.DeleteAsync(input.Id);
        }
        [AbpAuthorize(AppPermissions.Pages_ProjectSubcontractors)]
        public async Task<List<ProjectSubcontractorProjectLookupTableDto>> GetAllProjectForTableDropdown()
        {
            return await _lookup_projectRepository.GetAll()
                .Select(project => new ProjectSubcontractorProjectLookupTableDto
                {
                    Id = project.Id,
                    DisplayName = project == null || project.ProjectName == null ? "" : project.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSubcontractors)]
        public async Task<List<ProjectSubcontractorProjectExReviewDetailLookupTableDto>> GetAllProjectExReviewDetailForTableDropdown()
        {
            return await _lookup_projectExReviewDetailRepository.GetAll()
                .Select(projectExReviewDetail => new ProjectSubcontractorProjectExReviewDetailLookupTableDto
                {
                    Id = projectExReviewDetail.Id,
                    DisplayName = projectExReviewDetail == null || projectExReviewDetail.Title == null ? "" : projectExReviewDetail.Title.ToString()
                }).ToListAsync();
        }

    }
}