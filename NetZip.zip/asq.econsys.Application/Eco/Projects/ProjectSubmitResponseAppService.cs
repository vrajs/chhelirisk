﻿using asq.econsys.Eco.Projects;
using asq.econsys.Eco.NodeTasks;
using asq.econsys.Eco.Projects;
using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using Abp.Events.Bus;
using asq.econsys.Eco.Utils;
using asq.econsys.Eco.Utils.Storage;
using asq.econsys.Authorization.Users;
using asq.econsys.Eco.Dto;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace asq.econsys.Eco.Projects
{
    public class ProjectSubmitResponseAppService : econsysAppServiceBase, IProjectSubmitResponseAppService
    {
        private readonly IRepository<Project, long> _projectRepository;
        private readonly IRepository<Project, long> _lookup_projectRepository;
        private readonly IRepository<ProjectOAReview, long> _lookup_projectOAReviewRepository;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly IRepository<ProjectStatusOfSubmittedQuote, long> _projectStatusOfSubmittedQuoteRepository;
        private readonly IRepository<ProjectComment, long> _projectCommentRepository;

        private readonly IRepository<ProjectFile, Guid> _repositoryProjectFile;
        private readonly IBlobMethods _blobMethods;
        private readonly IWebHostEnvironment _env;
        private readonly UserManager _userManager;

        public IEventBus EventBus { get; set; }



        public ProjectSubmitResponseAppService(
            IRepository<Project, long> lookup_projectRepository,
            IRepository<ProjectOAReview, long> lookup_projectOAReviewRepository,
            IRepository<Project, long> projectRepository,
            IWebHostEnvironment env,
            IBlobMethods blobMethods,
            IRepository<ProjectFile, Guid> repositoryProjectFile,
            IRepository<ProjectStatusOfSubmittedQuote, long> projectStatusOfSubmittedQuoteRepository,
            IRepository<ProjectComment, long> projectCommentRepository,
            ProjectPermissionManager projectPermissionManager,
            UserManager userManager)
        {
            _lookup_projectRepository = lookup_projectRepository;
            _lookup_projectOAReviewRepository = lookup_projectOAReviewRepository;

            EventBus = NullEventBus.Instance;
            _projectRepository = projectRepository;
            _repositoryProjectFile = repositoryProjectFile;
            _env = env;
            _userManager = userManager;
            _blobMethods = blobMethods;
            _projectPermissionManager = projectPermissionManager;
            _projectStatusOfSubmittedQuoteRepository = projectStatusOfSubmittedQuoteRepository;
            _projectCommentRepository = projectCommentRepository;
        }

        #region Upload File Started

        public async Task<string> DownloadRequestDocument(string azureFileUrl)
        {
            string linkWithToken = await _blobMethods.GenerateAzureSasTokenUrl(new Uri(azureFileUrl));
            return linkWithToken;
        }
        public async Task<string> GetDocument(Guid id)
        {
            try
            {
                ProjectFile projectFile = await _repositoryProjectFile.GetAsync(id);

                var loggedInUser = await _userManager.GetUserByIdAsync((long)AbpSession.UserId);
                bool isAdmin = await _userManager.IsInRoleAsync(loggedInUser, "Admin");
                //if (projectFile.User.Id == (long)AbpSession.UserId || isAdmin)
                //{
                var tenancyName = "stc-econsys";// await GetTenancyNameFromTenantId();
                var container = await _blobMethods.SetUpContainer(tenancyName);
                var blob = await _blobMethods.DownloadToByteArray(container, projectFile.MetaData, projectFile.Name);

                string pdfBase64 = "data:" + projectFile.Extension + ";base64," + Convert.ToBase64String(blob);
                return pdfBase64;
                //}
                //return null;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public async Task<List<ProjectFileDto>> GetProjectFileList(int ProjectId)
        {
            var ProjectListView = await _repositoryProjectFile.GetAll()
                .Where(x => x.ProjectId == ProjectId && x.ParentId == null && x.NodeAction == "uploadObj")
                .Select(projectFile => new ProjectFileDto
                {
                    Id = projectFile.Id,
                    Name = projectFile.Name,
                    FullPath = projectFile.FullPath,
                    Extension = projectFile.Extension
                }).ToListAsync();
            return ProjectListView;
        }
        public async Task<List<ProjectFileDto>> GetProjectFileListTwo(int ProjectId)
        {
            var ProjectListView = await _repositoryProjectFile.GetAll()
                .Where(x => x.ProjectId == ProjectId && x.ParentId == null && x.NodeAction == "uploadObj1")
                .Select(projectFile => new ProjectFileDto
                {
                    Id = projectFile.Id,
                    Name = projectFile.Name,
                    FullPath = projectFile.FullPath,
                    Extension = projectFile.Extension
                }).ToListAsync();
            return ProjectListView;
        }
        public async void UploadFileFromAzure(List<string> fileIdList)
        {
            if (fileIdList.Count > 0)
            {
                foreach (var item in fileIdList)
                {
                    ProjectFile file = _repositoryProjectFile.FirstOrDefault(x => x.Id.ToString() == item);
                    file.ParentId = file.Id;
                    file.Id = Guid.Empty;
                    file.CreationTime = DateTime.Now;
                    file.CreatorUserId = AbpSession.UserId;
                    await _repositoryProjectFile.InsertAsync(file);
                }
            }
        }

        #endregion Upload File End

        public async Task<GetProjectForViewDto> CreateOrEdit(CreateOrEditProjectSubmitResponseDto input)
        {
            var oaSubmitResponse = new GetProjectSubmitResponseForViewDto();
            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.SubmitResponsetoCustomerCommitment,
                StatusId = input.Status,
                Comment = input.Comments,
                LoggedInUserId = (long)AbpSession.UserId,
                ProjectId = input.ProjectId.Value
            });

            project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);
            result.ProjectSubmitResponse = oaSubmitResponse;
            return result;
        }

        public async Task<GetProjectStatusOfSubmittedQuoteForViewDto> GetStatusOfSubmmitedQuoteData(long projectid)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = projectid
            });

            if (!check)
            {
                throw new UserFriendlyException("Access Denied", "You do not have the required role for this project");
            }
            //To Do Check
            var StatusOfSubmittedQuoteDto = await _projectStatusOfSubmittedQuoteRepository.GetAll().Where(x => x.ProjectId == projectid).OrderByDescending(x => x.Id).FirstOrDefaultAsync();

             var output = new GetProjectStatusOfSubmittedQuoteForViewDto { StatusOfSubmittedQuote = ObjectMapper.Map<StatusOfSubmittedQuoteDto>(StatusOfSubmittedQuoteDto) }; 
             return output;

        }
        public async Task<GetProjectCommentForViewDto> GetProjectCommentForView(long id)
        {
            var projectComments = _projectCommentRepository.GetAll().Where(x=>x.ProjectId == (id));

            var output = new GetProjectCommentForViewDto { ProjectComment = ObjectMapper.Map<ProjectCommentDto>(projectComments) };

            if (output.ProjectProjectName != null)
            {
                output.ProjectProjectName = output.ProjectProjectName;
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectSubmitResponse_Create)]
        protected virtual async Task<GetProjectCommentForViewDto> Create(CreateOrEditProjectCommentDto input)
        {
            long projectCommentid = 0;
            input.NodeTaskId = CNodeTasks.SubmitResponsetoCustomerCommitment;
            var projectComment = ObjectMapper.Map<ProjectComment>(input);
            if (AbpSession.TenantId != null)
            {
                projectComment.TenantId = (int?)AbpSession.TenantId;
            }
           
            projectCommentid = await _projectCommentRepository.InsertAndGetIdAsync(projectComment);
            var output = new GetProjectCommentForViewDto { ProjectComment = ObjectMapper.Map<ProjectCommentDto>(_projectCommentRepository.Get(projectCommentid)) };

            return output;
        }

        public async Task<bool> ResetTask(CreateOrEditProjectSubmitResponseDto input)
        {
            
            //To Do Check About
            //var IdDetails = await _projectSubmitResponseRepository.GetAll().Where(x => x.ProjectId == input.ProjectId).OrderByDescending(x => x.Id).FirstOrDefaultAsync();
            //if (IdDetails != null)
            //{
            //    var projectSubmitResponse = await _projectSubmitResponseRepository.FirstOrDefaultAsync((long)IdDetails.Id);
            //    input.LastModifierUserId = (long)AbpSession.UserId;
            //    input.LastModificationTime = DateTime.UtcNow;
            //    ObjectMapper.Map(input, projectSubmitResponse);
            //}
            var project = _lookup_projectRepository.FirstOrDefault(Convert.ToInt64(input.ProjectId));
            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.OrderAcceptance,
                TaskId = CNodeTasks.SubmitResponsetoCustomerCommitment,
                StatusId = input.Status,
                Comment = input.Comments
            });
            return true;
        }

        //public async Task<FileDto> GetProjectSubmitResponsesToExcel(GetAllProjectSubmitResponsesForExcelInput input)
        //{
        //    var filteredProjectSubmitResponses = _projectSubmitResponseRepository.GetAll()
        //                .Include(e => e.ProjectFk)
        //                .Include(e => e.NodeTaskFk)
        //                .Include(e => e.ProjectOAReviewFk)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ResponseText.Contains(input.Filter) || e.Comments.Contains(input.Filter) || e.Status.Contains(input.Filter))
        //                .WhereIf(input.IsRecReqComOfWorkFilter.HasValue && input.IsRecReqComOfWorkFilter > -1, e => (input.IsRecReqComOfWorkFilter == 1 && e.IsRecReqComOfWork == null) || (input.IsRecReqComOfWorkFilter == 0 && !e.IsRecReqComOfWork == null))
        //                .WhereIf(input.IsLimitFinalQuoteFilter.HasValue && input.IsLimitFinalQuoteFilter > -1, e => (input.IsLimitFinalQuoteFilter == 1 && e.IsLimitFinalQuote == null) || (input.IsLimitFinalQuoteFilter == 0 && !e.IsLimitFinalQuote == null))
        //                .WhereIf(input.IsRecImpLimitExpFilter.HasValue && input.IsRecImpLimitExpFilter > -1, e => (input.IsRecImpLimitExpFilter == 1 && e.IsRecImpLimitExp == null) || (input.IsRecImpLimitExpFilter == 0 && !e.IsRecImpLimitExp == null))
        //                .WhereIf(input.MinExpenditureLimitFilter != null, e => e.ExpenditureLimit >= input.MinExpenditureLimitFilter)
        //                .WhereIf(input.MaxExpenditureLimitFilter != null, e => e.ExpenditureLimit <= input.MaxExpenditureLimitFilter)
        //                .WhereIf(input.IsRecimpTimeLimitValidityFilter.HasValue && input.IsRecimpTimeLimitValidityFilter > -1, e => (input.IsRecimpTimeLimitValidityFilter == 1 && e.IsRecimpTimeLimitValidity == null) || (input.IsRecimpTimeLimitValidityFilter == 0 && !e.IsRecimpTimeLimitValidity == null))
        //                .WhereIf(input.MinProposedStartDateFilter != null, e => e.ProposedStartDate >= input.MinProposedStartDateFilter)
        //                .WhereIf(input.MaxProposedStartDateFilter != null, e => e.ProposedStartDate <= input.MaxProposedStartDateFilter)
        //                .WhereIf(input.MinProposedEndDateFilter != null, e => e.ProposedEndDate >= input.MinProposedEndDateFilter)
        //                .WhereIf(input.MaxProposedEndDateFilter != null, e => e.ProposedEndDate <= input.MaxProposedEndDateFilter)
        //                .WhereIf(input.MinProposedStartDateCommitFilter != null, e => e.ProposedStartDateCommit >= input.MinProposedStartDateCommitFilter)
        //                .WhereIf(input.MaxProposedStartDateCommitFilter != null, e => e.ProposedStartDateCommit <= input.MaxProposedStartDateCommitFilter)
        //                .WhereIf(input.MinProposedEndDateCommitFilter != null, e => e.ProposedEndDateCommit >= input.MinProposedEndDateCommitFilter)
        //                .WhereIf(input.MaxProposedEndDateCommitFilter != null, e => e.ProposedEndDateCommit <= input.MaxProposedEndDateCommitFilter)
        //                .WhereIf(input.IsRecOtherItemFurtherReviewFilter.HasValue && input.IsRecOtherItemFurtherReviewFilter > -1, e => (input.IsRecOtherItemFurtherReviewFilter == 1 && e.IsRecOtherItemFurtherReview == null) || (input.IsRecOtherItemFurtherReviewFilter == 0 && !e.IsRecOtherItemFurtherReview == null))
        //                .WhereIf(input.IsIntroTermsConditionFilter.HasValue && input.IsIntroTermsConditionFilter > -1, e => (input.IsIntroTermsConditionFilter == 1 && e.IsIntroTermsCondition == null) || (input.IsIntroTermsConditionFilter == 0 && !e.IsIntroTermsCondition == null))
        //                .WhereIf(input.IsScopeDetClientComFinQuoteScopeFilter.HasValue && input.IsScopeDetClientComFinQuoteScopeFilter > -1, e => (input.IsScopeDetClientComFinQuoteScopeFilter == 1 && e.IsScopeDetClientComFinQuoteScope == null) || (input.IsScopeDetClientComFinQuoteScopeFilter == 0 && !e.IsScopeDetClientComFinQuoteScope == null))
        //                .WhereIf(input.IsDocRefClientComQuoteBaseFilter.HasValue && input.IsDocRefClientComQuoteBaseFilter > -1, e => (input.IsDocRefClientComQuoteBaseFilter == 1 && e.IsDocRefClientComQuoteBase == null) || (input.IsDocRefClientComQuoteBaseFilter == 0 && !e.IsDocRefClientComQuoteBase == null))
        //                .WhereIf(input.IsTermCondComQuoteBasedOnFilter.HasValue && input.IsTermCondComQuoteBasedOnFilter > -1, e => (input.IsTermCondComQuoteBasedOnFilter == 1 && e.IsTermCondComQuoteBasedOn == null) || (input.IsTermCondComQuoteBasedOnFilter == 0 && !e.IsTermCondComQuoteBasedOn == null))
        //                .WhereIf(input.IsHappyCLAsExcKeyTechFinalQuoteFilter.HasValue && input.IsHappyCLAsExcKeyTechFinalQuoteFilter > -1, e => (input.IsHappyCLAsExcKeyTechFinalQuoteFilter == 1 && e.IsHappyCLAsExcKeyTechFinalQuote == null) || (input.IsHappyCLAsExcKeyTechFinalQuoteFilter == 0 && !e.IsHappyCLAsExcKeyTechFinalQuote == null))
        //                .WhereIf(input.MinProposedContractValueFilter != null, e => e.ProposedContractValue >= input.MinProposedContractValueFilter)
        //                .WhereIf(input.MaxProposedContractValueFilter != null, e => e.ProposedContractValue <= input.MaxProposedContractValueFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ResponseTextFilter), e => e.ResponseText == input.ResponseTextFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.CommentsFilter), e => e.Comments == input.CommentsFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.statusFilter), e => e.Status == input.statusFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectProjectNameFilter), e => e.ProjectFk != null && e.ProjectFk.ProjectName == input.ProjectProjectNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.NodeTaskTaskNameFilter), e => e.NodeTaskFk != null && e.NodeTaskFk.TaskName == input.NodeTaskTaskNameFilter)
        //                .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectOAReviewTitleFilter), e => e.ProjectOAReviewFk != null && e.ProjectOAReviewFk.Title == input.ProjectOAReviewTitleFilter);

        //    var query = (from o in filteredProjectSubmitResponses
        //                 join o1 in _lookup_projectRepository.GetAll() on o.ProjectId equals o1.Id into j1
        //                 from s1 in j1.DefaultIfEmpty()

        //                 join o2 in _lookup_nodeTaskRepository.GetAll() on o.NodeTaskId equals o2.Id into j2
        //                 from s2 in j2.DefaultIfEmpty()

        //                 join o3 in _lookup_projectOAReviewRepository.GetAll() on o.ProjectOAReviewId equals o3.Id into j3
        //                 from s3 in j3.DefaultIfEmpty()

        //                 select new GetProjectSubmitResponseForViewDto()
        //                 {
        //                     projectSubmitResponse = new ProjectSubmitResponseDto
        //                     {
        //                         IsRecReqComOfWork = o.IsRecReqComOfWork,
        //                         IsLimitFinalQuote = o.IsLimitFinalQuote,
        //                         IsRecImpLimitExp = o.IsRecImpLimitExp,
        //                         ExpenditureLimit = o.ExpenditureLimit,
        //                         IsRecimpTimeLimitValidity = o.IsRecimpTimeLimitValidity,
        //                         ProposedStartDate = o.ProposedStartDate,
        //                         ProposedEndDate = o.ProposedEndDate,
        //                         ProposedStartDateCommit = o.ProposedStartDateCommit,
        //                         ProposedEndDateCommit = o.ProposedEndDateCommit,
        //                         IsRecOtherItemFurtherReview = o.IsRecOtherItemFurtherReview,
        //                         IsIntroTermsCondition = o.IsIntroTermsCondition,
        //                         IsScopeDetClientComFinQuoteScope = o.IsScopeDetClientComFinQuoteScope,
        //                         IsDocRefClientComQuoteBase = o.IsDocRefClientComQuoteBase,
        //                         IsTermCondComQuoteBasedOn = o.IsTermCondComQuoteBasedOn,
        //                         IsHappyCLAsExcKeyTechFinalQuote = o.IsHappyCLAsExcKeyTechFinalQuote,
        //                         ProposedContractValue = o.ProposedContractValue,
        //                         ResponseText = o.ResponseText,
        //                         Comments = o.Comments,
        //                         status = o.Status,
        //                         Id = o.Id
        //                     },
        //                     ProjectProjectName = s1 == null || s1.ProjectName == null ? "" : s1.ProjectName.ToString(),
        //                     NodeTaskTaskName = s2 == null || s2.TaskName == null ? "" : s2.TaskName.ToString(),
        //                     ProjectOAReviewTitle = s3 == null || s3.Title == null ? "" : s3.Title.ToString()
        //                 });

        //    var projectSubmitResponseListDtos = await query.ToListAsync();

        //    return _projectSubmitResponsesExcelExporter.ExportToFile(projectSubmitResponseListDtos);
        //}

    }
}