﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_Administration_ProjectTypes)]
    public class ProjectTypesAppService : econsysAppServiceBase, IProjectTypesAppService
    {
        private readonly IRepository<ProjectType, string> _projectTypeRepository;
        private readonly IProjectTypesExcelExporter _projectTypesExcelExporter;

        public ProjectTypesAppService(IRepository<ProjectType, string> projectTypeRepository, IProjectTypesExcelExporter projectTypesExcelExporter)
        {
            _projectTypeRepository = projectTypeRepository;
            _projectTypesExcelExporter = projectTypesExcelExporter;

        }
        
        public async Task<PagedResultDto<GetProjectTypeForViewDto>> GetAll(GetAllProjectTypesInput input)
        {

            var filteredProjectTypes = _projectTypeRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Code.Contains(input.Filter) || e.Title.Contains(input.Filter) || e.Description.Contains(input.Filter) || e.HexColor.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CodeFilter), e => e.Code == input.CodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DescriptionFilter), e => e.Description == input.DescriptionFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HexColorFilter), e => e.HexColor == input.HexColorFilter);

            var pagedAndFilteredProjectTypes = filteredProjectTypes
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectTypes = from o in pagedAndFilteredProjectTypes
                               select new
                               {

                                   o.Code,
                                   o.Title,
                                   o.Description,
                                   o.HexColor,
                                   Id = o.Id
                               };

            var totalCount = await filteredProjectTypes.CountAsync();

            var dbList = await projectTypes.ToListAsync();
            var results = new List<GetProjectTypeForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectTypeForViewDto()
                {
                    ProjectType = new ProjectTypeDto
                    {

                        Code = o.Code,
                        Title = o.Title,
                        Description = o.Description,
                        HexColor = o.HexColor,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectTypeForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectTypeForViewDto> GetProjectTypeForView(string id)
        {
            var projectType = await _projectTypeRepository.GetAsync(id);

            var output = new GetProjectTypeForViewDto { ProjectType = ObjectMapper.Map<ProjectTypeDto>(projectType) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_ProjectTypes_Edit)]
        public async Task<GetProjectTypeForEditOutput> GetProjectTypeForEdit(EntityDto<string> input)
        {
            var projectType = await _projectTypeRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectTypeForEditOutput { ProjectType = ObjectMapper.Map<CreateOrEditProjectTypeDto>(projectType) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectTypeDto input)
        {
            if (input.Id.IsNullOrWhiteSpace())
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_ProjectTypes_Create)]
        protected virtual async Task Create(CreateOrEditProjectTypeDto input)
        {
            var projectType = ObjectMapper.Map<ProjectType>(input);

//            if (projectType.Id.IsNullOrWhiteSpace())
//            {
//                projectType.Id = Guid.NewGuid().ToString();
//;           }
            projectType.Id = input.Code.ToUpper();

            await _projectTypeRepository.InsertAsync(projectType);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_ProjectTypes_Edit)]
        protected virtual async Task Update(CreateOrEditProjectTypeDto input)
        {
            var projectType = await _projectTypeRepository.FirstOrDefaultAsync((string)input.Id);
            ObjectMapper.Map(input, projectType);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_ProjectTypes_Delete)]
        public async Task Delete(EntityDto<string> input)
        {
            await _projectTypeRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectTypesToExcel(GetAllProjectTypesForExcelInput input)
        {

            var filteredProjectTypes = _projectTypeRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Code.Contains(input.Filter) || e.Title.Contains(input.Filter) || e.Description.Contains(input.Filter) || e.HexColor.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CodeFilter), e => e.Code == input.CodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DescriptionFilter), e => e.Description == input.DescriptionFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HexColorFilter), e => e.HexColor == input.HexColorFilter);

            var query = (from o in filteredProjectTypes
                         select new GetProjectTypeForViewDto()
                         {
                             ProjectType = new ProjectTypeDto
                             {
                                 Code = o.Code,
                                 Title = o.Title,
                                 Description = o.Description,
                                 HexColor = o.HexColor,
                                 Id = o.Id
                             }
                         });

            var projectTypeListDtos = await query.ToListAsync();

            return _projectTypesExcelExporter.ExportToFile(projectTypeListDtos);
        }

    }
}