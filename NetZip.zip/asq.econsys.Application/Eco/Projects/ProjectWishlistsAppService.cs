﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_ProjectWishlists)]
    public class ProjectWishlistsAppService : econsysAppServiceBase, IProjectWishlistsAppService
    {
        private readonly IRepository<ProjectWishlist, long> _projectWishlistRepository;
        private readonly IProjectWishlistsExcelExporter _projectWishlistsExcelExporter;

        public ProjectWishlistsAppService(IRepository<ProjectWishlist, long> projectWishlistRepository, IProjectWishlistsExcelExporter projectWishlistsExcelExporter)
        {
            _projectWishlistRepository = projectWishlistRepository;
            _projectWishlistsExcelExporter = projectWishlistsExcelExporter;

        }

        public async Task<PagedResultDto<GetProjectWishlistForViewDto>> GetAll(GetAllProjectWishlistsInput input)
        {

            var filteredProjectWishlists = _projectWishlistRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter);

            var pagedAndFilteredProjectWishlists = filteredProjectWishlists
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projectWishlists = from o in pagedAndFilteredProjectWishlists
                                   select new
                                   {

                                       o.Title,
                                       Id = o.Id
                                   };

            var totalCount = await filteredProjectWishlists.CountAsync();

            var dbList = await projectWishlists.ToListAsync();
            var results = new List<GetProjectWishlistForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectWishlistForViewDto()
                {
                    ProjectWishlist = new ProjectWishlistDto
                    {

                        Title = o.Title,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectWishlistForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectWishlistForViewDto> GetProjectWishlistForView(long id)
        {
            var projectWishlist = await _projectWishlistRepository.GetAsync(id);

            var output = new GetProjectWishlistForViewDto { ProjectWishlist = ObjectMapper.Map<ProjectWishlistDto>(projectWishlist) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectWishlists_Edit)]
        public async Task<GetProjectWishlistForEditOutput> GetProjectWishlistForEdit(EntityDto<long> input)
        {
            var projectWishlist = await _projectWishlistRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectWishlistForEditOutput { ProjectWishlist = ObjectMapper.Map<CreateOrEditProjectWishlistDto>(projectWishlist) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditProjectWishlistDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_ProjectWishlists_Create)]
        protected virtual async Task Create(CreateOrEditProjectWishlistDto input)
        {
            var projectWishlist = ObjectMapper.Map<ProjectWishlist>(input);

            if (AbpSession.TenantId != null)
            {
                projectWishlist.TenantId = (int?)AbpSession.TenantId;
            }

            await _projectWishlistRepository.InsertAsync(projectWishlist);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectWishlists_Edit)]
        protected virtual async Task Update(CreateOrEditProjectWishlistDto input)
        {
            var projectWishlist = await _projectWishlistRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, projectWishlist);

        }

        [AbpAuthorize(AppPermissions.Pages_ProjectWishlists_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectWishlistRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetProjectWishlistsToExcel(GetAllProjectWishlistsForExcelInput input)
        {

            var filteredProjectWishlists = _projectWishlistRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Title.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TitleFilter), e => e.Title == input.TitleFilter);

            var query = (from o in filteredProjectWishlists
                         select new GetProjectWishlistForViewDto()
                         {
                             ProjectWishlist = new ProjectWishlistDto
                             {
                                 Title = o.Title,
                                 Id = o.Id
                             }
                         });

            var projectWishlistListDtos = await query.ToListAsync();

            return _projectWishlistsExcelExporter.ExportToFile(projectWishlistListDtos);
        }

    }
}