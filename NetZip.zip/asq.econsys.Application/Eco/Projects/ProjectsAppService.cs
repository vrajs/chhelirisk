﻿using Abp.Organizations;
using asq.econsys.Eco.Customers;
using asq.econsys.Eco.Leads;
using asq.econsys.Eco.Projects;
using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.Projects.Exporting;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.Customers.Dtos;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Eco.BusinessRules;
using Abp.Events.Bus;
using asq.econsys.Eco.Dto;
using Microsoft.AspNetCore.Mvc;
using asq.econsys.Eco.RefNoConfig;
using Abp.Runtime.Session;
using asq.econsys.Eco.Utils.Storage;
using asq.econsys.Authorization.Users;
using asq.econsys.Eco.Utils;
using Abp.Domain.Uow;
using asq.econsys.Eco.NodeTasks;
using asq.econsys.Authorization.Roles;

namespace asq.econsys.Eco.Projects
{
    [AbpAuthorize(AppPermissions.Pages_Projects)]
    public class ProjectsAppService : econsysAppServiceBase, IProjectsAppService
    {
        public IEventBus EventBus { get; set; }
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly WorkflowManager _workflowManager;
        private readonly UserManager _userManager;
        private readonly IRepository<Project, long> _projectRepository;
        private readonly IProjectsExcelExporter _projectsExcelExporter;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IRepository<ContactPerson, long> _lookup_contactPersonRepository;
        private readonly IRepository<Customer, long> _lookup_customerRepository;
        private readonly IRepository<Lead, long> _lookup_leadRepository;
        private readonly IRepository<LeadSource, int> _lookup_leadSourceRepository;
        private readonly IRepository<ProjectSite, long> _lookup_projectSiteRepository;
        private readonly IRepository<ProjectComment, long> _lookup_projectCommentRepository;
        private readonly IRepository<ProjectType, string> _lookup_projectTypeRepository;
        private readonly IRepository<ProjectWishlist, long> _lookup_projectWishlistRepository;
        private readonly IRepository<ProjectEstimate, long> _projectEstimateRepository;
        private readonly IRepository<ProjectEngineering> _projectEngineeringRepository;
        private readonly IRepository<RevenueRange, long> _lookup_revenueRangeRepository;
        private readonly IRepository<RuleElement, long> _lookup_ruleElementRepository;
        private readonly IRepository<RuleValue, long> _lookup_ruleValueRepository;
        private readonly IRepository<ProjectCommercial> _projectCommercialRepository;
        private readonly IRepository<ProjectRule, long> _projectRuleRepository;
        private readonly IRepository<ProjectAction, long> _projectActionRepository;
        private readonly IRepository<ProjectExReview, long> _projectExReviewRepository;
        private readonly IRefNoConfigsAppService _refNoConfigAppservice;
        private readonly IRefNoConfigDetailsAppService _refNoConfigDetailsAppservice;
        private readonly Utils.UtilsAppService _utilsAppService;
        private readonly IRepository<ProjectFile, Guid> _repositoryProjectFile;
        private readonly IRepository<ProjectPersonnel, long> _projectPersonnelRepository;
        private readonly IRepository<ProjectQuoteForm, long> _projectQuoteFormRepository;
        private readonly IRepository<ProjectSalesToOpsHand, long> _projectSalesToOpsHandRepository;
        private readonly IRepository<ProjectOpsConfirOfHand, long> _projectOpsConfirOfHandRepository;
        private readonly IRepository<ProjectMRABPL, long> _ProjectMRABPLRepository;

        //private readonly Projects.ProjectPermissionManager _projectPermissionManager;
        private readonly IRepository<User, long> _userRepository;
        private readonly ProjectPermissionManager _projectPermissionManager;
        private readonly IRepository<NodeStage, string> _nodeStageRepository;
        private readonly IRepository<NodeTask, string> _nodeTaskRepository;
        private readonly IRepository<ProjectQFDelegation, long> _projectQFDelegationRepository;
        private readonly IRepository<RefNoConfig.RefNoConfig, long> _refNoConfigRepository;
        private readonly IRepository<RefNoConfigDetails, long> _refNoConfigDetailsRepository;
        private readonly RefNoConfigManager _refNoConfigManager;
        private readonly IRepository<ProjectStatusOfSubmittedQuote, long> _statusOfSubmittedQuoteRepository;
        private readonly IRepository<ProjectQuoteMeta, long> _lookup_quoteRepository;
        private readonly IRepository<ProjectOACustCommAcceptance, long> _ProjectOACustCommAcceptanceRepository;
        private readonly IRepository<ProjectCommercialTasksPriorCommence, long> _projectCommercialTasksPriorCommenceRepository;

        private readonly RoleManager _roleManager;
        private readonly StorageManager _storageManager;

        public ProjectsAppService(
            IUnitOfWorkManager unitOfWorkManager,
            UserManager userManager,
            IRepository<Project, long> projectRepository,
            IProjectsExcelExporter projectsExcelExporter,
            IRepository<OrganizationUnit, long> lookup_organizationUnitRepository,
            IRepository<ContactPerson, long> lookup_contactPersonRepository,
            IRepository<Customer, long> lookup_customerRepository,
            IRepository<Lead, long> lookup_leadRepository,
            IRepository<LeadSource, int> lookup_leadSourceRepository,
            IRepository<ProjectSite, long> lookup_projectSiteRepository,
            IRepository<ProjectComment, long> lookup_projectCommentRepository,
            IRepository<ProjectType, string> lookup_projectTypeRepository,
            IRepository<ProjectWishlist, long> lookup_projectWishlistRepository,
            IRepository<ProjectEstimate, long> projectEstimateRepository,
            IRepository<ProjectSalesToOpsHand, long> projectSalesToOpsHandRepository,
            IRepository<ProjectOpsConfirOfHand, long> projectOpsConfirOfHandRepository,
            IRepository<ProjectMRABPL, long> ProjectMRABPLRepository,
            IRepository<ProjectEngineering> projectEngineeringRepository,
            IRepository<RevenueRange, long> lookup_revenueRangeRepository,
            IRepository<RuleElement, long> lookup_ruleElementRepository,
            IRepository<RuleValue, long> lookup_ruleValueRepository,
            IRepository<ProjectCommercial> projectCommercialRepository,
            IRepository<ProjectRule, long> projectRuleRepository,
            IRepository<ProjectAction, long> projectActionRepository,
            IRepository<ProjectExReview, long> projectExReviewRepository,
            IRefNoConfigsAppService refNoConfigAppservice,
            IRefNoConfigDetailsAppService refNoConfigDetailsAppService,
            Utils.UtilsAppService utilsAppService,
            IRepository<ProjectFile, Guid> repositoryProjectFile,
            IRepository<ProjectPersonnel, long> projectPersonnelRepository,
            IRepository<ProjectQuoteForm, long> projectQuoteFormRepository,
            ProjectPermissionManager projectPermissionManager,
            IRepository<User, long> userRepository,
            IRepository<NodeStage, string> nodeStageRepository,
            IRepository<NodeTask, string> nodeTaskRepository,
            IRepository<ProjectQFDelegation, long> projectQFDelegationRepository,
            IRepository<RefNoConfig.RefNoConfig, long> refNoConfigRepository,
            IRepository<RefNoConfigDetails, long> refNoConfigDetailsRepository,
            WorkflowManager workflowManager,
            RefNoConfigManager refNoConfigManager,
            IRepository<ProjectQuoteMeta, long> lookup_quoteRepository,
            IRepository<ProjectStatusOfSubmittedQuote, long> statusOfSubmittedQuoteRepository,
            IRepository<ProjectOACustCommAcceptance, long> ProjectOACustCommAcceptanceRepository,
            IRepository<ProjectCommercialTasksPriorCommence, long> projectCommercialTasksPriorCommenceRepository,
            RoleManager roleManager,
            StorageManager storageManager
            )
        {
            EventBus = NullEventBus.Instance;
            _unitOfWorkManager = unitOfWorkManager;
            _userManager = userManager;
            _projectRepository = projectRepository;
            _projectsExcelExporter = projectsExcelExporter;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _lookup_contactPersonRepository = lookup_contactPersonRepository;
            _lookup_customerRepository = lookup_customerRepository;
            _lookup_leadRepository = lookup_leadRepository;
            _lookup_leadSourceRepository = lookup_leadSourceRepository;
            _lookup_projectSiteRepository = lookup_projectSiteRepository;
            _lookup_projectCommentRepository = lookup_projectCommentRepository;
            _lookup_projectTypeRepository = lookup_projectTypeRepository;
            _lookup_projectWishlistRepository = lookup_projectWishlistRepository;
            _projectEstimateRepository = projectEstimateRepository;
            _projectEngineeringRepository = projectEngineeringRepository;
            _lookup_revenueRangeRepository = lookup_revenueRangeRepository;
            _lookup_ruleElementRepository = lookup_ruleElementRepository;
            _lookup_ruleValueRepository = lookup_ruleValueRepository;
            _projectCommercialRepository = projectCommercialRepository;
            _projectRuleRepository = projectRuleRepository;
            _projectActionRepository = projectActionRepository;
            _projectExReviewRepository = projectExReviewRepository;
            _refNoConfigAppservice = refNoConfigAppservice;
            _refNoConfigDetailsAppservice = refNoConfigDetailsAppService;
            _utilsAppService = utilsAppService;
            _repositoryProjectFile = repositoryProjectFile;
            _projectPersonnelRepository = projectPersonnelRepository;
            _projectQuoteFormRepository = projectQuoteFormRepository;
            _projectPermissionManager = projectPermissionManager;
            _userRepository = userRepository;
            _nodeStageRepository = nodeStageRepository;
            _nodeTaskRepository = nodeTaskRepository;
            _projectQFDelegationRepository = projectQFDelegationRepository;
            _refNoConfigRepository = refNoConfigRepository;
            _refNoConfigDetailsRepository = refNoConfigDetailsRepository;
            _workflowManager = workflowManager;
            _refNoConfigManager = refNoConfigManager;
            _lookup_quoteRepository = lookup_quoteRepository;
            _statusOfSubmittedQuoteRepository = statusOfSubmittedQuoteRepository;
            _ProjectOACustCommAcceptanceRepository = ProjectOACustCommAcceptanceRepository;
            _projectSalesToOpsHandRepository = projectSalesToOpsHandRepository;
            _projectOpsConfirOfHandRepository = projectOpsConfirOfHandRepository;
            _ProjectMRABPLRepository = ProjectMRABPLRepository;
            _projectCommercialTasksPriorCommenceRepository = projectCommercialTasksPriorCommenceRepository;
            _roleManager = roleManager;
            _storageManager = storageManager;
        }

        public async Task<PagedResultDto<GetProjectForViewDto>> GetAll(GetAllProjectsInput input)
        {

            var filteredProjects = _projectRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.ContactPersonFk)
                        .Include(e => e.CustomerFk)
                        .Include(e => e.LeadFk)
                        .Include(e => e.LeadSourceFk)
                        .Include(e => e.ProjectSiteFk)
                        .Include(e => e.ProjectCommentFk)
                        .Include(e => e.ProjectTypeFk)
                        .Include(e => e.ProjectWishlistFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ProjectName.Contains(input.Filter) || e.DescriptionOfWork.Contains(input.Filter) || e.QRN.Contains(input.Filter) || e.JRN.Contains(input.Filter) || e.LeadSourceContextualData.Contains(input.Filter) || e.Consultant.Contains(input.Filter) || e.Status.Contains(input.Filter) || e.Stage.Contains(input.Filter) || e.Task.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectNameFilter), e => e.ProjectName == input.ProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DescriptionOfWorkFilter), e => e.DescriptionOfWork == input.DescriptionOfWorkFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.QRNFilter), e => e.QRN == input.QRNFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.JRNFilter), e => e.JRN == input.JRNFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadSourceContextualDataFilter), e => e.LeadSourceContextualData == input.LeadSourceContextualDataFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ConsultantFilter), e => e.Consultant == input.ConsultantFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StatusFilter), e => e.Status == input.StatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StageFilter), e => e.Stage == input.StageFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TaskFilter), e => e.Task == input.TaskFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ContactPersonNameFilter), e => e.ContactPersonFk != null && e.ContactPersonFk.Name == input.ContactPersonNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerNameFilter), e => e.CustomerFk != null && e.CustomerFk.Name == input.CustomerNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadProjectNameFilter), e => e.LeadFk != null && e.LeadFk.ProjectName == input.LeadProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadSourceTitleFilter), e => e.LeadSourceFk != null && e.LeadSourceFk.Title == input.LeadSourceTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectSiteSiteNameFilter), e => e.ProjectSiteFk != null && e.ProjectSiteFk.SiteName == input.ProjectSiteSiteNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectCommentCommentFilter), e => e.ProjectCommentFk != null && e.ProjectCommentFk.Content == input.ProjectCommentCommentFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectTypeCodeFilter), e => e.ProjectTypeFk != null && e.ProjectTypeFk.Code == input.ProjectTypeCodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectWishlistTitleFilter), e => e.ProjectWishlistFk != null && e.ProjectWishlistFk.Title == input.ProjectWishlistTitleFilter);

            var pagedAndFilteredProjects = filteredProjects
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var projects = from o in pagedAndFilteredProjects
                           join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                           from s1 in j1.DefaultIfEmpty()

                           join o2 in _lookup_contactPersonRepository.GetAll() on o.ContactPersonId equals o2.Id into j2
                           from s2 in j2.DefaultIfEmpty()

                           join o3 in _lookup_customerRepository.GetAll() on o.CustomerId equals o3.Id into j3
                           from s3 in j3.DefaultIfEmpty()

                           join o4 in _lookup_leadRepository.GetAll() on o.LeadId equals o4.Id into j4
                           from s4 in j4.DefaultIfEmpty()

                           join o5 in _lookup_leadSourceRepository.GetAll() on o.LeadSourceId equals o5.Id into j5
                           from s5 in j5.DefaultIfEmpty()

                           join o6 in _lookup_projectSiteRepository.GetAll() on o.ProjectSiteId equals o6.Id into j6
                           from s6 in j6.DefaultIfEmpty()

                           join o7 in _lookup_projectCommentRepository.GetAll() on o.ProjectCommentId equals o7.Id into j7
                           from s7 in j7.DefaultIfEmpty()

                           join o8 in _lookup_projectTypeRepository.GetAll() on o.ProjectTypeId equals o8.Id into j8
                           from s8 in j8.DefaultIfEmpty()

                           join o9 in _lookup_projectWishlistRepository.GetAll() on o.ProjectWishlistId equals o9.Id into j9
                           from s9 in j9.DefaultIfEmpty()

                           select new
                           {

                               o.ProjectName,
                               o.DescriptionOfWork,
                               o.QRN,
                               o.JRN,
                               o.LeadSourceContextualData,
                               o.Consultant,
                               o.Status,
                               o.Stage,
                               o.Task,
                               Id = o.Id,
                               o.CustomerId,
                               o.ContactPersonId,
                               o.ProjectSiteId,
                               OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                               ContactPersonName = s2 == null || s2.Name == null ? "" : s2.Name.ToString(),
                               CustomerName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
                               LeadProjectName = s4 == null || s4.ProjectName == null ? "" : s4.ProjectName.ToString(),
                               LeadSourceTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString(),
                               ProjectSiteSiteName = s6 == null || s6.SiteName == null ? "" : s6.SiteName.ToString(),
                               ProjectCommentComment = s7 == null || s7.Content == null ? "" : s7.Content.ToString(),
                               ProjectTypeCode = s8 == null || s8.Code == null ? "" : s8.Code.ToString(),
                               ProjectWishlistTitle = s9 == null || s9.Title == null ? "" : s9.Title.ToString()
                           };

            var totalCount = await filteredProjects.CountAsync();

            var dbList = await projects.ToListAsync();
            var results = new List<GetProjectForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectForViewDto()
                {
                    Project = new ProjectDto
                    {

                        ProjectName = o.ProjectName,
                        DescriptionOfWork = o.DescriptionOfWork,
                        QRN = o.QRN,
                        JRN = o.JRN,
                        LeadSourceContextualData = o.LeadSourceContextualData,
                        Consultant = o.Consultant,
                        Status = o.Status,
                        Stage = o.Stage,
                        Task = o.Task,
                        Id = o.Id,
                        CustomerId = o.CustomerId,
                        ContactPersonId = o.ContactPersonId,
                        ProjectSiteId = o.ProjectSiteId,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
                    ContactPersonName = o.ContactPersonName,
                    CustomerName = o.CustomerName,
                    LeadProjectName = o.LeadProjectName,
                    LeadSourceTitle = o.LeadSourceTitle,
                    ProjectSiteSiteName = o.ProjectSiteSiteName,
                    ProjectCommentComment = o.ProjectCommentComment,
                    ProjectTypeCode = o.ProjectTypeCode,
                    ProjectWishlistTitle = o.ProjectWishlistTitle
                };

                results.Add(res);
            }

            return new PagedResultDto<GetProjectForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetProjectForViewDto> GetProjectForView(long id, string projectType)
        {
            // TODO: check permissions
            //var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            //{
            //    ProjectId = id
            //});
            //if (!check)
            //{
            //    throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            //}

            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var project = await _projectRepository.GetAsync(id);

                    var output = new GetProjectForViewDto { Project = ObjectMapper.Map<ProjectDto>(project) };

                    output.WorkFlowSchema = await _workflowManager.GetSchemaAsync(projectType, AbpSession.TenantId);

                    if (output.Project.OrganizationUnitId != null)
                    {
                        var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.Project.OrganizationUnitId);
                        output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
                    }

                    if (output.Project.ContactPersonId != null)
                    {
                        var _lookupContactPerson = await _lookup_contactPersonRepository.FirstOrDefaultAsync((long)output.Project.ContactPersonId);
                        output.ContactPersonName = _lookupContactPerson?.Name?.ToString();
                        //output.ContactPersons = ObjectMapper.Map<List<ContactPersonDto>>(_lookupContactPerson);
                        output.ContactPersons = new List<ContactPersonDto>()
                            {
                                ObjectMapper.Map<ContactPersonDto>(_lookupContactPerson)
                            };

                    }

                    if (output.Project.CustomerId != null)
                    {
                        var _lookupCustomer = await _lookup_customerRepository.FirstOrDefaultAsync((long)output.Project.CustomerId);
                        output.CustomerName = _lookupCustomer?.Name?.ToString();
                        output.Customer = ObjectMapper.Map<CustomerDto>(_lookupCustomer);
                    }

                    if (output.Project.LeadId != null)
                    {
                        var _lookupLead = await _lookup_leadRepository.FirstOrDefaultAsync((long)output.Project.LeadId);
                        output.LeadProjectName = _lookupLead?.ProjectName?.ToString();
                    }

                    if (output.Project.LeadSourceId != null)
                    {
                        var _lookupLeadSource = await _lookup_leadSourceRepository.FirstOrDefaultAsync((int)output.Project.LeadSourceId);
                        output.LeadSourceTitle = _lookupLeadSource?.Title?.ToString();
                    }

                    if (output.Project.ProjectSiteId != null)
                    {
                        var _lookupProjectSite = await _lookup_projectSiteRepository.FirstOrDefaultAsync((long)output.Project.ProjectSiteId);
                        output.ProjectSiteSiteName = _lookupProjectSite?.SiteName?.ToString();
                        output.Project.SiteName = _lookupProjectSite?.SiteName?.ToString();
                        output.Project.SiteAddress1 = _lookupProjectSite?.SiteAddress1?.ToString();
                        output.Project.SiteAddress2 = _lookupProjectSite?.SiteAddress2?.ToString();
                        output.Project.SitePostCode = _lookupProjectSite?.SitePostCode?.ToString();
                        output.Project.SiteRef = _lookupProjectSite?.SiteRef?.ToString();
                    }

                    if (output.Project.ProjectCommentId != null)
                    {
                        var _lookupProjectComment = await _lookup_projectCommentRepository.FirstOrDefaultAsync((long)output.Project.ProjectCommentId);
                        output.ProjectCommentComment = _lookupProjectComment?.Content?.ToString();
                    }

                    if (output.Project.ProjectTypeId != null)
                    {
                        var _lookupProjectType = await _lookup_projectTypeRepository.FirstOrDefaultAsync((string)output.Project.ProjectTypeId);
                        output.ProjectTypeCode = _lookupProjectType?.Code?.ToString();
                    }

                    if (output.Project.ProjectWishlistId != null)
                    {
                        var _lookupProjectWishlist = await _lookup_projectWishlistRepository.FirstOrDefaultAsync((long)output.Project.ProjectWishlistId);
                        output.ProjectWishlistTitle = _lookupProjectWishlist?.Title?.ToString();
                    }

                    if (project != null)
                    {
                        var estimate = await _projectEstimateRepository.FirstOrDefaultAsync(x => x.ProjectId == project.Id);
                        if (estimate != null)
                        {
                            var _lookupRevenue = new RevenueRange();
                            if (estimate.RevenueRangeId != null || estimate.RevenueRangeId == 0)
                            {

                                _lookupRevenue = await _lookup_revenueRangeRepository.FirstOrDefaultAsync((long)estimate.RevenueRangeId);
                            }
                            GetProjectEstimateForViewDto testimate = new GetProjectEstimateForViewDto()
                            {
                                ProjectEstimate = ObjectMapper.Map<ProjectEstimateDto>(estimate),
                                ProjectProjectName = project.ProjectName,
                                RevenueDetails = estimate.RevenueRangeId != null ? ObjectMapper.Map<RevenueRangeDto>(_lookupRevenue) : new RevenueRangeDto(),
                            };
                            output.ProjectEstimate = testimate;
                        }

                        var salestoopshand = await _projectSalesToOpsHandRepository.FirstOrDefaultAsync(x => x.ProjectId == project.Id);
                        if (salestoopshand != null)
                        {
                            output.ProjectSalesToOpsHand = new GetProjectSalesToOpsHandForViewDto() { ProjectSalesToOpsHand = ObjectMapper.Map<ProjectSalesToOpsHandDto>(salestoopshand) };
                        }

                        var MeetNotesbyProLead = await _ProjectMRABPLRepository.FirstOrDefaultAsync(x => x.ProjectId == project.Id);
                        if (MeetNotesbyProLead != null)
                        {
                            output.ProjectMRABPL = new GetProjectMRABPLForViewDto() { ProjectMRABPL = ObjectMapper.Map<ProjectMRABPLDto>(MeetNotesbyProLead) };
                        }


                        var opsconfofhand = await _projectOpsConfirOfHandRepository.GetAll().Where(x => x.ProjectId == project.Id).ToListAsync();
                        if (opsconfofhand != null)
                        {

                            List<GetProjectOpsConfirOfHandForViewDto> topsconfofhand = new List<GetProjectOpsConfirOfHandForViewDto>();
                            foreach (var item in opsconfofhand)
                            {


                                topsconfofhand.Add(new GetProjectOpsConfirOfHandForViewDto()
                                {
                                    ProjectOpsConfirOfHand = ObjectMapper.Map<ProjectOpsConfirOfHandDto>(item),
                                });
                            }

                            output.ProjectOpsConfirOfHand = topsconfofhand;
                        }


                        var projectEngineerings = await _projectEngineeringRepository.GetAll().Where(x => x.ProjectId == project.Id).ToListAsync();
                        if (projectEngineerings != null)
                        {
                            List<GetProjectEngineeringForViewDto> tprojectEngineerings = new List<GetProjectEngineeringForViewDto>();
                            foreach (var item in projectEngineerings)
                            {
                                var ruleElement = _lookup_ruleElementRepository.FirstOrDefault((long)item.RuleElementId);
                                var ruleValue = _lookup_ruleValueRepository.FirstOrDefault(x => x.Id == item.RuleValueId && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));

                                if (ruleElement != null && ruleValue != null)
                                {
                                    tprojectEngineerings.Add(new GetProjectEngineeringForViewDto()
                                    {
                                        ProjectEngineering = ObjectMapper.Map<ProjectEngineeringDto>(item),
                                        ProjectProjectName = project.ProjectName,
                                        RuleElementTitle = ruleElement.Title,
                                        RuleValueTitle = ruleValue.Title
                                    });
                                }
                            }

                            output.ProjectEngineerings = tprojectEngineerings;
                        }

                        var projectCommercials = await _projectCommercialRepository.GetAll().Where(x => x.ProjectId == project.Id).ToListAsync();
                        if (projectCommercials != null)
                        {
                            List<GetProjectCommercialForViewDto> tprojectCommercials = new List<GetProjectCommercialForViewDto>();
                            foreach (var item in projectCommercials)
                            {
                                var ruleElement = _lookup_ruleElementRepository.FirstOrDefault((long)item.RuleElementId);
                                var ruleValue = _lookup_ruleValueRepository.FirstOrDefault(x => x.Id == item.RuleValueId && x.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));

                                if (ruleElement != null && ruleValue != null)
                                {
                                    tprojectCommercials.Add(new GetProjectCommercialForViewDto()
                                    {
                                        ProjectCommercial = ObjectMapper.Map<ProjectCommercialDto>(item),
                                        ProjectProjectName = project.ProjectName,
                                        RuleElementTitle = ruleElement.Title,
                                        RuleValueTitle = ruleValue.Title
                                    });
                                }
                            }

                            output.ProjectCommercials = tprojectCommercials;
                        }

                        var actionId = await _projectActionRepository.GetAll().Where(x => x.ProjectId == project.Id).OrderByDescending(x => x.CreationTime).ToListAsync();
                        if (actionId.Count != 0)
                        {
                            var projectRules = await _projectRuleRepository.GetAll().Where(x => x.ProjectId == project.Id && x.ProjectActionId == actionId[0].Id).ToListAsync();
                            if (projectRules != null)
                            {
                                List<GetProjectRuleForViewDto> tprojectRules = new List<GetProjectRuleForViewDto>();
                                foreach (var item in projectRules)
                                {
                                    tprojectRules.Add(new GetProjectRuleForViewDto()
                                    {
                                        ProjectRule = ObjectMapper.Map<ProjectRuleDto>(item)
                                    });
                                }

                                output.ProjectRules = tprojectRules;
                            }
                        }

                        var projectExReviews = await _projectExReviewRepository.GetAll().Where(x => x.ProjectId == project.Id).ToListAsync();
                        if (projectExReviews != null)
                        {
                            List<GetProjectExReviewForViewDto> tprojectExReviews = new List<GetProjectExReviewForViewDto>();
                            foreach (var item in projectExReviews)
                            {
                                tprojectExReviews.Add(new GetProjectExReviewForViewDto()
                                {
                                    ProjectExReview = new ProjectExReviewDto
                                    {
                                        Title = item.Title,
                                        IsCurrent = item.IsCurrent,
                                        DisplayOrder = item.DisplayOrder,
                                        Id = item.Id
                                    },
                                    ProjectProjectName = project.ProjectName
                                });
                            }

                            output.ProjectExReviews = tprojectExReviews;
                        }

                        var projectPersonnels = await _projectPersonnelRepository.GetAll().Where(x => x.ProjectId == project.Id).ToListAsync();
                        if (projectPersonnels != null)
                        {
                            List<GetProjectPersonnelForViewDto> tprojectPersonnels = new List<GetProjectPersonnelForViewDto>();
                            List<ProjectAppointKeyStaffDto> tAppointKeyStaff = new List<ProjectAppointKeyStaffDto>();
                            foreach (var item in projectPersonnels)
                            {
                                var user = await UserManager.GetUserByIdAsync(Convert.ToInt64(item.UserId));
                                var role = await _roleManager.GetRoleByIdAsync(Convert.ToInt64(item.RoleId));
                                tprojectPersonnels.Add(new GetProjectPersonnelForViewDto()
                                {
                                    projectAppointKeyStaff = new ProjectAppointKeyStaffDto
                                    {
                                        Id = item.Id,
                                        ProjectId = item.ProjectId,
                                        EngineeringLead = role.Name.ToUpper() == "ENGINEERING LEADER" ? user.UserName : null,
                                        CommercialLead = role.Name.ToUpper() == "COMMERCIAL LEADER" ? user.UserName : null,
                                        ProjectLead = role.Name.ToUpper() == "PROJECT LEAD" ? user.UserName : null
                                    }
                                });
                            }

                            output.ProjectPersonnels = tprojectPersonnels;
                        }

                        var projectQuoteForms = await _projectQuoteFormRepository.GetAll().Where(x => x.ProjectId == project.Id).ToListAsync();
                        if (projectQuoteForms != null)
                        {
                            List<GetProjectQuoteFormForViewDto> tprojectQuoteForms = new List<GetProjectQuoteFormForViewDto>();
                            foreach (var item in projectQuoteForms)
                            {
                                tprojectQuoteForms.Add(new GetProjectQuoteFormForViewDto()
                                {
                                    ProjectQuoteForm = ObjectMapper.Map<ProjectQuoteFormDto>(item)

                                });
                            }
                            output.ProjectQuoteForms = tprojectQuoteForms;
                        }

                        var statusOfSubmitQuote = await _statusOfSubmittedQuoteRepository.GetAll().Where(x => x.ProjectId == project.Id).ToListAsync();
                        ProjectQuoteMeta QuoteMeta = new ProjectQuoteMeta();
                        if (statusOfSubmitQuote != null)
                        {
                            List<CreateOrEditProjectStatusOfSubmittedQuoteDto> tprojectStatusOfSubmitQuotes = new List<CreateOrEditProjectStatusOfSubmittedQuoteDto>();

                            foreach (var item in statusOfSubmitQuote)
                            {
                                QuoteMeta = _lookup_quoteRepository.GetAll().Where(x => x.ProjectId == project.Id && x.ProjectStatusOfSubmittedQuoteId == item.Id).ToList().FirstOrDefault();
                                var statusOfsubmittedQuote = ObjectMapper.Map<CreateOrEditProjectStatusOfSubmittedQuoteDto>(item);
                                var mappedQuoteMeta = ObjectMapper.Map<QuoteMetaDto>(QuoteMeta);
                                statusOfsubmittedQuote.QuoteMeta = mappedQuoteMeta;
                                tprojectStatusOfSubmitQuotes.Add(statusOfsubmittedQuote);
                            }
                            output.StatusOfSubmittedQuotes = tprojectStatusOfSubmitQuotes;
                        }
                        //var QuoteMeta = await _lookup_quoteRepository.GetAll().Where(x => x.ProjectId == project.Id).ToListAsync();
                        //if (QuoteMeta != null)
                        //{
                        //    List<QuoteMetaDto> tprojectQuoteMetas = new List<QuoteMetaDto>();
                        //    foreach (var item in QuoteMeta)
                        //    {

                        //        tprojectQuoteMetas.Add(ObjectMapper.Map<QuoteMetaDto>(item));
                        //    }
                        //    output.StatusOfSubmittedQuotes.qu = tprojectQuoteMetas;
                        //}





                        var ProjectOACustCommAcceptances = await _ProjectOACustCommAcceptanceRepository.GetAll().Where(x => x.ProjectId == project.Id).OrderBy(x => x.Id).ToListAsync();
                        if (ProjectOACustCommAcceptances != null)
                        {
                            foreach (var item in ProjectOACustCommAcceptances)
                            {
                                GetProjectOACustCommAcceptanceForViewDto tProjectOACustCommAcceptances = new GetProjectOACustCommAcceptanceForViewDto()
                                {
                                    projectOACustCommAcceptance = ObjectMapper.Map<ProjectOACustCommAcceptanceDto>(item),
                                    ProjectProjectName = project.ProjectName
                                };
                                output.projectOACustCommAcceptance = tProjectOACustCommAcceptances;
                            }
                        }

                        var ctptc = await _projectCommercialTasksPriorCommenceRepository.FirstOrDefaultAsync(x => x.ProjectId == project.Id);
                        if (ctptc != null)
                        {
                            output.ProjectCommercialTasksPriorCommence = new GetProjectCommercialTasksPriorCommenceForViewDto() { ProjectCommercialTasksPriorCommence = ObjectMapper.Map<ProjectCommercialTasksPriorCommenceDto>(ctptc) };
                        }

                    }

                    return output;

                }
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Projects_Edit)]
        public async Task<GetProjectForEditOutput> GetProjectForEdit(EntityDto<long> input)
        {
            var project = await _projectRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetProjectForEditOutput { Project = ObjectMapper.Map<CreateOrEditProjectDto>(project) };

            if (output.Project.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.Project.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            if (output.Project.ContactPersonId != null)
            {
                var _lookupContactPerson = await _lookup_contactPersonRepository.FirstOrDefaultAsync((long)output.Project.ContactPersonId);
                output.ContactPersonName = _lookupContactPerson?.Name?.ToString();
                output.ContactPersons = new List<ContactPersonDto>()
                {
                    ObjectMapper.Map<ContactPersonDto>(_lookupContactPerson)
                };
            }

            if (output.Project.CustomerId != null)
            {
                var _lookupCustomer = await _lookup_customerRepository.FirstOrDefaultAsync((long)output.Project.CustomerId);
                output.CustomerName = _lookupCustomer?.Name?.ToString();
                output.Customer = ObjectMapper.Map<CustomerDto>(_lookupCustomer);
            }

            if (output.Project.LeadId != null)
            {
                var _lookupLead = await _lookup_leadRepository.FirstOrDefaultAsync((long)output.Project.LeadId);
                output.LeadProjectName = _lookupLead?.ProjectName?.ToString();
            }

            if (output.Project.LeadSourceId != null)
            {
                var _lookupLeadSource = await _lookup_leadSourceRepository.FirstOrDefaultAsync((int)output.Project.LeadSourceId);
                output.LeadSourceTitle = _lookupLeadSource?.Title?.ToString();
            }

            if (output.Project.ProjectSiteId != null)
            {
                var _lookupProjectSite = await _lookup_projectSiteRepository.FirstOrDefaultAsync((long)output.Project.ProjectSiteId);
                output.ProjectSiteSiteName = _lookupProjectSite?.SiteName?.ToString();
                output.Project.SiteName = _lookupProjectSite.SiteName;
                output.Project.SiteAddress1 = _lookupProjectSite.SiteAddress1;
                output.Project.SiteAddress2 = _lookupProjectSite.SiteAddress2;
                output.Project.SitePostCode = _lookupProjectSite.SitePostCode;
                output.Project.SiteRef = _lookupProjectSite.SiteRef;
            }

            if (output.Project.ProjectCommentId != null)
            {
                var _lookupProjectComment = await _lookup_projectCommentRepository.FirstOrDefaultAsync((long)output.Project.ProjectCommentId);
                output.ProjectCommentComment = _lookupProjectComment?.Content?.ToString();
            }

            if (output.Project.ProjectTypeId != null)
            {
                var _lookupProjectType = await _lookup_projectTypeRepository.FirstOrDefaultAsync((string)output.Project.ProjectTypeId);
                output.ProjectTypeCode = _lookupProjectType?.Code?.ToString();
            }

            if (output.Project.ProjectWishlistId != null)
            {
                var _lookupProjectWishlist = await _lookup_projectWishlistRepository.FirstOrDefaultAsync((long)output.Project.ProjectWishlistId);
                output.ProjectWishlistTitle = _lookupProjectWishlist?.Title?.ToString();
            }

            return output;
        }

        public async Task<GetProjectForEditOutput> CreateOrEdit(CreateOrEditProjectDto input)
        {
            GetProjectForEditOutput result = new GetProjectForEditOutput();
            await _unitOfWorkManager.WithUnitOfWork(async () =>
            {
                var tenantId = AbpSession.TenantId;
                using (CurrentUnitOfWork.SetTenantId(tenantId))
                {
                    using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        var project = new GetProjectForEditOutput();

                        Project oldProject = null;

                        if (input.Id == null || input.Id == 0)
                        {
                            input.TenantId = (int)AbpSession.TenantId;
                            project = await Create(input);
                        }
                        else
                        {
                            oldProject = _projectRepository.Get(input.Id.Value);
                            input.TenantId = oldProject.TenantId;
                            project = await Update(input);
                        }

                        if (project.Project != null)
                        {
                            if (oldProject == null || (oldProject != null && oldProject.CustomerId != project.Project.CustomerId))
                            {
                                await EventBus.TriggerAsync(new EditProjectEventData()
                                {
                                    ProjectId = (long)project.Project.Id,
                                    StageId = CNodeStages.PreOrder,
                                    TaskId = CNodeTasks.SelectCustomer,
                                    StatusId = CNodeStatuses.Save,
                                    LoggedInUserId = (long)AbpSession.UserId
                                });
                            }

                            await EventBus.TriggerAsync(new EditProjectEventData()
                            {
                                ProjectId = (long)project.Project.Id,
                                StageId = CNodeStages.PreOrder,
                                TaskId = CNodeTasks.CreateProject,
                                StatusId = CNodeStatuses.Save,
                                LoggedInUserId = (long)AbpSession.UserId
                            });

                            result = project;
                        }
                    }
                }
            });

            return result;
        }

        [AbpAuthorize(AppPermissions.Pages_Projects_Create)]
        protected virtual async Task<GetProjectForEditOutput> Create(CreateOrEditProjectDto input)
        {
            var project = ObjectMapper.Map<Project>(input);

            if (AbpSession.TenantId != null)
            {
                project.TenantId = (int?)AbpSession.TenantId;
            }

            if (input.ProjectSiteId == null)
            {
                ProjectSite projectSite = new ProjectSite();
                projectSite.SiteAddress1 = input.SiteAddress1;
                projectSite.SiteAddress2 = input.SiteAddress2;
                projectSite.SiteName = input.SiteName;
                projectSite.SiteRef = input.SiteRef;
                projectSite.SitePostCode = input.SitePostCode;

                if (AbpSession.TenantId != null)
                {
                    projectSite.TenantId = (int?)AbpSession.TenantId;
                }
                var projectSiteId = _lookup_projectSiteRepository.InsertAndGetId(projectSite);
                project.ProjectSiteId = projectSiteId;
            }
            var projectId = _projectRepository.InsertAndGetId(project);
            //await _projectRepository.InsertAsync(project);
            var projectDetails = _projectRepository.Get(projectId);
            var output = await GetProjectDetails(projectDetails);

            return output;
        }

        private async Task<GetProjectForEditOutput> GetProjectDetails(Project projectDetails)
        {
            var output = new GetProjectForEditOutput { Project = ObjectMapper.Map<CreateOrEditProjectDto>(projectDetails) };
            if (output.Project != null)
            {
                if (output.Project.ContactPersonId != null)
                {
                    var _lookupContactPerson = await _lookup_contactPersonRepository.FirstOrDefaultAsync((long)output.Project.ContactPersonId);
                    output.ContactPersonName = _lookupContactPerson?.Name?.ToString();
                    output.ContactPersons = new List<ContactPersonDto>()
                    {
                        ObjectMapper.Map<ContactPersonDto>(_lookupContactPerson)
                    };
                }

                if (output.Project.CustomerId != null)
                {
                    var _lookupCustomer = await _lookup_customerRepository.FirstOrDefaultAsync((long)output.Project.CustomerId);
                    output.CustomerName = _lookupCustomer?.Name?.ToString();
                    output.Customer = ObjectMapper.Map<CustomerDto>(_lookupCustomer);
                }

                if (output.Project.LeadId != null)
                {
                    var _lookupLead = await _lookup_leadRepository.FirstOrDefaultAsync((long)output.Project.LeadId);
                    output.LeadProjectName = _lookupLead?.ProjectName?.ToString();
                }

                if (output.Project.LeadSourceId != null)
                {
                    var _lookupLeadSource = await _lookup_leadSourceRepository.FirstOrDefaultAsync((int)output.Project.LeadSourceId);
                    output.LeadSourceTitle = _lookupLeadSource?.Title?.ToString();
                }

                if (output.Project.ProjectSiteId != null)
                {
                    var _lookupProjectSite = await _lookup_projectSiteRepository.FirstOrDefaultAsync((long)output.Project.ProjectSiteId);
                    output.ProjectSiteSiteName = _lookupProjectSite?.SiteName?.ToString();
                }

                if (output.Project.ProjectCommentId != null)
                {
                    var _lookupProjectComment = await _lookup_projectCommentRepository.FirstOrDefaultAsync((long)output.Project.ProjectCommentId);
                    output.ProjectCommentComment = _lookupProjectComment?.Content?.ToString();
                }

                if (output.Project.ProjectTypeId != null)
                {
                    var _lookupProjectType = await _lookup_projectTypeRepository.FirstOrDefaultAsync((string)output.Project.ProjectTypeId);
                    output.ProjectTypeCode = _lookupProjectType?.Code?.ToString();
                }

                if (output.Project.ProjectWishlistId != null)
                {
                    var _lookupProjectWishlist = await _lookup_projectWishlistRepository.FirstOrDefaultAsync((long)output.Project.ProjectWishlistId);
                    output.ProjectWishlistTitle = _lookupProjectWishlist?.Title?.ToString();
                }
            }
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Projects_Edit)]
        protected virtual async Task<GetProjectForEditOutput> Update(CreateOrEditProjectDto input)
        {
            if (input.ProjectSiteId == null)
            {
                ProjectSite projectSite = new ProjectSite();
                projectSite.SiteAddress1 = input.SiteAddress1;
                projectSite.SiteAddress2 = input.SiteAddress2;
                projectSite.SiteName = input.SiteName;
                projectSite.SiteRef = input.SiteRef;
                if (AbpSession.TenantId != null)
                {
                    projectSite.TenantId = (int?)AbpSession.TenantId;
                }
                var projectSiteId = _lookup_projectSiteRepository.InsertAndGetId(projectSite);
                input.ProjectSiteId = projectSiteId;
            }
            var project = await _projectRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, project);
            var output = await GetProjectDetails(project);

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Projects_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _projectRepository.DeleteAsync(input.Id);
        }

        public async Task<econsys.Dto.FileDto> GetProjectsToExcel(GetAllProjectsForExcelInput input)
        {

            var filteredProjects = _projectRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.ContactPersonFk)
                        .Include(e => e.CustomerFk)
                        .Include(e => e.LeadFk)
                        .Include(e => e.LeadSourceFk)
                        .Include(e => e.ProjectSiteFk)
                        .Include(e => e.ProjectCommentFk)
                        .Include(e => e.ProjectTypeFk)
                        .Include(e => e.ProjectWishlistFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ProjectName.Contains(input.Filter) || e.DescriptionOfWork.Contains(input.Filter) || e.QRN.Contains(input.Filter) || e.JRN.Contains(input.Filter) || e.LeadSourceContextualData.Contains(input.Filter) || e.Consultant.Contains(input.Filter) || e.Status.Contains(input.Filter) || e.Stage.Contains(input.Filter) || e.Task.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectNameFilter), e => e.ProjectName == input.ProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DescriptionOfWorkFilter), e => e.DescriptionOfWork == input.DescriptionOfWorkFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.QRNFilter), e => e.QRN == input.QRNFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.JRNFilter), e => e.JRN == input.JRNFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadSourceContextualDataFilter), e => e.LeadSourceContextualData == input.LeadSourceContextualDataFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ConsultantFilter), e => e.Consultant == input.ConsultantFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StatusFilter), e => e.Status == input.StatusFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.StageFilter), e => e.Stage == input.StageFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.TaskFilter), e => e.Task == input.TaskFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ContactPersonNameFilter), e => e.ContactPersonFk != null && e.ContactPersonFk.Name == input.ContactPersonNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CustomerNameFilter), e => e.CustomerFk != null && e.CustomerFk.Name == input.CustomerNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadProjectNameFilter), e => e.LeadFk != null && e.LeadFk.ProjectName == input.LeadProjectNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.LeadSourceTitleFilter), e => e.LeadSourceFk != null && e.LeadSourceFk.Title == input.LeadSourceTitleFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectSiteSiteNameFilter), e => e.ProjectSiteFk != null && e.ProjectSiteFk.SiteName == input.ProjectSiteSiteNameFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectCommentCommentFilter), e => e.ProjectCommentFk != null && e.ProjectCommentFk.Content == input.ProjectCommentCommentFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectTypeCodeFilter), e => e.ProjectTypeFk != null && e.ProjectTypeFk.Code == input.ProjectTypeCodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectWishlistTitleFilter), e => e.ProjectWishlistFk != null && e.ProjectWishlistFk.Title == input.ProjectWishlistTitleFilter);

            var query = (from o in filteredProjects
                         join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         join o2 in _lookup_contactPersonRepository.GetAll() on o.ContactPersonId equals o2.Id into j2
                         from s2 in j2.DefaultIfEmpty()

                         join o3 in _lookup_customerRepository.GetAll() on o.CustomerId equals o3.Id into j3
                         from s3 in j3.DefaultIfEmpty()

                         join o4 in _lookup_leadRepository.GetAll() on o.LeadId equals o4.Id into j4
                         from s4 in j4.DefaultIfEmpty()

                         join o5 in _lookup_leadSourceRepository.GetAll() on o.LeadSourceId equals o5.Id into j5
                         from s5 in j5.DefaultIfEmpty()

                         join o6 in _lookup_projectSiteRepository.GetAll() on o.ProjectSiteId equals o6.Id into j6
                         from s6 in j6.DefaultIfEmpty()

                         join o7 in _lookup_projectCommentRepository.GetAll() on o.ProjectCommentId equals o7.Id into j7
                         from s7 in j7.DefaultIfEmpty()

                         join o8 in _lookup_projectTypeRepository.GetAll() on o.ProjectTypeId equals o8.Id into j8
                         from s8 in j8.DefaultIfEmpty()

                         join o9 in _lookup_projectWishlistRepository.GetAll() on o.ProjectWishlistId equals o9.Id into j9
                         from s9 in j9.DefaultIfEmpty()

                         select new GetProjectForViewDto()
                         {
                             Project = new ProjectDto
                             {
                                 ProjectName = o.ProjectName,
                                 DescriptionOfWork = o.DescriptionOfWork,
                                 QRN = o.QRN,
                                 JRN = o.JRN,
                                 LeadSourceContextualData = o.LeadSourceContextualData,
                                 Consultant = o.Consultant,
                                 Status = o.Status,
                                 Stage = o.Stage,
                                 Task = o.Task,
                                 Id = o.Id
                             },
                             OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                             ContactPersonName = s2 == null || s2.Name == null ? "" : s2.Name.ToString(),
                             CustomerName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
                             LeadProjectName = s4 == null || s4.ProjectName == null ? "" : s4.ProjectName.ToString(),
                             LeadSourceTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString(),
                             ProjectSiteSiteName = s6 == null || s6.SiteName == null ? "" : s6.SiteName.ToString(),
                             ProjectCommentComment = s7 == null || s7.Content == null ? "" : s7.Content.ToString(),
                             ProjectTypeCode = s8 == null || s8.Code == null ? "" : s8.Code.ToString(),
                             ProjectWishlistTitle = s9 == null || s9.Title == null ? "" : s9.Title.ToString()
                         });

            var projectListDtos = await query.ToListAsync();

            return _projectsExcelExporter.ExportToFile(projectListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new ProjectOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectContactPersonLookupTableDto>> GetAllContactPersonForTableDropdown()
        {
            return await _lookup_contactPersonRepository.GetAll()
                .Select(contactPerson => new ProjectContactPersonLookupTableDto
                {
                    Id = contactPerson.Id,
                    DisplayName = contactPerson == null || contactPerson.Name == null ? "" : contactPerson.Name.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectCustomerLookupTableDto>> GetAllCustomerForTableDropdown()
        {
            return await _lookup_customerRepository.GetAll()
                .Select(customer => new ProjectCustomerLookupTableDto
                {
                    Id = customer.Id,
                    DisplayName = customer == null || customer.Name == null ? "" : customer.Name.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectLeadLookupTableDto>> GetAllLeadForTableDropdown()
        {
            return await _lookup_leadRepository.GetAll()
                .Select(lead => new ProjectLeadLookupTableDto
                {
                    Id = lead.Id,
                    DisplayName = lead == null || lead.ProjectName == null ? "" : lead.ProjectName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectLeadSourceLookupTableDto>> GetAllLeadSourceForTableDropdown()
        {
            return await _lookup_leadSourceRepository.GetAll()
                .Select(leadSource => new ProjectLeadSourceLookupTableDto
                {
                    Id = leadSource.Id,
                    DisplayName = leadSource == null || leadSource.Title == null ? "" : leadSource.Title.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectProjectSiteLookupTableDto>> GetAllProjectSiteForTableDropdown()
        {
            return await _lookup_projectSiteRepository.GetAll()
                .Select(projectSite => new ProjectProjectSiteLookupTableDto
                {
                    Id = projectSite.Id,
                    DisplayName = projectSite == null || projectSite.SiteName == null ? "" : projectSite.SiteName.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectProjectCommentLookupTableDto>> GetAllProjectCommentForTableDropdown()
        {
            return await _lookup_projectCommentRepository.GetAll()
                .Select(projectComment => new ProjectProjectCommentLookupTableDto
                {
                    Id = projectComment.Id,
                    DisplayName = projectComment == null || projectComment.Content == null ? "" : projectComment.Content.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectProjectTypeLookupTableDto>> GetAllProjectTypeForTableDropdown()
        {
            return await _lookup_projectTypeRepository.GetAll()
                .Select(projectType => new ProjectProjectTypeLookupTableDto
                {
                    Id = projectType.Id,
                    DisplayName = projectType == null || projectType.Code == null ? "" : projectType.Code.ToString()
                }).ToListAsync();
        }

        [AbpAuthorize(AppPermissions.Pages_Projects)]
        public async Task<List<ProjectProjectWishlistLookupTableDto>> GetAllProjectWishlistForTableDropdown()
        {
            return await _lookup_projectWishlistRepository.GetAll()
                .Select(projectWishlist => new ProjectProjectWishlistLookupTableDto
                {
                    Id = projectWishlist.Id,
                    DisplayName = projectWishlist == null || projectWishlist.Title == null ? "" : projectWishlist.Title.ToString()
                }).ToListAsync();
        }

        public async Task<List<GetProjectForViewDto>> GetWithActionRequired()
        {
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    /// TODO - check logic to get actions required, check access permissions
                    var filteredProjects = _projectRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.ContactPersonFk)
                        .Include(e => e.CustomerFk)
                        .Include(e => e.LeadFk)
                        .Include(e => e.LeadSourceFk)
                        .Include(e => e.ProjectSiteFk)
                        .Include(e => e.ProjectCommentFk)
                        .Include(e => e.ProjectTypeFk)
                        .Include(e => e.ProjectWishlistFk)
                        .Where(e => e.IsDeleted == false && e.TenantId == tenantId);

                    var projects = from o in filteredProjects
                                   join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                                   from s1 in j1.DefaultIfEmpty()

                                   join o2 in _lookup_contactPersonRepository.GetAll() on o.ContactPersonId equals o2.Id into j2
                                   from s2 in j2.DefaultIfEmpty()

                                   join o3 in _lookup_customerRepository.GetAll() on o.CustomerId equals o3.Id into j3
                                   from s3 in j3.DefaultIfEmpty()

                                   join o4 in _lookup_leadRepository.GetAll() on o.LeadId equals o4.Id into j4
                                   from s4 in j4.DefaultIfEmpty()

                                   join o5 in _lookup_leadSourceRepository.GetAll() on o.LeadSourceId equals o5.Id into j5
                                   from s5 in j5.DefaultIfEmpty()

                                   join o6 in _lookup_projectSiteRepository.GetAll() on o.ProjectSiteId equals o6.Id into j6
                                   from s6 in j6.DefaultIfEmpty()

                                   join o7 in _lookup_projectCommentRepository.GetAll() on o.ProjectCommentId equals o7.Id into j7
                                   from s7 in j7.DefaultIfEmpty()

                                   join o8 in _lookup_projectTypeRepository.GetAll() on o.ProjectTypeId equals o8.Id into j8
                                   from s8 in j8.DefaultIfEmpty()

                                   join o9 in _lookup_projectWishlistRepository.GetAll() on o.ProjectWishlistId equals o9.Id into j9
                                   from s9 in j9.DefaultIfEmpty()

                                   select new
                                   {
                                       o.ProjectName,
                                       o.DescriptionOfWork,
                                       o.QRN,
                                       o.JRN,
                                       o.LeadSourceContextualData,
                                       o.Consultant,
                                       o.Status,
                                       o.Stage,
                                       o.Task,
                                       o.NextTask,
                                       Id = o.Id,
                                       o.CustomerId,
                                       o.ContactPersonId,
                                       o.ProjectSiteId,
                                       o.ProjectTypeId,
                                       o.LastModificationTime,
                                       OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                                       ContactPersonName = s2 == null || s2.Name == null ? "" : s2.Name.ToString(),
                                       CustomerName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
                                       LeadProjectName = s4 == null || s4.ProjectName == null ? "" : s4.ProjectName.ToString(),
                                       LeadSourceTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString(),
                                       ProjectSiteSiteName = s6 == null || s6.SiteName == null ? "" : s6.SiteName.ToString(),
                                       ProjectCommentComment = s7 == null || s7.Content == null ? "" : s7.Content.ToString(),
                                       ProjectTypeCode = s8 == null || s8.Code == null ? "" : s8.Code.ToString(),
                                       ProjectWishlistTitle = s9 == null || s9.Title == null ? "" : s9.Title.ToString()
                                   };

                    var totalCount = await filteredProjects.CountAsync();

                    var dbList = await projects.ToListAsync();
                    var results = new List<GetProjectForViewDto>();

                    var nodeStages = _nodeStageRepository.GetAll();

                    foreach (var o in dbList)
                    {
                        var nodeStage = nodeStages.FirstOrDefault(x => x.Id.ToLower() == o.Stage.ToLower());
                        var res = new GetProjectForViewDto()
                        {
                            Project = new ProjectDto
                            {
                                ProjectName = o.ProjectName,
                                DescriptionOfWork = o.DescriptionOfWork,
                                QRN = o.QRN,
                                JRN = o.JRN,
                                LeadSourceContextualData = o.LeadSourceContextualData,
                                Consultant = o.Consultant,
                                Status = o.Status,
                                Stage = o.Stage,
                                Task = o.Task,
                                NextTask = o.NextTask,
                                Id = o.Id,
                                CustomerId = o.CustomerId,
                                ContactPersonId = o.ContactPersonId,
                                ProjectSiteId = o.ProjectSiteId,
                                ProjectTypeId = o.ProjectTypeId,
                                LastModificationTime = o.LastModificationTime
                            },
                            OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
                            ContactPersonName = o.ContactPersonName,
                            CustomerName = o.CustomerName,
                            LeadProjectName = o.LeadProjectName,
                            LeadSourceTitle = o.LeadSourceTitle,
                            ProjectSiteSiteName = o.ProjectSiteSiteName,
                            ProjectCommentComment = o.ProjectCommentComment,
                            ProjectTypeCode = o.ProjectTypeCode,
                            ProjectWishlistTitle = o.ProjectWishlistTitle,
                            StagehexColorBg = nodeStage == null ? null : nodeStage.HexColorBg
                        };

                        results.Add(res);
                    }

                    return results;
                }
            }

            return null;
        }


        public async Task<List<GetProjectForViewDto>> GetRecent()
        {
            /// TODO - check logic to get actions required, check access permissions
            var filteredProjects = _projectRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.ContactPersonFk)
                        .Include(e => e.CustomerFk)
                        .Include(e => e.LeadFk)
                        .Include(e => e.LeadSourceFk)
                        .Include(e => e.ProjectSiteFk)
                        .Include(e => e.ProjectCommentFk)
                        .Include(e => e.ProjectTypeFk)
                        .Include(e => e.ProjectWishlistFk)
                        .Where(e => e.IsDeleted == false);

            var projects = from o in filteredProjects
                           join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                           from s1 in j1.DefaultIfEmpty()

                           join o2 in _lookup_contactPersonRepository.GetAll() on o.ContactPersonId equals o2.Id into j2
                           from s2 in j2.DefaultIfEmpty()

                           join o3 in _lookup_customerRepository.GetAll() on o.CustomerId equals o3.Id into j3
                           from s3 in j3.DefaultIfEmpty()

                           join o4 in _lookup_leadRepository.GetAll() on o.LeadId equals o4.Id into j4
                           from s4 in j4.DefaultIfEmpty()

                           join o5 in _lookup_leadSourceRepository.GetAll() on o.LeadSourceId equals o5.Id into j5
                           from s5 in j5.DefaultIfEmpty()

                           join o6 in _lookup_projectSiteRepository.GetAll() on o.ProjectSiteId equals o6.Id into j6
                           from s6 in j6.DefaultIfEmpty()

                           join o7 in _lookup_projectCommentRepository.GetAll() on o.ProjectCommentId equals o7.Id into j7
                           from s7 in j7.DefaultIfEmpty()

                           join o8 in _lookup_projectTypeRepository.GetAll() on o.ProjectTypeId equals o8.Id into j8
                           from s8 in j8.DefaultIfEmpty()

                           join o9 in _lookup_projectWishlistRepository.GetAll() on o.ProjectWishlistId equals o9.Id into j9
                           from s9 in j9.DefaultIfEmpty()

                           select new
                           {
                               o.ProjectName,
                               o.DescriptionOfWork,
                               o.QRN,
                               o.JRN,
                               o.LeadSourceContextualData,
                               o.Consultant,
                               o.Status,
                               o.Stage,
                               o.Task,
                               o.NextTask,
                               Id = o.Id,
                               o.CustomerId,
                               o.ContactPersonId,
                               o.ProjectSiteId,
                               o.ProjectTypeId,
                               o.LastModificationTime,
                               OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString(),
                               ContactPersonName = s2 == null || s2.Name == null ? "" : s2.Name.ToString(),
                               CustomerName = s3 == null || s3.Name == null ? "" : s3.Name.ToString(),
                               LeadProjectName = s4 == null || s4.ProjectName == null ? "" : s4.ProjectName.ToString(),
                               LeadSourceTitle = s5 == null || s5.Title == null ? "" : s5.Title.ToString(),
                               ProjectSiteSiteName = s6 == null || s6.SiteName == null ? "" : s6.SiteName.ToString(),
                               ProjectCommentComment = s7 == null || s7.Content == null ? "" : s7.Content.ToString(),
                               ProjectTypeCode = s8 == null || s8.Code == null ? "" : s8.Code.ToString(),
                               ProjectWishlistTitle = s9 == null || s9.Title == null ? "" : s9.Title.ToString()
                           };

            var totalCount = await filteredProjects.CountAsync();

            var dbList = await projects.ToListAsync();
            var results = new List<GetProjectForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetProjectForViewDto()
                {
                    Project = new ProjectDto
                    {

                        ProjectName = o.ProjectName,
                        DescriptionOfWork = o.DescriptionOfWork,
                        QRN = o.QRN,
                        JRN = o.JRN,
                        LeadSourceContextualData = o.LeadSourceContextualData,
                        Consultant = o.Consultant,
                        Status = o.Status,
                        Stage = o.Stage,
                        Task = o.Task,
                        NextTask = o.NextTask,
                        Id = o.Id,
                        CustomerId = o.CustomerId,
                        ContactPersonId = o.ContactPersonId,
                        ProjectSiteId = o.ProjectSiteId,
                        ProjectTypeId = o.ProjectTypeId,
                        LastModificationTime = o.LastModificationTime
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName,
                    ContactPersonName = o.ContactPersonName,
                    CustomerName = o.CustomerName,
                    LeadProjectName = o.LeadProjectName,
                    LeadSourceTitle = o.LeadSourceTitle,
                    ProjectSiteSiteName = o.ProjectSiteSiteName,
                    ProjectCommentComment = o.ProjectCommentComment,
                    ProjectTypeCode = o.ProjectTypeCode,
                    ProjectWishlistTitle = o.ProjectWishlistTitle
                };

                results.Add(res);
            }

            return results;
        }

        [AbpAuthorize(AppPermissions.Pages_Projects_Create)]
        public async Task<GetProjectForViewDto> UpdateRTQ([FromForm] UpdateRTQDto input)
        {
            //var project = ObjectMapper.Map<Project>(input);
            var project = this._projectRepository.Get(input.ProjectId);
            if (project == null) return null;

            if (AbpSession.TenantId != null)
            {
                project.TenantId = (int?)AbpSession.TenantId;
            }
            if (input.Attachments != null && input.Attachments.Count > 0)
            {
                List<ProjectFileInput> projectFilesInput = new List<ProjectFileInput>();
                foreach (var file in input.Attachments)
                {
                    projectFilesInput.Add(new ProjectFileInput()
                    {
                        File = file,
                        ProjectId = input.ProjectId,
                        TaskId = CNodeTasks.RequestToQuote,
                        MetaData = "UpdateRTQ"
                    });
                }

                if (projectFilesInput.Count > 0)
                {
                    var fileURLs = await this._storageManager.UploadProjectFilesAsync(projectFilesInput);
                }
            }

            //var loggedInUser = await _userManager.GetUserByIdAsync((long)AbpSession.UserId);

            //if (input.Attachments != null && input.Attachments.Count > 0)
            //{
            //    /// TODO - upload documents
            //    /// 
            //    var tenancyName = "stc-econsys";// await GetTenancyNameFromTenantId();
            //    var container = await _blobMethods.SetUpContainer(tenancyName);
            //    //_blobMethods.CloudBlobContainer = container;

            //    string documentFolder = "Projects";
            //    foreach (var file in input.Attachments)
            //    {
            //        string fileName = file.FileName;
            //        string targetFilePath = Path.Combine(_env.WebRootPath, "UploadDocuments", fileName);
            //        //var FileName1 = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Replace("\"", "");

            //        //Uploading same file(s) to wwwroot folder
            //        if (!Directory.Exists(targetFilePath))
            //        {
            //            Directory.CreateDirectory(Path.Combine(_env.WebRootPath, "UploadDocuments"));
            //        }
            //        string strFileExt = Path.GetExtension(fileName);
            //        //using (var stream = new FileStream(targetFilePath, FileMode.Create))
            //        //{
            //        //    //Upload the file to the specified path
            //        //    file.CopyTo(stream);

            //        //    stream.Position = 0;
            //        //}

            //        //process file
            //        using (var ms = new MemoryStream())
            //        {
            //            var FileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Replace("\"", "");
            //            //take out the timestamp
            //            //var Timestamp = FindTextBetween(FileName, "[", "]");
            //            //FileName = FileName.Replace("[" + Timestamp + "]", "");

            //            var FileNameWithoutExtension = Path.GetFileNameWithoutExtension(FileName);
            //            var Extension = Path.GetExtension(FileName);
            //            //put the timestamp back in
            //            //FileName = documentFolder + "/" + FileNameWithoutExtension + "[" + GetTimestamp() + "]" + Extension;
            //            FileName = documentFolder + "/" + FileNameWithoutExtension + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + Extension;

            //            var DisplayString = L("DocumentUploadedBy", loggedInUser.FullName, DateTime.Now.ToLocalTime().ToString("ddd d MMM yyyy H:mm"));
            //            var MediaType = file.ContentType;

            //            file.CopyTo(ms);
            //            var fileBytes = ms.ToArray();

            //            // post to BlobStorage
            //            var metaData = new Dictionary<string, string>();
            //            metaData.Add("EntityType", "Project");
            //            //metaData.Add("EntityType", typeof([ClassNameOfContext]).GetProperty(name));

            //            metaData.Add("ProjectId", project.Id.ToString());
            //            metaData.Add("NodeTaskId", CNodeTasks.RequestToQuote);
            //            //metaData.Add("NodeActionId", CNodeActions.SubmitRTQ);
            //            metaData.Add("MediaType", MediaType);
            //            //metaData.Add("TenantId", AbpSession.TenantId.ToString());
            //            metaData.Add("UserId", AbpSession.UserId.ToString());
            //            metaData.Add("DisplayString", DisplayString);
            //            metaData.Add("DocumentFolder", documentFolder);

            //            var blob = await _blobMethods.UploadFromByteArray(fileBytes, FileName, MediaType, metaData, "no-cache");

            //            // Get a reference to a blob  
            //            //CloudBlockBlob blockBlob = container.GetBlockBlobReference(file.FileName);
            //            string URL = blob.Uri.ToString();
            //        }
            //    }

            //}

            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.PreOrder,
                TaskId = CNodeTasks.RequestToQuote,
                StatusId = input.StatusId,
                Comment = input.Comment,
                LoggedInUserId = (long)AbpSession.UserId
            });

            project = await _projectRepository.FirstOrDefaultAsync(input.ProjectId);
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);

            return result;
        }

        public async void UploadFileFromAzure(List<string> fileIdList)
        {
            if (fileIdList.Count > 0)
            {
                foreach (var item in fileIdList)
                {
                    ProjectFile file = _repositoryProjectFile.FirstOrDefault(x => x.Id.ToString() == item);
                    file.ParentId = file.Id;
                    file.Id = Guid.Empty;
                    file.CreationTime = DateTime.Now;
                    file.CreatorUserId = AbpSession.UserId;
                    await _repositoryProjectFile.InsertAsync(file);
                }
            }
        }

        public async Task<string> DownloadRequestDocument(string azureFileUrl)
        {
            string linkWithToken = await _storageManager.GenerateAzureSasTokenUrl(new Uri(azureFileUrl));
            return linkWithToken;
        }

        public async Task<string> GetDocument(Guid id)
        {
            try
            {
                return await _storageManager.GetProjectFile(id);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<GetProjectForViewDto> StatusAction([FromForm] UpdateStatusDto input)
        {
            var check = await _projectPermissionManager.CheckAccess(new ProjectPermissionEvent()
            {
                ProjectId = input.ProjectId,
                Task = input.TaskId
            });
            if (!check)
            {
                throw new UserFriendlyException(this.L("AccessDenied"), this.L("Access Denied"));
            }

            var project = await _projectRepository.GetAsync(input.ProjectId);
            if (project == null)
            {
                throw new UserFriendlyException("Not Found", "Couldn't find project with these details.");
            }

            if (project.Task == CNodeTasks.RequestToQuote)
            {
                if (project.QRN == null)
                {
                    project.QRN = await _refNoConfigManager.GenerateQRNAsync(project.Id);
                }
            }

            await EventBus.TriggerAsync(new EditProjectEventData()
            {
                Project = project,
                StageId = CNodeStages.PreOrder,
                TaskId = input.TaskId,
                StatusId = input.StatusId,
                Comment = input.Comment,
                LoggedInUserId = (long)AbpSession.UserId
            });

            project = await _projectRepository.FirstOrDefaultAsync(input.ProjectId);
            GetProjectForViewDto result = new GetProjectForViewDto();
            result.Project = ObjectMapper.Map<ProjectDto>(project);

            return result;
        }

        public async Task<List<ProjectFileDto>> GetProjectFileList(long projectId, string taskId = null)
        {
            return await _repositoryProjectFile.GetAll()
                .Where(x => x.ProjectId == projectId)
                .WhereIf(!String.IsNullOrEmpty(taskId), x => x.NodeTaskId == taskId)
                .Select(projectFile => new ProjectFileDto
                {
                    Id = projectFile.Id,
                    Name = projectFile.Name,
                    FullPath = projectFile.FullPath,
                    Extension = projectFile.Extension,
                    FileSize = projectFile.FileSize,
                    MetaData = projectFile.MetaData,
                    NodeTaskId = projectFile.NodeTaskId
                }).ToListAsync();
        }

        public async Task<List<GetProjectRuleForViewDto>> GetProjectRulesForProject(long id, string taskId)
        {
            List<GetProjectRuleForViewDto> projectRules = new List<GetProjectRuleForViewDto>();
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    //var check = _projectPermissionManager.grantOrDenyPermission( id);
                    //var projectAction = await _projectActionRepository.FirstOrDefaultAsync(x => x.ProjectId == id && x.NodeTaskId.ToLower() == taskId.ToLower());
                    var projectActions = await _projectActionRepository.GetAll()
                        .Where(e => e.ProjectId == id && e.NodeTaskId.ToLower() == taskId.ToLower() && e.IsDeleted == false)// && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .OrderByDescending(x => x.CreationTime).ToListAsync();

                    if (projectActions == null || projectActions.Count == 0)
                    {
                        return null;
                    }
                    var projectAction = projectActions[0];
                    var project = _projectRepository.Get(id);


                    if (project.NextTask == CNodeTasks.PermissionToQuote)
                    {
                        projectRules = await _projectRuleRepository.GetAllIncluding(x => x.ProjectFk, x => x.RuleFlagFk, x => x.ProjectActionFk)
                                       .Where(e => e.ProjectId == id && e.ProjectActionId == projectAction.Id && e.IsDeleted == false && e.RuleFlagId == CRuleFlags.Red)// && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                                       .Select(x => new GetProjectRuleForViewDto()
                                       {
                                           ProjectRule = ObjectMapper.Map<ProjectRuleDto>(x),
                                           ProjectProjectName = x.ProjectFk.ProjectName,
                                           ProjectActionStatus = x.ProjectActionFk.Status,
                                           RuleFlagTitle = x.RuleFlagFk.Title
                                       })
                                       .ToListAsync();
                    }
                    else if (project.NextTask == CNodeTasks.EngineeringInvolvementwithQuote || project.NextTask == CNodeTasks.EngineeringInvolvementwithRevisedQuote || project.NextTask == CNodeTasks.EngineeringReviewofQuote || project.NextTask == CNodeTasks.EngineeringReviewofRevisedQuote || project.NextTask == CNodeTasks.CommercialInvolvementwithQuote || project.NextTask == CNodeTasks.CommercialInvolvementwithRevisedQuote || project.NextTask == CNodeTasks.CommercialReviewofQuote || project.NextTask == CNodeTasks.CommercialReviewofRevisedQuote)
                    {
                        var ruleCategory = "";
                        if (project.NextTask == CNodeTasks.EngineeringInvolvementwithQuote || project.NextTask == CNodeTasks.EngineeringInvolvementwithRevisedQuote || project.NextTask == CNodeTasks.EngineeringReviewofQuote || project.NextTask == CNodeTasks.EngineeringReviewofRevisedQuote)
                        {
                            ruleCategory = CRuleCategories.Engineering;
                        }
                        else if (project.NextTask == CNodeTasks.CommercialInvolvementwithQuote || project.NextTask == CNodeTasks.CommercialInvolvementwithRevisedQuote || project.NextTask == CNodeTasks.CommercialReviewofQuote || project.NextTask == CNodeTasks.CommercialReviewofRevisedQuote)
                        {
                            ruleCategory = CRuleCategories.Commercial;
                        }

                        projectRules = await _projectRuleRepository.GetAllIncluding(x => x.ProjectFk, x => x.RuleFlagFk, x => x.ProjectActionFk)
                                        .Where(e => e.ProjectId == id && e.ProjectActionId == projectAction.Id && e.RuleCategory == ruleCategory && e.IsDeleted == false)// && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                                        .Select(x => new GetProjectRuleForViewDto()
                                        {
                                            ProjectRule = ObjectMapper.Map<ProjectRuleDto>(x),
                                            ProjectProjectName = x.ProjectFk.ProjectName,
                                            ProjectActionStatus = x.ProjectActionFk.Status,
                                            RuleFlagTitle = x.RuleFlagFk.Title
                                        })
                                        .ToListAsync();
                    }
                    else
                    {
                        var ruleKey = "";
                        if (project.NextTask == CNodeTasks.PrepareQuoteCLApproval || project.NextTask == CNodeTasks.RevisedQuoteCommercialApproval)
                        {
                            ruleKey = CRuleKey.QuotationFormate;
                        }
                        else if (project.NextTask == CNodeTasks.ApprovaltoSubmitQuote || project.NextTask == CNodeTasks.ApprovaltoSubmitRevisedQuote)
                        {
                            ruleKey = CRuleKey.AuthCriteria;
                        }
                        projectRules = await _projectRuleRepository.GetAllIncluding(x => x.ProjectFk, x => x.RuleFlagFk, x => x.ProjectActionFk)
                                        .Where(e => e.ProjectId == id && e.ProjectActionId == projectAction.Id && e.RuleKey == ruleKey && e.IsDeleted == false)// && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                                        .Select(x => new GetProjectRuleForViewDto()
                                        {
                                            ProjectRule = ObjectMapper.Map<ProjectRuleDto>(x),
                                            ProjectProjectName = x.ProjectFk.ProjectName,
                                            ProjectActionStatus = x.ProjectActionFk.Status,
                                            RuleFlagTitle = x.RuleFlagFk.Title
                                        })
                                        .ToListAsync();
                    }
                }
            }

            return projectRules;
        }

        public async Task<List<GetProjectQFDelegationForViewDto>> GetMyDelegations()
        {
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var result = _projectQFDelegationRepository.GetAll()
                        .Include(e => e.ProjectFk)
                        .Include(e => e.AssignToFk)
                        .Include(e => e.ProjectQuoteFormFk)
                        .Where(e => e.IsCurrent == true && e.AssignTo == AbpSession.UserId)
                        .Select(o => new GetProjectQFDelegationForViewDto()
                        {
                            ProjectQFDelegation = new ProjectQFDelegationDto
                            {
                                Category = o.Category,
                                Revision = o.Revision,
                                RequiredByDate = o.RequiredByDate,
                                RequestComments = o.RequestComments,
                                ResponseDate = o.ResponseDate,
                                ResponseComments = o.ResponseComments,
                                IsCurrent = o.IsCurrent,
                                DisplayOrder = o.DisplayOrder,
                                AssignTo = o.AssignTo,
                                Id = o.Id,
                                ProjectId = o.ProjectId,
                                CreatorUserId = o.CreatorUserId,
                                LastModificationTime = o.LastModificationTime == null ? o.CreationTime : o.LastModificationTime
                            },
                            ProjectProjectName = o.ProjectFk.ProjectName,
                            UserName = o.AssignToFk.UserName,
                            ProjectQuoteFormQRN = o.ProjectQuoteFormFk.QRN
                        })
                        .OrderByDescending(x => x.ProjectQFDelegation.DisplayOrder)
                        .ToList();

                    return result;
                }
            }

            return null;
        }

        public async Task<List<GetProjectPersonnelForViewDto>> GetProjectPersonnel(long projectId)
        {
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var filteredProjectPersonnels = _projectPersonnelRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .Include(e => e.ProjectFk)
                        .Include(e => e.UserFk)
                        .Include(e => e.RoleFk)
                        .Include(e => e.NodeStageFk)
                        .Include(e => e.NodeTaskFk)
                        .Where(e => e.ProjectId == projectId && e.IsDeleted == false);

                    var results = new List<GetProjectPersonnelForViewDto>();

                    foreach (var o in filteredProjectPersonnels)
                    {
                        var res = new GetProjectPersonnelForViewDto()
                        {
                            ProjectPersonnel = new ProjectPersonnelDto
                            {
                                Id = o.Id,
                                ProjectId = o.ProjectId,
                                RoleId = o.RoleId,
                                UserId = o.UserId
                            },
                            OrganizationUnitDisplayName = o.OrganizationUnitFk == null ? null : o.OrganizationUnitFk.DisplayName,
                            ProjectProjectName = o.ProjectFk == null ? null : o.ProjectFk.ProjectName,
                            UserName = o.UserFk == null ? null : o.UserFk.UserName,
                            FullName = o.UserFk == null ? null : o.UserFk.FullName,
                            Email = o.UserFk == null ? null : o.UserFk.EmailAddress,
                            Phone = o.UserFk == null ? null : o.UserFk.PhoneNumber,
                            RoleName = o.RoleFk == null ? null : o.RoleFk.Name,
                            NodeStageId = o.NodeStageId,
                            NodeTaskTaskName = o.NodeTaskFk == null ? null : o.NodeTaskFk.TaskName
                        };

                        results.Add(res);
                    }

                    return results;
                }
            }

            return null;
        }

        public async Task<List<SalesDashBoardCardDataDto>> SalesDashBoardCardData(string sortType)
        {
            List<SalesDashBoardCardDataDto> result = new List<SalesDashBoardCardDataDto>();

            int currentMonth = DateTime.Now.Month;
            int currentYear = DateTime.Now.Year;
            int qrtr = (int)Math.Ceiling(DateTime.Today.Month / 3m);
            int mnth = 0;
            if (qrtr == 1) mnth = 1;
            else if (qrtr == 2) mnth = 4;
            else if (qrtr == 3) mnth = 7;
            else if (qrtr == 4) mnth = 10;

            var projects = _projectRepository.GetAll().Where(x => x.IsDeleted == false);

            switch (sortType)
            {
                case "month":
                    projects = projects.Where(x => x.CreationTime.Month == currentMonth && x.CreationTime.Year == currentYear);
                    break;
                case "year":
                    projects = projects.Where(x => x.CreationTime.Year == currentYear);
                    break;
                case "quarter":
                    projects = projects.Where(x => x.CreationTime.Month >= mnth && x.CreationTime.Month <= mnth + 3 && x.CreationTime.Year == currentYear);
                    break;
                default:
                    break;
            }

            if (projects.ToList().Count > 0)
            {
                var nodeTasks = _nodeTaskRepository.GetAll().Where(x => x.IsDeleted == false);
                foreach (var item in nodeTasks)
                {
                    //List<long> ids = null;
                    List<decimal?> itemList = null;
                    var count = 0;
                    var value = 0;
                    foreach (var proj in projects)
                    {
                        switch (item.Id)
                        {
                            case "status-of-submitted-quote":
                                //ids = projects.Select(x => x.Id).ToList();
                                //itemList = _projectQuoteFormRepository.GetAll().Where(x => ids.Contains(x.ProjectId)).Select(x => x.OverAllProjectSell).ToList();
                                itemList = _projectQuoteFormRepository.GetAll().Where(x => x.ProjectId == proj.Id && x.Id == proj.ProjectQuoteFormId).Select(x => x.OverAllProjectSell).ToList();
                                value += (int)itemList.Sum();
                                if (itemList.Count() > 0) count++;
                                break;
                            case "submit-quote":
                                itemList = _projectQuoteFormRepository.GetAll().Where(x => x.ProjectId == proj.Id && x.Id == proj.ProjectQuoteFormId).Select(x => x.OverAllProjectSell).ToList();
                                value += (int)itemList.Sum();
                                if (itemList.Count() > 0) count++;
                                break;
                            case "customer-commitment-acceptance":
                                itemList = _ProjectOACustCommAcceptanceRepository.GetAll().Where(x => x.ProjectId == proj.Id).Select(x => x.SlrProposedContractValueCommit).ToList();
                                value += (int)itemList.Sum();
                                if (itemList.Count() > 0) count++;
                                break;
                            default:
                                break;
                        }
                    }
                    result.Add(new SalesDashBoardCardDataDto()
                    {
                        TaskId = item.Id,
                        Count = count,
                        Value = value,
                    });
                }
            }
            return result;
        }

    }
}