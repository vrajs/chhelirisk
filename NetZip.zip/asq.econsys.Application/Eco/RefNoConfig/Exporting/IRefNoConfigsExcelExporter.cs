﻿using System.Collections.Generic;
using asq.econsys.Eco.RefNoConfig.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Eco.RefNoConfig.Exporting
{
    public interface IRefNoConfigsExcelExporter
    {
        FileDto ExportToFile(List<GetRefNoConfigForViewDto> refNoConfigs);
    }
}