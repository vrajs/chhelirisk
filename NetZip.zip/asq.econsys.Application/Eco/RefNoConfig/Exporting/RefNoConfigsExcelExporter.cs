﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Eco.RefNoConfig.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Eco.RefNoConfig.Exporting
{
    public class RefNoConfigsExcelExporter : NpoiExcelExporterBase, IRefNoConfigsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public RefNoConfigsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetRefNoConfigForViewDto> refNoConfigs)
        {
            return CreateExcelPackage(
                "RefNoConfigs.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("RefNoConfigs"));

                    AddHeader(
                        sheet,
                        L("ProjectType"),
                        L("QRNAutoGenerate"),
                        L("QRNMandatory"),
                        L("QRNMaintainRevision"),
                        L("QRNLinkedProjHasSAmeQRN"),
                        L("JRNSameAsQuoteNo"),
                        L("JRNAutoGenerate"),
                        (L("OrganizationUnit")) + L("DisplayName")
                        );

                    AddObjects(
                        sheet, refNoConfigs,
                        _ => _.RefNoConfig.ProjectType,
                        _ => _.RefNoConfig.QRNAutoGenerate,
                        _ => _.RefNoConfig.QRNMandatory,
                        _ => _.RefNoConfig.QRNMaintainRevision,
                        _ => _.RefNoConfig.QRNLinkedProjHasSAmeQRN,
                        _ => _.RefNoConfig.JRNSameAsQuoteNo,
                        _ => _.RefNoConfig.JRNAutoGenerate,
                        _ => _.OrganizationUnitDisplayName
                        );

                });
        }
    }
}