﻿using asq.econsys.Eco.RefNoConfig;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.RefNoConfig.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.RefNoConfig
{
    [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigDetails)]
    public class RefNoConfigDetailsAppService : econsysAppServiceBase, IRefNoConfigDetailsAppService
    {
        private readonly IRepository<RefNoConfigDetails, long> _refNoConfigDetailsRepository;
        private readonly IRepository<RefNoConfig, long> _lookup_refNoConfigRepository;

        public RefNoConfigDetailsAppService(IRepository<RefNoConfigDetails, long> refNoConfigDetailsRepository, IRepository<RefNoConfig, long> lookup_refNoConfigRepository)
        {
            _refNoConfigDetailsRepository = refNoConfigDetailsRepository;
            _lookup_refNoConfigRepository = lookup_refNoConfigRepository;

        }
        public async Task<List<CreateOrEditRefNoConfigDetailsDto>> GetRefNoConfigTypeDetails(string ProjectType)
        {
            var type_details = _refNoConfigDetailsRepository.GetAll()
               .Include(e => e.RefNoConfigFk)
               .Where(e => (ProjectType == e.ProjectType));
            var refNoConfigsDetails = from o in type_details
                               join o1 in _lookup_refNoConfigRepository.GetAll() on o.RefNoConfigId equals o1.Id into j1
                               from s1 in j1.DefaultIfEmpty()

                               select new
                               {

                                   o.ProjectType,
                                   o.Prefix,
                                   o.StartingFrom,
                                   o.MinDigits,
                                   o.ValueType,
                                   o.RefType,
                                   o.Suffix,
                                   Id = o.Id,
                               };
            var totalCount = await refNoConfigsDetails.CountAsync();

            var dbList = await refNoConfigsDetails.ToListAsync();
            var results = new List<CreateOrEditRefNoConfigDetailsDto>();

            foreach (var o in dbList)
            {
                var res = new CreateOrEditRefNoConfigDetailsDto
                {
                        RefType = o.RefType,
                        ValueType = o.ValueType,
                        Prefix = o.Prefix,
                        StartingFrom = o.StartingFrom,
                        MinDigits = o.MinDigits,
                        Suffix = o.Suffix,
                        Id = o.Id,
                };

                results.Add(res);
            }

                return results;
        }
        public async Task<PagedResultDto<GetRefNoConfigDetailsForViewDto>> GetAll(GetAllRefNoConfigDetailsInput input)
        {

            var filteredRefNoConfigDetails = _refNoConfigDetailsRepository.GetAll()
                        .Include(e => e.RefNoConfigFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.RefType.Contains(input.Filter) || e.ValueType.Contains(input.Filter) || e.Prefix.Contains(input.Filter) || e.Suffix.Contains(input.Filter) || e.DisplayOrder.Contains(input.Filter) || e.PreviewNum.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RefTypeFilter), e => e.RefType == input.RefTypeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ValueTypeFilter), e => e.ValueType == input.ValueTypeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PrefixFilter), e => e.Prefix == input.PrefixFilter)
                        .WhereIf(input.MinStartingFromFilter != null, e => e.StartingFrom >= input.MinStartingFromFilter)
                        .WhereIf(input.MaxStartingFromFilter != null, e => e.StartingFrom <= input.MaxStartingFromFilter)
                        .WhereIf(input.MinMinDigitsFilter != null, e => e.MinDigits >= input.MinMinDigitsFilter)
                        .WhereIf(input.MaxMinDigitsFilter != null, e => e.MinDigits <= input.MaxMinDigitsFilter)
                        .WhereIf(input.MinCurrentDigitFilter != null, e => e.CurrentDigit >= input.MinCurrentDigitFilter)
                        .WhereIf(input.MaxCurrentDigitFilter != null, e => e.CurrentDigit <= input.MaxCurrentDigitFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.SuffixFilter), e => e.Suffix == input.SuffixFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DisplayOrderFilter), e => e.DisplayOrder == input.DisplayOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.PreviewNumFilter), e => e.PreviewNum == input.PreviewNumFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.RefNoConfigProjectTypeFilter), e => e.RefNoConfigFk != null && e.RefNoConfigFk.ProjectType == input.RefNoConfigProjectTypeFilter)
                        .WhereIf(input.RefNoConfigIdFilter.HasValue, e => false || e.RefNoConfigId == input.RefNoConfigIdFilter.Value);

            var pagedAndFilteredRefNoConfigDetails = filteredRefNoConfigDetails
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var refNoConfigDetails = from o in pagedAndFilteredRefNoConfigDetails
                                     join o1 in _lookup_refNoConfigRepository.GetAll() on o.RefNoConfigId equals o1.Id into j1
                                     from s1 in j1.DefaultIfEmpty()

                                     select new
                                     {

                                         o.RefType,
                                         o.ValueType,
                                         o.Prefix,
                                         o.StartingFrom,
                                         o.MinDigits,
                                         o.CurrentDigit,
                                         o.Suffix,
                                         o.DisplayOrder,
                                         o.PreviewNum,
                                         Id = o.Id,
                                         RefNoConfigProjectType = s1 == null || s1.ProjectType == null ? "" : s1.ProjectType.ToString()
                                     };

            var totalCount = await filteredRefNoConfigDetails.CountAsync();

            var dbList = await refNoConfigDetails.ToListAsync();
            var results = new List<GetRefNoConfigDetailsForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetRefNoConfigDetailsForViewDto()
                {
                    RefNoConfigDetails = new RefNoConfigDetailsDto
                    {

                        RefType = o.RefType,
                        ValueType = o.ValueType,
                        Prefix = o.Prefix,
                        StartingFrom = o.StartingFrom,
                        MinDigits = o.MinDigits,
                        CurrentDigit = o.CurrentDigit,
                        Suffix = o.Suffix,
                        DisplayOrder = o.DisplayOrder,
                        PreviewNum = o.PreviewNum,
                        Id = o.Id,
                    },
                    RefNoConfigProjectType = o.RefNoConfigProjectType
                };

                results.Add(res);
            }

            return new PagedResultDto<GetRefNoConfigDetailsForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetRefNoConfigDetailsForViewDto> GetRefNoConfigDetailsForView(long id)
        {
            var refNoConfigDetails = await _refNoConfigDetailsRepository.GetAsync(id);

            var output = new GetRefNoConfigDetailsForViewDto { RefNoConfigDetails = ObjectMapper.Map<RefNoConfigDetailsDto>(refNoConfigDetails) };

            if (output.RefNoConfigDetails.RefNoConfigId != null)
            {
                var _lookupRefNoConfig = await _lookup_refNoConfigRepository.FirstOrDefaultAsync((long)output.RefNoConfigDetails.RefNoConfigId);
                output.RefNoConfigProjectType = _lookupRefNoConfig?.ProjectType?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigDetails_Edit)]
        public async Task<GetRefNoConfigDetailsForEditOutput> GetRefNoConfigDetailsForEdit(EntityDto<long> input)
        {
            var refNoConfigDetails = await _refNoConfigDetailsRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRefNoConfigDetailsForEditOutput { RefNoConfigDetails = ObjectMapper.Map<CreateOrEditRefNoConfigDetailsDto>(refNoConfigDetails) };

            if (output.RefNoConfigDetails.RefNoConfigId != null)
            {
                var _lookupRefNoConfig = await _lookup_refNoConfigRepository.FirstOrDefaultAsync((long)output.RefNoConfigDetails.RefNoConfigId);
                output.RefNoConfigProjectType = _lookupRefNoConfig?.ProjectType?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditRefNoConfigDetailsDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigDetails_Create)]
        protected virtual async Task Create(CreateOrEditRefNoConfigDetailsDto input)
        {
            var refNoConfigDetails = ObjectMapper.Map<RefNoConfigDetails>(input);
            //var prefixLength = refNoConfigDetails.StartingFrom.ToString().Length;
            //refNoConfigDetails.PreviewNum = refNoConfigDetails.Prefix + refNoConfigDetails.StartingFrom.ToString().PadLeft(refNoConfigDetails.MinDigits - prefixLength, '0') + refNoConfigDetails.Suffix;
            if (AbpSession.TenantId != null)
            {
                refNoConfigDetails.TenantId = (int?)AbpSession.TenantId;
            }

            await _refNoConfigDetailsRepository.InsertAsync(refNoConfigDetails);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigDetails_Edit)]
        protected virtual async Task Update(CreateOrEditRefNoConfigDetailsDto input)
        {
            var refNoConfigDetails = await _refNoConfigDetailsRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, refNoConfigDetails);

        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigDetails_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _refNoConfigDetailsRepository.DeleteAsync(input.Id);
        }
        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigDetails)]
        public async Task<List<RefNoConfigDetailsRefNoConfigLookupTableDto>> GetAllRefNoConfigForTableDropdown()
        {
            return await _lookup_refNoConfigRepository.GetAll()
                .Select(refNoConfig => new RefNoConfigDetailsRefNoConfigLookupTableDto
                {
                    Id = refNoConfig.Id,
                    DisplayName = refNoConfig == null || refNoConfig.ProjectType == null ? "" : refNoConfig.ProjectType.ToString()
                }).ToListAsync();
        }

    }
}