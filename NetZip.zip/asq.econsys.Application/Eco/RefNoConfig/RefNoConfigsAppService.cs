﻿using Abp.Organizations;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.RefNoConfig.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.RefNoConfig
{
    [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigs)]
    public class RefNoConfigsAppService : econsysAppServiceBase, IRefNoConfigsAppService
    {
        private readonly IRepository<RefNoConfig, long> _refNoConfigRepository;
        private readonly IRepository<OrganizationUnit, long> _lookup_organizationUnitRepository;
        private readonly IRefNoConfigDetailsAppService _refNoConfigDetailsAppService;
        private readonly IRepository<RefNoConfigDetails, long> _refNoConfigDetailsRepository;
        public RefNoConfigsAppService(
            IRepository<RefNoConfig, long> refNoConfigRepository,
            IRepository<OrganizationUnit, long> lookup_organizationUnitRepository,
            IRefNoConfigDetailsAppService refNoConfigDetailsAppService,
            IRepository<RefNoConfigDetails, long> refNoConfigDetailsRepository)
        {
            _refNoConfigRepository = refNoConfigRepository;
            _lookup_organizationUnitRepository = lookup_organizationUnitRepository;
            _refNoConfigDetailsAppService = refNoConfigDetailsAppService;
            _refNoConfigDetailsRepository = refNoConfigDetailsRepository;
        }

        public async Task<RefNoConfigDto> GetTypeDetails(string ProjectType)
        {
            var type_details = _refNoConfigRepository.GetAll()
               .Include(e => e.OrganizationUnitFk)
               .Where(e => (ProjectType.ToLower() == e.ProjectType.ToLower()));
            var refNoConfigs = from o in type_details
                               join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                               from s1 in j1.DefaultIfEmpty()

                               select new
                               {

                                   o.ProjectType,
                                   o.QRNAutoGenerate,
                                   o.QRNMandatory,
                                   o.QRNMaintainRevision,
                                   o.QRNLinkedProjHasSAmeQRN,
                                   o.JRNSameAsQuoteNo,
                                   o.JRNAutoGenerate,
                                   o.JRNMandatory,
                                   o.OrganizationUnitId,
                                   Id = o.Id,
                                   //OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                               };
            var dbList = await refNoConfigs.FirstOrDefaultAsync();
            var result = new RefNoConfigDto();
            if (dbList != null)
            {
                var rnRecords = await _refNoConfigDetailsRepository.GetAll().Where(x => x.RefNoConfigId == dbList.Id).ToListAsync();

                result.ProjectType = dbList.ProjectType;
                result.JRNAutoGenerate = dbList.JRNAutoGenerate;
                result.JRNSameAsQuoteNo = dbList.JRNSameAsQuoteNo;
                result.JRNMandatory = dbList.JRNMandatory;
                result.QRNAutoGenerate = dbList.QRNAutoGenerate;
                result.QRNLinkedProjHasSAmeQRN = dbList.QRNLinkedProjHasSAmeQRN;
                result.QRNMaintainRevision = dbList.QRNMaintainRevision;
                result.QRNMandatory = dbList.QRNMandatory;
                result.Id = dbList.Id;
                result.RefNumberRecords = ObjectMapper.Map<List<CreateOrEditRefNoConfigDetailsDto>>(rnRecords);
            }
            else
            {
            }
            return result;
        }

        public async Task<PagedResultDto<GetRefNoConfigForViewDto>> GetAll(GetAllRefNoConfigsInput input)
        {
            var filteredRefNoConfigs = _refNoConfigRepository.GetAll()
                        .Include(e => e.OrganizationUnitFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.ProjectType.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ProjectTypeFilter), e => e.ProjectType == input.ProjectTypeFilter)
                        .WhereIf(input.QRNAutoGenerateFilter.HasValue && input.QRNAutoGenerateFilter > -1, e => (input.QRNAutoGenerateFilter == 1 && e.QRNAutoGenerate) || (input.QRNAutoGenerateFilter == 0 && !e.QRNAutoGenerate))
                        .WhereIf(input.QRNMandatoryFilter.HasValue && input.QRNMandatoryFilter > -1, e => (input.QRNMandatoryFilter == 1 && e.QRNMandatory) || (input.QRNMandatoryFilter == 0 && !e.QRNMandatory))
                        .WhereIf(input.QRNMaintainRevisionFilter.HasValue && input.QRNMaintainRevisionFilter > -1, e => (input.QRNMaintainRevisionFilter == 1 && e.QRNMaintainRevision) || (input.QRNMaintainRevisionFilter == 0 && !e.QRNMaintainRevision))
                        .WhereIf(input.QRNLinkedProjHasSAmeQRNFilter.HasValue && input.QRNLinkedProjHasSAmeQRNFilter > -1, e => (input.QRNLinkedProjHasSAmeQRNFilter == 1 && e.QRNLinkedProjHasSAmeQRN) || (input.QRNLinkedProjHasSAmeQRNFilter == 0 && !e.QRNLinkedProjHasSAmeQRN))
                        .WhereIf(input.JRNSameAsQuoteNoFilter.HasValue && input.JRNSameAsQuoteNoFilter > -1, e => (input.JRNSameAsQuoteNoFilter == 1 && e.JRNSameAsQuoteNo) || (input.JRNSameAsQuoteNoFilter == 0 && !e.JRNSameAsQuoteNo))
                        .WhereIf(input.JRNAutoGenerateFilter.HasValue && input.JRNAutoGenerateFilter > -1, e => (input.JRNAutoGenerateFilter == 1 && e.JRNAutoGenerate) || (input.JRNAutoGenerateFilter == 0 && !e.JRNAutoGenerate))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.OrganizationUnitDisplayNameFilter), e => e.OrganizationUnitFk != null && e.OrganizationUnitFk.DisplayName == input.OrganizationUnitDisplayNameFilter);

            var pagedAndFilteredRefNoConfigs = filteredRefNoConfigs
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var refNoConfigs = from o in pagedAndFilteredRefNoConfigs
                               join o1 in _lookup_organizationUnitRepository.GetAll() on o.OrganizationUnitId equals o1.Id into j1
                               from s1 in j1.DefaultIfEmpty()

                               select new
                               {

                                   o.ProjectType,
                                   o.QRNAutoGenerate,
                                   o.QRNMandatory,
                                   o.QRNMaintainRevision,
                                   o.QRNLinkedProjHasSAmeQRN,
                                   o.JRNSameAsQuoteNo,
                                   o.JRNAutoGenerate,
                                   Id = o.Id,
                                   OrganizationUnitDisplayName = s1 == null || s1.DisplayName == null ? "" : s1.DisplayName.ToString()
                               };

            var totalCount = await filteredRefNoConfigs.CountAsync();

            var dbList = await refNoConfigs.ToListAsync();
            var results = new List<GetRefNoConfigForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetRefNoConfigForViewDto()
                {
                    RefNoConfig = new RefNoConfigDto
                    {

                        ProjectType = o.ProjectType,
                        QRNAutoGenerate = o.QRNAutoGenerate,
                        QRNMandatory = o.QRNMandatory,
                        QRNMaintainRevision = o.QRNMaintainRevision,
                        QRNLinkedProjHasSAmeQRN = o.QRNLinkedProjHasSAmeQRN,
                        JRNSameAsQuoteNo = o.JRNSameAsQuoteNo,
                        JRNAutoGenerate = o.JRNAutoGenerate,
                        Id = o.Id,
                    },
                    OrganizationUnitDisplayName = o.OrganizationUnitDisplayName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetRefNoConfigForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetRefNoConfigForViewDto> GetRefNoConfigForView(long id)
        {
            var refNoConfig = await _refNoConfigRepository.GetAsync(id);

            var output = new GetRefNoConfigForViewDto { RefNoConfig = ObjectMapper.Map<RefNoConfigDto>(refNoConfig) };

            if (output.RefNoConfig.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RefNoConfig.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigs_Edit)]
        public async Task<GetRefNoConfigForEditOutput> GetRefNoConfigForEdit(EntityDto<long> input)
        {
            var refNoConfig = await _refNoConfigRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetRefNoConfigForEditOutput { RefNoConfig = ObjectMapper.Map<CreateOrEditRefNoConfigDto>(refNoConfig) };

            if (output.RefNoConfig.OrganizationUnitId != null)
            {
                var _lookupOrganizationUnit = await _lookup_organizationUnitRepository.FirstOrDefaultAsync((long)output.RefNoConfig.OrganizationUnitId);
                output.OrganizationUnitDisplayName = _lookupOrganizationUnit?.DisplayName?.ToString();
            }

            return output;
        }

        public async Task<RefNoConfigDto> CreateOrEdit(CreateOrEditRefNoConfigDto input)
        {
            if (input.Id == null || input.Id == 0)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
            var output = await GetTypeDetails(input.ProjectType);
            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigs_Create)]
        protected virtual async Task Create(CreateOrEditRefNoConfigDto input)
        {
            var refNoConfig = ObjectMapper.Map<RefNoConfig>(input);
            List<CreateOrEditRefNoConfigDetailsDto> refNoRecords = input.RefNumberRecords;
            if (refNoConfig.JRNSameAsQuoteNo)
            {
                refNoConfig.JRNAutoGenerate = false;
            }
            else if (refNoConfig.JRNAutoGenerate)
            {
                refNoConfig.JRNSameAsQuoteNo = false;
            }
            //else if (!refNoConfig.JRNAutoGenerate && !refNoConfig.JRNSameAsQuoteNo)
            //{
            //    refNoConfig.JRNMandatory = true;
            //}
            if (AbpSession.TenantId != null)
            {
                refNoConfig.TenantId = (int?)AbpSession.TenantId;
            }
            var refNoConfigId = await _refNoConfigRepository.InsertAndGetIdAsync(refNoConfig);
            int i = 0;
            foreach (CreateOrEditRefNoConfigDetailsDto record in refNoRecords)
            {
                record.ProjectType = refNoConfig.ProjectType;
                record.RefNoConfigId = refNoConfigId;
                record.DisplayOrder = i.ToString();
                await _refNoConfigDetailsAppService.CreateOrEdit(record);
                i++;
            }
            if (input.JRNSameAsQuoteNo)
            {
                foreach (CreateOrEditRefNoConfigDetailsDto record in refNoRecords)
                {
                    record.RefType = RefNoConfigConsts.JobRefNumber;
                    record.ProjectType = refNoConfig.ProjectType;
                    await _refNoConfigDetailsAppService.CreateOrEdit(record);
                }
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigs_Edit)]
        protected virtual async Task Update(CreateOrEditRefNoConfigDto input)
        {
            if (input.JRNSameAsQuoteNo)
            {
                input.JRNAutoGenerate = false;
            }
            else if (input.JRNAutoGenerate)
            {
                input.JRNSameAsQuoteNo = false;
            }
            var refNoConfig = await _refNoConfigRepository.FirstOrDefaultAsync((long)input.Id);

            ObjectMapper.Map(input, refNoConfig);
            var rnRecordsList = await _refNoConfigDetailsRepository.GetAll().Where(x => x.RefNoConfigId == refNoConfig.Id).ToListAsync();
            var rnRecords = ObjectMapper.Map<List<CreateOrEditRefNoConfigDetailsDto>>(rnRecordsList);

            List<CreateOrEditRefNoConfigDetailsDto> jrnRecords = new List<CreateOrEditRefNoConfigDetailsDto>();
            List<CreateOrEditRefNoConfigDetailsDto> qrnRecords = new List<CreateOrEditRefNoConfigDetailsDto>();
            List<CreateOrEditRefNoConfigDetailsDto> inputJrn = new List<CreateOrEditRefNoConfigDetailsDto>();
            List<CreateOrEditRefNoConfigDetailsDto> inputQrn = new List<CreateOrEditRefNoConfigDetailsDto>();

            if (rnRecords != null)
            {
                foreach (CreateOrEditRefNoConfigDetailsDto record in rnRecords)
                {
                    if (record.RefType == RefNoConfigConsts.JobRefNumber)
                    {
                        jrnRecords.Add(record);
                    }
                    else
                    {
                        qrnRecords.Add(record);
                    }
                }
            }
            int i = 0;
            foreach (CreateOrEditRefNoConfigDetailsDto record in input.RefNumberRecords)
            {
                record.ProjectType = input.ProjectType;
                record.RefNoConfigId = refNoConfig.Id;
                record.DisplayOrder = i.ToString();
                if (record.RefType == RefNoConfigConsts.QuoteRefNumber)
                {
                    inputQrn.Add(record);
                }
                else
                {
                    inputJrn.Add(record);
                }
                await _refNoConfigDetailsAppService.CreateOrEdit(record);
                i++;
            }
            if (inputJrn.Count < jrnRecords.Count)
            {
                for (int j = 0; j < jrnRecords.Count; j++)
                {
                    var recordExist = false;
                    for (int k=0; k < inputJrn.Count; k++)
                    {
                        if (jrnRecords[j].Id == inputJrn[k].Id)
                        {
                            recordExist = true;
                            return;
                        }
                        else
                        {
                            recordExist = false;
                        }
                    }
                    if (!recordExist)
                    {
                        var deleteInput = new EntityDto<long>((long)jrnRecords[i].Id);
                        await _refNoConfigDetailsAppService.Delete(deleteInput);
                    }
                }
            }
            if (inputQrn.Count < qrnRecords.Count)
            {
                for (int j = 0; j < qrnRecords.Count; j++)
                {
                    var recordExist = false;
                    for (int k = 0; k < inputQrn.Count; k++)
                    {
                        if (qrnRecords[j].Id == inputQrn[k].Id)
                        {
                            recordExist = true;
                            return;
                        }
                        else
                        {
                            recordExist = false;
                        }
                    }
                    if (!recordExist)
                    {
                        var deleteInput = new EntityDto<long>((long)qrnRecords[i].Id);
                        await _refNoConfigDetailsAppService.Delete(deleteInput);
                    }
                }
            }
        }

        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigs_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _refNoConfigRepository.DeleteAsync(input.Id);
        }
        [AbpAuthorize(AppPermissions.Pages_Administration_RefNoConfigs)]
        public async Task<List<RefNoConfigOrganizationUnitLookupTableDto>> GetAllOrganizationUnitForTableDropdown()
        {
            return await _lookup_organizationUnitRepository.GetAll()
                .Select(organizationUnit => new RefNoConfigOrganizationUnitLookupTableDto
                {
                    Id = organizationUnit.Id,
                    DisplayName = organizationUnit == null || organizationUnit.DisplayName == null ? "" : organizationUnit.DisplayName.ToString()
                }).ToListAsync();
        }

    }
}