﻿using asq.econsys.Eco.SiteRefConfig;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.SiteRefConfig.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Eco.SiteRefConfig
{
    [AbpAuthorize(AppPermissions.Pages_SiteRefConfigDetails)]
    public class SiteRefConfigDetailsAppService : econsysAppServiceBase, ISiteRefConfigDetailsAppService
    {
        private readonly IRepository<SiteRefConfigDetails, long> _siteRefConfigDetailsRepository;
        private readonly IRepository<SiteRefConfig, long> _lookup_siteRefConfigRepository;

        public SiteRefConfigDetailsAppService(IRepository<SiteRefConfigDetails, long> siteRefConfigDetailsRepository, IRepository<SiteRefConfig, long> lookup_siteRefConfigRepository)
        {
            _siteRefConfigDetailsRepository = siteRefConfigDetailsRepository;
            _lookup_siteRefConfigRepository = lookup_siteRefConfigRepository;

        }

        public async Task<List<GetSiteRefConfigDetailsForViewDto>> GetAll()
        {

            var filteredSiteRefConfigDetails = _siteRefConfigDetailsRepository.GetAll()
                        .Include(e => e.SiteRefConfigFk);

            var siteRefConfigDetails = from o in filteredSiteRefConfigDetails
                                       join o1 in _lookup_siteRefConfigRepository.GetAll() on o.SiteRefConfigId equals o1.Id into j1
                                       from s1 in j1.DefaultIfEmpty()

                                       select new
                                       {

                                           o.ValueType,
                                           o.Prefix,
                                           o.StartingFrom,
                                           o.MinDigits,
                                           o.Suffix,
                                           o.DisplayOrder,
                                           o.CurrentDigit,
                                           o.PreviewNum,
                                           Id = o.Id,
                                           SiteRefConfigCurrentNum = s1 == null || s1.CurrentNum == null ? "" : s1.CurrentNum.ToString()
                                       };

            var dbList = await siteRefConfigDetails.ToListAsync();
            var results = new List<GetSiteRefConfigDetailsForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetSiteRefConfigDetailsForViewDto()
                {
                    SiteRefConfigDetails = new SiteRefConfigDetailsDto
                    {

                        ValueType = o.ValueType,
                        Prefix = o.Prefix,
                        StartingFrom = o.StartingFrom,
                        MinDigits = o.MinDigits,
                        Suffix = o.Suffix,
                        DisplayOrder = o.DisplayOrder,
                        CurrentDigit = o.CurrentDigit,
                        PreviewNum = o.PreviewNum,
                        Id = o.Id,
                    },
                    SiteRefConfigCurrentNum = o.SiteRefConfigCurrentNum
                };

                results.Add(res);
            }

            return results;

        }

        public async Task<GetSiteRefConfigDetailsForViewDto> GetSiteRefConfigDetailsForView(long id)
        {
            var siteRefConfigDetails = await _siteRefConfigDetailsRepository.GetAsync(id);

            var output = new GetSiteRefConfigDetailsForViewDto { SiteRefConfigDetails = ObjectMapper.Map<SiteRefConfigDetailsDto>(siteRefConfigDetails) };

            if (output.SiteRefConfigDetails.SiteRefConfigId != null)
            {
                var _lookupSiteRefConfig = await _lookup_siteRefConfigRepository.FirstOrDefaultAsync((long)output.SiteRefConfigDetails.SiteRefConfigId);
                output.SiteRefConfigCurrentNum = _lookupSiteRefConfig?.CurrentNum?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigDetails_Edit)]
        public async Task<GetSiteRefConfigDetailsForEditOutput> GetSiteRefConfigDetailsForEdit(EntityDto<long> input)
        {
            var siteRefConfigDetails = await _siteRefConfigDetailsRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetSiteRefConfigDetailsForEditOutput { SiteRefConfigDetails = ObjectMapper.Map<CreateOrEditSiteRefConfigDetailsDto>(siteRefConfigDetails) };

            if (output.SiteRefConfigDetails.SiteRefConfigId != null)
            {
                var _lookupSiteRefConfig = await _lookup_siteRefConfigRepository.FirstOrDefaultAsync((long)output.SiteRefConfigDetails.SiteRefConfigId);
                output.SiteRefConfigCurrentNum = _lookupSiteRefConfig?.CurrentNum?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditSiteRefConfigDetailsDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigDetails_Create)]
        protected virtual async Task Create(CreateOrEditSiteRefConfigDetailsDto input)
        {
            var siteRefConfigDetails = ObjectMapper.Map<SiteRefConfigDetails>(input);

            if (AbpSession.TenantId != null)
            {
                siteRefConfigDetails.TenantId = (int?)AbpSession.TenantId;
            }

            await _siteRefConfigDetailsRepository.InsertAsync(siteRefConfigDetails);

        }

        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigDetails_Edit)]
        protected virtual async Task Update(CreateOrEditSiteRefConfigDetailsDto input)
        {
            var siteRefConfigDetails = await _siteRefConfigDetailsRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, siteRefConfigDetails);

        }

        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigDetails_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _siteRefConfigDetailsRepository.DeleteAsync(input.Id);
        }
        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigDetails)]
        public async Task<List<SiteRefConfigDetailsSiteRefConfigLookupTableDto>> GetAllSiteRefConfigForTableDropdown()
        {
            return await _lookup_siteRefConfigRepository.GetAll()
                .Select(siteRefConfig => new SiteRefConfigDetailsSiteRefConfigLookupTableDto
                {
                    Id = siteRefConfig.Id,
                    DisplayName = siteRefConfig == null || siteRefConfig.CurrentNum == null ? "" : siteRefConfig.CurrentNum.ToString()
                }).ToListAsync();
        }

    }
}