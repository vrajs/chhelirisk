﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Eco.SiteRefConfig.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Eco.RefNoConfig;
using asq.econsys.Eco.RefNoConfig.Dtos;
using Abp.Domain.Uow;

namespace asq.econsys.Eco.SiteRefConfig
{
    [AbpAuthorize(AppPermissions.Pages_SiteRefConfigs)]
    public class SiteRefConfigsAppService : econsysAppServiceBase, ISiteRefConfigsAppService
    {
        private readonly IRepository<SiteRefConfig, long> _siteRefConfigRepository;
        private readonly IRepository<SiteRefConfigDetails, long> _siteRefConfigDetailsRepository;
        private readonly ISiteRefConfigDetailsAppService _siteRefConfigDetailsAppService;

        public SiteRefConfigsAppService(IRepository<SiteRefConfig, long> siteRefConfigRepository,
            IRepository<SiteRefConfigDetails, long> siteRefConfigDetailsRepository,
            ISiteRefConfigDetailsAppService siteRefConfigDetailsAppService)
        {
            _siteRefConfigRepository = siteRefConfigRepository;
            _siteRefConfigDetailsRepository = siteRefConfigDetailsRepository;
            _siteRefConfigDetailsAppService = siteRefConfigDetailsAppService;
        }

        public async Task<SiteRefConfigDto> GetAll()
        {
            var results = new SiteRefConfigDto();
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var filteredSiteRefConfigs = _siteRefConfigRepository.GetAll().Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId));

                    var siteRefConfigs = from o in filteredSiteRefConfigs
                                         select new
                                         {
                                             o.SRNAutoGenerate,
                                             o.CurrentNum,
                                             Id = o.Id
                                         };

                    var dbList = await siteRefConfigs.FirstOrDefaultAsync();

                    if (dbList != null)
                    {
                        var rnRecords = await _siteRefConfigDetailsRepository.GetAll().Where(x => x.SiteRefConfigId == dbList.Id).ToListAsync();

                        results.SRNAutoGenerate = dbList.SRNAutoGenerate;
                        results.CurrentNum = dbList.CurrentNum;
                        results.Id = dbList.Id;
                        results.SiteRefNumberRecords = ObjectMapper.Map<List<CreateOrEditSiteRefConfigDetailsDto>>(rnRecords);
                    }
                }
            }
            return results;
        }

        public async Task<GetSiteRefConfigForViewDto> GetSiteRefConfigForView(long id)
        {
            var siteRefConfig = await _siteRefConfigRepository.GetAsync(id);

            var output = new GetSiteRefConfigForViewDto { SiteRefConfig = ObjectMapper.Map<SiteRefConfigDto>(siteRefConfig) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigs_Edit)]
        public async Task<GetSiteRefConfigForEditOutput> GetSiteRefConfigForEdit(EntityDto<long> input)
        {
            var siteRefConfig = await _siteRefConfigRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetSiteRefConfigForEditOutput { SiteRefConfig = ObjectMapper.Map<CreateOrEditSiteRefConfigDto>(siteRefConfig) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditSiteRefConfigDto input)
        {
            if (input.Id == null || input.Id <= 0)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigs_Create)]
        protected virtual async Task Create(CreateOrEditSiteRefConfigDto input)
        {
            var siteRefConfig = ObjectMapper.Map<SiteRefConfig>(input);
            List<CreateOrEditSiteRefConfigDetailsDto> refNoRecords = input.SiteRefNumberRecords;

            if (AbpSession.TenantId != null)
            {
                siteRefConfig.TenantId = (int?)AbpSession.TenantId;
            }

            var siteRefConfigId = _siteRefConfigRepository.InsertAndGetId(siteRefConfig);

            foreach (CreateOrEditSiteRefConfigDetailsDto record in refNoRecords)
            {
                record.SiteRefConfigId = siteRefConfigId;
                //record.RefType = "Site";
                await _siteRefConfigDetailsAppService.CreateOrEdit(record);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigs_Edit)]
        protected virtual async Task Update(CreateOrEditSiteRefConfigDto input)
        {
            var siteRefConfig = await _siteRefConfigRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, siteRefConfig);
            List<CreateOrEditSiteRefConfigDetailsDto> refNoRecords = input.SiteRefNumberRecords;
            foreach (CreateOrEditSiteRefConfigDetailsDto record in refNoRecords)
            {
                record.SiteRefConfigId = siteRefConfig.Id;

                await _siteRefConfigDetailsAppService.CreateOrEdit(record);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_SiteRefConfigs_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _siteRefConfigRepository.DeleteAsync(input.Id);
        }

    }
}