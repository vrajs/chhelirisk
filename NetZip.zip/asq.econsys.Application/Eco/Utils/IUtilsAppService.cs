﻿using Abp.Application.Services;
using asq.econsys.Authorization.Users.Dto;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Eco.Dto;
using asq.econsys.Eco.GuidanceNotes.Dtos;
using asq.econsys.Eco.Projects;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Eco.Settings.Dtos;
using asq.econsys.Flexi.Dtos;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asq.econsys.Eco.Utils
{
    public interface IUtilsAppService : IApplicationService
    {
        Task UpdateGridSettingsAsync(GridSettingsDto input);

        Task<List<FlexiFieldDto>> GetFlexiFieldsBySectionId(string sectionId);

        Task<List<GetRuleFlagForViewDto>> GetRuleFlags();

        Task<List<GuidanceNoteDto>> GetGuidanceNotes();

        Task<List<RevenueRangeDto>> GetRevenueRanges();

        Task<ProjectDDLDto> GetProjectDDL(string projectType);

        Task<List<ProjectTypeDto>> GetAllProjectTypes();

        Task<Boolean> CheckProjectAccessForView(long projectId);
        
        Task<List<asq.econsys.Eco.GridMaster.GridMaster>> GetAllCostCodes(string projectType);

        Task<List<asq.econsys.Eco.GridMaster.GridMaster>> GetMasterData(string gridName);

        Task<List<UserListDto>> GetUsersWithRole(string role);

        Task<List<GetProjectPersonnelForViewDto>> GetPersonnelWorkload(long userId);

        Task<List<ProjectFileDto>> GetAllProjectFiles(int projectId);

    }
}
