﻿using Abp.Authorization;
using Abp.Authorization.Users;
using Abp.Domain.Repositories;
using Abp.Domain.Uow;
using Abp.Runtime.Caching;
using Abp.Runtime.Session;
using Abp.UI;
using asq.econsys.Authorization.Roles;
using asq.econsys.Authorization.Users;
using asq.econsys.Authorization.Users.Dto;
using asq.econsys.Configuration;
using asq.econsys.Eco.BusinessRules;
using asq.econsys.Eco.BusinessRules.Dtos;
using asq.econsys.Eco.Dto;
using asq.econsys.Eco.GuidanceNotes;
using asq.econsys.Eco.GuidanceNotes.Dtos;
using asq.econsys.Eco.NodeTasks;
using asq.econsys.Eco.NodeTasks.Dtos;
using asq.econsys.Eco.Projects;
using asq.econsys.Eco.Projects.Dtos;
using asq.econsys.Eco.Settings.Dtos;
using asq.econsys.Eco.Utils.Storage;
using asq.econsys.Flexi;
using asq.econsys.Flexi.Dtos;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace asq.econsys.Eco.Utils
{
    [AbpAuthorize]
    public class UtilsAppService : econsysAppServiceBase, IUtilsAppService
    {
        private readonly ICacheManager _cacheManager;
        private readonly IRepository<FlexiField, long> _flexiFieldRepository;
        private readonly IRepository<RuleFlag, string> _ruleFlagRepository;
        private readonly IRepository<GuidanceNote, long> _guidanceNoteRepository;
        private readonly IRepository<RevenueRange, long> _revenueRangeRepository;
        private readonly IRepository<NodeStage, string> _nodeStageRepository;
        private readonly IRepository<NodeTask, string> _nodeTaskRepository;
        private readonly IRepository<ProjectType, string> _projectTypeRepository;
        private IAbpSession _session;
        private readonly IRepository<Project, long> _projectRepository;
        private readonly IRepository<ProjectPersonnel, long> _projectPersonnelRepository;
        private readonly IRepository<asq.econsys.Eco.GridMaster.GridMaster, long> _gridMasterRepository;
        private readonly UserManager _userManager;
        private readonly string _requiredRoleName;
        private readonly RoleManager _roleManager;
        private readonly IRepository<UserRole, long> _userRoleRepository;
        private readonly WorkflowManager _workflowManager;
        private readonly IBlobMethods _blobMethods;
        private readonly IWebHostEnvironment _env;
        private readonly IRepository<ProjectFile, Guid> _repositoryProjectFile;

        private readonly StorageManager _storageManager;

        public UtilsAppService(ICacheManager cacheManager,
            IRepository<FlexiField, long> flexiFieldRepository,
            IRepository<RuleFlag, string> ruleFlagRepository,
            IRepository<GuidanceNote, long> guidanceNoteRepository,
            IRepository<RevenueRange, long> revenueRangeRepository,
            IRepository<NodeStage, string> nodeStageRepository,
            IRepository<NodeTask, string> nodeTaskRepository,
            IRepository<ProjectType, string> projectTypeRepository,
            IAbpSession session,
            IRepository<Project, long> projectRepository,
            IRepository<ProjectPersonnel, long> projectPersonnelRepository,
            IRepository<asq.econsys.Eco.GridMaster.GridMaster, long> gridMasterRepository,
            UserManager userManager,
            WorkflowManager workflowManager,
            IBlobMethods blobMethods,
            IWebHostEnvironment env,
            RoleManager roleManager,
            IRepository<UserRole, long> userRoleRepository,
            IRepository<ProjectFile, Guid> repositoryProjectFile,
            StorageManager storageManager)
        {
            _cacheManager = cacheManager;
            _flexiFieldRepository = flexiFieldRepository;
            _ruleFlagRepository = ruleFlagRepository;
            _guidanceNoteRepository = guidanceNoteRepository;
            _revenueRangeRepository = revenueRangeRepository;
            _nodeStageRepository = nodeStageRepository;
            _nodeTaskRepository = nodeTaskRepository;
            _projectTypeRepository = projectTypeRepository;
            _session = session;
            _projectRepository = projectRepository;
            _projectPersonnelRepository = projectPersonnelRepository;
            _gridMasterRepository = gridMasterRepository;
            _userManager = userManager;
            _workflowManager = workflowManager;
            _blobMethods = blobMethods;
            _env = env;
            _roleManager = roleManager;
            _userRoleRepository = userRoleRepository;
            _repositoryProjectFile = repositoryProjectFile;
            _storageManager = storageManager;
        }

        [HttpPost]
        public async Task UpdateGridSettingsAsync(GridSettingsDto input)
        {
            await SettingManager.ChangeSettingForUserAsync(
                AbpSession.ToUserIdentifier(),
                AppSettings.Grid.Settings,
                input.Settings.ToString()
            );
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sectionId"></param>
        /// <returns></returns>
        public async Task<List<FlexiFieldDto>> GetFlexiFieldsBySectionId(string sectionId)
        {
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                var filteredFlexiFields = await _flexiFieldRepository.GetAll()
                        .Include(e => e.FlexiSectionFk)
                        .Where(e => e.FlexiSectionFk != null && e.FlexiSectionFk.Id == sectionId && e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .ToListAsync();

                var results = ObjectMapper.Map<List<FlexiFieldDto>>(filteredFlexiFields);

                return results;
            }
        }

        public async Task<List<GetRuleFlagForViewDto>> GetRuleFlags()
        {
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var dbList = await _ruleFlagRepository.GetAll().ToListAsync();
                    var results = new List<GetRuleFlagForViewDto>();

                    foreach (var o in dbList)
                    {
                        var res = new GetRuleFlagForViewDto()
                        {
                            RuleFlag = new RuleFlagDto
                            {
                                Title = o.Title,
                                HexColor = o.HexColor,
                                DisplayOrder = o.DisplayOrder,
                                Id = o.Id,
                            }
                        };

                        results.Add(res);
                    }

                    return results;
                }
            }
        }

        public async Task<List<GuidanceNoteDto>> GetGuidanceNotes()
        {
            //var cacheval = _cacheManager.GetCache("App.GuidanceNotes");
            //if(cacheval == null)
            //{
            //    var res = _flexiFieldRepository.GetAll().ToList();

            //    await cacheval.SetAsync("App.GuidanceNotes", res);

            //    var result = ObjectMapper.Map<List<GuidanceNoteDto>>(res);

            //} else
            //{
            //    var res = await cacheval.GetAsync("App.GuidanceNotes");
            //    var result = ObjectMapper.Map<List<GuidanceNoteDto>>(res);
            //}

            //return await _cacheManager.GetCache("App.GuidanceNotes").SetAsync("GuidanceNote", async () => GetAllGuidanceNotes());

            //return await _cacheManager.GetCache("App.GuidanceNotes")
            //    .Get("GuidanceNote", async () =>
            //{
            //    var res = _flexiFieldRepository.GetAll().ToList();

            //    var results = ObjectMapper.Map<List<GuidanceNoteDto>>(res);

            //    return results;
            //});

            return await GetAllGuidanceNotes();
        }

        public async Task<List<GuidanceNoteDto>> GetAllGuidanceNotes()
        {
            var res = _guidanceNoteRepository.GetAll().ToList();

            var result = ObjectMapper.Map<List<GuidanceNoteDto>>(res);

            return result;
        }

        public async Task<List<RevenueRangeDto>> GetRevenueRanges()
        {
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    /// TODO - check tenancy
                    var result = _revenueRangeRepository.GetAll()
                        .Where(e => e.IsDeleted == false && e.TenantId == AbpSession.TenantId)
                        .ToList();
                    var revenueRanges = new List<RevenueRangeDto>();

                    foreach (var o in result)
                    {
                        var res = new RevenueRangeDto()
                        {
                            Title = o.Title,
                            DisplayOrder = o.DisplayOrder,
                            MinRange = o.MinRange,
                            MaxRange = o.MaxRange,
                            Id = o.Id,
                        };

                        revenueRanges.Add(res);
                    }
                    return revenueRanges;
                }
            }
        }

        public async Task<ProjectDDLDto> GetProjectDDL(string projectType)
        {
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    ProjectDDLDto result = new ProjectDDLDto();

                    /// TODO - check tenancy
                    var nodeStages = await _nodeStageRepository.GetAll()
                            .Where(e => e.IsDeleted == false) // && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                            .OrderBy(x => x.DisplayOrder)
                            .ToListAsync();

                    result.NodeStages = ObjectMapper.Map<List<NodeStageDto>>(nodeStages);

                    var nodeTasks = await _nodeTaskRepository.GetAll()
                            .Where(e => e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                            .OrderBy(x => x.DisplayOrder)
                            .ToListAsync();

                    result.WorkflowSchema = await _workflowManager.GetSchemaAsync(projectType, AbpSession.TenantId);
                    result.NodeTasks = ObjectMapper.Map<List<NodeTaskDto>>(nodeTasks);

                    return result;
                }
            }
            return null;
        }
        public async Task<List<ProjectTypeDto>> GetAllProjectTypes()
        {
            var allProjectTypes = await _projectTypeRepository.GetAll().ToListAsync();
            var result = ObjectMapper.Map<List<ProjectTypeDto>>(allProjectTypes);
            //var result = allProjectTypes;
            return result;
        }

        public async Task<Boolean> CheckProjectAccessForView(long projectId)
        {
            //var projectId = context.HttpContext.Request.Query["id"].ToString();
            var projectCurrentTask = _projectRepository.Get(projectId);
            var currentUser = await _userManager.GetUserByIdAsync(_session.UserId.Value);
            var isAdmin = await _userManager.IsInRoleAsync(currentUser, StaticRoleNames.Host.Admin);
            var isInRole = await _userManager.IsInRoleAsync(currentUser, "Sales Leader");
            var projectPersonnal = _projectPersonnelRepository.GetAll().Where(x => x.ProjectId == projectId && x.NodeTaskId == projectCurrentTask.Task).ToList();
            CurrentUnitOfWork.SaveChanges();
            if (isAdmin || isInRole)
            {
                if (projectPersonnal.Count == 0)
                {
                    return true;
                }
                if (projectPersonnal.Count != 0 && projectPersonnal[0].UserId == _session.UserId)
                {
                    return true;
                }
                if (projectPersonnal.Count != 0 && projectPersonnal[0].UserId != _session.UserId)
                {
                    throw new UserFriendlyException("Access Denied", "You are not authorized for this project");
                }
            }
            return false;
        }

        /// <summary>
        /// TODO: same function is defined in ProjectAppservice. check permissions and security and use only one implementation
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public async Task<List<ProjectFileDto>> GetAllProjectFiles(int projectId)
        {
            return await _repositoryProjectFile.GetAll()
               .Where(x => x.ProjectId == projectId && x.ParentId == null)
               .Select(projectFile => new ProjectFileDto
               {
                   Id = projectFile.Id,
                   Name = projectFile.Name,
                   FullPath = projectFile.FullPath,
                   Extension = projectFile.Extension,
                   FileSize = projectFile.FileSize,
                   MetaData = projectFile.MetaData,
                   NodeTaskId = projectFile.NodeTaskId
               }).ToListAsync();
        }

        public async Task<List<asq.econsys.Eco.GridMaster.GridMaster>> GetAllCostCodes(string projectType)
        {
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var gridDatas = await _gridMasterRepository.GetAll()
                        .Where(c => c.Name.ToLower() == CGridMasters.CostCode.ToLower() && c.IsDeleted == false && c.TenantId == AbpSession.TenantId)
                        .Select(data => new asq.econsys.Eco.GridMaster.GridMaster
                        {
                            CoumnOne = data.CoumnOne,
                            ForPRJ = data.ForPRJ,
                            ForSWK = data.ForSWK,
                            ForCALL = data.ForCALL,
                            ForPPM = data.ForPPM,
                            ForTandM = data.ForTandM
                        }).ToListAsync();
                    switch ("For" + projectType)
                    {
                        case "ForPRJ":
                            gridDatas = gridDatas.Where(x => x.ForPRJ == true).ToList();
                            break;
                        case "ForSWK":
                            gridDatas = gridDatas.Where(x => x.ForSWK == true).ToList();
                            break;
                        case "ForTandM":
                            gridDatas = gridDatas.Where(x => x.ForTandM == true).ToList();
                            break;
                        case "ForPPM":
                            gridDatas = gridDatas.Where(x => x.ForPPM == true).ToList();
                            break;
                        case "ForCALL":
                            gridDatas = gridDatas.Where(x => x.ForCALL == true).ToList();
                            break;
                        default:
                            break;
                    }
                    return gridDatas;
                }
            }

            return null;
        }
        public async Task<List<asq.econsys.Eco.GridMaster.GridMaster>> GetMasterData(string gridName)
        {
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var masterData = await _gridMasterRepository.GetAll()
                        .Where(c => c.Name == gridName
                        // && c.ForPRJ == true // TODO: need to check this
                        && c.IsDeleted == false && c.TenantId == AbpSession.TenantId)
                        .Select(data => new asq.econsys.Eco.GridMaster.GridMaster
                        {
                            CoumnOne = data.CoumnOne,
                            ForPRJ = data.ForPRJ,
                            Id = data.Id
                        }).ToListAsync();
                    return masterData;
                }
            }

            return null;
        }
        private async Task FillRoleNames(IReadOnlyCollection<UserListDto> userListDtos)
        {
            /* This method is optimized to fill role names to given list. */
            var userIds = userListDtos.Select(u => u.Id);

            var userRoles = await _userRoleRepository.GetAll()
                .Where(userRole => userIds.Contains(userRole.UserId))
                .Select(userRole => userRole).ToListAsync();

            var distinctRoleIds = userRoles.Select(userRole => userRole.RoleId).Distinct();

            foreach (var user in userListDtos)
            {
                var rolesOfUser = userRoles.Where(userRole => userRole.UserId == user.Id).ToList();
                user.Roles = ObjectMapper.Map<List<UserListRoleDto>>(rolesOfUser);
            }

            var roleNames = new Dictionary<int, string>();
            foreach (var roleId in distinctRoleIds)
            {
                var role = await _roleManager.FindByIdAsync(roleId.ToString());
                if (role != null)
                {
                    roleNames[roleId] = role.DisplayName;
                }
            }

            foreach (var userListDto in userListDtos)
            {
                foreach (var userListRoleDto in userListDto.Roles)
                {
                    if (roleNames.ContainsKey(userListRoleDto.RoleId))
                    {
                        userListRoleDto.RoleName = roleNames[userListRoleDto.RoleId];
                    }
                }

                userListDto.Roles = userListDto.Roles.Where(r => r.RoleName != null).OrderBy(r => r.RoleName).ToList();
            }
        }

        public async Task<List<UserListDto>> GetUsersWithRole(string role)
        {
            /// TODO: need to remove this function
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                var users = await UserManager.GetUsersInRoleAsync(role);

                if (users != null)
                {
                    var userListDtos = ObjectMapper.Map<List<UserListDto>>(users);
                    await this.FillRoleNames(userListDtos);

                    return userListDtos;
                }

                return null;
            }
        }


        public async Task<List<UserListDto>> GetUsersByRoleId(int roleId)
        {
            using (CurrentUnitOfWork.SetTenantId(AbpSession.TenantId))
            {
                var role = await _roleManager.GetRoleByIdAsync(roleId);
                var users = await UserManager.GetUsersInRoleAsync(role.Name);

                if (users != null)
                {
                    var userListDtos = ObjectMapper.Map<List<UserListDto>>(users);
                    await this.FillRoleNames(userListDtos);

                    return userListDtos;
                }

                return null;
            }
        }

        public async Task<List<GetProjectPersonnelForViewDto>> GetPersonnelWorkload(long userId)
        {
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    var personnel = await _projectPersonnelRepository
                        .GetAllIncluding(x => x.NodeTaskFk, x => x.ProjectFk)
                        .Where(x => x.UserId == userId && x.IsDeleted == false && x.TenantId == tenantId && x.ProjectFk != null)
                        .ToListAsync();

                    var result = new List<GetProjectPersonnelForViewDto>();
                    foreach (var x in personnel)
                    {
                        result.Add(new GetProjectPersonnelForViewDto()
                        {
                            ProjectPersonnel = ObjectMapper.Map<ProjectPersonnelDto>(x),
                            ProjectName = x.ProjectFk == null ? null : x.ProjectFk.ProjectName,
                            NodeTaskTaskName = x.NodeTaskFk == null ? null : x.NodeTaskFk.TaskName
                        });
                    }

                    return result;
                }
            }

            return null;
        }
    }
}
