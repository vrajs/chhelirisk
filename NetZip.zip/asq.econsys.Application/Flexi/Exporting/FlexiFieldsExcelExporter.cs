﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Flexi.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Flexi.Exporting
{
    public class FlexiFieldsExcelExporter : NpoiExcelExporterBase, IFlexiFieldsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public FlexiFieldsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetFlexiFieldForViewDto> flexiFields)
        {
            return CreateExcelPackage(
                "FlexiFields.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("FlexiFields"));

                    AddHeader(
                        sheet,
                        L("Code"),
                        L("DisplayName"),
                        L("SortOrder"),
                        L("IsEnabled"),
                        L("HTMLType"),
                        L("HTMLInputType"),
                        L("Validations"),
                        L("DBType"),
                        L("FieldType"),
                        (L("FlexiSection")) + L("Name")
                        );

                    AddObjects(
                        sheet, flexiFields,
                        _ => _.FlexiField.Code,
                        _ => _.FlexiField.DisplayName,
                        _ => _.FlexiField.SortOrder,
                        _ => _.FlexiField.IsEnabled,
                        _ => _.FlexiField.HTMLType,
                        _ => _.FlexiField.HTMLInputType,
                        _ => _.FlexiField.Validations,
                        _ => _.FlexiField.DBType,
                        _ => _.FlexiField.FieldType,
                        _ => _.FlexiSectionName
                        );

                });
        }
    }
}