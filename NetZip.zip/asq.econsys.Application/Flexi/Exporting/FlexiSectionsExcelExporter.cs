﻿using System.Collections.Generic;
using Abp.Runtime.Session;
using Abp.Timing.Timezone;
using asq.econsys.DataExporting.Excel.NPOI;
using asq.econsys.Flexi.Dtos;
using asq.econsys.Dto;
using asq.econsys.Storage;

namespace asq.econsys.Flexi.Exporting
{
    public class FlexiSectionsExcelExporter : NpoiExcelExporterBase, IFlexiSectionsExcelExporter
    {

        private readonly ITimeZoneConverter _timeZoneConverter;
        private readonly IAbpSession _abpSession;

        public FlexiSectionsExcelExporter(
            ITimeZoneConverter timeZoneConverter,
            IAbpSession abpSession,
            ITempFileCacheManager tempFileCacheManager) :
    base(tempFileCacheManager)
        {
            _timeZoneConverter = timeZoneConverter;
            _abpSession = abpSession;
        }

        public FileDto ExportToFile(List<GetFlexiSectionForViewDto> flexiSections)
        {
            return CreateExcelPackage(
                "FlexiSections.xlsx",
                excelPackage =>
                {

                    var sheet = excelPackage.CreateSheet(L("FlexiSections"));

                    AddHeader(
                        sheet,
                        L("Name"),
                        L("SortOrder"),
                        L("MetaFields")
                        );

                    AddObjects(
                        sheet, flexiSections,
                        _ => _.FlexiSection.Name,
                        _ => _.FlexiSection.SortOrder,
                        _ => _.FlexiSection.MetaFields
                        );

                });
        }
    }
}