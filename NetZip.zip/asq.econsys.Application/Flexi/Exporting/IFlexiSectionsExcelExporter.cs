﻿using System.Collections.Generic;
using asq.econsys.Flexi.Dtos;
using asq.econsys.Dto;

namespace asq.econsys.Flexi.Exporting
{
    public interface IFlexiSectionsExcelExporter
    {
        FileDto ExportToFile(List<GetFlexiSectionForViewDto> flexiSections);
    }
}