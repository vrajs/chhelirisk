﻿using asq.econsys.Flexi;

using asq.econsys;

using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Flexi.Exporting;
using asq.econsys.Flexi.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;

namespace asq.econsys.Flexi
{
    [AbpAuthorize(AppPermissions.Pages_FlexiFields)]
    public class FlexiFieldsAppService : econsysAppServiceBase, IFlexiFieldsAppService
    {
        private readonly IRepository<FlexiField, long> _flexiFieldRepository;
        private readonly IFlexiFieldsExcelExporter _flexiFieldsExcelExporter;
        private readonly IRepository<FlexiSection, string> _lookup_flexiSectionRepository;

        public FlexiFieldsAppService(IRepository<FlexiField, long> flexiFieldRepository, IFlexiFieldsExcelExporter flexiFieldsExcelExporter, IRepository<FlexiSection, string> lookup_flexiSectionRepository)
        {
            _flexiFieldRepository = flexiFieldRepository;
            _flexiFieldsExcelExporter = flexiFieldsExcelExporter;
            _lookup_flexiSectionRepository = lookup_flexiSectionRepository;

        }

        public async Task<PagedResultDto<GetFlexiFieldForViewDto>> GetAll(GetAllFlexiFieldsInput input)
        {
            var fieldTypeFilter = input.FieldTypeFilter.HasValue
                        ? (FlexiFieldType)input.FieldTypeFilter
                        : default;

            var filteredFlexiFields = _flexiFieldRepository.GetAll()
                        .Include(e => e.FlexiSectionFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Code.Contains(input.Filter) || e.DisplayName.Contains(input.Filter) || e.HTMLType.Contains(input.Filter) || e.HTMLInputType.Contains(input.Filter) || e.Validations.Contains(input.Filter) || e.DBType.Contains(input.Filter) || e.FlexiSectionId.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CodeFilter), e => e.Code == input.CodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DisplayNameFilter), e => e.DisplayName == input.DisplayNameFilter)
                        .WhereIf(input.MinSortOrderFilter != null, e => e.SortOrder >= input.MinSortOrderFilter)
                        .WhereIf(input.MaxSortOrderFilter != null, e => e.SortOrder <= input.MaxSortOrderFilter)
                        .WhereIf(input.IsEnabledFilter.HasValue && input.IsEnabledFilter > -1, e => (input.IsEnabledFilter == 1 && e.IsEnabled) || (input.IsEnabledFilter == 0 && !e.IsEnabled))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HTMLTypeFilter), e => e.HTMLType == input.HTMLTypeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HTMLInputTypeFilter), e => e.HTMLInputType == input.HTMLInputTypeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ValidationsFilter), e => e.Validations == input.ValidationsFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DBTypeFilter), e => e.DBType == input.DBTypeFilter)
                        .WhereIf(input.FieldTypeFilter.HasValue && input.FieldTypeFilter > -1, e => e.FieldType == fieldTypeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.FlexiSectionNameFilter), e => e.FlexiSectionFk != null && e.FlexiSectionFk.Name == input.FlexiSectionNameFilter);
            
            ///Remove this line once server side pagination is implimented.
            input.MaxResultCount = filteredFlexiFields.Count();

            var pagedAndFilteredFlexiFields = filteredFlexiFields
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var flexiFields = from o in pagedAndFilteredFlexiFields
                              join o1 in _lookup_flexiSectionRepository.GetAll() on o.FlexiSectionId equals o1.Id into j1
                              from s1 in j1.DefaultIfEmpty()

                              select new
                              {
                                  o.FlexiSectionId,
                                  o.Code,
                                  o.DisplayName,
                                  o.SortOrder,
                                  o.IsEnabled,
                                  o.HTMLType,
                                  o.HTMLInputType,
                                  o.Validations,
                                  o.DBType,
                                  o.FieldType,
                                  Id = o.Id,
                                  FlexiSectionName = s1 == null || s1.Name == null ? "" : s1.Name.ToString()
                              };

            var totalCount = await filteredFlexiFields.CountAsync();

            var dbList = await flexiFields.ToListAsync();
            var results = new List<GetFlexiFieldForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetFlexiFieldForViewDto()
                {
                    FlexiField = new FlexiFieldDto
                    {
                        FlexiSectionId = o.FlexiSectionId,
                        Code = o.Code,
                        DisplayName = o.DisplayName,
                        SortOrder = o.SortOrder,
                        IsEnabled = o.IsEnabled,
                        HTMLType = o.HTMLType,
                        HTMLInputType = o.HTMLInputType,
                        Validations = o.Validations,
                        DBType = o.DBType,
                        FieldType = o.FieldType,
                        Id = o.Id,
                    },
                    FlexiSectionName = o.FlexiSectionName
                };

                results.Add(res);
            }

            return new PagedResultDto<GetFlexiFieldForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetFlexiFieldForViewDto> GetFlexiFieldForView(long id)
        {
            var flexiField = await _flexiFieldRepository.GetAsync(id);

            var output = new GetFlexiFieldForViewDto { FlexiField = ObjectMapper.Map<FlexiFieldDto>(flexiField) };

            if (output.FlexiField.FlexiSectionId != null)
            {
                var _lookupFlexiSection = await _lookup_flexiSectionRepository.FirstOrDefaultAsync((string)output.FlexiField.FlexiSectionId);
                output.FlexiSectionName = _lookupFlexiSection?.Name?.ToString();
            }

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_FlexiFields_Edit)]
        public async Task<GetFlexiFieldForEditOutput> GetFlexiFieldForEdit(EntityDto<long> input)
        {
            var flexiField = await _flexiFieldRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetFlexiFieldForEditOutput { FlexiField = ObjectMapper.Map<CreateOrEditFlexiFieldDto>(flexiField) };

            if (output.FlexiField.FlexiSectionId != null)
            {
                var _lookupFlexiSection = await _lookup_flexiSectionRepository.FirstOrDefaultAsync((string)output.FlexiField.FlexiSectionId);
                output.FlexiSectionName = _lookupFlexiSection?.Name?.ToString();
            }

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditFlexiFieldDto input)
        {
            if (input.Id == null)
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_FlexiFields_Create)]
        protected virtual async Task Create(CreateOrEditFlexiFieldDto input)
        {
            var flexiField = ObjectMapper.Map<FlexiField>(input);

            if (AbpSession.TenantId != null)
            {
                flexiField.TenantId = (int?)AbpSession.TenantId;
            }

            await _flexiFieldRepository.InsertAsync(flexiField);

        }

        [AbpAuthorize(AppPermissions.Pages_FlexiFields_Edit)]
        protected virtual async Task Update(CreateOrEditFlexiFieldDto input)
        {
            var flexiField = await _flexiFieldRepository.FirstOrDefaultAsync((long)input.Id);
            ObjectMapper.Map(input, flexiField);

        }

        [AbpAuthorize(AppPermissions.Pages_FlexiFields_Delete)]
        public async Task Delete(EntityDto<long> input)
        {
            await _flexiFieldRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetFlexiFieldsToExcel(GetAllFlexiFieldsForExcelInput input)
        {
            var fieldTypeFilter = input.FieldTypeFilter.HasValue
                        ? (FlexiFieldType)input.FieldTypeFilter
                        : default;

            var filteredFlexiFields = _flexiFieldRepository.GetAll()
                        .Include(e => e.FlexiSectionFk)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Code.Contains(input.Filter) || e.DisplayName.Contains(input.Filter) || e.HTMLType.Contains(input.Filter) || e.HTMLInputType.Contains(input.Filter) || e.Validations.Contains(input.Filter) || e.DBType.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.CodeFilter), e => e.Code == input.CodeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DisplayNameFilter), e => e.DisplayName == input.DisplayNameFilter)
                        .WhereIf(input.MinSortOrderFilter != null, e => e.SortOrder >= input.MinSortOrderFilter)
                        .WhereIf(input.MaxSortOrderFilter != null, e => e.SortOrder <= input.MaxSortOrderFilter)
                        .WhereIf(input.IsEnabledFilter.HasValue && input.IsEnabledFilter > -1, e => (input.IsEnabledFilter == 1 && e.IsEnabled) || (input.IsEnabledFilter == 0 && !e.IsEnabled))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HTMLTypeFilter), e => e.HTMLType == input.HTMLTypeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.HTMLInputTypeFilter), e => e.HTMLInputType == input.HTMLInputTypeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.ValidationsFilter), e => e.Validations == input.ValidationsFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.DBTypeFilter), e => e.DBType == input.DBTypeFilter)
                        .WhereIf(input.FieldTypeFilter.HasValue && input.FieldTypeFilter > -1, e => e.FieldType == fieldTypeFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.FlexiSectionNameFilter), e => e.FlexiSectionFk != null && e.FlexiSectionFk.Name == input.FlexiSectionNameFilter);

            var query = (from o in filteredFlexiFields
                         join o1 in _lookup_flexiSectionRepository.GetAll() on o.FlexiSectionId equals o1.Id into j1
                         from s1 in j1.DefaultIfEmpty()

                         select new GetFlexiFieldForViewDto()
                         {
                             FlexiField = new FlexiFieldDto
                             {
                                 Code = o.Code,
                                 DisplayName = o.DisplayName,
                                 SortOrder = o.SortOrder,
                                 IsEnabled = o.IsEnabled,
                                 HTMLType = o.HTMLType,
                                 HTMLInputType = o.HTMLInputType,
                                 Validations = o.Validations,
                                 DBType = o.DBType,
                                 FieldType = o.FieldType,
                                 Id = o.Id
                             },
                             FlexiSectionName = s1 == null || s1.Name == null ? "" : s1.Name.ToString()
                         });

            var flexiFieldListDtos = await query.ToListAsync();

            return _flexiFieldsExcelExporter.ExportToFile(flexiFieldListDtos);
        }

        [AbpAuthorize(AppPermissions.Pages_FlexiFields)]
        public async Task<PagedResultDto<FlexiFieldFlexiSectionLookupTableDto>> GetAllFlexiSectionForLookupTable(GetAllForLookupTableInput input)
        {
            var query = _lookup_flexiSectionRepository.GetAll().WhereIf(
                   !string.IsNullOrWhiteSpace(input.Filter),
                  e => e.Name != null && e.Name.Contains(input.Filter)
               );

            var totalCount = await query.CountAsync();

            var flexiSectionList = await query
                .PageBy(input)
                .ToListAsync();

            var lookupTableDtoList = new List<FlexiFieldFlexiSectionLookupTableDto>();
            foreach (var flexiSection in flexiSectionList)
            {
                lookupTableDtoList.Add(new FlexiFieldFlexiSectionLookupTableDto
                {
                    Id = flexiSection.Id,
                    DisplayName = flexiSection.Name?.ToString()
                });
            }

            return new PagedResultDto<FlexiFieldFlexiSectionLookupTableDto>(
                totalCount,
                lookupTableDtoList
            );
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sectionId"></param>
        /// <returns></returns>
        public async Task<List<FlexiFieldDto>> GetAllBySectionId(string sectionId)
        {
            var tenantId = AbpSession.TenantId;
            using (CurrentUnitOfWork.SetTenantId(tenantId))
            {
                var filteredFlexiFields = await _flexiFieldRepository.GetAll()
                        .Include(e => e.FlexiSectionFk)
                        .Where(e => e.FlexiSectionFk != null && e.FlexiSectionFk.Id == sectionId && e.IsDeleted == false && e.TenantId == (AbpSession.TenantId == null ? null : AbpSession.TenantId))
                        .ToListAsync();

                var results = ObjectMapper.Map<List<FlexiFieldDto>>(filteredFlexiFields);

                return results;
            }
        }

        public async Task<List<FlexiSectionDto>> GetAllFlexiSections()
        {
            return await _lookup_flexiSectionRepository.GetAll()
                .Select(flexiSections => new FlexiSectionDto
                {
                            Id = flexiSections.Id,
                            Name = flexiSections.Name,
                        }).ToListAsync();
        }

    }
}