﻿using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using Abp.Linq.Extensions;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using asq.econsys.Flexi.Exporting;
using asq.econsys.Flexi.Dtos;
using asq.econsys.Dto;
using Abp.Application.Services.Dto;
using asq.econsys.Authorization;
using Abp.Extensions;
using Abp.Authorization;
using Microsoft.EntityFrameworkCore;
using Abp.UI;
using asq.econsys.Storage;
using asq.econsys.Utils;

namespace asq.econsys.Flexi
{
    [AbpAuthorize(AppPermissions.Pages_FlexiSections)]
    public class FlexiSectionsAppService : econsysAppServiceBase, IFlexiSectionsAppService
    {
        private readonly IRepository<FlexiSection, string> _flexiSectionRepository;
        private readonly IFlexiSectionsExcelExporter _flexiSectionsExcelExporter;

        public FlexiSectionsAppService(IRepository<FlexiSection, string> flexiSectionRepository, IFlexiSectionsExcelExporter flexiSectionsExcelExporter)
        {
            _flexiSectionRepository = flexiSectionRepository;
            _flexiSectionsExcelExporter = flexiSectionsExcelExporter;

        }

        public async Task<PagedResultDto<GetFlexiSectionForViewDto>> GetAll(GetAllFlexiSectionsInput input)
        {

            var filteredFlexiSections = _flexiSectionRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.MetaFields.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(input.MinSortOrderFilter != null, e => e.SortOrder >= input.MinSortOrderFilter)
                        .WhereIf(input.MaxSortOrderFilter != null, e => e.SortOrder <= input.MaxSortOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MetaFieldsFilter), e => e.MetaFields == input.MetaFieldsFilter);

            var pagedAndFilteredFlexiSections = filteredFlexiSections
                .OrderBy(input.Sorting ?? "id asc")
                .PageBy(input);

            var flexiSections = from o in pagedAndFilteredFlexiSections
                                select new
                                {

                                    o.Name,
                                    o.SortOrder,
                                    o.MetaFields,
                                    Id = o.Id
                                };

            var totalCount = await filteredFlexiSections.CountAsync();

            var dbList = await flexiSections.ToListAsync();
            var results = new List<GetFlexiSectionForViewDto>();

            foreach (var o in dbList)
            {
                var res = new GetFlexiSectionForViewDto()
                {
                    FlexiSection = new FlexiSectionDto
                    {

                        Name = o.Name,
                        SortOrder = o.SortOrder,
                        MetaFields = o.MetaFields,
                        Id = o.Id,
                    }
                };

                results.Add(res);
            }

            return new PagedResultDto<GetFlexiSectionForViewDto>(
                totalCount,
                results
            );

        }

        public async Task<GetFlexiSectionForViewDto> GetFlexiSectionForView(string id)
        {
            var flexiSection = await _flexiSectionRepository.GetAsync(id);

            var output = new GetFlexiSectionForViewDto { FlexiSection = ObjectMapper.Map<FlexiSectionDto>(flexiSection) };

            return output;
        }

        [AbpAuthorize(AppPermissions.Pages_FlexiSections_Edit)]
        public async Task<GetFlexiSectionForEditOutput> GetFlexiSectionForEdit(EntityDto<string> input)
        {
            var flexiSection = await _flexiSectionRepository.FirstOrDefaultAsync(input.Id);

            var output = new GetFlexiSectionForEditOutput { FlexiSection = ObjectMapper.Map<CreateOrEditFlexiSectionDto>(flexiSection) };

            return output;
        }

        public async Task CreateOrEdit(CreateOrEditFlexiSectionDto input)
        {
            if (input.Id.IsNullOrWhiteSpace())
            {
                await Create(input);
            }
            else
            {
                await Update(input);
            }
        }

        private string GetSlug(string slug, int counter = 0)
        {
            slug = StringHelper.GenerateSlug(slug);
            var title = _flexiSectionRepository.FirstOrDefault(x => x.Id.ToLower() == slug);
            if(title == null)
            {
                return slug;
            } else
            {
                counter++;
                return this.GetSlug(slug + "-" + counter, counter);
            }
        }

        [AbpAuthorize(AppPermissions.Pages_FlexiSections_Create)]
        protected virtual async Task Create(CreateOrEditFlexiSectionDto input)
        {
            var flexiSection = ObjectMapper.Map<FlexiSection>(input);

            if (flexiSection.Id.IsNullOrWhiteSpace())
            {
                //flexiSection.Id = Guid.NewGuid().ToString();
                flexiSection.Id = this.GetSlug(input.Name);
            }

            await _flexiSectionRepository.InsertAsync(flexiSection);

        }

        [AbpAuthorize(AppPermissions.Pages_FlexiSections_Edit)]
        protected virtual async Task Update(CreateOrEditFlexiSectionDto input)
        {
            var flexiSection = await _flexiSectionRepository.FirstOrDefaultAsync((string)input.Id);
            ObjectMapper.Map(input, flexiSection);

        }

        [AbpAuthorize(AppPermissions.Pages_FlexiSections_Delete)]
        public async Task Delete(EntityDto<string> input)
        {
            await _flexiSectionRepository.DeleteAsync(input.Id);
        }

        public async Task<FileDto> GetFlexiSectionsToExcel(GetAllFlexiSectionsForExcelInput input)
        {

            var filteredFlexiSections = _flexiSectionRepository.GetAll()
                        .WhereIf(!string.IsNullOrWhiteSpace(input.Filter), e => false || e.Name.Contains(input.Filter) || e.MetaFields.Contains(input.Filter))
                        .WhereIf(!string.IsNullOrWhiteSpace(input.NameFilter), e => e.Name == input.NameFilter)
                        .WhereIf(input.MinSortOrderFilter != null, e => e.SortOrder >= input.MinSortOrderFilter)
                        .WhereIf(input.MaxSortOrderFilter != null, e => e.SortOrder <= input.MaxSortOrderFilter)
                        .WhereIf(!string.IsNullOrWhiteSpace(input.MetaFieldsFilter), e => e.MetaFields == input.MetaFieldsFilter);

            var query = (from o in filteredFlexiSections
                         select new GetFlexiSectionForViewDto()
                         {
                             FlexiSection = new FlexiSectionDto
                             {
                                 Name = o.Name,
                                 SortOrder = o.SortOrder,
                                 MetaFields = o.MetaFields,
                                 Id = o.Id
                             }
                         });

            var flexiSectionListDtos = await query.ToListAsync();

            return _flexiSectionsExcelExporter.ExportToFile(flexiSectionListDtos);
        }

    }
}