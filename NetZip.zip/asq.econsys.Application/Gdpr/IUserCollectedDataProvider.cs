﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Abp;
using asq.econsys.Dto;

namespace asq.econsys.Gdpr
{
    public interface IUserCollectedDataProvider
    {
        Task<List<FileDto>> GetFiles(UserIdentifier user);
    }
}
