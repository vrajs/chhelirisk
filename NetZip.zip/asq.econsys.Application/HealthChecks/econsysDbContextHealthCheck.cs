﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using asq.econsys.EntityFrameworkCore;

namespace asq.econsys.HealthChecks
{
    public class econsysDbContextHealthCheck : IHealthCheck
    {
        private readonly DatabaseCheckHelper _checkHelper;

        public econsysDbContextHealthCheck(DatabaseCheckHelper checkHelper)
        {
            _checkHelper = checkHelper;
        }

        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = new CancellationToken())
        {
            if (_checkHelper.Exist("db"))
            {
                return Task.FromResult(HealthCheckResult.Healthy("econsysDbContext connected to database."));
            }

            return Task.FromResult(HealthCheckResult.Unhealthy("econsysDbContext could not connect to database"));
        }
    }
}
