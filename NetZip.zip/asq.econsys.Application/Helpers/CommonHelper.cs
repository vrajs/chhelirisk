﻿using asq.econsys.Authorization.Accounts.Dto;
using asq.econsys.Authorization.Users.Dto;
using IdentityModel.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace asq.econsys.Helpers
{
    public class CommonHelper
    {
        #region mehod declaration
        /// <summary>
        /// Saves the registered user to identity server.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns>
        /// Is success or not
        /// </returns>
        public static async Task<bool> RegisterUserToIdentityServer(CreateOrUpdateUserInput model, string apiURL)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    apiURL = string.Concat(apiURL, "api/User/save");

                    var decodedToken = CommonHelper.DecodeToken(model.IDPAccessToken);
                    var loggedInClientId = Convert.ToInt32(decodedToken.Payload["C_Id"]);

                    client.SetBearerToken(model.IDPAccessToken);
                    var role = model.AssignedRoleNames.Length > 0 && model.AssignedRoleNames.Any(a => a == "Admin") ? 0 : 1;

                    RegisterModelDto registerModelDto = new RegisterModelDto();
                    registerModelDto.Email = model.User.EmailAddress;
                    registerModelDto.ClientId = loggedInClientId != null ? loggedInClientId.ToString() : "0";
                    registerModelDto.UserRoles = role;
                    registerModelDto.Password = model.User.Password;
                    registerModelDto.ConfirmPassword = model.User.Password;
                    registerModelDto.IsActive = model.User.IsActive;
                    registerModelDto.IsDeleted = false;
                    registerModelDto.FirstName = model.User.Name;
                    registerModelDto.Surname = model.User.Surname;

                    var json = JsonConvert.SerializeObject(registerModelDto);

                    var content = new StringContent(json.ToString(), Encoding.UTF8, "application/json");

                    var result = await client.PostAsync(apiURL, content);
                    if (result.IsSuccessStatusCode)
                    {
                        var response = await result.Content.ReadAsStringAsync();
                        var resultModel = JsonConvert.DeserializeObject<ResultModel>(response);
                        return resultModel.IsSuccess;
                    }
                    else
                    {
                        throw new Exception("Something went wrong while saving the data in Identity Server");
                    }
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Confirms the user email to idp.
        /// </summary>
        /// <returns></returns>
        /// <exception cref="EconsysDemo.Authorization.Users.Importing.Dto.ImportUserDto.Exception">Something went wrong while updatting the data in Identity Server</exception>
        public static async Task<bool> ConfirmUserEmailToIDP(string email,string apiURL)
        {
            using (var client = new HttpClient())
            {
                apiURL = string.Concat(apiURL, "api/Account/confirm-email?email=" + email + "");
                var json = JsonConvert.SerializeObject(email);

                var content = new StringContent(json.ToString(), Encoding.UTF8, "application/json");

                var result = await client.PostAsync(apiURL, null);
                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    var resultModel = JsonConvert.DeserializeObject<ResultModel>(response);
                    return resultModel.IsSuccess;
                }
                else
                {
                    throw new Exception("Something went wrong while updatting the data in Identity Server");
                }
            }
        }

        /// <summary>
        /// Updates the user to identity server.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        /// <exception cref="asq.econsys.Authorization.Users.Importing.Dto.ImportUserDto.Exception">Something went wrong while saving the data in Identity Server</exception>
        public static async Task<bool> UpdateUserToIdentityServer(CreateOrUpdateUserInput model, string apiURL)
        {
            using (var client = new HttpClient())
            {
                apiURL = string.Concat(apiURL, "api/User/update");

                var decodedToken = CommonHelper.DecodeToken(model.IDPAccessToken);
                var loggedInClientId = Convert.ToInt32(decodedToken.Payload["C_Id"]);

                client.SetBearerToken(model.IDPAccessToken);

                var role = model.AssignedRoleNames.Length > 0 && model.AssignedRoleNames.Any(a => a == "Admin") ? 0 : 1;

                RegisterModelDto registerModelDto = new RegisterModelDto();
                registerModelDto.Email = model.User.EmailAddress;
                registerModelDto.Password = model.User.Password;
                registerModelDto.ConfirmPassword = model.User.Password;
                registerModelDto.IsActive = model.User.IsActive;
                registerModelDto.IsDeleted = false;
                registerModelDto.ClientId = loggedInClientId != null ? loggedInClientId.ToString() : "0";
                registerModelDto.UserRoles = role;
                registerModelDto.FirstName = model.User.Name;
                registerModelDto.Surname = model.User.Surname;

                var json = JsonConvert.SerializeObject(registerModelDto);

                var content = new StringContent(json.ToString(), Encoding.UTF8, "application/json");

                var result = await client.PostAsync(apiURL, content);
                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    var resultModel = JsonConvert.DeserializeObject<ResultModel>(response);
                    return resultModel.IsSuccess;
                }
                else
                {
                    throw new Exception("Something went wrong while saving the data in Identity Server");
                }
            }
            return true;
        }

        /// <summary>
        /// Deletes the user from idp.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <param name="accessToken">The access token.</param>
        /// <returns></returns>
        /// <exception cref="EconsysDemo.Authorization.Users.Importing.Dto.ImportUserDto.Exception">Something went wrong while deleting the user from Identity Server</exception>
        public static async Task<bool> DeleteUserFromIDP(string email, string accessToken, string apiURL)
        {
            using (var client = new HttpClient())
            {
                apiURL = string.Concat(apiURL, "api/User/delete?email=" + email + "");

                client.SetBearerToken(accessToken);

                var json = JsonConvert.SerializeObject(email);

                var content = new StringContent(json.ToString(), Encoding.UTF8, "application/json");

                var result = await client.PostAsync(apiURL, null);

                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    var resultModel = JsonConvert.DeserializeObject<ResultModel>(response);
                    return resultModel.IsSuccess;
                }
                else
                {
                    throw new Exception("Something went wrong while deleting the user from Identity Server");
                }
            }
        }

        /// <summary>
        /// Changes the password for idp user.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <param name="apiURL">The API URL.</param>
        /// <param name="accessToken">The access token.</param>
        /// <returns></returns>
        /// <exception cref="asq.econsys.Authorization.Users.Importing.Dto.ImportUserDto.Exception">Something went wrong while saving the data in Identity Server</exception>
        public static async Task<bool> ChangePasswordForIDPUser(ResetIDPPasswordDto model, string apiURL,string accessToken)
        {
            using (var client = new HttpClient())
            {
                if (string.IsNullOrEmpty(accessToken))
                {
                    apiURL = string.Concat(apiURL, "api/Account/change-password");
                    model.UserId = model.EmailAddress;
                }
                else
                {
                    apiURL = string.Concat(apiURL, "api/User/change-password");
                    var decodedToken = CommonHelper.DecodeToken(accessToken);
                    var loggedinUserId = Convert.ToString(decodedToken.Payload["sub"]);
                    model.UserId = loggedinUserId;
                    client.SetBearerToken(accessToken);
                }
                

                var json = JsonConvert.SerializeObject(model);

                var content = new StringContent(json.ToString(), Encoding.UTF8, "application/json");

                var result = await client.PostAsync(apiURL, content);
                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    var resultModel = JsonConvert.DeserializeObject<ResultModel>(response);
                    return resultModel.IsSuccess;
                }
                else
                {
                    throw new Exception("Something went wrong while updating the entry in Identity Server");
                }
            }
            return true;
        }

        /// <summary>
        /// Decodes the token.
        /// </summary>
        /// <param name="accessToken">The access token.</param>
        /// <returns>
        /// Decoded access token as JwtSecurityToken
        /// </returns>
        public static JwtSecurityToken DecodeToken(string accessToken)
        {
            var stream = accessToken;
            var handler = new JwtSecurityTokenHandler();
            var jsonToken = handler.ReadToken(stream);
            var token = handler.ReadJwtToken(accessToken);
            return jsonToken as JwtSecurityToken;
        }

        /// <summary>
        /// Encodes the value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// Encoded string
        /// </returns>
        public static string EncodeValue(string value)
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(value));
        }

        /// <summary>
        /// Decodes the value.
        /// </summary>
        /// <param name="encodedValue">The encoded value.</param>
        /// <returns>
        /// Decoded string
        /// </returns>
        public static string DecodeValue(string encodedValue)
        {
            return Encoding.UTF8.GetString(Convert.FromBase64String(encodedValue));
        }

        #endregion
    }
}
