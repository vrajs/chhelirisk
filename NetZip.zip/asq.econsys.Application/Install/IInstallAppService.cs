﻿using System.Threading.Tasks;
using Abp.Application.Services;
using asq.econsys.Install.Dto;

namespace asq.econsys.Install
{
    public interface IInstallAppService : IApplicationService
    {
        Task Setup(InstallDto input);

        AppSettingsJsonDto GetAppSettingsJson();

        CheckDatabaseOutput CheckDatabase();
    }
}