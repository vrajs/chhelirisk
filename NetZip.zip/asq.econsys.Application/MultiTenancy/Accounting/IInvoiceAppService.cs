﻿using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using asq.econsys.MultiTenancy.Accounting.Dto;

namespace asq.econsys.MultiTenancy.Accounting
{
    public interface IInvoiceAppService
    {
        Task<InvoiceDto> GetInvoiceInfo(EntityDto<long> input);

        Task CreateInvoice(CreateInvoiceDto input);
    }
}
