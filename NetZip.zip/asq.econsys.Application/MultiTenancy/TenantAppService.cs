﻿using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using Abp;
using Abp.Application.Features;
using Abp.Application.Services.Dto;
using Abp.Authorization;
using Abp.Authorization.Users;
using Abp.Domain.Uow;
using Abp.Events.Bus;
using Abp.Extensions;
using Abp.Linq.Extensions;
using Abp.Runtime.Security;
using Microsoft.EntityFrameworkCore;
using asq.econsys.Authorization;
using asq.econsys.Editions.Dto;
using asq.econsys.MultiTenancy.Dto;
using asq.econsys.Url;
using Abp.Domain.Repositories;
using asq.econsys.Migrations.Seed.Tenants;
using Abp.EntityFrameworkCore;
using asq.econsys.EntityFrameworkCore;
using System.Threading;
using System.Transactions;
using asq.econsys.Authorization.Users;
using System;
using asq.econsys.Authorization.Roles;

namespace asq.econsys.MultiTenancy
{
    [AbpAuthorize(AppPermissions.Pages_Tenants)]
    public class TenantAppService : econsysAppServiceBase, ITenantAppService
    {
        public IAppUrlService AppUrlService { get; set; }
        public IEventBus EventBus { get; set; }
        protected readonly IRepository<Tenant> _tenantRepository;
        private readonly IDbContextProvider<econsysDbContext> _dbContextProvider;
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly ICurrentUnitOfWorkProvider _unitOfWorkProvider;
        private readonly IRepository<User, Int64> _userRepository;
        private readonly IRepository<UserRole, long> _userRoleRepository;
        private readonly IRepository<Role> _roleRepository;

        public TenantAppService(IRepository<Tenant> tenantRepository,
            IDbContextProvider<econsysDbContext> dbContextProvider,
            IUnitOfWorkManager unitOfWorkManager,
            ICurrentUnitOfWorkProvider unitOfWorkProvider,
            IRepository<User, Int64> userRepository,
            IRepository<UserRole, long> userRoleRepository,
            IRepository<Role> roleRepository)
        {
            AppUrlService = NullAppUrlService.Instance;
            EventBus = NullEventBus.Instance;
            _tenantRepository = tenantRepository;
            _dbContextProvider = dbContextProvider;
            _unitOfWorkManager = unitOfWorkManager;
            _unitOfWorkProvider = unitOfWorkProvider;
            _userRepository = userRepository;
            _userRoleRepository = userRoleRepository;
            _roleRepository = roleRepository;
        }

        public async Task<PagedResultDto<TenantListDto>> GetTenants(GetTenantsInput input)
        {
            var query = TenantManager.Tenants
                .Include(t => t.Edition)
                .WhereIf(!input.Filter.IsNullOrWhiteSpace(), t => t.Name.Contains(input.Filter) || t.TenancyName.Contains(input.Filter))
                .WhereIf(input.CreationDateStart.HasValue, t => t.CreationTime >= input.CreationDateStart.Value)
                .WhereIf(input.CreationDateEnd.HasValue, t => t.CreationTime <= input.CreationDateEnd.Value)
                .WhereIf(input.SubscriptionEndDateStart.HasValue, t => t.SubscriptionEndDateUtc >= input.SubscriptionEndDateStart.Value.ToUniversalTime())
                .WhereIf(input.SubscriptionEndDateEnd.HasValue, t => t.SubscriptionEndDateUtc <= input.SubscriptionEndDateEnd.Value.ToUniversalTime())
                .WhereIf(input.EditionIdSpecified, t => t.EditionId == input.EditionId);

            var tenantCount = await query.CountAsync();
            var tenants = await query.OrderBy(input.Sorting).PageBy(input).ToListAsync();

            return new PagedResultDto<TenantListDto>(
                tenantCount,
                ObjectMapper.Map<List<TenantListDto>>(tenants)
                );
        }

        [AbpAuthorize(AppPermissions.Pages_Tenants_Create)]
        [UnitOfWork(IsDisabled = true)]
        public async Task CreateTenant(CreateTenantInput input)
        {
            int tenantId = await TenantManager.CreateWithAdminUserAsync(input.TenancyName,
                input.Name,
                input.AdminPassword,
                input.AdminEmailAddress,
                input.ConnectionString,
                input.IsActive,
                input.EditionId,
                input.ShouldChangePasswordOnNextLogin,
                input.SendActivationEmail,
                input.SubscriptionEndDateUtc?.ToUniversalTime(),
                input.IsInTrialPeriod,
                AppUrlService.CreateEmailActivationUrlFormat(input.TenancyName)
            );

            #region TenantDataSeeder
            try
            {
                using (var uow = _unitOfWorkManager.Begin())
                {
                    var tenant = _tenantRepository.Get(tenantId);

                    // Switching to host is necessary for single tenant mode.
                    using (_unitOfWorkManager.Current.SetTenantId(null))
                    {
                        var dbContext = await _dbContextProvider.GetDbContextAsync();
                        CancellationToken cancellationToken = new CancellationToken();
                        if (await dbContext.Database.CanConnectAsync(cancellationToken))
                        {
                            new TenantDataCreator(dbContext, tenant).Create();
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {

                //throw;
            }
            #endregion TenantDataSeeder
        }

        [AbpAuthorize(AppPermissions.Pages_Tenants_Edit)]
        public async Task<TenantEditDto> GetTenantForEdit(EntityDto input)
        {
            var tenantEditDto = ObjectMapper.Map<TenantEditDto>(await TenantManager.GetByIdAsync(input.Id));
            tenantEditDto.ConnectionString = SimpleStringCipher.Instance.Decrypt(tenantEditDto.ConnectionString);
            return tenantEditDto;
        }

        [AbpAuthorize(AppPermissions.Pages_Tenants_Edit)]
        public async Task UpdateTenant(TenantEditDto input)
        {
            await TenantManager.CheckEditionAsync(input.EditionId, input.IsInTrialPeriod);

            input.ConnectionString = SimpleStringCipher.Instance.Encrypt(input.ConnectionString);
            var tenant = await TenantManager.GetByIdAsync(input.Id);

            if (tenant.EditionId != input.EditionId)
            {
                await EventBus.TriggerAsync(new TenantEditionChangedEventData
                {
                    TenantId = input.Id,
                    OldEditionId = tenant.EditionId,
                    NewEditionId = input.EditionId
                });
            }


            ObjectMapper.Map(input, tenant);
            tenant.SubscriptionEndDateUtc = tenant.SubscriptionEndDateUtc?.ToUniversalTime();

            await TenantManager.UpdateAsync(tenant);
            #region TenantDataSeeder
            try
            {
                using (var uow = _unitOfWorkManager.Begin())
                {
                    //var tenant = _tenantRepository.Get(tenantId);

                    // Switching to host is necessary for single tenant mode.
                    using (_unitOfWorkManager.Current.SetTenantId(null))
                    {
                        var dbContext = await _dbContextProvider.GetDbContextAsync();
                        CancellationToken cancellationToken = new CancellationToken();
                        if (await dbContext.Database.CanConnectAsync(cancellationToken))
                        {
                            new TenantDataCreator(dbContext, tenant).Create();
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {

                //throw;
            }
            #endregion TenantDataSeeder
        }

        [AbpAuthorize(AppPermissions.Pages_Tenants_Delete)]
        public async Task DeleteTenant(EntityDto input)
        {
            var tenant = await TenantManager.GetByIdAsync(input.Id);
            await TenantManager.DeleteAsync(tenant);
        }

        [AbpAuthorize(AppPermissions.Pages_Tenants_ChangeFeatures)]
        public async Task<GetTenantFeaturesEditOutput> GetTenantFeaturesForEdit(EntityDto input)
        {
            var features = FeatureManager.GetAll()
                .Where(f => f.Scope.HasFlag(FeatureScopes.Tenant));
            var featureValues = await TenantManager.GetFeatureValuesAsync(input.Id);

            return new GetTenantFeaturesEditOutput
            {
                Features = ObjectMapper.Map<List<FlatFeatureDto>>(features).OrderBy(f => f.DisplayName).ToList(),
                FeatureValues = featureValues.Select(fv => new NameValueDto(fv)).ToList()
            };
        }

        [AbpAuthorize(AppPermissions.Pages_Tenants_ChangeFeatures)]
        public async Task UpdateTenantFeatures(UpdateTenantFeaturesInput input)
        {
            await TenantManager.SetFeatureValuesAsync(input.Id, input.FeatureValues.Select(fv => new NameValue(fv.Name, fv.Value)).ToArray());
        }

        [AbpAuthorize(AppPermissions.Pages_Tenants_ChangeFeatures)]
        public async Task ResetTenantSpecificFeatures(EntityDto input)
        {
            await TenantManager.ResetAllFeaturesAsync(input.Id);
        }

        public async Task UnlockTenantAdmin(EntityDto input)
        {
            using (CurrentUnitOfWork.SetTenantId(input.Id))
            {
                var tenantAdmin = await UserManager.GetAdminAsync();
                if (tenantAdmin != null)
                {
                    tenantAdmin.Unlock();
                }
            }
        }

        /// <summary>
        /// Gets the tenants for dropdown.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns>
        /// The tenant list dto
        /// </returns>
        public async Task<List<TenantListDto>> GetTenantsForDropdown(string email)
        {
            List<TenantAndAdminIdsDto> tenantAndAdminIds = new List<TenantAndAdminIdsDto>();
            var tenants = _tenantRepository.GetAll().Where(a=> !a.IsDeleted && a.IsActive).IgnoreQueryFilters();

            using (var uow = _unitOfWorkManager.Begin(TransactionScopeOption.RequiresNew))
            {
                foreach (var tenant in tenants)
                {
                    using (_unitOfWorkProvider.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
                    {
                        using (_unitOfWorkProvider.Current.SetTenantId(tenant.Id))
                        {
                            try
                            {
                                if (string.IsNullOrEmpty(tenant.ConnectionString))
                                {
                                    var users = _userRepository.GetAll().Where(x => x.EmailAddress.ToLower() == email.ToLower() && x.TenantId != null && x.IsActive && !x.IsDeleted);
                                    if (users !=null && users.Count() > 0 )
                                    {
                                        foreach (var item in users.ToList())
                                        {
                                            var isItemExists = tenantAndAdminIds.Any(a => a.TenantId == item.TenantId);
                                            if (!isItemExists)
                                            {
                                                string tenancyName = string.Empty;
                                                var userRole = _userRoleRepository.GetAll().Where(a => a.UserId == item.Id && a.TenantId == item.TenantId).FirstOrDefault();
                                                if (userRole != null)
                                                {
                                                    var roleId = userRole.RoleId;
                                                    var role = _roleRepository.GetAll().Where(r => r.Id == roleId).FirstOrDefault();
                                                    if (role != null)
                                                    {
                                                        tenancyName = role.Name;
                                                    }
                                                }

                                                tenantAndAdminIds.Add(new TenantAndAdminIdsDto { TenantId = item.TenantId, AdminId = item.Id,TenancyRole= tenancyName });
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    string conn = SimpleStringCipher.Instance.Decrypt(tenant.ConnectionString);
                                    var options = new DbContextOptionsBuilder<econsysDbContext>().UseSqlServer(conn).Options;

                                    using (var context = new econsysDbContext(options))
                                    {
                                        var users = context.Users.Where(x => x.EmailAddress.ToLower() == email.ToLower() && x.TenantId != null && x.IsActive && !x.IsDeleted);
                                        if (users != null && users.Count() > 0)
                                        {
                                            foreach (var item in users.ToList())
                                            {
                                                var isItemExists = tenantAndAdminIds.Any(a => a.TenantId == item.TenantId);
                                                if (!isItemExists)
                                                {
                                                    if (!isItemExists)
                                                    {
                                                        string displayRoleName = string.Empty;
                                                        var userRole = context.UserRoles.Where(ur => ur.UserId == item.Id && ur.TenantId == item.TenantId).FirstOrDefault();
                                                        if (userRole != null)
                                                        {
                                                            var roleId = userRole.RoleId;
                                                            var role = context.Roles.Where(r => r.Id == roleId).FirstOrDefault();
                                                            if (role != null)
                                                            {
                                                                displayRoleName = role.Name;
                                                            }
                                                        }

                                                        tenantAndAdminIds.Add(new TenantAndAdminIdsDto { TenantId = item.TenantId, AdminId = item.Id, TenancyRole = displayRoleName });
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                            }
                        }
                    }
                }
            }
            using (_unitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
            {
            }

            List<TenantListDto> tenantListDtos = new List<TenantListDto>();
            if (tenantAndAdminIds != null && tenantAndAdminIds.Count() > 0)
            {
                List<Tenant> tenantList = new List<Tenant>();
                foreach (var item in tenantAndAdminIds)
                {
                    var tenant = TenantManager.Tenants.Where(a => a.Id == item.TenantId).FirstOrDefault();
                    if (tenant != null)
                    {
                        TenantListDto tenantDto = ObjectMapper.Map<TenantListDto>(tenant);
                        tenantDto.Id = tenant.Id;
                        tenantDto.AdminId = item.AdminId;
                        tenantDto.TenancyRoleName = item.TenancyRole;
                        tenantListDtos.Add(tenantDto);
                    }
                }
            }

            return tenantListDtos;
        }

        public async Task<List<TenantListDto>> GetAllTenants()
        {
            var tenants = await TenantManager.Tenants.ToListAsync();

            ObjectMapper.Map<List<TenantListDto>>(tenants);

            return ObjectMapper.Map<List<TenantListDto>>(tenants);
        }
    }
}
