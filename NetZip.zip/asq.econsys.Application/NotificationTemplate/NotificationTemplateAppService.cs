﻿using Abp.Authorization;
using Abp.Domain.Uow;
using Abp.EntityFrameworkCore;
using asq.econsys.EntityFrameworkCore;
using asq.econsys.NotificationTemplate.Dto;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using asq.econsys.Eco.EmailTemplates;
using asq.econsys.Net.Emailing;
using Abp.Domain.Repositories;

namespace asq.econsys.NotificationTemplate
{
    [AbpAuthorize]
    public class NotificationTemplateAppService : econsysAppServiceBase, INotificationTemplateAppService
    {
        #region private readonly variables
        private readonly IDbContextProvider<econsysDbContext> _dbContextProvider;
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly EmailTemplateProvider _emailTemplateProvider;
        private readonly IRepository<NotifTemplate, long> _notifTemplate;
        #endregion

        #region constructor
        public NotificationTemplateAppService(IDbContextProvider<econsysDbContext> dbContextProvider,
            IUnitOfWorkManager unitOfWorkManager,
            EmailTemplateProvider emailTemplateProvider,
            IRepository<NotifTemplate, long> notifTemplate)
        {
            _dbContextProvider = dbContextProvider;
            _unitOfWorkManager = unitOfWorkManager;
            _emailTemplateProvider = emailTemplateProvider;
            _notifTemplate = notifTemplate;
        }
        #endregion

        /// <summary>
        /// Gets the notification templte for tenant.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <returns>
        /// Notification template dto model
        /// </returns>
        public async Task<NotificationTemplateDto> GetNotificationTemplteForTenant(int tenantId)
        {
            var notificationTemplateDto = new NotificationTemplateDto();
            try
            {
                notificationTemplateDto = await GetTemplate(tenantId);
            }
            catch (System.Exception ex)
            {
            }

            return notificationTemplateDto;
        }

        public async Task CreateOrUpdate(NotificationTemplateDto notificationTemplateDto)
        {
            var dbContext = await _dbContextProvider.GetDbContextAsync();
            CancellationToken cancellationToken = new CancellationToken();
            if (await dbContext.Database.CanConnectAsync(cancellationToken))
            {
                using (CurrentUnitOfWork.DisableFilter(AbpDataFilters.MayHaveTenant))
                {
                    try
                    {
                        var template = this._notifTemplate.FirstOrDefault(t => t.TenantId == notificationTemplateDto.TenantId && !t.IsDeleted);
                        if (template != null)
                        {
                            template.EmailBody = notificationTemplateDto.EmailBody;
                            await _notifTemplate.UpdateAsync(template);
                        }
                        else
                        {
                            NotifTemplate notifTemplate = new NotifTemplate();
                            notifTemplate.TenantId = notificationTemplateDto.TenantId;
                            notifTemplate.EmailBody = notificationTemplateDto.EmailBody;

                            await _notifTemplate.InsertAsync(notifTemplate);
                        }
                        dbContext.SaveChanges();
                    }
                    catch (System.Exception)
                    {
                    }
                }
            }
        }

        public async Task<NotificationTemplateDto> GetTemplateForSpecificTenant(int tenantId)
        {
            var notificationTemplateDto = new NotificationTemplateDto();
            try
            {
                notificationTemplateDto = await GetTemplate(tenantId);
                if (notificationTemplateDto != null && string.IsNullOrEmpty(notificationTemplateDto.EmailBody))
                {
                    string strTemplate = _emailTemplateProvider.GetDefaultTemplate(tenantId);
                    notificationTemplateDto.EmailBody = strTemplate;
                }
            }
            catch (System.Exception ex)
            {
                string strTemplate = _emailTemplateProvider.GetDefaultTemplate(tenantId);
                notificationTemplateDto.EmailBody = strTemplate;
            }

            return notificationTemplateDto;
        }


        /// <summary>
        /// Gets the template.
        /// </summary>
        /// <param name="tenantId">The tenant identifier.</param>
        private async Task<NotificationTemplateDto> GetTemplate(int tenantId)
        {
            var notificationTemplateDto = new NotificationTemplateDto();
            try
            {
                using (var uow = _unitOfWorkManager.Begin())
                {
                    using (_unitOfWorkManager.Current.SetTenantId(tenantId))
                    {
                        var dbContext = await _dbContextProvider.GetDbContextAsync();
                        CancellationToken cancellationToken = new CancellationToken();
                        if (await dbContext.Database.CanConnectAsync(cancellationToken))
                        {
                            var template = _notifTemplate.FirstOrDefault(t => t.TenantId == tenantId && !t.IsDeleted);
                            if (template != null)
                            {
                                notificationTemplateDto.Id = template.Id;
                                notificationTemplateDto.EmailBody = template.EmailBody;
                                notificationTemplateDto.TenantId = template.TenantId;
                                //return notificationTemplateDto;
                            }
                        }
                    }
                }
            }
            catch (System.Exception)
            {

            }
            

            return notificationTemplateDto;
        }
    }
}
