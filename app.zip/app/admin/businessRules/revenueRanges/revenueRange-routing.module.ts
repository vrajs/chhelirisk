﻿import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {RevenueRangesComponent} from './revenueRanges.component';



const routes: Routes = [
    {
        path: '',
        component: RevenueRangesComponent,
        pathMatch: 'full'
    },
    
    
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class RevenueRangeRoutingModule {
}
