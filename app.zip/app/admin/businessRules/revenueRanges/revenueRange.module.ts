﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';
import {RevenueRangeRoutingModule} from './revenueRange-routing.module';
import {RevenueRangesComponent} from './revenueRanges.component';
import {CreateOrEditRevenueRangeModalComponent} from './create-or-edit-revenueRange-modal.component';
import {ViewRevenueRangeModalComponent} from './view-revenueRange-modal.component';
import { GridModule, EditService, ToolbarService, SortService, PageService } from '@syncfusion/ej2-angular-grids';



@NgModule({
    declarations: [
        RevenueRangesComponent,
        CreateOrEditRevenueRangeModalComponent,
        ViewRevenueRangeModalComponent,
        
    ],
    imports: [AppSharedModule, RevenueRangeRoutingModule , AdminSharedModule , GridModule],
    bootstrap:[RevenueRangesComponent],
    providers: [EditService, ToolbarService, SortService, PageService]
    
})
export class RevenueRangeModule {
}
