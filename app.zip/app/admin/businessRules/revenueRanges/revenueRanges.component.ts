﻿import {AppConsts} from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute , Router} from '@angular/router';
import { RevenueRangesServiceProxy, RevenueRangeDto, CreateOrEditRevenueRangeDto, GetRevenueRangeForViewDto  } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditRevenueRangeModalComponent } from './create-or-edit-revenueRange-modal.component';

import { ViewRevenueRangeModalComponent } from './view-revenueRange-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import { DateTime } from 'luxon';

             import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { EditSettingsModel, ToolbarItems } from '@syncfusion/ej2-grids';
import { finalize } from 'rxjs/operators';

@Component({
    templateUrl: './revenueRanges.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()]
})
export class RevenueRangesComponent extends AppComponentBase {
    
    
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditRevenueRangeModal', { static: true }) createOrEditRevenueRangeModal: CreateOrEditRevenueRangeModalComponent;
    @ViewChild('viewRevenueRangeModalComponent', { static: true }) viewRevenueRangeModal: ViewRevenueRangeModalComponent;   
    
    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    advancedFiltersAreShown = false;
    filterText = '';
    titleFilter = '';
    maxDisplayOrderFilter : number;
		maxDisplayOrderFilterEmpty : number;
		minDisplayOrderFilter : number;
		minDisplayOrderFilterEmpty : number;
    maxMinRangeFilter : number;
		maxMinRangeFilterEmpty : number;
		minMinRangeFilter : number;
		minMinRangeFilterEmpty : number;
    maxMaxRangeFilter : number;
		maxMaxRangeFilterEmpty : number;
		minMaxRangeFilter : number;
		minMaxRangeFilterEmpty : number;


    _entityTypeFullName = 'asq.econsys.Eco.BusinessRules.RevenueRange';
    entityHistoryEnabled = false;

    editSettings: EditSettingsModel;
    toolbar: ToolbarItems[];
    revenueRangeRules: object;
    editeditemindex: any;
    skip_count = 0;
    take_count = 10;
    count = 0;
    value = 'value';
    indexTitle: any;

    revenueRanges: GetRevenueRangeForViewDto[] = [];
    addOrEditRevenueRange: CreateOrEditRevenueRangeDto = new CreateOrEditRevenueRangeDto();
    saving: boolean;


    constructor(
        injector: Injector,
        private _revenueRangesServiceProxy: RevenueRangesServiceProxy,
        private _notifyService: NotifyService,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
             private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.revenueRangeRules = {
            required: true,
            minLength: [this.minRange, 'The entered value is already present in another range.'],
            maxLength: [this.maxRange, 'The entered value is already present in another range.'],
        };
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        this._revenueRangesServiceProxy
            .getAll(
                this.filterText,
                this.titleFilter,
                this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty : this.maxDisplayOrderFilter,
                this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty : this.minDisplayOrderFilter,
                this.maxMinRangeFilter == null ? this.maxMinRangeFilterEmpty : this.maxMinRangeFilter,
                this.minMinRangeFilter == null ? this.minMinRangeFilterEmpty : this.minMinRangeFilter,
                this.maxMaxRangeFilter == null ? this.maxMaxRangeFilterEmpty : this.maxMaxRangeFilter,
                this.minMaxRangeFilter == null ? this.minMaxRangeFilterEmpty : this.minMaxRangeFilter,
                'title',
                0,
                1000
            )
            .subscribe((result) => {
                this.revenueRanges = result.items;
            });
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true };
        this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return this.isGrantedAny('Pages.Administration.AuditLogs') && customSettings.EntityHistory && customSettings.EntityHistory.isEnabled && _filter(customSettings.EntityHistory.enabledEntities, entityType => entityType === this._entityTypeFullName).length === 1;
    }
    actionBegin(args: any): void {
           
        if (args.action === 'edit') {
            this.revenueRanges.splice(this.indexTitle, 1);
            this.revenueRanges.splice(this.indexTitle, 0, args.data);
            

        } else if (args.requestType === 'infiniteScroll' && args.data.length < this.count) {
            this.skip_count += this.take_count;
        } else if (args.requestType === 'delete') {
               
            var deleteRevenueRange = new RevenueRangeDto();
            deleteRevenueRange.id = args.data[0].revenueRange.id;
               
            this.deleteRevenueRange(deleteRevenueRange);
        } else if (args.action === 'add' && args.requestType === 'save') {
               
            this.addOrEditRevenueRange.title = args.data.revenueRange.title;
            this.addOrEditRevenueRange.minRange = args.data.revenueRange.minRange;

            this.addOrEditRevenueRange.maxRange = args.data.revenueRange.maxRange;

            this.addSize(this.addOrEditRevenueRange);
            this.revenueRanges.sort();
        }
        if (args.requestType === 'beginEdit' || args.requestType === 'save') {
            this.indexTitle = args.rowData.revenueRange.title;
               
            this.addOrEditRevenueRange.id = args.data.revenueRange.id;

            this.addOrEditRevenueRange.title = args.data.revenueRange.title;
            this.addOrEditRevenueRange.minRange = args.data.revenueRange.minRange;

            this.addOrEditRevenueRange.maxRange = args.data.revenueRange.maxRange;
            this.addSize(this.addOrEditRevenueRange);
            
        }
        //    
    }
    addSize(size): void {
        this._revenueRangesServiceProxy
            .createOrEdit(size)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
            });
    }


    getRevenueRanges(event?: LazyLoadEvent) {
        if (this.primengTableHelper.shouldResetPaging(event)) {
            this.paginator.changePage(0);
            if (this.primengTableHelper.records &&
                this.primengTableHelper.records.length > 0) {
                return;
            }
        }

        this.primengTableHelper.showLoadingIndicator();

        this._revenueRangesServiceProxy.getAll(
            this.filterText,
            this.titleFilter,
            this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty: this.maxDisplayOrderFilter,
            this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty: this.minDisplayOrderFilter,
            this.maxMinRangeFilter == null ? this.maxMinRangeFilterEmpty: this.maxMinRangeFilter,
            this.minMinRangeFilter == null ? this.minMinRangeFilterEmpty: this.minMinRangeFilter,
            this.maxMaxRangeFilter == null ? this.maxMaxRangeFilterEmpty: this.maxMaxRangeFilter,
            this.minMaxRangeFilter == null ? this.minMaxRangeFilterEmpty: this.minMaxRangeFilter,
            this.primengTableHelper.getSorting(this.dataTable),
            this.primengTableHelper.getSkipCount(this.paginator, event),
            this.primengTableHelper.getMaxResultCount(this.paginator, event)
        ).subscribe(result => {
            this.primengTableHelper.totalRecordsCount = result.totalCount;
            this.primengTableHelper.records = result.items;
            this.primengTableHelper.hideLoadingIndicator();
            this.revenueRanges = result.items;

        });
    }

    reloadPage(): void {
        this.paginator.changePage(this.paginator.getPage());
    }

    createRevenueRange(): void {
        this.createOrEditRevenueRangeModal.show();        
    }


    showHistory(revenueRange: RevenueRangeDto): void {
        this.entityTypeHistoryModal.show({
            entityId: revenueRange.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: ''
        });
    }

    deleteRevenueRange(revenueRange: RevenueRangeDto): void {
        this.message.confirm(
            '',
            this.l('AreYouSure'),
            (isConfirmed) => {
                if (isConfirmed) {
                    this._revenueRangesServiceProxy.delete(revenueRange.id)
                        .subscribe(() => {
                            this.reloadPage();
                            this.notify.success(this.l('SuccessfullyDeleted'));
                        });
                }
            }
        );
    }

    exportToExcel(): void {
        this._revenueRangesServiceProxy.getRevenueRangesToExcel(
        this.filterText,
            this.titleFilter,
            this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty: this.maxDisplayOrderFilter,
            this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty: this.minDisplayOrderFilter,
            this.maxMinRangeFilter == null ? this.maxMinRangeFilterEmpty: this.maxMinRangeFilter,
            this.minMinRangeFilter == null ? this.minMinRangeFilterEmpty: this.minMinRangeFilter,
            this.maxMaxRangeFilter == null ? this.maxMaxRangeFilterEmpty: this.maxMaxRangeFilter,
            this.minMaxRangeFilter == null ? this.minMaxRangeFilterEmpty: this.minMaxRangeFilter,
        )
        .subscribe(result => {
            this._fileDownloadService.downloadTempFile(result);
         });
    }
    
    minRange: (args: { [key: string]: string }) => boolean = (args: { [key: string]: string }) => {
           
        var rangeCheck = true;
        for (let range of this.revenueRanges) {
            if (this.indexTitle == range.revenueRange.title) {
                continue;
                } else if (
                range.revenueRange.minRange <= Number(args[this.value]) &&
                range.revenueRange.maxRange >= Number(args[this.value])
            ) {
                rangeCheck = false;
                break;
            }
        }
        //  this.revenueRanges.map((range)=>{
        //         
        //      if(range.revenueRange.minRange <= Number(args[this.value]) && range.revenueRange.maxRange >= Number(args[this.value])  ){
        //          rangeCheck=false
        //             

        //      }
        //      else{
        //          rangeCheck=true
        //      }
        //  })
        return rangeCheck;
    };
    maxRange: (args: { [key: string]: string }) => boolean = (args: { [key: string]: string }) => {
        var rangeCheck = true;
        for (let range of this.revenueRanges) {
            if (this.indexTitle == range.revenueRange.title) {
                continue;
                } else if (
                range.revenueRange.minRange <= Number(args[this.value]) &&
                range.revenueRange.maxRange >= Number(args[this.value])
            ) {
                rangeCheck = false;
                   
                break;
            } else {
                rangeCheck = true;
            }
        }

        // var isInRange=this.revenueRanges.map((range)=>{

        //     if(range.revenueRange.minRange <= Number(args[this.value]) && range.revenueRange.maxRange >= Number(args[this.value])  ){
        //         rangeCheck=false
        //     }
        //     else{
        //         rangeCheck=true
        //     }
        // })
        return rangeCheck;
        // return args[this.value].length <= 8;
    };
    
    
    
}
