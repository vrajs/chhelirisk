﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef} from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { RuleConfigurationsServiceProxy, CreateOrEditRuleConfigurationDto ,RuleConfigurationOrganizationUnitLookupTableDto
					,RuleConfigurationRuleElementLookupTableDto
					,RuleConfigurationRevenueRangeLookupTableDto
					,RuleConfigurationRuleFlagLookupTableDto
					,RuleConfigurationRuleValueLookupTableDto
					} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

             import { DateTimeService } from '@app/shared/common/timing/date-time.service';



@Component({
    selector: 'createOrEditRuleConfigurationModal',
    templateUrl: './create-or-edit-ruleConfiguration-modal.component.html'
})
export class CreateOrEditRuleConfigurationModalComponent extends AppComponentBase implements OnInit{
   
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    ruleConfiguration: CreateOrEditRuleConfigurationDto = new CreateOrEditRuleConfigurationDto();

    organizationUnitDisplayName = '';
    ruleElementTitle = '';
    revenueRangeTitle = '';
    ruleFlagTitle = '';
    ruleValueTitle = '';

	allOrganizationUnits: RuleConfigurationOrganizationUnitLookupTableDto[];
						allRuleElements: RuleConfigurationRuleElementLookupTableDto[];
						allRevenueRanges: RuleConfigurationRevenueRangeLookupTableDto[];
						allRuleFlags: RuleConfigurationRuleFlagLookupTableDto[];
						allRuleValues: RuleConfigurationRuleValueLookupTableDto[];
					

    constructor(
        injector: Injector,
        private _ruleConfigurationsServiceProxy: RuleConfigurationsServiceProxy,
             private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }
    
    show(ruleConfigurationId?: number): void {
    

        if (!ruleConfigurationId) {
            this.ruleConfiguration = new CreateOrEditRuleConfigurationDto();
            this.ruleConfiguration.id = ruleConfigurationId;
            this.organizationUnitDisplayName = '';
            this.ruleElementTitle = '';
            this.revenueRangeTitle = '';
            this.ruleFlagTitle = '';
            this.ruleValueTitle = '';


            this.active = true;
            this.modal.show();
        } else {
            this._ruleConfigurationsServiceProxy.getRuleConfigurationForEdit(ruleConfigurationId).subscribe(result => {
                this.ruleConfiguration = result.ruleConfiguration;

                this.organizationUnitDisplayName = result.organizationUnitDisplayName;
                this.ruleElementTitle = result.ruleElementTitle;
                this.revenueRangeTitle = result.revenueRangeTitle;
                this.ruleFlagTitle = result.ruleFlagTitle;
                this.ruleValueTitle = result.ruleValueTitle;


                this.active = true;
                this.modal.show();
            });
        }
        this._ruleConfigurationsServiceProxy.getAllOrganizationUnitForTableDropdown().subscribe(result => {						
						this.allOrganizationUnits = result;
					});
					this._ruleConfigurationsServiceProxy.getAllRuleElementForTableDropdown().subscribe(result => {						
						this.allRuleElements = result;
					});
					this._ruleConfigurationsServiceProxy.getAllRevenueRangeForTableDropdown().subscribe(result => {						
						this.allRevenueRanges = result;
					});
					this._ruleConfigurationsServiceProxy.getAllRuleFlagForTableDropdown().subscribe(result => {						
						this.allRuleFlags = result;
					});
					this._ruleConfigurationsServiceProxy.getAllRuleValueForTableDropdown().subscribe(result => {						
						this.allRuleValues = result;
					});
					
        
    }

    save(): void {
            this.saving = true;
            
			
			
            this._ruleConfigurationsServiceProxy.createOrEdit(this.ruleConfiguration)
             .pipe(finalize(() => { this.saving = false;}))
             .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
             });
    }













    close(): void {
        this.active = false;
        this.modal.hide();
    }
    
     ngOnInit(): void {
        
     }    
}
