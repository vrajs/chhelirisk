﻿import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {RuleConfigurationsComponent} from './ruleConfigurations.component';



const routes: Routes = [
    {
        path: '',
        component: RuleConfigurationsComponent,
        pathMatch: 'full'
    },
    
    
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class RuleConfigurationRoutingModule {
}
