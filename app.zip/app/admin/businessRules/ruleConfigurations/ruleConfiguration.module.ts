﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';
import {RuleConfigurationRoutingModule} from './ruleConfiguration-routing.module';
import {RuleConfigurationsComponent} from './ruleConfigurations.component';
import {CreateOrEditRuleConfigurationModalComponent} from './create-or-edit-ruleConfiguration-modal.component';
import {ViewRuleConfigurationModalComponent} from './view-ruleConfiguration-modal.component';
import { EditService, ToolbarService, SortService, PageService, GridModule } from '@syncfusion/ej2-angular-grids';
import { DetailRowService } from '@syncfusion/ej2-angular-grids';



@NgModule({
    declarations: [
        RuleConfigurationsComponent,
        CreateOrEditRuleConfigurationModalComponent,
        ViewRuleConfigurationModalComponent,
        
    ],
    imports: [AppSharedModule, RuleConfigurationRoutingModule , AdminSharedModule , GridModule],
    providers: [EditService, ToolbarService, SortService, PageService , DetailRowService],
    bootstrap:[RuleConfigurationsComponent],

})
export class RuleConfigurationModule {
}
