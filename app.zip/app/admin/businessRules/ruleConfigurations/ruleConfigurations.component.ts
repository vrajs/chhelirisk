import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { RuleConfigurationsServiceProxy, RuleConfigurationDto, BusinessRuleAllDDLDto, RuleFlagsServiceProxy, RuleElementsServiceProxy, RuleValuesServiceProxy, RevenueRangesServiceProxy, CreateOrEditRuleConfigurationDto, GetRuleSettingForViewDto, CreateOrEditRuleSettingDto, RuleSettingsServiceProxy, RuleSettingDto  } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { CreateOrEditRuleConfigurationModalComponent } from './create-or-edit-ruleConfiguration-modal.component';
import { ViewRuleConfigurationModalComponent } from './view-ruleConfiguration-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import { FormArray, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { finalize } from 'rxjs/operators';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { EditSettingsModel, ToolbarItems, IEditCell, RowDataBoundEventArgs } from '@syncfusion/ej2-grids';
import { DataManager , Query} from '@syncfusion/ej2-data';


@Component({
    templateUrl: './ruleConfigurations.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()]
})
export class RuleConfigurationsComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditRuleConfigurationModal', { static: true }) createOrEditRuleConfigurationModal: CreateOrEditRuleConfigurationModalComponent;
    @ViewChild('viewRuleConfigurationModalComponent', { static: true }) viewRuleConfigurationModal: ViewRuleConfigurationModalComponent;   
    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    advancedFiltersAreShown = false;
    filterText = '';
    organizationUnitDisplayNameFilter = '';
    ruleElementTitleFilter = '';
    revenueRangeTitleFilter = '';
    ruleFlagTitleFilter = '';
    ruleValueTitleFilter = '';

    _entityTypeFullName = 'asq.econsys.Eco.BusinessRules.RuleConfiguration';
    entityHistoryEnabled = false;
    frmFG: FormGroup;
    allDDL: BusinessRuleAllDDLDto = new BusinessRuleAllDDLDto();
    colors: {[key: string]: string} = {};
    saving: boolean = false;
    haschangesEng: boolean = false;
    haschangesCom: boolean = false;
    selectedTab: string = 'tabengineering';
    decimalFieldValueCheck:number;
    
    editSettings: EditSettingsModel;
    toolbar: ToolbarItems[];
    skip_count = 0;
    take_count = 10;
    count = 0;
    value = 'value';
    savingSetting: boolean;
    valueParams: IEditCell;
    ruleTypeTitle = '';
    organizationUnitDisplayName = '';
    
    public options: any[] = [
        { option: 'Yes', Id: '1' },
        { option: 'No', Id: '2' }
    ];
    optionParams = {
        params: {
            allowFiltering: true,
            dataSource: new DataManager(this.options),
            fields: { text: 'option', value: 'option' },
            // query: new Query(),
            actionComplete: () => false
        }
    };
   
    
      valueRules: object;

    marginConfigurations: GetRuleSettingForViewDto[] = [];
    customerCommitments: GetRuleSettingForViewDto[] = [];
    smallWorks: GetRuleSettingForViewDto[] = [];
    timeAndMaterials: GetRuleSettingForViewDto[] = [];
    addOrEditRuleSetting: CreateOrEditRuleSettingDto = new CreateOrEditRuleSettingDto();
    ruleSettingsForEditArray: CreateOrEditRuleSettingDto[]=[];
    dataWithDecimalFieldValue:GetRuleSettingForViewDto[] = [];
    dataWithStringFieldValue:GetRuleSettingForViewDto[] = [];
    


    constructor(
        injector: Injector,
        private _fileDownloadService: FileDownloadService,
        private _ruleConfigurationsServiceProxy: RuleConfigurationsServiceProxy,
        private _ruleSettingsServiceProxy : RuleSettingsServiceProxy,
        private formBuilder: FormBuilder
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.valueRules = {
            required: true ,
            number  :true           
        };
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        this.frmFG = this.formBuilder.group({
            engineeringBRArray: this.formBuilder.array([]),
            commercialBRArray: this.formBuilder.array([]),
        });

        this.spinnerService.show();
        this._ruleConfigurationsServiceProxy.getBusinessRuleAllDDL().subscribe((result) => {
            this.spinnerService.hide();
            this.allDDL = result;
            if(result.ruleFlags != null && result.ruleFlags.length > 0) {
                result.ruleFlags.forEach(element => {
                this.colors[element.ruleFlag.id] = element.ruleFlag.hexColor;
                });
            }
            this.createForm();
            this.marginConfigurations = result.ruleSettings.filter((item) => item.ruleSetting.ruleTypeId == 'margin configuration');
                this.customerCommitments = result.ruleSettings.filter((item) => item.ruleSetting.ruleTypeId == 'customer commitment');

                this.smallWorks = result.ruleSettings.filter((item) => item.ruleSetting.ruleTypeId == 'small works');
 
                this.timeAndMaterials = result.ruleSettings.filter((item) => item.ruleSetting.ruleTypeId == 'time and material');
                this.dataWithDecimalFieldValue= result.ruleSettings.filter((item) => item.ruleSetting.ruleTypeId == 'customer commitment' && item.ruleSetting.fieldType=="Decimal");
                this.dataWithStringFieldValue= result.ruleSettings.filter((item) => item.ruleSetting.ruleTypeId  == 'customer commitment' && item.ruleSetting.fieldType=="String");
                this.decimalFieldValueCheck=this.dataWithDecimalFieldValue.length;

        }, () => {
            this.spinnerService.hide();
        });
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true  };
        this.toolbar = ['Edit', 'Update', 'Cancel'];
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return this.isGrantedAny('Pages.Administration.AuditLogs') && customSettings.EntityHistory && customSettings.EntityHistory.isEnabled && _filter(customSettings.EntityHistory.enabledEntities, entityType => entityType === this._entityTypeFullName).length === 1;
    }

    getRuleConfigurations(event?: LazyLoadEvent) {
        if (this.primengTableHelper.shouldResetPaging(event)) {
            this.paginator.changePage(0);
            if (this.primengTableHelper.records &&
                this.primengTableHelper.records.length > 0) {
                return;
            }
        }

        this.primengTableHelper.showLoadingIndicator();

        this._ruleConfigurationsServiceProxy.getAll(
            this.filterText,
            this.organizationUnitDisplayNameFilter,
            this.ruleElementTitleFilter,
            this.revenueRangeTitleFilter,
            this.ruleFlagTitleFilter,
            this.ruleValueTitleFilter,
            this.primengTableHelper.getSorting(this.dataTable),
            this.primengTableHelper.getSkipCount(this.paginator, event),
            this.primengTableHelper.getMaxResultCount(this.paginator, event)
        ).subscribe(result => {
            this.primengTableHelper.totalRecordsCount = result.totalCount;
            this.primengTableHelper.records = result.items;
            this.primengTableHelper.hideLoadingIndicator();
        });
    }

    reloadPage(): void {
        this.paginator.changePage(this.paginator.getPage());
    }

    createRuleConfiguration(): void {
        this.createOrEditRuleConfigurationModal.show();        
    }


    showHistory(ruleConfiguration: RuleConfigurationDto): void {
        this.entityTypeHistoryModal.show({
            entityId: ruleConfiguration.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: ''
        });
    }

    deleteRuleConfiguration(ruleConfiguration: RuleConfigurationDto): void {
        this.message.confirm(
            '',
            this.l('AreYouSure'),
            (isConfirmed) => {
                if (isConfirmed) {
                    this._ruleConfigurationsServiceProxy.delete(ruleConfiguration.id)
                        .subscribe(() => {
                            this.reloadPage();
                            this.notify.success(this.l('SuccessfullyDeleted'));
                        });
                }
            }
        );
    }

    exportToExcel(): void {
        this._ruleConfigurationsServiceProxy.getRuleConfigurationsToExcel(
        this.filterText,
            this.organizationUnitDisplayNameFilter,
            this.ruleElementTitleFilter,
            this.revenueRangeTitleFilter,
            this.ruleFlagTitleFilter,
            this.ruleValueTitleFilter,
        )
        .subscribe(result => {
            this._fileDownloadService.downloadTempFile(result);
         });
    }

    onSelectTab(data: TabDirective): void {
        this.selectedTab = data.customClass;
        // this.haschanges = false;
    }

    get engineeringBRArray(): FormArray {
        return this.frmFG.get('engineeringBRArray') as FormArray;
    }

    get commercialBRArray(): FormArray {
        return this.frmFG.get('commercialBRArray') as FormArray;
    }
    
    createForm() {
        const faEngineering = this.frmFG.get('engineeringBRArray') as FormArray;
        const faCommercial = this.frmFG.get('commercialBRArray') as FormArray;
        this.allDDL.revenueRanges.forEach((size, index) => {
            this.allDDL.ruleValues.forEach((ruleValue, index2) => {
                let rc = this.allDDL.ruleConfigurations.filter(x => x.ruleConfiguration.ruleValueId == ruleValue.ruleValue.id && x.ruleConfiguration.revenueRangeId == size.revenueRange.id)[0];

                if(ruleValue.ruleValue.ruleTypeId == "engineering") {
                    faEngineering.push(
                        this.formBuilder.group({
                            id: new FormControl(rc != undefined ? rc.ruleConfiguration.id : null, []),
                            ruleValueId: new FormControl(ruleValue.ruleValue.id, []),
                            revenueRangeId: new FormControl(size.revenueRange.id, []),
                            ruleFlagId: new FormControl(rc != undefined ? rc.ruleConfiguration.ruleFlagId : null, []),
                            ruleElementId: new FormControl(ruleValue.ruleValue.ruleElementId),
                            haschanges: false
                        })
                    );
                }
            });
        });

        this.allDDL.ruleValues.forEach((ruleValue, index2) => {
            let rc = this.allDDL.ruleConfigurations.filter(x => x.ruleConfiguration.ruleValueId == ruleValue.ruleValue.id )[0];

            if(ruleValue.ruleValue.ruleTypeId == "commercial") {
                faCommercial.push(
                    this.formBuilder.group({
                        id: new FormControl(rc != undefined ? rc.ruleConfiguration.id : null, []),
                        ruleValueId: new FormControl(ruleValue.ruleValue.id, []),
                        ruleFlagId: new FormControl(rc != undefined ? rc.ruleConfiguration.ruleFlagId : null, []),
                        ruleElementId: new FormControl(ruleValue.ruleValue.ruleElementId),
                        haschanges: false
                    })
                );
            }
        });

        this.frmFG.get('engineeringBRArray').valueChanges.subscribe(changes=> {
            if(this.selectedTab == 'tabengineering') {
                let hc = changes.filter(x => x.haschanges == true);
                this.haschangesEng = (hc && hc.length > 0 ? true : false);
            }
        });

        this.frmFG.get('commercialBRArray').valueChanges.subscribe(changes=> {
            if(this.selectedTab == 'tabcommercial') {
                let hc = changes.filter(x => x.haschanges == true);
                this.haschangesCom = (hc && hc.length > 0 ? true : false);
            }
        });
    }

    getFlagIdValue(ruleValueId, revenueRangeId) {
        let rc = this.allDDL.ruleConfigurations.filter(x => x.ruleConfiguration.ruleValueId == ruleValueId && x.ruleConfiguration.revenueRangeId == revenueRangeId)[0];
        if(rc != null && rc != undefined) {
            let flag = this.allDDL.ruleFlags.filter(x => x.ruleFlag.id == rc.ruleConfiguration.ruleFlagId)[0];
            return (flag != null && flag != undefined ? flag.ruleFlag.id : null)
        }
    }

    getFlagColorHex(id) {
        let flag = this.allDDL.ruleFlags.filter(x => x.ruleFlag.id == id)[0];
        return (flag != null && flag != undefined ? flag.ruleFlag.hexColor : '');
    }

    onFlagChange(event: any, frmitem: any, index) {
        let original = this.getFlagIdValue(frmitem.ruleValueId, frmitem.revenueRangeId);
        let haschange = original != frmitem.ruleFlagId ? true : false;
        if(this.selectedTab == 'tabengineering') {
            this.engineeringBRArray.controls[index].get('haschanges').setValue(haschange);
        } else if(this.selectedTab == 'tabcommercial') {
            this.commercialBRArray.controls[index].get('haschanges').setValue(haschange);
        }
    }

    saveEngineeringRules(): void {
        let formdata: CreateOrEditRuleConfigurationDto[] = [];
        if(this.selectedTab == 'tabengineering') {
            if(this.frmFG.value.engineeringBRArray != null && this.frmFG.value.engineeringBRArray.length > 0) {
                this.frmFG.value.engineeringBRArray.forEach((element, index) => {
                    if(element.haschanges) {
                        let dobj: CreateOrEditRuleConfigurationDto = new CreateOrEditRuleConfigurationDto();
                        Object.assign(dobj, element);
                        formdata.push(dobj);
                    }
                });
            }
        } else if(this.selectedTab == 'tabcommercial') {
            if(this.frmFG.value.commercialBRArray != null && this.frmFG.value.commercialBRArray.length > 0) {
                this.frmFG.value.commercialBRArray.forEach((element, index) => {
                    if(element.haschanges) {
                        let dobj: CreateOrEditRuleConfigurationDto = new CreateOrEditRuleConfigurationDto();
                        
                        Object.assign(dobj, element);
                        formdata.push(dobj);
                    }
                });
            }
        }
        
        if(!(formdata && formdata.length > 0)) {
            this.notify.warn("Please submit proper values!");
            return;
        }

        this.message.confirm(
            '',
            this.l('AreYouSure'),
            (isConfirmed) => {
                if (isConfirmed) {
                    this.saving = true;
                    this.spinnerService.show();
                    this._ruleConfigurationsServiceProxy
                        .bulkCreateOrEdit(formdata)
                        .pipe(finalize(() => { this.saving = false;}))
                        .subscribe(() => {
                            this.saving = false;
                            this.spinnerService.hide();
                            this.notify.info(this.l('SavedSuccessfully'));
                        }, () => {
                            this.saving = false;
                            this.spinnerService.hide();
                        });
                }
            }
        );
    }

    ruleValuesByElementId(id) {
        let result = this.allDDL.ruleValues.filter((x) => x.ruleValue.ruleElementId == id); // TODO - add sorting
        return result;
    }

    abbreviateNumber(value) {
        // return newValue;
        if (value <= 999) {
            return value;
        }
        // thousands
        else if (value >= 1000 && value <= 999999) {
            return value / 1000 + 'K';
        }
        // millions
        else if (value >= 1000000 && value <= 999999999) {
            return value / 1000000 + 'M';
        }
        // billions
        else if (value >= 1000000000 && value <= 999999999999) {
            return value / 1000000000 + 'B';
        } else {
            return value;
        }
    }

    actionBegin(args: any): void {
        
        if (args.requestType === 'infiniteScroll' && args.data.length < this.count) {
            this.skip_count += this.take_count;
        }

        if (args.action === 'edit' && args.requestType === 'save') {
            this._ruleSettingsServiceProxy.getRuleSettingForEdit(args.data.ruleSetting.id).subscribe((result) => {
                this.addOrEditRuleSetting = result.ruleSetting;

                this.ruleTypeTitle = result.ruleTypeTitle;
                this.organizationUnitDisplayName = result.organizationUnitDisplayName;
            });
            this.addOrEditRuleSetting.id = args.data.ruleSetting.id;

            this.addOrEditRuleSetting.title = args.data.ruleSetting.title;
            this.addOrEditRuleSetting.value = args.data.ruleSetting.value;
            this.addOrEditRuleSetting.organizationUnitId = args.data.ruleSetting.organizationUnitId;

            this.addOrEditRuleSetting.ruleTypeId = args.data.ruleSetting.ruleTypeId;
            this.addOrEditRuleSetting.fieldType = args.data.ruleSetting.fieldType;


            this.editRuleSetting(this.addOrEditRuleSetting);

        }
    }
    editRuleSetting(ruleSetting): void {
        this.ruleSettingsForEditArray.push(ruleSetting);
    }
    saveEditedRuleSettings():void{
        this._ruleSettingsServiceProxy
            .createOrEdit(this.ruleSettingsForEditArray)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
            });
    }

    deleteRuleSettins(ruleSetting:any): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._ruleSettingsServiceProxy.delete(ruleSetting.id).subscribe(() => {
                    this.reloadPage();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }
    
    
}
