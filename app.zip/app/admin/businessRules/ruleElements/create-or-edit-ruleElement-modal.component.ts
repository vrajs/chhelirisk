﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    RuleElementsServiceProxy,
    CreateOrEditRuleElementDto,
    RuleElementOrganizationUnitLookupTableDto,
    RuleElementRuleTypeLookupTableDto,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    selector: 'createOrEditRuleElementModal',
    templateUrl: './create-or-edit-ruleElement-modal.component.html',
})
export class CreateOrEditRuleElementModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    ruleElement: CreateOrEditRuleElementDto = new CreateOrEditRuleElementDto();

    organizationUnitDisplayName = '';
    ruleTypeTitle = '';

    allOrganizationUnits: RuleElementOrganizationUnitLookupTableDto[];
    allRuleTypes: RuleElementRuleTypeLookupTableDto[];

    constructor(
        injector: Injector,
        private _ruleElementsServiceProxy: RuleElementsServiceProxy,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    show(ruleElementId?: number): void {
        if (!ruleElementId) {
            this.ruleElement = new CreateOrEditRuleElementDto();
            this.ruleElement.id = ruleElementId;
            this.organizationUnitDisplayName = '';
            this.ruleTypeTitle = '';

            this.active = true;
            this.modal.show();
        } else {
            this._ruleElementsServiceProxy.getRuleElementForEdit(ruleElementId).subscribe((result) => {
                this.ruleElement = result.ruleElement;

                this.organizationUnitDisplayName = result.organizationUnitDisplayName;
                this.ruleTypeTitle = result.ruleTypeTitle;

                this.active = true;
                this.modal.show();
            });
        }
        this._ruleElementsServiceProxy.getAllOrganizationUnitForTableDropdown().subscribe((result) => {
            this.allOrganizationUnits = result;
        });
        this._ruleElementsServiceProxy.getAllRuleTypeForTableDropdown().subscribe((result) => {
            this.allRuleTypes = result;
        });
    }

    save(): void {
        this.saving = true;

        this._ruleElementsServiceProxy
            .createOrEdit(this.ruleElement)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                // window.location.reload();
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
            });
    }

    close(): void {
        this.modalSave.emit(null);

        this.active = false;
        this.modal.hide();
    }

    ngOnInit(): void {}
}
