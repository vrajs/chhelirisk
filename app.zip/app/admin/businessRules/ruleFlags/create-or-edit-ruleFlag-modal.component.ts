﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { RuleFlagsServiceProxy, CreateOrEditRuleFlagDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    selector: 'createOrEditRuleFlagModal',
    templateUrl: './create-or-edit-ruleFlag-modal.component.html',
})
export class CreateOrEditRuleFlagModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    ruleFlag: CreateOrEditRuleFlagDto = new CreateOrEditRuleFlagDto();

    constructor(
        injector: Injector,
        private _ruleFlagsServiceProxy: RuleFlagsServiceProxy,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    show(ruleFlagId?: string): void {
        if (!ruleFlagId) {
            this.ruleFlag = new CreateOrEditRuleFlagDto();
            this.ruleFlag.id = ruleFlagId;

            this.active = true;
            this.modal.show();
        } else {
            this._ruleFlagsServiceProxy.getRuleFlagForEdit(ruleFlagId).subscribe((result) => {
                this.ruleFlag = result.ruleFlag;

                this.active = true;
                this.modal.show();
            });
        }
    }

    save(): void {
        this.saving = true;

        this._ruleFlagsServiceProxy
            .createOrEdit(this.ruleFlag)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
            });
    }

    close(): void {
        this.modalSave.emit(null);

        this.active = false;
        this.modal.hide();
    }

    ngOnInit(): void {}
}
