﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';
import {RuleFlagRoutingModule} from './ruleFlag-routing.module';
import {RuleFlagsComponent} from './ruleFlags.component';
import {CreateOrEditRuleFlagModalComponent} from './create-or-edit-ruleFlag-modal.component';
import {ViewRuleFlagModalComponent} from './view-ruleFlag-modal.component';



@NgModule({
    declarations: [
        RuleFlagsComponent,
        CreateOrEditRuleFlagModalComponent,
        ViewRuleFlagModalComponent,
        
    ],
    imports: [AppSharedModule, RuleFlagRoutingModule , AdminSharedModule ],
    
})
export class RuleFlagModule {
}
