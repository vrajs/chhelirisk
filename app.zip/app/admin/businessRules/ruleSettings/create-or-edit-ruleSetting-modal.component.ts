﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    RuleSettingsServiceProxy,
    CreateOrEditRuleSettingDto,
    RuleSettingRuleTypeLookupTableDto,
    RuleSettingOrganizationUnitLookupTableDto,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    selector: 'createOrEditRuleSettingModal',
    templateUrl: './create-or-edit-ruleSetting-modal.component.html',
})
export class CreateOrEditRuleSettingModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    ruleSetting: CreateOrEditRuleSettingDto = new CreateOrEditRuleSettingDto();
    ruleSettings: CreateOrEditRuleSettingDto[] = [];

    ruleTypeTitle = '';
    organizationUnitDisplayName = '';

    allRuleTypes: RuleSettingRuleTypeLookupTableDto[];
    allOrganizationUnits: RuleSettingOrganizationUnitLookupTableDto[];

    constructor(
        injector: Injector,
        private _ruleSettingsServiceProxy: RuleSettingsServiceProxy,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    show(ruleSettingId?: number): void {
        if (!ruleSettingId) {
            this.ruleSetting = new CreateOrEditRuleSettingDto();
            this.ruleSetting.id = ruleSettingId;
            this.ruleTypeTitle = '';
            this.organizationUnitDisplayName = '';

            this.active = true;
            this.modal.show();
        } else {
            this._ruleSettingsServiceProxy.getRuleSettingForEdit(ruleSettingId).subscribe((result) => {
                this.ruleSetting = result.ruleSetting;

                this.ruleTypeTitle = result.ruleTypeTitle;
                this.organizationUnitDisplayName = result.organizationUnitDisplayName;

                this.active = true;
                this.modal.show();
            });
        }
        this._ruleSettingsServiceProxy.getAllRuleTypeForTableDropdown().subscribe((result) => {
            this.allRuleTypes = result;
        });
        this._ruleSettingsServiceProxy.getAllOrganizationUnitForTableDropdown().subscribe((result) => {
            this.allOrganizationUnits = result;
        });
    }

    save(): void {
        this.saving = true;
        this.ruleSettings.push(this.ruleSetting)
        this._ruleSettingsServiceProxy
            .createOrEdit(this.ruleSettings)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {

                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
            });
            this.ruleSettings=[];

    }

    close(): void {
        this.modalSave.emit(null);

        this.active = false;
        this.modal.hide();
    }

    ngOnInit(): void {}
}
