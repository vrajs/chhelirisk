﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { RuleSettingRoutingModule } from './ruleSetting-routing.module';
import { RuleSettingsComponent } from './ruleSettings.component';
import { CreateOrEditRuleSettingModalComponent } from './create-or-edit-ruleSetting-modal.component';
import { ViewRuleSettingModalComponent } from './view-ruleSetting-modal.component';

@NgModule({
    declarations: [RuleSettingsComponent, CreateOrEditRuleSettingModalComponent, ViewRuleSettingModalComponent],
    imports: [AppSharedModule, RuleSettingRoutingModule, AdminSharedModule],
})
export class RuleSettingModule {}
