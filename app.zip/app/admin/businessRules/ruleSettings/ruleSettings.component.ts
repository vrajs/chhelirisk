﻿import { AppConsts } from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RuleSettingsServiceProxy, RuleSettingDto, RuleTypeDto } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditRuleSettingModalComponent } from './create-or-edit-ruleSetting-modal.component';

import { ViewRuleSettingModalComponent } from './view-ruleSetting-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { filter as _filter } from 'lodash-es';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { EditSettingsModel, CommandModel, PageSettingsModel, InfiniteScrollSettingsModel, ToolbarItems } from '@syncfusion/ej2-grids';

@Component({
    templateUrl: './ruleSettings.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class RuleSettingsComponent extends AppComponentBase {
    @ViewChild('createOrEditRuleSettingModal', { static: true })
    createOrEditRuleSettingModal: CreateOrEditRuleSettingModalComponent;
    @ViewChild('viewRuleSettingModalComponent', { static: true }) viewRuleSettingModal: ViewRuleSettingModalComponent;

    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    advancedFiltersAreShown = false;
    filterText = '';
    titleFilter = '';
    valueFilter = '';
    fieldTypeFilter = '';
    maxDisplayOrderFilter: number;
    maxDisplayOrderFilterEmpty: number;
    minDisplayOrderFilter: number;
    minDisplayOrderFilterEmpty: number;
    ruleTypeTitleFilter = '';
    organizationUnitDisplayNameFilter = '';

    public editSettings: EditSettingsModel;
        public commands: CommandModel[];
        public options: PageSettingsModel | undefined;
        public infiniteOptions: InfiniteScrollSettingsModel | undefined;
        public count = 0;
        maxResultCount: number = 5;
        skipCount: number = 0;
        sortColumn: string = "";
        sortDirection: string = "";
        totalRecordCount: number = 0;
        pageSettings: any = { pageSizes: true, pageSize: 10, pageCount: 0, currentPage: 1 };
        public toolbarOptions: ToolbarItems[];
        public initialPage: PageSettingsModel;
        ruleSettingData: any[] = [];
    

    constructor(
        injector: Injector,
        private _ruleSettingsServiceProxy: RuleSettingsServiceProxy,
        private _notifyService: NotifyService,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }
    ngOnInit(): void {
        this.getRuleSettings();
        this.editSettings = { allowEditing: true, allowDeleting: true , showDeleteConfirmDialog:true };
        this.commands = [
        { type: "Edit", buttonOption: { cssClass: "e-flat", iconCss: "e-edit e-icons" } },
        { type: "Delete", buttonOption: { cssClass: 'e-flat', iconCss: "e-delete e-icons" } },
        //{ type: "Save", buttonOption: { cssClass: 'e-flat', iconCss: 'e-update e-icons' } },
        { type: "Cancel", buttonOption: { cssClass: "e-flat", iconCss: "e-cancel-icon e-icons" } }
    ];
        this.toolbarOptions = ['ColumnChooser','Search'];
        this.pageSettings = { pageSizes: false, pageSize: AppConsts.grid.defaultPageSize, 
            //pageCount: 0, 
            currentPage: 1 };
        this.options = { pageSize: 50 };
        this.infiniteOptions = { };
    }

    getRuleSettings() {
        
        this.primengTableHelper.showLoadingIndicator();

        this._ruleSettingsServiceProxy
            .getAll(
                this.filterText,
                this.titleFilter,
                this.valueFilter,
                this.fieldTypeFilter,
                this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty : this.maxDisplayOrderFilter,
                this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty : this.minDisplayOrderFilter,
                this.ruleTypeTitleFilter,
                this.organizationUnitDisplayNameFilter,
                // this.primengTableHelper.getSorting(this.dataTable),
                // this.primengTableHelper.getSkipCount(this.paginator, event),
                // this.primengTableHelper.getMaxResultCount(this.paginator, event)
                "title",
                0,
                1000
            )
            .subscribe((result) => {
                this.primengTableHelper.totalRecordsCount = result.totalCount;
                this.primengTableHelper.records = result.items;
                this.primengTableHelper.hideLoadingIndicator();
                this.ruleSettingData=result.items;
            });
    }

    reloadPage(): void {
        this.paginator.changePage(this.paginator.getPage());
    }

    createRuleSetting(): void {
        this.createOrEditRuleSettingModal.show();
    }

    deleteRuleSetting(ruleSetting: RuleSettingDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._ruleSettingsServiceProxy.delete(ruleSetting.id).subscribe(() => {
                    // this.reloadPage();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    exportToExcel(): void {
        this._ruleSettingsServiceProxy
            .getRuleSettingsToExcel(
                this.filterText,
                this.titleFilter,
                this.valueFilter,
                this.fieldTypeFilter,
                this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty : this.maxDisplayOrderFilter,
                this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty : this.minDisplayOrderFilter,
                this.ruleTypeTitleFilter,
                this.organizationUnitDisplayNameFilter
            )
            .subscribe((result) => {
                this._fileDownloadService.downloadTempFile(result);
            });
    }

    onActionBegin(args) {
        if (args.requestType == 'beginEdit')
        {
            this.createOrEditRuleSettingModal.show(args.rowData.ruleSetting["id"]);

        }
        if (args.requestType == 'delete')
        {
           
           this._ruleSettingsServiceProxy.delete(args.data[0].ruleSetting.id).subscribe(() => {
            this.notify.success(this.l('SuccessfullyDeleted'));
        });
        }
        if (args.requestType == "paging") {
            this.skipCount = (args.currentPage - 1) * this.pageSettings.pageSize;
            this.pageSettings.currentPage = args.currentPage;
            this.getRuleSettings();
        } else if(args.requestType == "sorting") {
            this.sortColumn = args.columnName;
            this.sortDirection = args.direction == 'Ascending' ? 'asc' : 'desc';
            this.getRuleSettings();
        } else if (args.requestType === "infiniteScroll" && this.ruleSettingData.length < this.totalRecordCount) {
            this.skipCount += this.maxResultCount;
            this.getRuleSettings();
            
        }
    }
    
    modalSave(event) {
        this.ruleSettingData = [];
        this.getRuleSettings();
        
    }

    
    
}
