﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { RuleTypesServiceProxy, CreateOrEditRuleTypeDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    selector: 'createOrEditRuleTypeModal',
    templateUrl: './create-or-edit-ruleType-modal.component.html',
})
export class CreateOrEditRuleTypeModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    ruleType: CreateOrEditRuleTypeDto = new CreateOrEditRuleTypeDto();

    constructor(
        injector: Injector,
        private _ruleTypesServiceProxy: RuleTypesServiceProxy,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    show(ruleTypeId?: string): void {
        if (!ruleTypeId) {
            this.ruleType = new CreateOrEditRuleTypeDto();
            this.ruleType.id = ruleTypeId;

            this.active = true;
            this.modal.show();
        } else {
            this._ruleTypesServiceProxy.getRuleTypeForEdit(ruleTypeId).subscribe((result) => {
                this.ruleType = result.ruleType;

                this.active = true;
                this.modal.show();
            });
        }
    }

    save(): void {
        this.saving = true;

        this._ruleTypesServiceProxy
            .createOrEdit(this.ruleType)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                // window.location.reload();
                this.notify.info(this.l('SavedSuccessfully'));

                this.close();
                this.modalSave.emit(null);
            });
    }

    close(): void {
        this.modalSave.emit(null);

        this.active = false;
        this.modal.hide();
    }

    ngOnInit(): void {}
}
