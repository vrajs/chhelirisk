﻿import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {RuleTypesComponent} from './ruleTypes.component';



const routes: Routes = [
    {
        path: '',
        component: RuleTypesComponent,
        pathMatch: 'full'
    },
    
    
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class RuleTypeRoutingModule {
}
