﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';
import {RuleTypeRoutingModule} from './ruleType-routing.module';
import {RuleTypesComponent} from './ruleTypes.component';
import {CreateOrEditRuleTypeModalComponent} from './create-or-edit-ruleType-modal.component';
import {ViewRuleTypeModalComponent} from './view-ruleType-modal.component';



@NgModule({
    declarations: [
        RuleTypesComponent,
        CreateOrEditRuleTypeModalComponent,
        ViewRuleTypeModalComponent,
        
    ],
    imports: [AppSharedModule, RuleTypeRoutingModule , AdminSharedModule ],
    
})
export class RuleTypeModule {
}
