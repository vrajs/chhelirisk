﻿import { AppConsts } from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RuleTypesServiceProxy, RuleTypeDto } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditRuleTypeModalComponent } from './create-or-edit-ruleType-modal.component';

import { ViewRuleTypeModalComponent } from './view-ruleType-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import {
    EditSettingsModel,
    CommandModel,
    PageSettingsModel,
    InfiniteScrollSettingsModel,
    ToolbarItems,
} from '@syncfusion/ej2-grids';

@Component({
    templateUrl: './ruleTypes.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class RuleTypesComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditRuleTypeModal', { static: true })
    createOrEditRuleTypeModal: CreateOrEditRuleTypeModalComponent;
    @ViewChild('viewRuleTypeModalComponent', { static: true }) viewRuleTypeModal: ViewRuleTypeModalComponent;

    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    advancedFiltersAreShown = false;
    filterText = '';
    titleFilter = '';
    maxDisplayOrderFilter: number;
    maxDisplayOrderFilterEmpty: number;
    minDisplayOrderFilter: number;
    minDisplayOrderFilterEmpty: number;
    outputVariableFilter = '';
    statusDetailsVariableFilter = '';
    isRangeSpecificFilter = -1;
    public editSettings: EditSettingsModel;
    public commands: CommandModel[];
    public options: PageSettingsModel | undefined;
    public infiniteOptions: InfiniteScrollSettingsModel | undefined;
    public count = 0;
    maxResultCount: number = 5;
    skipCount: number = 0;
    sortColumn: string = '';
    sortDirection: string = '';
    totalRecordCount: number = 0;
    pageSettings: any = { pageSizes: true, pageSize: 10, pageCount: 0, currentPage: 1 };
    public toolbarOptions: ToolbarItems[];
    public initialPage: PageSettingsModel;

    ruleTypeData: any[] = [];

    _entityTypeFullName = 'asq.econsys.Eco.BusinessRules.RuleType';
    entityHistoryEnabled = false;

    constructor(
        injector: Injector,
        private _ruleTypesServiceProxy: RuleTypesServiceProxy,
        private _notifyService: NotifyService,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.getRuleTypes();
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        this.editSettings = { allowEditing: true, allowDeleting: true, showDeleteConfirmDialog: true };
        this.commands = [
            { type: 'Edit', buttonOption: { cssClass: 'e-flat', iconCss: 'e-edit e-icons' } },
            { type: 'Delete', buttonOption: { cssClass: 'e-flat', iconCss: 'e-delete e-icons' } },
            //{ type: "Save", buttonOption: { cssClass: 'e-flat', iconCss: 'e-update e-icons' } },
            { type: 'Cancel', buttonOption: { cssClass: 'e-flat', iconCss: 'e-cancel-icon e-icons' } },
        ];
        this.toolbarOptions = ['ColumnChooser', 'Search'];
        this.pageSettings = {
            pageSizes: false,
            pageSize: AppConsts.grid.defaultPageSize,
            //pageCount: 0,
            currentPage: 1,
        };
        this.options = { pageSize: 50 };
        this.infiniteOptions = {};
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }

    getRuleTypes() {
        this.primengTableHelper.showLoadingIndicator();

        this._ruleTypesServiceProxy
            .getAll(
                this.filterText,
                this.titleFilter,
                this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty : this.maxDisplayOrderFilter,
                this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty : this.minDisplayOrderFilter,
                this.outputVariableFilter,
                this.statusDetailsVariableFilter,
                this.isRangeSpecificFilter,
                // this.primengTableHelper.getSorting(this.dataTable),
                // this.primengTableHelper.getSkipCount(this.paginator, event),
                // this.primengTableHelper.getMaxResultCount(this.paginator, event)
                'displayOrder',
                0,
                1000
            )
            .subscribe((result) => {
                this.primengTableHelper.totalRecordsCount = result.totalCount;
                this.primengTableHelper.records = result.items;
                this.primengTableHelper.hideLoadingIndicator();
                this.ruleTypeData = result.items;
            });
    }

    reloadPage(): void {
        this.paginator.changePage(this.paginator.getPage());
    }

    createRuleType(): void {
        this.createOrEditRuleTypeModal.show();
    }

    showHistory(ruleType: RuleTypeDto): void {
        this.entityTypeHistoryModal.show({
            entityId: ruleType.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteRuleType(ruleType: RuleTypeDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._ruleTypesServiceProxy.delete(ruleType.id).subscribe(() => {
                    // this.reloadPage();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    exportToExcel(): void {
        this._ruleTypesServiceProxy
            .getRuleTypesToExcel(
                this.filterText,
                this.titleFilter,
                this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty : this.maxDisplayOrderFilter,
                this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty : this.minDisplayOrderFilter,
                this.outputVariableFilter,
                this.statusDetailsVariableFilter,
                this.isRangeSpecificFilter
            )
            .subscribe((result) => {
                this._fileDownloadService.downloadTempFile(result);
            });
    }

    onActionBegin(args) {
        if (args.requestType == 'beginEdit') {
            this.createOrEditRuleTypeModal.show(args.rowData.ruleType['id']);
        }
        if (args.requestType == 'delete') {
            this._ruleTypesServiceProxy.delete(args.data[0].ruleType.id).subscribe(() => {
                // this.reloadPage();
                this.notify.success(this.l('SuccessfullyDeleted'));
            });
        }
        if (args.requestType == 'paging') {
            this.skipCount = (args.currentPage - 1) * this.pageSettings.pageSize;
            this.pageSettings.currentPage = args.currentPage;
            this.getRuleTypes();
        } else if (args.requestType == 'sorting') {
            this.sortColumn = args.columnName;
            this.sortDirection = args.direction == 'Ascending' ? 'asc' : 'desc';
            this.getRuleTypes();
        } else if (args.requestType === 'infiniteScroll' && this.ruleTypeData.length < this.totalRecordCount) {
            this.skipCount += this.maxResultCount;
            this.getRuleTypes();
        }
    }

    modalSave(event) {
        this.ruleTypeData = [];
        this.getRuleTypes();
    }
}
