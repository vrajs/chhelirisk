﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    RuleValuesServiceProxy,
    CreateOrEditRuleValueDto,
    RuleValueOrganizationUnitLookupTableDto,
    RuleValueRuleTypeLookupTableDto,
    RuleValueRuleElementLookupTableDto,
    GetRuleElementForViewDto,
    RuleElementsServiceProxy,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    selector: 'createOrEditRuleValueModal',
    templateUrl: './create-or-edit-ruleValue-modal.component.html',
})
export class CreateOrEditRuleValueModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;
    filterText = '';
    titleFilter = '';
    maxDisplayOrderFilter;
    minDisplayOrderFilter;
    variableNameFilter = '';
    ruleTypeTitleFilter = '';
    organizationUnitDisplayFilter = '';

    ruleValue: CreateOrEditRuleValueDto = new CreateOrEditRuleValueDto();

    organizationUnitDisplayName = '';
    ruleTypeTitle = '';
    ruleElementTitle = '';

    allOrganizationUnits: RuleValueOrganizationUnitLookupTableDto[];
    allRuleTypes: RuleValueRuleTypeLookupTableDto[];
    allRuleElements: RuleValueRuleElementLookupTableDto[];
    ruleElements: GetRuleElementForViewDto[] = [];
    allRuleElementsFiltered: GetRuleElementForViewDto[] = [];

    constructor(
        injector: Injector,
        private _ruleValuesServiceProxy: RuleValuesServiceProxy,
        private _ruleElementsServiceProxy: RuleElementsServiceProxy,

        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    show(ruleValueId?: number): void {
        if (!ruleValueId) {
            this.ruleValue = new CreateOrEditRuleValueDto();
            this.ruleValue.id = ruleValueId;
            this.organizationUnitDisplayName = '';
            this.ruleTypeTitle = '';
            this.ruleElementTitle = '';

            this.active = true;
            this.modal.show();
        } else {
            this._ruleValuesServiceProxy.getRuleValueForEdit(ruleValueId).subscribe((result) => {
                this.ruleValue = result.ruleValue;

                this.organizationUnitDisplayName = result.organizationUnitDisplayName;
                this.ruleTypeTitle = result.ruleTypeTitle;
                this.ruleElementTitle = result.ruleElementTitle;

                this.active = true;
                this.modal.show();
            });
        }
        this._ruleElementsServiceProxy
            .getAll(
                this.filterText,
                this.titleFilter,
                this.maxDisplayOrderFilter,
                this.minDisplayOrderFilter,
                this.variableNameFilter,
                this.organizationUnitDisplayFilter,
                this.ruleTypeTitleFilter,

                // this.maxSortOrderFilter == null ? this.maxSortOrderFilterEmpty : this.maxSortOrderFilter,
                // this.minSortOrderFilter == null ? this.minSortOrderFilterEmpty : this.minSortOrderFilter,
                //this.primengTableHelper.getSorting(this.dataTable),
                // this.ruleTypeTitleFilter,
                'title',
                0,
                1000
            )
            .subscribe((result) => {
                // this.primengTableHelper.totalRecordsCount = result.totalCount;
                // this.primengTableHelper.records = result.items;
                this.ruleElements = result.items;
                // this.ruleElements = result.items;
                //this.primengTableHelper.hideLoadingIndicator();
            });

        this._ruleValuesServiceProxy.getAllOrganizationUnitForTableDropdown().subscribe((result) => {
            this.allOrganizationUnits = result;
        });
        this._ruleValuesServiceProxy.getAllRuleTypeForTableDropdown().subscribe((result) => {
            this.allRuleTypes = result;
        });
        this._ruleValuesServiceProxy.getAllRuleElementForTableDropdown().subscribe((result) => {
            this.allRuleElements = result;
        });
    }

    save(): void {
        this.saving = true;

        this._ruleValuesServiceProxy
            .createOrEdit(this.ruleValue)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
            });
    }

    close(): void {
        this.modalSave.emit(null);

        this.active = false;
        this.modal.hide();
    }
    getFilteredRuleElements(event) {
        var typeTitle = this.allRuleTypes.filter((item) => item.id == event.target.value);

        this.allRuleElementsFiltered = this.ruleElements.filter(
            (item) => item.ruleTypeTitle == typeTitle[0].displayName
        );
    }

    ngOnInit(): void {}
}
