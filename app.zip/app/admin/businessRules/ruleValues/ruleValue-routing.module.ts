﻿import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {RuleValuesComponent} from './ruleValues.component';



const routes: Routes = [
    {
        path: '',
        component: RuleValuesComponent,
        pathMatch: 'full'
    },
    
    
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class RuleValueRoutingModule {
}
