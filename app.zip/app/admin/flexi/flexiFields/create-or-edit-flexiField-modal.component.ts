﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { FlexiFieldsServiceProxy, CreateOrEditFlexiFieldDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { FlexiFieldFlexiSectionLookupTableModalComponent } from './flexiField-flexiSection-lookup-table-modal.component';
import { HtmlHelper } from '@shared/helpers/HtmlHelper';
import { FormBuilder, FormGroup } from '@angular/forms';
import { TabComponent } from '@syncfusion/ej2-angular-navigations';

@Component({
    selector: 'createOrEditFlexiFieldModal',
    templateUrl: './create-or-edit-flexiField-modal.component.html',
})
export class CreateOrEditFlexiFieldModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @ViewChild('flexiFieldFlexiSectionLookupTableModal', { static: true })
    flexiFieldFlexiSectionLookupTableModal: FlexiFieldFlexiSectionLookupTableModalComponent;
    // @ViewChild('tabObj') tabObj: TabComponent;
    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    flexiField: CreateOrEditFlexiFieldDto = new CreateOrEditFlexiFieldDto();
    hasAdminAccess: boolean = false;
    flexiSections: any[] = [];

    constructor(
        injector: Injector,
        private _flexiFieldsServiceProxy: FlexiFieldsServiceProxy,
        private _dateTimeService: DateTimeService,
        private fb: FormBuilder
    ) {
        super(injector);
    }

    localMetaData: any;
    localFlowData: any = [];
    localProjectType: any;
    frmFG: FormGroup = this.fb.group({});

    show(flexiFieldId?: number): void {
        this.hasAdminAccess = this.permission.isGranted('Pages.FlexiSections') ? true : false;

        if (!flexiFieldId) {
            this.flexiField = new CreateOrEditFlexiFieldDto();
            this.flexiField.id = flexiFieldId;

            this.active = true;
            this.modal.show();
        } else {
            this._flexiFieldsServiceProxy.getFlexiFieldForEdit(flexiFieldId).subscribe((result) => {
                this.flexiField = result.flexiField;

                if (this.flexiField.metaData) {
                    this.localMetaData = this.utilsService.parseFlexiJson(this.flexiField.metaData);
                    this.localFlowData = this.localMetaData.flowData;
                    this.localProjectType = this.localFlowData[0].projectType;
                    this.localFlowData.forEach(f => {
                        Object.entries(f).forEach(x => {
                            this.frmFG.setControl(x[0], this.fb.control(x[1]));
                        });
                    });
                    this.updateValue();
                }

                if (
                    this.flexiField.validations != '' &&
                    this.flexiField.validations != null &&
                    this.flexiField.validations != 'null'
                ) {
                    this.flexiField.validations = JSON.parse(this.flexiField.validations);
                }
                this.active = true;
                this.modal.show();
            });
        }
    }

    updateValue() {
        this.localFlowData.forEach(f => {
            if (f.projectType == this.localProjectType) {
                Object.entries(f).forEach(x => {
                    this.frmFG.controls[x[0]].setValue(x[1]);
                });
            }
        });
    }

    selected(args) {
        this.localProjectType = this.localFlowData[args.selectedIndex].projectType;
        Object.entries(this.frmFG.controls).forEach(x => {
            this.localFlowData[args.previousIndex][x[0]] = this.frmFG.controls[x[0]].value;
        });
        this.updateValue();
    }

    save(): void {
        this.saving = true;
        if (
            this.flexiField.validations != '' &&
            this.flexiField.validations != null &&
            this.flexiField.validations != 'null'
        ) {
            this.flexiField.validations = JSON.stringify(this.flexiField.validations);
            // this.flexiField.validations = this.flexiField.validations.replace(/(?:\\[rn])+/g, '').replace(/(?:\\[t])+/g, '');

            var re = new RegExp(/(?:\\[rn])+/g, 'g');
            this.flexiField.validations = this.flexiField.validations.replace(re, '');

            var re = new RegExp(/(?:\\\\)+/g, 'g');
            this.flexiField.validations = this.flexiField.validations.replace(re, '');

            // this.flexiField.validations = HtmlHelper.encodeJson(this.flexiField.validations);
        } else {
            this.flexiField.validations = null;
        }

        // if (
        //     this.flexiField.metaData != '' &&
        //     this.flexiField.metaData != null &&
        //     this.flexiField.metaData != 'null'
        // ) {
        //     this.flexiField.metaData = JSON.stringify(this.flexiField.metaData);
        //     var re = new RegExp(/(?:\\[rnt])+/g, 'g');
        //     this.flexiField.metaData = this.flexiField.metaData.replace(re, '');

        //     var re = new RegExp(/(?:\\\\)+/g, 'g');
        //     this.flexiField.metaData = this.flexiField.metaData.replace(re, '');
        // } else {
        //     this.flexiField.metaData = null;
        // }
        if (this.flexiField.metaData) {
            Object.entries(this.localMetaData).forEach(x => {
                Object.entries(this.flexiField).forEach(f => {
                    if (x[0] == f[0])
                        this.localMetaData[x[0]] = f[1];
                });
            });

            this.localFlowData.forEach((x, i) => {
                if (x.projectType == this.frmFG.value.projectType) {
                    Object.entries(this.frmFG.controls).forEach(x => {
                        this.localFlowData[i][x[0]] = this.frmFG.controls[x[0]].value;
                    });
                }
            });

            var str = JSON.stringify(this.localMetaData);
            var metaDataValue = '"' + (str.replace(/"/gi, '\\"')) + '"';
            this.flexiField.metaData = metaDataValue;
        }

        this.spinnerService.show();
        this._flexiFieldsServiceProxy
            .createOrEdit(this.flexiField)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(
                () => {
                    this.notify.info(this.l('SavedSuccessfully'));
                    this.close();
                    this.modalSave.emit(null);
                    this.spinnerService.hide();
                },
                () => {
                    this.spinnerService.hide();
                }
            );
    }

    close(): void {
        this.active = false;
        this.modal.hide();
    }

    ngOnInit(): void {
    }

}
