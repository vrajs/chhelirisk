﻿import { AppConsts } from '@shared/AppConsts';
import {
    Component,
    Injector,
    ViewEncapsulation,
    ViewChild,
    OnInit,
    AfterViewInit,
    ChangeDetectorRef,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FlexiFieldsServiceProxy, FlexiFieldDto, FlexiFieldType } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditFlexiFieldModalComponent } from './create-or-edit-flexiField-modal.component';

import { ViewFlexiFieldModalComponent } from './view-flexiField-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import {
    Column,
    CommandModel,
    EditSettingsModel,
    ExcelExportProperties,
    GridComponent,
    PageSettingsModel,
    TextWrapSettingsModel,
    ToolbarItems,
} from '@syncfusion/ej2-angular-grids';
import { NgModel } from '@angular/forms';
import { DropDownButton } from '@syncfusion/ej2-splitbuttons';
import { ComboBox } from '@syncfusion/ej2-dropdowns';

@Component({
    templateUrl: './flexiFields.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class FlexiFieldsComponent extends AppComponentBase implements OnInit, AfterViewInit {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditFlexiFieldModal', { static: true })
    createOrEditFlexiFieldModal: CreateOrEditFlexiFieldModalComponent;
    @ViewChild('viewFlexiFieldModalComponent', { static: true }) viewFlexiFieldModal: ViewFlexiFieldModalComponent;

    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;
    @ViewChild('template') toolbarTemplate: any;

    advancedFiltersAreShown = false;
    filterText = '';
    codeFilter = '';
    displayNameFilter = '';
    maxSortOrderFilter: number;
    maxSortOrderFilterEmpty: number;
    minSortOrderFilter: number;
    minSortOrderFilterEmpty: number;
    isEnabledFilter = -1;
    htmlTypeFilter = '';
    htmlInputTypeFilter = '';
    validationsFilter = '';
    dbTypeFilter = '';
    fieldTypeFilter = -1;
    flexiSectionNameFilter = '';

    flexiFieldType = FlexiFieldType;
    flexiFields: any[] = [];
    public toolbarOptions: any;
    public pageSettings: any = { pageSizes: true, pageSize: 10, pageCount: 0, currentPage: 1 };
    public wrapSettings: TextWrapSettingsModel = { wrapMode: 'Content' };
    public editSettings: EditSettingsModel;
    maxResultCount: number = 10;
    skipCount: number = 0;
    sortColumn: string = '';
    sortDirection: string = '';
    totalRecordCount: number = 0;
    public commands: CommandModel[];
    @ViewChild('actiontemplate') public actiontemplate: NgModel;
    @ViewChild('grid') public grid: GridComponent;

    _entityTypeFullName = 'asq.econsys.Flexi.FlexiField';
    entityHistoryEnabled = false;
    hasAdminAccess: boolean = false;
    gridfields: any[] = [];
    flexiSectionData = [];

    constructor(
        injector: Injector,
        private _flexiFieldsServiceProxy: FlexiFieldsServiceProxy,
        private _notifyService: NotifyService,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
        private _dateTimeService: DateTimeService,
        private _changeDetector: ChangeDetectorRef
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.getAllFlexiSections();
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        this.hasAdminAccess = this.permission.isGranted('Pages.FlexiSections') ? true : false;

        this.editSettings = { allowEditing: false, allowDeleting: false };
        this.toolbarOptions = ['Search', 'ExcelExport', 'Print',
            // {
            //     type: 'Button',
            //     text: 'DropDownButton',
            //     align: 'Right',
            //     template: '<button id="dropDownButton"></button>',
            // }
        ];
        this.pageSettings = {
            pageSizes: false,
            pageSize: AppConsts.grid.defaultPageSize,
            //pageCount: 0,
            currentPage: 1,
        };
        // this.commands = [
        //     { type: 'Edit', buttonOption: { cssClass: 'e-flat', iconCss: 'e-edit e-icons' } },
        //     { type: 'Delete', buttonOption: { cssClass: 'e-flat', iconCss: 'e-delete e-icons' } },
        //     //{ type: "Save", buttonOption: { cssClass: 'e-flat', iconCss: 'e-update e-icons' } },
        //     { type: 'Cancel', buttonOption: { cssClass: 'e-flat', iconCss: 'e-cancel-icon e-icons' } },
        // ];
    }

    ngAfterViewInit() {
        this.getFlexiFields(null);
        this.gridfields = [
            {
                headerText: this.l('Action'),
                field: 'action',
                template: this.actiontemplate,
                width: 100,
                allowFiltering: false,
            },
            { headerText: this.l('FlexiSectionId'), field: 'flexiSectionName' },
            { headerText: this.l('Code'), field: 'flexiField.code' },
            { headerText: this.l('DisplayName'), field: 'flexiField.displayName' },
            { headerText: this.l('SortOrder'), field: 'flexiField.sortOrder' },
            { headerText: this.l('IsEnabled'), field: 'flexiField.isEnabled' },
            { headerText: this.l('HTMLType'), field: 'flexiField.htmlType' },
            { headerText: this.l('HTMLInputType'), field: 'flexiField.htmlInputType' },
            { headerText: this.l('DBType'), field: 'flexiField.dbType' },
            { headerText: this.l('Validations'), field: 'flexiField.validations' },
        ];
        this._changeDetector.detectChanges();
        console.log(
            '%cflexiFields.component.ts line:125 this.gridfields',
            'color: #007acc;',
            this.actiontemplate,
            this.gridfields
        );
    }
    dataBound() {
        this.grid.pageSettings.totalRecordsCount = this.totalRecordCount;
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }

    getFlexiFields(event?: LazyLoadEvent) {
        // if (this.primengTableHelper.shouldResetPaging(event)) {
        //     this.paginator.changePage(0);
        //     return;
        // }

        // this.primengTableHelper.showLoadingIndicator();
        console.log("getFlexiFields");

        this._flexiFieldsServiceProxy
            .getAll(
                this.filterText,
                this.codeFilter,
                this.displayNameFilter,
                this.maxSortOrderFilter == null ? this.maxSortOrderFilterEmpty : this.maxSortOrderFilter,
                this.minSortOrderFilter == null ? this.minSortOrderFilterEmpty : this.minSortOrderFilter,
                this.isEnabledFilter,
                this.htmlTypeFilter,
                this.htmlInputTypeFilter,
                this.validationsFilter,
                this.dbTypeFilter,
                this.fieldTypeFilter,
                this.flexiSectionNameFilter,
                // this.primengTableHelper.getSorting(this.dataTable),
                // this.primengTableHelper.getSkipCount(this.paginator, event),
                // this.primengTableHelper.getMaxResultCount(this.paginator, event)
                this.sortColumn + ' ' + this.sortDirection,
                this.skipCount,
                this.maxResultCount
            )
            .subscribe((result) => {
                this.totalRecordCount = result.totalCount;
                // this.primengTableHelper.totalRecordsCount = result.totalCount;
                // this.primengTableHelper.records = result.items;
                // this.primengTableHelper.hideLoadingIndicator();

                this.flexiFields = result.items;
                if (result.items.length > this.pageSettings.pageSize - 1) {
                    this.pageSettings.skipCount += this.pageSettings.pageSize;
                } else {
                    this.pageSettings.skipCount = 0;
                }
                this.grid.refresh();
            });
    }

    reloadPage(): void {
        this.paginator.changePage(this.paginator.getPage());
    }

    createFlexiField(): void {
        this.createOrEditFlexiFieldModal.show();
    }

    showHistory(flexiField: FlexiFieldDto): void {
        this.entityTypeHistoryModal.show({
            entityId: flexiField.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteFlexiField(flexiField: FlexiFieldDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._flexiFieldsServiceProxy.delete(flexiField.id).subscribe(() => {
                    this.reloadPage();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    // exportToExcel(): void {
    //     this._flexiFieldsServiceProxy
    //         .getFlexiFieldsToExcel(
    //             this.filterText,
    //             this.codeFilter,
    //             this.displayNameFilter,
    //             this.maxSortOrderFilter == null ? this.maxSortOrderFilterEmpty : this.maxSortOrderFilter,
    //             this.minSortOrderFilter == null ? this.minSortOrderFilterEmpty : this.minSortOrderFilter,
    //             this.isEnabledFilter,
    //             this.htmlTypeFilter,
    //             this.htmlInputTypeFilter,
    //             this.validationsFilter,
    //             this.dbTypeFilter,
    //             this.fieldTypeFilter,
    //             this.flexiSectionNameFilter
    //         )
    //         .subscribe((result) => {
    //             this._fileDownloadService.downloadTempFile(result);
    //         });
    // }

    onActionBegin(args) {
        if (args.requestType == 'sorting') {
            if (args.columnName != null) {
                this.flexiFields = [];
                this.sortColumn = args.columnName == "flexiSectionName" ? "FlexiSectionId" : args.columnName.split(".")[1];
                this.sortDirection = args.direction == 'Ascending' ? 'asc' : 'desc';
                this.getFlexiFields();
            }
        }
        if (args.requestType == "searching") {
            this.filterText = args.searchString;
            this.getFlexiFields();
        }
        if (args.requestType == "paging") {
            this.pageSettings.currentPage = args.currentPage;
            this.skipCount = (args.currentPage - 1) * this.pageSettings.pageSize;
            console.log("before", this.pageSettings.currentPage);
            // this.getFlexiFields();
        }
    }

    toolbarClick(args): void {
        if (args.item.id === 'flexifieldsgrid_excelexport') {
            this.grid.showSpinner();
            (this.grid.columns[0] as Column).visible = false;
            const excelExportProperties: ExcelExportProperties = {
                fileName: "FlexiFields.xlsx",
                exportType: 'AllPages'
            };
            this.grid.excelExport(excelExportProperties);
            for (const columns of this.grid.columns) {
                if ((columns as Column).headerText === 'Action') {
                    (columns as Column).visible = false;
                    exportType: 'AllPages'
                }
            }
        }
    }

    getAllFlexiSections() {
        this._flexiFieldsServiceProxy.getAllFlexiSections().subscribe((result) => {
            result.forEach((x) => {
                this.flexiSectionData.push({ Id: x.id, text: x.name });
            });
            this.filterFlexiSectionId();
        });
    }

    filterFlexiSectionId() {
        var comboBox = new ComboBox(
            {
                dataSource: this.flexiSectionData,
                placeholder: "Type section name",
                change(args) {
                    this.flexiSectionNameFilter = args.itemData.Id;
                    console.log(this.flexiSectionNameFilter);
                    console.log(comboBox)
                    // this.getFlexiFields();

                }
            }, '#dropDownButton'
        );
        console.log(comboBox)

        // new DropDownButton(
        //     {
        //         content: 'Flexi Section',
        //         items: this.flexiSectionData,
        //     }, '#dropDownButton'
        // );

    }

    load() {
        (this.grid.localeObj as any).localeStrings.Excelexport = 'Export To Excel';
        (this.grid.localeObj as any).localeStrings.Print = 'Print';
    }

    exportComplete() {
        this.grid.hideSpinner();
    }

    dropDownList(args) {
        this.filterText = args.itemData?.Id;
        this.getFlexiFields();
    }

}
