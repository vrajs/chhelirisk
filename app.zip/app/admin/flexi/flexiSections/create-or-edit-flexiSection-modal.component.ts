﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef} from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { FlexiSectionsServiceProxy, CreateOrEditFlexiSectionDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

             import { DateTimeService } from '@app/shared/common/timing/date-time.service';



@Component({
    selector: 'createOrEditFlexiSectionModal',
    templateUrl: './create-or-edit-flexiSection-modal.component.html'
})
export class CreateOrEditFlexiSectionModalComponent extends AppComponentBase implements OnInit{
   
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    flexiSection: CreateOrEditFlexiSectionDto = new CreateOrEditFlexiSectionDto();




    constructor(
        injector: Injector,
        private _flexiSectionsServiceProxy: FlexiSectionsServiceProxy,
             private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }
    
    show(flexiSectionId?: string): void {
    

        if (!flexiSectionId) {
            this.flexiSection = new CreateOrEditFlexiSectionDto();
            this.flexiSection.id = flexiSectionId;


            this.active = true;
            this.modal.show();
        } else {
            this._flexiSectionsServiceProxy.getFlexiSectionForEdit(flexiSectionId).subscribe(result => {
                this.flexiSection = result.flexiSection;



                this.active = true;
                this.modal.show();
            });
        }
        
        
    }

    save(): void {
            this.saving = true;
            
			
			
            this._flexiSectionsServiceProxy.createOrEdit(this.flexiSection)
             .pipe(finalize(() => { this.saving = false;}))
             .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
             });
    }













    close(): void {
        this.active = false;
        this.modal.hide();
    }
    
     ngOnInit(): void {
        
     }    
}
