﻿import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {FlexiSectionsComponent} from './flexiSections.component';



const routes: Routes = [
    {
        path: '',
        component: FlexiSectionsComponent,
        pathMatch: 'full'
    },
    
    
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class FlexiSectionRoutingModule {
}
