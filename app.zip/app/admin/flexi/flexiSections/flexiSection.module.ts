﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';
import {FlexiSectionRoutingModule} from './flexiSection-routing.module';
import {FlexiSectionsComponent} from './flexiSections.component';
import {CreateOrEditFlexiSectionModalComponent} from './create-or-edit-flexiSection-modal.component';
import {ViewFlexiSectionModalComponent} from './view-flexiSection-modal.component';



@NgModule({
    declarations: [
        FlexiSectionsComponent,
        CreateOrEditFlexiSectionModalComponent,
        ViewFlexiSectionModalComponent,
        
    ],
    imports: [AppSharedModule, FlexiSectionRoutingModule , AdminSharedModule ],
    
})
export class FlexiSectionModule {
}
