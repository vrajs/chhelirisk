﻿import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GridMastersComponent } from './gridMasters.component';

const routes: Routes = [
    {
        path: '',
        component: GridMastersComponent,
        pathMatch: 'full',
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class GridMasterRoutingModule {}
