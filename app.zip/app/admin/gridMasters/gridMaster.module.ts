﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { GridMasterRoutingModule } from './gridMaster-routing.module';
import { GridMastersComponent } from './gridMasters.component';
import { CreateOrEditGridMasterModalComponent } from './create-or-edit-gridMaster-modal.component';
import { ViewGridMasterModalComponent } from './view-gridMaster-modal.component';

@NgModule({
    declarations: [GridMastersComponent, CreateOrEditGridMasterModalComponent, ViewGridMasterModalComponent],
    imports: [
        AppSharedModule,
        GridMasterRoutingModule,
        AdminSharedModule
    ],
})
export class GridMasterModule {}
