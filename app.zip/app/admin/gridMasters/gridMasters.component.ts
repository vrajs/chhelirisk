﻿import { AppConsts } from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
    GridMastersServiceProxy,
    GridMasterDto,
    CreateOrEditGridMasterDto,
    PagedResultDtoOfGetGridMasterForViewDto,
} from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditGridMasterModalComponent } from './create-or-edit-gridMaster-modal.component';

import { ViewGridMasterModalComponent } from './view-gridMaster-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter, result } from 'lodash-es';
import {
    EditSettingsModel,
    GridComponent,
    ToolbarItems,
    IEditCell,
    PageService,
    DataStateChangeEventArgs,
    InfiniteScrollSettingsModel,
} from '@syncfusion/ej2-angular-grids';
import { Query, DataManager } from '@syncfusion/ej2-data';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    templateUrl: './gridMasters.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class GridMastersComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditGridMasterModal', { static: true })
    createOrEditGridMasterModal: CreateOrEditGridMasterModalComponent;
    @ViewChild('viewGridMasterModalComponent', { static: true }) viewGridMasterModal: ViewGridMasterModalComponent;
    // @ViewChild('dataTable', { static: true }) dataTable: Table;
    // @ViewChild('paginator', { static: true }) paginator: Paginator;
    public data: object;
    public toolbar: ToolbarItems[];
    @ViewChild('gridMain') public gridMain: GridComponent;
    saving = false;

    gridMaster: CreateOrEditGridMasterDto = new CreateOrEditGridMasterDto();

    advancedFiltersAreShown = false;
    filterText = '';
    nameFilter = '';
    coumnOneFilter = '';
    columnTwoFilter = '';
    forPRJFilter = -1;
    forSWKFilter = -1;
    forCALLFilter = -1;
    forPPMFilter = -1;
    forTandMFilter = -1;
    maxDisplayOrderFilter: number;
    maxDisplayOrderFilterEmpty: number;
    minDisplayOrderFilter: number;
    minDisplayOrderFilterEmpty: number;
    organizationUnitDisplayNameFilter = '';
    colPPP: boolean;
    colTYP: boolean;
    colCALL: boolean;
    colSW: boolean;
    colTM: boolean;
    colSM: boolean;
    tabSelectedName: string;
    tabNames = [
        'Project Programme and Progress',
        'Sub-contractor Procurement',
        'Cost Code',
        'Sales to Operation Handover',
        'Small works',
        'Lead Source',
        'Time and Material',
        'Service/Maintenance',
    ];
    activeTab: number = 1;

    _entityTypeFullName = 'asq.econsys.Eco.GridMaster.GridMaster';
    entityHistoryEnabled = false;
    public editSettings: Object;
    public editparams: Object;
    public state: DataStateChangeEventArgs;
    public maxResultCount: number = 4;
    public skipCount: number = 0;
    public sortColumn: string = '';
    public sortDirection: string = '';
    public totalRecordCount: number = 0;
    public pageSettings: any = { pageSizes: true, pageSize: 10, pageCount: 0, currentPage: 1 };
    // public infiniteOptions: InfiniteScrollSettingsModel | undefined;

    constructor(injector: Injector, private _gridMastersServiceProxy: GridMastersServiceProxy) {
        super(injector);
    }

    ngOnInit(): void {
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        //this.data = orderData.slice(0,5);
        this.data = [];
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' };
        this.toolbar = ['Add', 'Edit', 'Update', 'Cancel', 'Delete'];
        this.editparams = {
            params: {
                allowFiltering: false,
                dataSource: new DataManager(this.genums.trueFalseDDL),
                fields: { value: 'value', text: 'text' },
                query: new Query(),
                actionComplete: () => false,
            },
        };
        this.pageSettings = {
            pageSizes: false,
            pageSize: AppConsts.grid.defaultPageSize,
            // pageCount: 0,
            currentPage: 1,
        };
        this.showContent(0);
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }

    // getGridMasters(event?: LazyLoadEvent) {
    //     if (this.primengTableHelper.shouldResetPaging(event)) {
    //         this.paginator.changePage(0);
    //         return;
    //     }

    //     this.primengTableHelper.showLoadingIndicator();

    //     this._gridMastersServiceProxy
    //         .getAll(
    //             this.filterText,
    //             this.nameFilter,
    //             this.coumnOneFilter,
    //             this.columnTwoFilter,
    //             this.forPRJFilter,
    //             this.forSWKFilter,
    //             this.forCALLFilter,
    //             this.forPPMFilter,
    //             this.forTandMFilter,
    //             this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty : this.maxDisplayOrderFilter,
    //             this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty : this.minDisplayOrderFilter,
    //             this.organizationUnitDisplayNameFilter,
    //             // this.primengTableHelper.getSorting(this.dataTable),
    //             // this.primengTableHelper.getSkipCount(this.paginator, event),
    //             // this.primengTableHelper.getMaxResultCount(this.paginator, event)
    //             this.sortColumn + ' ' + this.sortDirection,
    //             this.skipCount,
    //             this.maxResultCount
    //         )
    //         .subscribe((result) => {
    //             // this.primengTableHelper.totalRecordsCount = result.totalCount;
    //             // this.primengTableHelper.records = result.items;
    //             // this.primengTableHelper.hideLoadingIndicator();
    //             this.data = result;
    //             this.totalRecordCount = result.totalCount;
    //         });
    // }

    // reloadPage(): void {
    //     this.paginator.changePage(this.paginator.getPage());
    // }

    createGridMaster(): void {
        this.createOrEditGridMasterModal.show();
    }

    showHistory(gridMaster: GridMasterDto): void {
        this.entityTypeHistoryModal.show({
            entityId: gridMaster.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteGridMaster(gridMaster: GridMasterDto): void {
        console.log(gridMaster);
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._gridMastersServiceProxy.delete(gridMaster.id).subscribe(() => {
                    // this.reloadPage();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    tabAcive(e) {
        var elems = document.querySelectorAll('.active');
        [].forEach.call(elems, function (el) {
            el.classList.remove('active');
        });
        e.target.className = 'active';
    }

    onActionComplete(args) {
        // console.log('%cgridMasters.component.ts line:208 onActionComplete', 'color: #007acc;', args);
        if (args.action == 'edit' || args.requestType == 'save') {
            this.gridMaster = JSON.parse(JSON.stringify(args.data));
            this.gridMaster['name'] = this.tabSelectedName;
            this.gridMaster['forPRJ'] = this.gridMaster['forPRJ'] == true ? true : false;
            this.gridMaster['forSWK'] = this.gridMaster['forSWK'] == true ? true : false;
            this.gridMaster['forCALL'] = this.gridMaster['forCALL'] == true ? true : false;
            this.gridMaster['forPPM'] = this.gridMaster['forPPM'] == true ? true : false;
            this.gridMaster['forTandM'] = this.gridMaster['forTandM'] == true ? true : false;

            this.spinnerService.show();
            this._gridMastersServiceProxy.createOrEdit(this.gridMaster).subscribe((result) => {
                console.log('%cgridMasters.component.ts line:234 result', 'color: #007acc;', result);
                this.spinnerService.hide();
                this.notify.info(this.l('SavedSuccessfully'));
            }, () => {
                this.spinnerService.hide();
                // console.log('%cgridMasters.component.ts line:234 err', 'color: #007acc;', args, args.form[0]);
                // args.e.form.elements.namedItem(this.setFocus.field).focus();

                // setTimeout(function(args){
                //     console.log('%cgridMasters.component.ts line:243 setTimeout', 'color: #007acc;', args.form[0]);
                //     // console.log('%cgridMasters.component.ts line:244 length', 'color: #007acc;', $('#gridMaincoumnOne').length);
                //     args.form[0].focus(); 
                //     var targLink = args.form[0]
                //     var clickEvent  = document.createEvent ('MouseEvents');
                //     clickEvent.initEvent ('dblclick', true, true);
                //     targLink.dispatchEvent (clickEvent);
                // }.bind(this),10, args); 
                return false;
            });
        }
        if (args.requestType == 'delete') {
            this.gridMaster = JSON.parse(JSON.stringify(args.data));
            this._gridMastersServiceProxy.delete(this.gridMaster[0]['gridMaster'].id).subscribe(() => {
                this.notify.warn(this.l('Deleted Successfully'));
            });
        }
    }

    created() {
        //this.grid.element.querySelector('.e-toolbar-items').style.float = 'right';
    }

    getGridData(index) {
        this._gridMastersServiceProxy
            .getAll(
                this.filterText,
                this.nameFilter,
                this.coumnOneFilter,
                this.columnTwoFilter,
                this.forPRJFilter,
                this.forSWKFilter,
                this.forCALLFilter,
                this.forPPMFilter,
                this.forTandMFilter,
                this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty : this.maxDisplayOrderFilter,
                this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty : this.minDisplayOrderFilter,
                this.organizationUnitDisplayNameFilter,
                this.sortColumn + ' ' + this.sortDirection,
                this.skipCount,
                this.maxResultCount
            )
            .subscribe((result) => {
                let filteredRes = result.items
                    .filter((obj) => obj.gridMaster.name.toLowerCase() == this.tabNames[index].toLowerCase())
                    .map((x) => ({ ...x.gridMaster }));
                this.data = filteredRes;
                this.pageSettings.totalRecordsCount = result.totalCount;
                console.log(
                    '%cgridMasters.component.ts line:253 filteredRes',
                    'color: #007acc;',
                    result,
                    filteredRes,
                    this.pageSettings
                );
            });
    }
    handleColumns(colPPP:boolean, colCALL:boolean, colTYP:boolean, colTM:boolean, colSM:boolean, colSW:boolean) {
        this.colPPP = colPPP;
        this.colCALL = colCALL;
        this.colTYP = colTYP;
        this.colTM = colTM;
        this.colSM = colSM;
        this.colSW = colSW; 
    }
    showContent(indicator): void {        
        this.activeTab = indicator;
        this.handleColumns(false, false, false, false, false, false);             

        switch (indicator) {            
            case 0: {
                this.tabSelectedName = this.tabNames[0];   
                this.handleColumns(true, true, false, true, true, true);             
                this.getGridData(0);
                break;
            }
            case 1: {
                this.tabSelectedName = this.tabNames[1];
                this.handleColumns(true, true, true, true, true, true);
                this.getGridData(1);
                break;
            }
            case 2: {
                this.tabSelectedName = this.tabNames[2];
                this.handleColumns(true, true, false, true, true, true);
                this.getGridData(2);
                break;
            }
            case 3: {
                this.tabSelectedName = this.tabNames[3];
                this.handleColumns(false, false, false, false, false, false);
                this.getGridData(3);
                break;
            }
            case 4: {
                this.tabSelectedName = this.tabNames[4];                
                this.getGridData(4);
                break;
            }
            case 5: {
                this.tabSelectedName = this.tabNames[5];
                this.handleColumns(false, false, false, false, false, false);
                this.getGridData(5);
                break;
            }
            case 6: {
                this.tabSelectedName = this.tabNames[6];
                this.handleColumns(false, false, false, false, false, false);
                this.getGridData(6);
                break;
            }
            case 7: {
                this.tabSelectedName = this.tabNames[7];
                this.getGridData(7);
                break;
            }
            default: {
                console.log(indicator.index);
                break;
            }
        }
    }

    // exportToExcel(): void {
    //     this._gridMastersServiceProxy
    //         .getGridMastersToExcel(
    //             this.filterText,
    //             this.nameFilter,
    //             this.coumnOneFilter,
    //             this.columnTwoFilter,
    //             this.forPRJFilter,
    //             this.forSWKFilter,
    //             this.forCALLFilter,
    //             this.forPPMFilter,
    //             this.forTandMFilter,
    //             this.maxDisplayOrderFilter == null ? this.maxDisplayOrderFilterEmpty : this.maxDisplayOrderFilter,
    //             this.minDisplayOrderFilter == null ? this.minDisplayOrderFilterEmpty : this.minDisplayOrderFilter,
    //             this.organizationUnitDisplayNameFilter
    //         )
    //         .subscribe((result) => {
    //             this._fileDownloadService.downloadTempFile(result);
    //         });
    // }
}
