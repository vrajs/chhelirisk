﻿import { AppConsts } from '@shared/AppConsts';
import { Component, ViewChild, Injector, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { GetGridMasterForViewDto, GridMasterDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';

@Component({
    selector: 'viewGridMasterModal',
    templateUrl: './view-gridMaster-modal.component.html',
})
export class ViewGridMasterModalComponent extends AppComponentBase {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    item: GetGridMasterForViewDto;

    constructor(injector: Injector) {
        super(injector);
        this.item = new GetGridMasterForViewDto();
        this.item.gridMaster = new GridMasterDto();
    }

    show(item: GetGridMasterForViewDto): void {
        this.item = item;
        this.active = true;
        this.modal.show();
    }

    close(): void {
        this.active = false;
        this.modal.hide();
    }
}
