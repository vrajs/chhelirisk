﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { GuidanceNotesServiceProxy, CreateOrEditGuidanceNoteDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { EditorManager, RichTextEditorComponent } from '@syncfusion/ej2-angular-richtexteditor';
import { ComboBox } from '@syncfusion/ej2-dropdowns';



@Component({
    selector: 'createOrEditGuidanceNoteModal',
    templateUrl: './create-or-edit-guidanceNote-modal.component.html',
})
export class CreateOrEditGuidanceNoteModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @ViewChild('editor') rteRef: RichTextEditorComponent;
    public editorManager: EditorManager;
    public rteObj: RichTextEditorComponent;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    

    active = false;
    saving = false;

    editorValue: string;

    guidanceNote: CreateOrEditGuidanceNoteDto = new CreateOrEditGuidanceNoteDto();
    @ViewChild("taskObj") public taskObj: ComboBox;
    projectStages: any[] = [];
    projectTasks: any[] = [];

    constructor(
        injector: Injector,
        private _guidanceNotesServiceProxy: GuidanceNotesServiceProxy,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    
    show(guidanceNoteId?: number): void {
        if (!guidanceNoteId) {
            this.guidanceNote = new CreateOrEditGuidanceNoteDto();
            this.guidanceNote.id = guidanceNoteId;
            this.editorValue = '';
            this.active = true;
            this.modal.show();
        } else {
            this._guidanceNotesServiceProxy.getGuidanceNoteForEdit(guidanceNoteId).subscribe((result) => {
                this.guidanceNote = result.guidanceNote;
                this.editorValue = result.guidanceNote.helpContent;
                this.active = true;
                this.modal.show();
                
            });
        }
    }

    

    save(): void {
        this.saving = true;
        this.guidanceNote.helpContent= this.editorValue;
        
        this._guidanceNotesServiceProxy
            .createOrEdit(this.guidanceNote)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);                                
            });
            
    }

    close(): void {
        this.active = false;
        this.modal.hide();
    }
    

    //Text Editor tools

    public tools: object = {
        type: 'MultiRow',
        items: ['Bold', 'Italic', 'Underline', 'StrikeThrough',
        'FontName', 'FontSize', 'FontColor', 'BackgroundColor',
        'LowerCase', 'UpperCase', '|',
        'Formats', 'Alignments', 'OrderedList', 'UnorderedList',
        'Outdent', 'Indent', '|',
        'CreateLink', 'Image', '|', 'ClearFormat', 'Print',
        'SourceCode', 'FullScreen', '|', 'Undo', 'Redo'            
        ]
    };
    public quickTools: object = {
        image: [
            'Replace', 'Align', 'Caption', 'Remove', 'InsertLink', '-', 'Display', 'AltText', 'Dimension']
    };

    public height: any='350px';



    onShow(){
        
    }
   
    reloadEditorUI(e){
        this.rteRef.refreshUI(); 
    }

    ngOnInit(): void {
        this.projectStages = Object.values(this.genums.projectStages)
        .sort((a, b) => a['displayOrder'] - b['displayOrder']);
        this.projectStages.push({code: "customer", title: "Customer"});
        this.projectStages.push({code: "lead", title: "Lead"});
    }

    chngStage(event) {
        this.projectTasks = Object.values(this.genums.projectTasks)
        .sort((a, b) => a['displayOrder'] - b['displayOrder'])
        .filter(x => x['stageId'] == event.value);
        this.projectTasks.push({code: "add-customer", title: "Add Customer", displayOrder:0, stageId: "customer"});
        this.projectTasks.push({code: "add-lead", title: "Add Lead", displayOrder:0, stageId: "lead"});
        this.taskObj.dataBind();
    }
}
