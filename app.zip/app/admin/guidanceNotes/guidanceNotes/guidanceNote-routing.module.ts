﻿import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {GuidanceNotesComponent} from './guidanceNotes.component';



const routes: Routes = [
    {
        path: '',
        component: GuidanceNotesComponent,
        pathMatch: 'full'
    },
    
    
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class GuidanceNoteRoutingModule {
}
