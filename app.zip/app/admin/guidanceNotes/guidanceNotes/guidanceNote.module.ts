﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { GuidanceNoteRoutingModule } from './guidanceNote-routing.module';
import { GuidanceNotesComponent } from './guidanceNotes.component';
import { CreateOrEditGuidanceNoteModalComponent } from './create-or-edit-guidanceNote-modal.component';
import { ViewGuidanceNoteModalComponent } from './view-guidanceNote-modal.component';

import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
import { LinkService, ImageService, HtmlEditorService } from "@syncfusion/ej2-angular-richtexteditor";
import { UploaderModule } from "@syncfusion/ej2-angular-inputs";
import { GridModule, InfiniteScrollService, SortService } from "@syncfusion/ej2-angular-grids";
import { EditService, FilterService, ToolbarService } from "@syncfusion/ej2-angular-grids";
import { ToolbarModule } from '@syncfusion/ej2-angular-navigations';



@NgModule({
    declarations: [GuidanceNotesComponent, CreateOrEditGuidanceNoteModalComponent, ViewGuidanceNoteModalComponent],
    imports: [
                AppSharedModule, GuidanceNoteRoutingModule,
                AdminSharedModule, RichTextEditorAllModule,
                UploaderModule, GridModule, ToolbarModule
            ],

    //Text editor provider
    providers: [
                    ToolbarService, LinkService, ImageService, HtmlEditorService,
                    FilterService, EditService, ToolbarService, SortService, InfiniteScrollService
                ]

})
export class GuidanceNoteModule {}
