﻿import { AppConsts } from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GuidanceNotesServiceProxy, GuidanceNoteDto, GetGuidanceNoteForViewDto, CreateOrEditGuidanceNoteDto } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditGuidanceNoteModalComponent } from './create-or-edit-guidanceNote-modal.component';

import { ViewGuidanceNoteModalComponent } from './view-guidanceNote-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { filter as _filter, result } from 'lodash-es';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

import { beginEdit, EditService, EditSettingsModel, GridComponent, PageSettingsModel } from "@syncfusion/ej2-angular-grids";
import { ToolbarItems } from '@syncfusion/ej2-angular-richtexteditor';
import { id } from '@swimlane/ngx-charts';
import { observable } from 'rxjs';
import { count } from 'console';
//import { data } from "./dataSource";

import { CommandModel } from '@syncfusion/ej2-angular-grids';
import { ModalDirective } from 'ngx-bootstrap/modal';

@Component({
    templateUrl: './guidanceNotes.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class GuidanceNotesComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditGuidanceNoteModal', { static: true })
    createOrEditGuidanceNoteModal: CreateOrEditGuidanceNoteModalComponent;
    @ViewChild('viewGuidanceNoteModalComponent', { static: true })
    viewGuidanceNoteModal: ViewGuidanceNoteModalComponent;

    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    @ViewChild('grid')
    public grid: GridComponent;

    advancedFiltersAreShown = false;
    filterText = '';
    stageFilter = '';
    taskFilter = '';
    helpContentFilter = '';

    constructor(
        injector: Injector,
        private _guidanceNotesServiceProxy: GuidanceNotesServiceProxy,
        private _notifyService: NotifyService,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
        private _dateTimeService: DateTimeService        
    ) {        
        super(injector);        
    }

    public toolbar: any[];
    public editParams;
    public pageSettings: PageSettingsModel;
    public editSettings: EditSettingsModel;
    guidanceNote: CreateOrEditGuidanceNoteDto = new CreateOrEditGuidanceNoteDto();
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    editorValue: string;
    active = false;
    saving = false;
    

    public dat: Array<GetGuidanceNoteForViewDto> = [];

    public menuItems:any[];
    display=true;
    public commands: CommandModel[];

    ngOnInit(): void {
        this.getGuidanceNotes();
        this.editSettings = { allowAdding: true, allowDeleting: true, allowEditing: true};
        this.toolbar = ["Edit", "Cancel"];
        this.editParams = {
            params: {
                allowFiltering: true
            }
        }
    }

    onClick(args){
        console.log(args);
        this.createOrEditGuidanceNoteModal.show(args.id);       
}

    onActionComplete(args) {                
        if (args.requestType == 'save') {                       
           this.createOrEditGuidanceNoteModal.show(args.id);
           this.notify.success(this.l('Successfully Added'));
             this._guidanceNotesServiceProxy.createOrEdit(args.data.guidanceNote).subscribe((result) => {            
               this.notify.success(this.l('Successfully Added'));
             });
        }
        if(args.requestType == 'beginEdit'){                
            args.cancel = true;
            //console.log(args.data.guidanceNote);
            //this.createOrEditGuidanceNoteModal.show();
            this.createOrEditGuidanceNoteModal.show(args.rowData.guidanceNote.id);       
            //this.notify.success(this.l('Successfully Added'));
        }
        if(args.requestType == 'delete'){
             //console.log(args.data[0].guidanceNote.id);
            this._guidanceNotesServiceProxy.delete(args.data[0].guidanceNote.id).subscribe((result) =>{
                this.reloadPage();
                this.notify.success(this.l('Successfully Deleted'));
            })
            
        }
    }
    public count: 10;


    getGuidanceNotes(event?: LazyLoadEvent) {        
        // if (this.primengTableHelper.shouldResetPaging(event)) {
        //     //this.paginator.changePage(0);
        //     if (this.primengTableHelper.records && this.primengTableHelper.records.length > 0) {
        //         return;
        //     }
        // }


       // this.primengTableHelper.showLoadingIndicator();

        this._guidanceNotesServiceProxy
            .getAll(
                this.filterText,
                this.stageFilter,
                this.taskFilter,
                this.helpContentFilter,
                //this.primengTableHelper.getSorting(this.dataTable),
                '',
                //this.primengTableHelper.getSkipCount(this.paginator, event),
                0,
                //this.primengTableHelper.getMaxResultCount(this.paginator, event)
                40  
            )
            .subscribe((result) => {
                window.localStorage.setItem('App.GuidanceNotes',JSON.stringify(result));
                this.primengTableHelper.totalRecordsCount = result.totalCount;
                this.primengTableHelper.records = result.items;
                this.primengTableHelper.hideLoadingIndicator();
                this.dat = result.items;
                
            });


    }



    reloadPage(): void {
        this.paginator.changePage(this.paginator.getPage());
    }

    createGuidanceNote(): void {
        this.createOrEditGuidanceNoteModal.show();
    }

    deleteGuidanceNote(guidanceNote: GuidanceNoteDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._guidanceNotesServiceProxy.delete(guidanceNote.id).subscribe(() => {
                    //this.reloadPage();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    exportToExcel(): void {
        this._guidanceNotesServiceProxy
            .getGuidanceNotesToExcel(this.filterText, this.stageFilter, this.taskFilter, this.helpContentFilter)
            .subscribe((result) => {
                this._fileDownloadService.downloadTempFile(result);
            });
    }
}
