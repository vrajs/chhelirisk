﻿import { AppConsts } from '@shared/AppConsts';
import { Component, ViewChild, Injector, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { GetGuidanceNoteForViewDto, GuidanceNoteDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';

@Component({
    selector: 'viewGuidanceNoteModal',
    templateUrl: './view-guidanceNote-modal.component.html',
})
export class ViewGuidanceNoteModalComponent extends AppComponentBase {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    item: GetGuidanceNoteForViewDto;

    constructor(injector: Injector) {
        super(injector);
        this.item = new GetGuidanceNoteForViewDto();
        this.item.guidanceNote = new GuidanceNoteDto();
    }

    show(item: GetGuidanceNoteForViewDto): void {
        this.item = item;
        this.active = true;
        this.modal.show();
    }

    close(): void {
        this.active = false;
        this.modal.hide();
    }

    
}
