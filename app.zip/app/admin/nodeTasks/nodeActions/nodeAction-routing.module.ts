﻿import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NodeActionsComponent } from './nodeActions.component';

const routes: Routes = [
    {
        path: '',
        component: NodeActionsComponent,
        pathMatch: 'full',
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class NodeActionRoutingModule {}
