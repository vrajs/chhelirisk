﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { NodeStageRoutingModule } from './nodeStage-routing.module';
import { NodeStagesComponent } from './nodeStages.component';
import { CreateOrEditNodeStageModalComponent } from './create-or-edit-nodeStage-modal.component';
import { ViewNodeStageModalComponent } from './view-nodeStage-modal.component';

@NgModule({
    declarations: [NodeStagesComponent, CreateOrEditNodeStageModalComponent, ViewNodeStageModalComponent],
    imports: [AppSharedModule, NodeStageRoutingModule, AdminSharedModule],
})
export class NodeStageModule {}
