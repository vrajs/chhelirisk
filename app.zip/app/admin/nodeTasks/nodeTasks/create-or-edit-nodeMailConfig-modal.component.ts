import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, AfterViewInit } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    NodeMailConfigsServiceProxy,
    CreateOrEditNodeMailConfigDto,
    RoleServiceProxy,
    GetRolesInput,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import {
    ToolbarService,
    LinkService,
    ImageService,
    HtmlEditorService,
    RichTextEditorComponent,
    InsertHtml,
} from '@syncfusion/ej2-angular-richtexteditor';
import { QueryBuilderComponent, ColumnsModel } from '@syncfusion/ej2-angular-querybuilder';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { NgForm } from '@angular/forms';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { AppConsts } from '@shared/AppConsts';
import { DatePipe } from '@angular/common';
import { IntervalSettingsDto } from '@app/shared/layout/interval-settings/interval-setting-dto';
@Component({
    selector: 'createOrEditNodeMailConfigModal',
    templateUrl: './create-or-edit-nodeMailConfig-modal.component.html',
    providers: [ToolbarService, LinkService, ImageService, HtmlEditorService, DatePipe],
})
export class CreateOrEditNodeMailConfigModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @ViewChild('editor') public rteRef: RichTextEditorComponent;
    @ViewChild('nodeMailConfigForm') public mailConfigForm: NgForm;
    public proxy: any;
    public dropDownListObject1: DropDownList;
    public drpnData1: [];
    public dropDownListObject2: DropDownList;
    public drpnData2 = [];
    @ViewChild('qryBldrRef') public qryBldrRef: QueryBuilderComponent;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;
    editorValue: string;
    filter: ColumnsModel[] = [];
    weeksArr: any = AppConsts.WeeksArray;
    public nodeTaskId: string;
    hasRulesNotAdded: boolean = false;
    isAnyOftheRuleEmpty: boolean = false;
    public tools = AppConsts.toolSettings;

    nodeMailConfig: CreateOrEditNodeMailConfigDto = new CreateOrEditNodeMailConfigDto();
    getRolesInput: GetRolesInput = new GetRolesInput();
    showQueryBuilder: boolean;
    notifType: string;
    templateId: string;
    allRoles: any = [];
    econsysVariables: any = [];
    daysArr = AppConsts.DaysArr;
    public weekday: any;
    intervalSettingsDto: IntervalSettingsDto = new IntervalSettingsDto();
    dateRecurrance = true;
    dayRecurrance = false;
    weekdays: string[];
    months: object[];
    recur: string[];
    showPreview: boolean = false;

    constructor(
        injector: Injector,
        private _nodeMailConfigsServiceProxy: NodeMailConfigsServiceProxy,
        private _roleService: RoleServiceProxy
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.filter = AppConsts.DateBasedRules;
        this.getAllRoles();
    }

    show(notifType: string, taskId: string, nodeMailConfigId?: number): void {
        this.rteRef.toolbarSettings = this.tools;
        this.weeksArr.map((obj) => (obj.isSelected = false));
        this.notifType = notifType;
        this.nodeTaskId = taskId;
        this.showPreview = true;
        this.showQueryBuilder =
            this.notifType.toLowerCase() == this.genums.notifTypes.PROMPT.code.toLowerCase() ||
            this.notifType.toLowerCase() == this.genums.notifTypes.ESCALATION.code.toLowerCase()
                ? true
                : false;

        this.getEconsysVariables('','',0);

        if (!nodeMailConfigId) {
            this.nodeMailConfig = new CreateOrEditNodeMailConfigDto();
            this.nodeMailConfig.id = nodeMailConfigId;
            this.editorValue = '';
            setTimeout(() => {
                this.qryBldrRef.setRules({});
            }, 1000);
            this.active = true;
            this.modal.show();
        } else {
            this._nodeMailConfigsServiceProxy.getNodeMailConfigForEdit(nodeMailConfigId).subscribe((result) => {
                this.nodeMailConfig = result.nodeMailConfig;
                if (this.nodeMailConfig && this.nodeMailConfig.weekly) {
                    this.intervalSettingsDto = JSON.parse(this.nodeMailConfig.weekly);
                    if (!this.intervalSettingsDto.recurDaySeq) {
                        this.dateRecurrance = true;
                        this.dayRecurrance = false;
                    }
                } else if (this.nodeMailConfig && this.nodeMailConfig.monthly) {
                    this.intervalSettingsDto = JSON.parse(this.nodeMailConfig.monthly);
                    if (this.intervalSettingsDto.recurDaySeq) {
                        this.dateRecurrance = false;
                        this.dayRecurrance = true;
                    }
                }
                this.editorValue = result.nodeMailConfig.body;
                if (this.qryBldrRef) {
                    if (result.nodeMailConfig.ruleJson) {
                        this.qryBldrRef.setRules(JSON.parse(result.nodeMailConfig.ruleJson));
                    } else {
                        this.qryBldrRef.setRules({});
                    }
                }
                this.active = true;
                this.modal.show();
            });
        }
    }

    oncreated(): void {
        let proxy = this.rteRef;
        this._roleService.getRoles(this.getRolesInput).subscribe((result) => {
            this.drpnData2 = result.items;
            this.dropDownListObject2 = new DropDownList({
                dataSource: this.drpnData2,
                fields: { text: 'displayName' },
                width: '180px',
                change: (args: any) => {
                    proxy.focusIn();
                    let value = '<&' + args.value + '&>';
                    InsertHtml.Insert(document, document.createTextNode(value));
                },
            });
            this.dropDownListObject2.appendTo('#ddlelement2');
        });
    }

    OnChanged(args) {
        this.rteRef.placeholder = args.value;
    }

    checkChange(flag: boolean) {
        this.nodeMailConfig.isDisabled = flag;
    }

    save(): void {
        this.hasRulesNotAdded = false;
        this.isAnyOftheRuleEmpty = false;
        this.nodeMailConfig.templateId = '597367_EP_2'; //TBD as discssued with team
        if (this.qryBldrRef && this.qryBldrRef.getRules()) {
            if (this.qryBldrRef.getRules().rules.length == 0) {
                this.hasRulesNotAdded = true;
                this.isAnyOftheRuleEmpty = false;
                return;
            } else {
                this.qryBldrRef.getRules().rules.forEach((currentRule) => {
                    if (
                        currentRule &&
                        (!currentRule.field || !currentRule.label || !currentRule.operator || !currentRule.type)
                    ) {
                        this.hasRulesNotAdded = false;
                        this.isAnyOftheRuleEmpty = true;
                        return;
                    }
                });
            }
        }

        if (this.isAnyOftheRuleEmpty || this.hasRulesNotAdded) {
            return;
        }

        this.saving = true;
        this.nodeMailConfig.body = this.rteRef.getHtml();
        if (this.showQueryBuilder) {
            this.nodeMailConfig.ruleJson = JSON.stringify(this.qryBldrRef.getRules());
        }

        this.nodeMailConfig.type = this.notifType;
        this.nodeMailConfig.nodeTaskId = this.nodeTaskId;
        if (this.intervalSettingsDto && this.intervalSettingsDto.weekly) {
            this.nodeMailConfig.weekly = JSON.stringify(this.intervalSettingsDto);
            this.nodeMailConfig.monthly = null;
            this.nodeMailConfig.weekMonth = true;
        } else if (this.intervalSettingsDto && this.intervalSettingsDto.monthly) {
            this.nodeMailConfig.monthly = this.nodeMailConfig.weekly = JSON.stringify(this.intervalSettingsDto);
            this.nodeMailConfig.weekly = null;
            this.nodeMailConfig.weekMonth = false;
        }

        this.spinnerService.show();
        this._nodeMailConfigsServiceProxy
            .createOrEdit(this.nodeMailConfig)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(
                () => {
                    this.spinnerService.hide();
                    this.notify.info(this.l('SavedSuccessfully'));
                    this.close();
                    this.modalSave.emit(null);
                },
                () => {
                    this.spinnerService.hide();
                    this.saving = false;
                }
            );
    }

    close(): void {
        this.active = false;
        this.resetForm();
        this.modal.hide();
    }

    reloadEditorUI(e) {
        this.rteRef.refreshUI();
        this.resetForm();
    }

    resetForm() {
        this.hasRulesNotAdded = false;
        this.isAnyOftheRuleEmpty = false;
        if (this.mailConfigForm) {
            this.mailConfigForm.form.markAsPristine();
            this.mailConfigForm.form.markAsUntouched();
        }
    }

    showParentModal() {
        this.modal.show();
    }

    getAllRoles() {
        this._nodeMailConfigsServiceProxy.getRoles().subscribe((roles) => {
            this.allRoles = roles.items;
        });
    }

    getVariableValue(e: TypeaheadMatch, type: string) {
        if (type == 'to') {
            this.nodeMailConfig.to = '<&' + e.value + '&>';
        } else if (type == 'cc') {
            this.nodeMailConfig.cc = '<&' + e.value + '&>';
        }
    }

    getEconsysVariables(type: string, nodeTaskId:string, nodeMailConfigId:number) {
        this.econsysVariables = [];
        this.dropDownListObject1 = new DropDownList({
            dataSource: this.drpnData1,
            fields: { text: 'code' },
            cssClass: "cls_variables",
            width: '180px',
            change: (args: any) => {
                this.rteRef.focusIn();
                let value = '<$' + args.itemData.code + "_" + args.itemData.flexiSectionId + "$>";
                InsertHtml.Insert(document, document.createTextNode(value));
            },
        });

        var drpVariables = document.getElementsByClassName("seetings_tools");
        if (drpVariables) {
            var length = drpVariables.length;
            for (let index = 0; index < length; index++) {
                const element = drpVariables[index];
                element.innerHTML = '';
                element.innerHTML = '<input type="text" tabindex="1" id="ddlelement1" value="Econsys Variables" />'
                this.rteRef.refreshUI();
            }
        }

        this.dropDownListObject1.appendTo('#ddlelement1');
        this.rteRef.refreshUI();
        // // this._nodeMailConfigsServiceProxy.getEconsysVariables(type,nodeTaskId,nodeMailConfigId?nodeMailConfigId:undefined).subscribe((result: any) => {
        // //     this.drpnData1 = result;
            
        // // });
    }

    onDataIntervalChange(period: any): void {
        const self = this;
        self.intervalSettingsDto = new IntervalSettingsDto();
        if (period === 'weekly') {
            self.intervalSettingsDto.monthly = false;
            self.intervalSettingsDto.weekly = true;
        } else if (period === 'monthly') {
            self.intervalSettingsDto.weekly = false;
            self.intervalSettingsDto.monthly = true;
        } else if (period === 'recurDate') {
            this.intervalSettingsDto.weekly = true;
            this.intervalSettingsDto.monthly = false;

            this.intervalSettingsDto.weekly = false;
            this.intervalSettingsDto.monthly = true;
            self.dateRecurrance = true;
            self.dayRecurrance = false;
        } else if (period === 'recurDay') {
            this.intervalSettingsDto.weekly = true;
            this.intervalSettingsDto.monthly = false;

            this.intervalSettingsDto.weekly = false;
            this.intervalSettingsDto.monthly = true;
            self.dateRecurrance = false;
            self.dayRecurrance = true;
        }
    }
}
