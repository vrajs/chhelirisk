﻿import { Component, Injector, OnInit } from '@angular/core';
import { finalize } from 'rxjs/operators';
import {
    NodeTasksServiceProxy,
    CreateOrEditNodeTaskDto
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';
import { ActivatedRoute, Router } from '@angular/router';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Observable } from '@node_modules/rxjs';
import { BreadcrumbItem } from '@app/shared/common/sub-header/sub-header.component';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    templateUrl: './create-or-edit-nodeTask.component.html',
    animations: [appModuleAnimation()],
})
export class CreateOrEditNodeTaskComponent extends AppComponentBase implements OnInit {
    active = false;
    saving = false;

    nodeTask: CreateOrEditNodeTaskDto = new CreateOrEditNodeTaskDto();

    nodeStageTitle = '';

    allNodeStages = [];


    breadcrumbs: BreadcrumbItem[] = [
        new BreadcrumbItem(this.l('NodeTask'), '/app/admin/nodeTasks/nodeTasks'),
        new BreadcrumbItem(this.l('Entity_Name_Plural_Here') + '' + this.l('Details')),
    ];

    constructor(
        injector: Injector,
        private _activatedRoute: ActivatedRoute,
        private _nodeTasksServiceProxy: NodeTasksServiceProxy,
        private _router: Router,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.show(this._activatedRoute.snapshot.queryParams['id']);
    }

    show(nodeTaskId?: string): void {
        if (!nodeTaskId) {
            this.nodeTask = new CreateOrEditNodeTaskDto();
            this.nodeTask.id = nodeTaskId;
            this.nodeStageTitle = '';

            this.active = true;
        } else {
            this._nodeTasksServiceProxy.getNodeTaskForEdit(nodeTaskId).subscribe((result) => {
                this.nodeTask = result.nodeTask;

                this.nodeStageTitle = result.nodeStageTitle;

                this.active = true;
            });
        }
        // this._nodeTasksServiceProxy.getAllNodeStageForTableDropdown().subscribe((result) => {
        //     this.allNodeStages = result;
        // });
    }

    save(): void {
        this.saving = true;

        this._nodeTasksServiceProxy
            .createOrEdit(this.nodeTask)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe((x) => {
                this.saving = false;
                this.notify.info(this.l('SavedSuccessfully'));
                this._router.navigate(['/app/admin/nodeTasks/nodeTasks']);
            });
    }

    saveAndNew(): void {
        this.saving = true;

        this._nodeTasksServiceProxy
            .createOrEdit(this.nodeTask)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe((x) => {
                this.saving = false;
                this.notify.info(this.l('SavedSuccessfully'));
                this.nodeTask = new CreateOrEditNodeTaskDto();
            });
    }
}
