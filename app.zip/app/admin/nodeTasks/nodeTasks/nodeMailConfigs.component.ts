import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
    NodeMailConfigsServiceProxy,
    NodeMailConfigDto,
    CreateOrEditNodeMailConfigDto,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { CreateOrEditNodeMailConfigModalComponent } from './create-or-edit-nodeMailConfig-modal.component';

import { appModuleAnimation } from '@shared/animations/routerTransition';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';

import { BreadcrumbItem } from '@app/shared/common/sub-header/sub-header.component';

@Component({
    templateUrl: './nodeMailConfigs.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class NodeMailConfigsComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditNodeMailConfigModal', { static: true })
    createOrEditNodeMailConfigModal: CreateOrEditNodeMailConfigModalComponent;
    nodeMail: CreateOrEditNodeMailConfigDto = new CreateOrEditNodeMailConfigDto();
    public data: object;
    public toolbar: any; // ToolbarItems[];
    saving = false;
    public editSettings: Object;
    public pageSettings: any = { pageSizes: false, pageSize: 10000, pageCount: 0, currentPage: 1 };

    advancedFiltersAreShown = false;
    filterText = '';

    _entityTypeFullName = 'asq.econsys.Eco.NodeMailConfig.NodeMailConfig';
    entityHistoryEnabled = false;

    breadcrumbs: BreadcrumbItem[] = [
        new BreadcrumbItem(this.l('NodeTask'), '/app/admin/nodeTasks/nodeTasks'),
        new BreadcrumbItem(this.l('NodeMailConfigs')),
    ];
    type: string;
    rule: string;
    ruleJson: string;
    eventRecords: any;
    promptsRecords: any;
    esclationRecords: any;
    promptsRecordsCount: any;
    eventsRecordsCount: any;
    escalationRecordsCount: any;
    public taskName: any;
    public nodeTaskId: string;

    @ViewChild('addPrpmpt', { static: true }) addPrpmpt: any;

    constructor(
        injector: Injector,
        private _nodeMailConfigsServiceProxy: NodeMailConfigsServiceProxy,
        private _activatedRoute: ActivatedRoute
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.nodeTaskId = this._activatedRoute.snapshot.queryParams['nodeTaskId'];
        this.taskName = this._activatedRoute.snapshot.queryParams['taskName'];
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        this.data = [];
        this.editSettings = { allowEditing: false, allowAdding: true, allowDeleting: true, mode: 'Normal' };
        this.toolbar = ['Add', { template: this.addPrpmpt }];

        this.getNodeMailConfigs();
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }

    getNodeMailConfigs() {
        this.primengTableHelper.showLoadingIndicator();

        this._nodeMailConfigsServiceProxy
            .getAllForTask(this.nodeTaskId)
            .subscribe((result) => {                
                this.eventRecords = result
                    .filter((element, index, array) => {
                        return element.nodeMailConfig.type.toLowerCase() === this.genums.notifTypes.EVENT.code.toLowerCase();
                    })
                    .map((x) => ({ ...x.nodeMailConfig }));
                this.promptsRecords = result
                    .filter((element, index, array) => {
                        return element.nodeMailConfig.type.toLowerCase() === this.genums.notifTypes.PROMPT.code.toLowerCase();
                    })
                    .map((x) => ({ ...x.nodeMailConfig }));
                this.esclationRecords = result
                    .filter((element, index, array) => {
                        return element.nodeMailConfig.type.toLowerCase() === this.genums.notifTypes.ESCALATION.code.toLowerCase();
                    })
                    .map((x) => ({ ...x.nodeMailConfig }));
                this.eventsRecordsCount = this.eventRecords.length;
                this.promptsRecordsCount = this.promptsRecords.length;
                this.escalationRecordsCount = this.esclationRecords.length;
                this.primengTableHelper.hideLoadingIndicator();
            });
    }

    isDisabledFlag(field, data, column) {
        var value = data[field] 
        if (value) { 
            return "No" 
        } else { 
            return "Yes" 
        } 
    }

    // createNodeMailConfig(): void {
    //     this.createOrEditNodeMailConfigModal.show();
    // }

    showHistory(nodeMailConfig: NodeMailConfigDto): void {
        this.entityTypeHistoryModal.show({
            entityId: nodeMailConfig.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteNodeMailConfig(nodeMailConfig: NodeMailConfigDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._nodeMailConfigsServiceProxy.delete(nodeMailConfig.id).subscribe(() => {
                    this.getNodeMailConfigs();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    onAccordionlLoaded(e) {
        //var x= this.dataTable;
    }

    onActionComplete(args) {
        if (args.action == 'edit' || args.requestType == 'save') {
            this.nodeMail = JSON.parse(JSON.stringify(args.data));
            this._nodeMailConfigsServiceProxy.createOrEdit(this.nodeMail['nodeMail']).subscribe(() => {                
                this.notify.info(this.l('SavedSuccessfully'));
            });
        }
        if (args.requestType == 'delete') {
            this.nodeMail = JSON.parse(JSON.stringify(args.data));
            this._nodeMailConfigsServiceProxy.delete(this.nodeMail[0]['nodeMail'].id).subscribe(() => {
                this.notify.warn(this.l('Deleted Successfully'));
            });
        }
    }

    getRule(ruleJson:any){
        let ruleStr = '';
        if(ruleJson){
            var rule = JSON.parse(ruleJson);
            let operator = '';
            if(rule && rule.rules.length > 0){
                let ind = 0;
                rule.rules.forEach(currentRule => {
                    ind = ind + 1;
                    switch (currentRule.operator) {
                        case "greaterthanorequal":
                            operator = this.genums.rule.greaterthanorequal;
                            break;
                        case "equal":
                            operator = this.genums.rule.equal;
                            break;
                        case "greaterthan":
                            operator = this.genums.rule.greaterthan;
                            break;
                        case "lessthan":
                            operator = this.genums.rule.lessthan;
                            break;
                        case "notbetween":
                            operator = this.genums.rule.notbetween;
                            break;
                        case "lessthanorequal":
                            operator = this.genums.rule.lessthanorequal;
                            break;
                        case "notequal":
                            operator = this.genums.rule.notequal;
                            break;
                        case "in":
                            operator = this.genums.rule.in;
                            break;
                        case "notin":
                            operator = this.genums.rule.notin;
                            break;
                        case "isnull":
                            operator = this.genums.rule.isnull;
                            break;
                        case "isnotnull":
                            operator = this.genums.rule.isnotnull;
                            break;
                        default:
                            break;
                    }

                    let condtiion = "";
                    if(rule.rules.length > 1 && ind != rule.rules.length){
                        condtiion = rule.condition;
                    }
                    ruleStr += currentRule.label + ' ' + operator + ' ' + currentRule.value + ' ' + condtiion + ' ';
                });
                
            }
        }
        return ruleStr;
    }
}
