﻿import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NodeTasksComponent } from './nodeTasks.component';
import { CreateOrEditNodeTaskComponent } from './create-or-edit-nodeTask.component';
import { ViewNodeTaskComponent } from './view-nodeTask.component';
import { NodeMailConfigsComponent } from './nodeMailConfigs.component';

const routes: Routes = [
    {
        path: '',
        component: NodeTasksComponent,
        pathMatch: 'full',
    },

    {
        path: 'createOrEdit',
        component: CreateOrEditNodeTaskComponent,
        pathMatch: 'full',
    },

    {
        path: 'view',
        component: ViewNodeTaskComponent,
        pathMatch: 'full',
    },
    {
        path: 'nodeMailConfig',
        component: NodeMailConfigsComponent,
        pathMatch: 'full',
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class NodeTaskRoutingModule {}
