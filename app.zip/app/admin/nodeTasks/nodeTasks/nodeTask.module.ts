﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { NodeTaskRoutingModule } from './nodeTask-routing.module';
import { NodeTasksComponent } from './nodeTasks.component';
import { CreateOrEditNodeTaskComponent } from './create-or-edit-nodeTask.component';
import { ViewNodeTaskComponent } from './view-nodeTask.component';
import { PromptsAndAlertPreviewComponent } from './prompts-and-alert-preview.component'
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { NodeMailConfigsComponent } from './nodeMailConfigs.component';
import { CreateOrEditNodeMailConfigModalComponent } from './create-or-edit-nodeMailConfig-modal.component';

@NgModule({
    declarations: [
        NodeTasksComponent, 
        CreateOrEditNodeTaskComponent, 
        ViewNodeTaskComponent,
        NodeMailConfigsComponent,
        CreateOrEditNodeMailConfigModalComponent,
        PromptsAndAlertPreviewComponent],
    imports: [AppSharedModule, NodeTaskRoutingModule, AdminSharedModule,TypeaheadModule],
})
export class NodeTaskModule {}
