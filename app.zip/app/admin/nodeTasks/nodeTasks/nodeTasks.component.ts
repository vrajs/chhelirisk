﻿import { Component, Injector, ViewEncapsulation, ViewChild, Query } from '@angular/core';
import { Router } from '@angular/router';
import { NodeTasksServiceProxy, NodeTaskDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import {
    GridComponent,
    InfiniteScrollSettingsModel,
    PageSettingsModel,
  } from "@syncfusion/ej2-angular-grids";

@Component({
    templateUrl: './nodeTasks.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class NodeTasksComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;

    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;
    @ViewChild("nodetaskgrid", { static: true }) public grid: GridComponent;

    advancedFiltersAreShown = true;
    filterText = '';
    nodeStageTitleFilter = '';

    _entityTypeFullName = 'asq.econsys.Eco.NodeTasks.NodeTask';
    entityHistoryEnabled = false;
    public options: PageSettingsModel;
    public infiniteOptions: InfiniteScrollSettingsModel;
    public tableData: object[] = [];
    public skip_count = 0;
    public take_count = 100;
    public count = 0;
    oldFilterlength = 0;
    public filtering: boolean = false;
    public isSearchContinue:boolean=false;
    toolbar: any;
    public isColumnVisible=true;
    statusFilterList = [];
    statusList: any;
    public stages: { [key: string]: Object }[] = [];
    public selectedStage:any;

    public fields: Object = { text: "title", value: "title" };

    public text: string = "Select Stage";

    constructor(
        injector: Injector,
        private _nodeTasksServiceProxy: NodeTasksServiceProxy,
        private _router: Router,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        this.getNodeStages();
        this.options = { pageSize: 10 };
        this.infiniteOptions = {};
        this.toolbar = ['ColumnChooser', { text: 'Reset', tooltipText: 'Reset', prefixIcon: 'e-refresh', id: 'reset',align: 'Right' }];
    }
    
    public onChange(data:any){
        this.nodeStageTitleFilter = data && data.value ? data.value : '';
        this.tableData = [];
        this.getNodeTasks();
    }

    actionHandler(event) {
        if (
          event.requestType === "infiniteScroll" &&
          this.tableData.length < this.count
        ) {
          this.skip_count += this.take_count;
          this.isSearchContinue=(this.filterText=="" || this.filterText===undefined) ? false : true;
          this.getNodeTasks();
        }
      }
    
      clickHandler(args): void {
        if (args.item.id === 'reset') {
            this.grid.enablePersistence = false; 
            window.localStorage.setItem("gridnodetaskgrid"+this.appSession.userId, "");
            this.grid.destroy(); 
            location.reload(); 
        }
    }
    getNodeTasks(event?: LazyLoadEvent) {
        this.primengTableHelper.showLoadingIndicator();
        if ((this.statusFilterList.length != this.oldFilterlength)  || (this.filterText!="" && !this.isSearchContinue)) {
            this.skip_count = 0;
            this.tableData = [];
          }

        this._nodeTasksServiceProxy
            .getAll(
                this.filterText,
                this.nodeStageTitleFilter,
                "",
                this.skip_count,
                this.take_count
            )
            .subscribe((result) => {
                this.primengTableHelper.totalRecordsCount = result.totalCount;
                this.primengTableHelper.records = result.items;
                this.primengTableHelper.hideLoadingIndicator();
                if (this.tableData.length == 0 && result.totalCount != 0) {
                  this.tableData = result.items;
                  this.oldFilterlength = this.statusFilterList.length;
                  this.filtering = true;
                } else if (this.tableData.length < result.totalCount) {
                  this.tableData = this.tableData.concat(result.items);
                  this.filtering = false;
                }
                this.count = result.totalCount;
            });
    }

    getNodeStages(){
        this.primengTableHelper.showLoadingIndicator();
        this._nodeTasksServiceProxy
        .getAllStages().subscribe((result) => {
            this.primengTableHelper.hideLoadingIndicator();
            if(result){
                result.forEach(stage => {
                    var obj = {
                        id: stage.id,
                        title: stage.title
                    }
                    this.stages.push(obj);

                    if(this.stages && this.stages.length > 0){
                        this.nodeStageTitleFilter = this.stages[0].title.toString();
                        this.selectedStage = this.stages[0].title;
                    }
                });
                this.getNodeTasks();
            }else{
                this.stages = [];
                this.getNodeTasks();
            }
        });

    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }
    reloadPage(): void {
        this.skip_count=0;
        this.tableData=[];
        this.getNodeTasks();
    }

    createNodeTask(): void {
        this._router.navigate(['/app/admin/nodeTasks/nodeTasks/createOrEdit']);
    }

    showHistory(nodeTask: NodeTaskDto): void {
        this.entityTypeHistoryModal.show({
            entityId: nodeTask.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteNodeTask(nodeTask: NodeTaskDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._nodeTasksServiceProxy.delete(nodeTask.id).subscribe(() => {
                    this.reloadPage();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }
}
