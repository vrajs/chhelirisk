import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PromptsAndAlertPreviewComponent } from './prompts-and-alert-preview.component';

describe('PromptsAndAlertPreviewComponent', () => {
  let component: PromptsAndAlertPreviewComponent;
  let fixture: ComponentFixture<PromptsAndAlertPreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PromptsAndAlertPreviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PromptsAndAlertPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
