import { Component, EventEmitter, Injector, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { AppConsts } from '@shared/AppConsts';
import { AppComponentBase } from '@shared/common/app-component-base';
import { NotificationTemplateServiceProxy } from '@shared/service-proxies/service-proxies';
import { ModalDirective } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-prompts-and-alert-preview',
  templateUrl: './prompts-and-alert-preview.component.html',
  styleUrls: ['./prompts-and-alert-preview.component.scss']
})
export class PromptsAndAlertPreviewComponent extends AppComponentBase implements OnInit,OnChanges {
  @Input() body : string = '';
  @Input() subject : string = '';
  tenantId: any;

  appBaseURL: string = AppConsts.appBaseUrl;
  tenantTemplate: any = '';
  senitizedTemplate:any;

  constructor(injector: Injector,private notificationTemplateService: NotificationTemplateServiceProxy,private sanitizer: DomSanitizer){
    super(injector)
  }

  ngOnInit(){
    if(this.appSession.tenant && this.appSession.tenant.id){
      this.tenantId = this.appSession.tenant.id;
      this.getTenantTemplate();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    // if(changes && changes.body){
    //   if(this.tenantTemplate && this.tenantTemplate.indexOf('{EMAIL_BODY}') > -1){
    //     this.tenantTemplate = this.tenantTemplate.replace('{EMAIL_BODY}',changes.body.currentValue);
    //   }
    //   if(this.tenantTemplate && this.tenantTemplate.indexOf('##HTMLBODY##') > -1){
    //     this.tenantTemplate = this.tenantTemplate.replace('##HTMLBODY##',changes.body.currentValue);
    //   }
    // }else if(changes && changes.subject){
    //   if(this.tenantTemplate && this.tenantTemplate.indexOf('{EMAIL_TITLE}') > -1){
    //     this.tenantTemplate = this.tenantTemplate.replace('{EMAIL_TITLE}',changes.subject.currentValue);
    //   }
    //   if(this.tenantTemplate && this.tenantTemplate.indexOf('##SUBJECT##') > -1){
    //     this.tenantTemplate = this.tenantTemplate.replace('##SUBJECT##',changes.subject.currentValue);
    //   }
    // }

    this.senitizedTemplate = this.getSenitizedHTML();
  }

  getTenantTemplate(){
    this.notificationTemplateService.getTemplateForSpecificTenant(this.tenantId).subscribe((result:any)=>{
      if(result && result.emailBody){
        this.tenantTemplate = result.emailBody;
        this.senitizedTemplate = this.getSenitizedHTML();
      }
    })
  }

  getSenitizedHTML(){
    return this.senitizedTemplate = this.sanitizer.bypassSecurityTrustHtml(this.tenantTemplate);
  }
}
