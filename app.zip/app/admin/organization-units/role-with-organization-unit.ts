export interface IRoleWithOrganizationUnit {
    roleId: number;
    ouId: number;
}
