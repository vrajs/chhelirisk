export interface IUsersWithOrganizationUnit {
    userIds: number[];
    ouId: number;
}
