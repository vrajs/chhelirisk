﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { ProjectTypesServiceProxy, CreateOrEditProjectTypeDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    selector: 'createOrEditProjectTypeModal',
    templateUrl: './create-or-edit-projectType-modal.component.html',
})
export class CreateOrEditProjectTypeModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    projectType: CreateOrEditProjectTypeDto = new CreateOrEditProjectTypeDto();

    constructor(
        injector: Injector,
        private _projectTypesServiceProxy: ProjectTypesServiceProxy,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    show(projectTypeId?: string): void {
        if (!projectTypeId) {
            this.projectType = new CreateOrEditProjectTypeDto();
            this.projectType.id = projectTypeId;

            this.active = true;
            this.modal.show();
        } else {
            this._projectTypesServiceProxy.getProjectTypeForEdit(projectTypeId).subscribe((result) => {
                this.projectType = result.projectType;

                this.active = true;
                this.modal.show();
            });
        }
    }

    save(): void {
        this.saving = true;

        this._projectTypesServiceProxy
            .createOrEdit(this.projectType)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
            });
    }
    close(): void {
        this.modalSave.emit(null);

        this.active = false;
        this.modal.hide();
    }

    ngOnInit(): void {}
}
