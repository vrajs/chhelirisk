﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';
import {ProjectTypeRoutingModule} from './projectType-routing.module';
import {ProjectTypesComponent} from './projectTypes.component';
import {CreateOrEditProjectTypeModalComponent} from './create-or-edit-projectType-modal.component';
import {ViewProjectTypeModalComponent} from './view-projectType-modal.component';



@NgModule({
    declarations: [
        ProjectTypesComponent,
        CreateOrEditProjectTypeModalComponent,
        ViewProjectTypeModalComponent,
        
    ],
    imports: [AppSharedModule, ProjectTypeRoutingModule , AdminSharedModule ],
    
})
export class ProjectTypeModule {
}
