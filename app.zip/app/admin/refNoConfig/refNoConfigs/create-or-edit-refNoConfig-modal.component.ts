﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ViewEncapsulation, Input, DoCheck, AfterViewInit } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import {
  RefNoConfigOrganizationUnitLookupTableDto,
  CreateOrEditRefNoConfigDetailsDto
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';

import { GridComponent, IEditCell, RowDDService, SelectionService } from '@syncfusion/ej2-angular-grids';

import { EditSettingsModel } from '@syncfusion/ej2-angular-grids';
import { Query, DataManager } from '@syncfusion/ej2-data';
import {
  EditService,
  ToolbarService,
  PageService
} from '@syncfusion/ej2-angular-grids';
import { DropDownList } from '@syncfusion/ej2-angular-dropdowns';

import { DataUtil } from "@syncfusion/ej2-data";
import { TextBox } from '@syncfusion/ej2-angular-inputs';

@Component({
  selector: 'createOrEditRefNoConfigModal',
  templateUrl: './create-or-edit-refNoConfig-modal.component.html',
  providers: [RowDDService,
    SelectionService,
    ToolbarService, EditService, PageService],
  encapsulation: ViewEncapsulation.Emulated
})
export class CreateOrEditRefNoConfigModalComponent extends AppComponentBase implements OnInit, DoCheck {
  @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
  @ViewChild('qrngridRefNoConfig') public qrngridRefNoConfig: GridComponent;

  @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();
  @Input() records: CreateOrEditRefNoConfigDetailsDto[];
  @Input() isRefNumGrid: boolean;

  saving = false;
  defaultRN = '';
  public editSettings: EditSettingsModel;
  public toolbar: any;
  public valueTypeParams: object;
  public selectOptions: Object;

  organizationUnitDisplayName = '';

  allOrganizationUnits: RefNoConfigOrganizationUnitLookupTableDto[];
  localRecords: CreateOrEditRefNoConfigDetailsDto[];
  valueTypeRules: object = { required: true };
  prefixRules: object;

  constructor(
    injector: Injector) {
    super(injector);
  }

  index = 0;
  previewRefConfig = '';
  changed = false;
  mode= '';

  public startingElem: HTMLElement;
  public startingText: TextBox;
  public startingEditParams: IEditCell;

  public valueElem: HTMLElement;
  public valueText: TextBox;
  public valueEditParams: IEditCell;

  public minDigitsElem: HTMLElement;
  public minDigitsText: TextBox;
  public minDigitsParams: IEditCell;
  
  rowDrop(args) {
    this.changed = true;
    args.cancel = true;
    var value = [];
    for (var r = 0; r < args.rows.length; r++) {
      value.push(args.fromIndex + r);
    }
    this.qrngridRefNoConfig.reorderRows(value, args.dropIndex);
  }

  qrnActionBegin(args: any): void {
    this.changed = true;
    if (args.requestType === 'add') {
      args.data['refType'] = this.defaultRN;
      this.index = this.records.length;
    }
    if (args.requestType === "beginEdit") {
      this.index = args.rowIndex;
      this.mode = args.requestType;
    }
    if (args.requestType === 'delete') {
    }
    if (args.requestType === 'save') {
      if (this.qrngridRefNoConfig.editSettings.newRowPosition === 'Bottom') {
        args.index = this.index;
      }
    }
  }

  ngDoCheck() {
    if (this.changed) {
      this.previewNumGenerator();
    }
    this.changed = false;
  }

  previewNumGenerator() {
    this.previewRefConfig = '';
    this.records.forEach((item, index) => {
      if (item.valueType === 'String') {
        this.previewRefConfig = this.previewRefConfig + item.prefix;
      }
      else if (item.valueType === 'Year' && item.startingFrom != null) {
        this.previewRefConfig = this.previewRefConfig + item.startingFrom;
      }
      else if (item.valueType === 'Number') {
        if (item.startingFrom != null || item.minDigits != null || item.minDigits != 0){
          this.previewRefConfig = this.previewRefConfig + String(item.startingFrom).padStart(item.minDigits, '0');
        }
      }
    })
  }

  ngOnInit(): void {

    this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
    this.valueTypeParams = {
      params: {
        allowFiltering: true,
        dataSource: new DataManager(this.genums.refNoValueTypesDDL),
        fields: { text: 'title', value: 'title' },
        query: new Query(),
        actionComplete: (e) => {
          if (this.mode === "beginEdit"){
            if (this.records[this.index].valueType === 'String'){
              this.startingText.enabled = false;
              this.minDigitsText.enabled = false;
              this.valueText.enabled = true;
            }
            else if (this.records[this.index].valueType === 'Number'){
              this.valueText.enabled = false;
              this.startingText.enabled = true;
              this.minDigitsText.enabled = true;
            }
            else if (this.records[this.index].valueType === 'Year'){
              this.valueText.enabled = false;
              this.minDigitsText.enabled = false;
              this.startingText.enabled = true;
            }
          }
        },
        read: () => {
          console.log('red')
          return this.genums.refNoValueTypesDDL;
        },
        change: (e) => {
          if (e.value === 'String'){
            this.startingText.enabled = false;
            this.minDigitsText.enabled = false;
            this.valueText.enabled = true;
          }
          else if (e.value === 'Number'){
            this.valueText.enabled = false;
            this.startingText.enabled = true;
            this.minDigitsText.enabled = true;
          }
          else if (e.value === 'Year'){
            this.valueText.enabled = false;
            this.minDigitsText.enabled = false;
            this.startingText.enabled = true;
          }
        }
      }
    };
    this.startingEditParams = {
      create: () => {
        this.startingElem = document.createElement('input');
        return this.startingElem;
      },
      write: args => {
        this.startingText = new TextBox({
          
        });
        this.startingText.appendTo(this.startingElem);
      }
    };
    this.valueEditParams = {
      create: () => {
        this.valueElem = document.createElement('input');
        return this.valueElem;
      },
      write: args => {
        this.valueText = new TextBox({
          
        });
        this.valueText.appendTo(this.valueElem);
      }
    };
    this.minDigitsParams = {
      create: () => {
        this.minDigitsElem = document.createElement('input');
        return this.minDigitsElem;
      },
      write: args => {
        this.minDigitsText = new TextBox({
          
        });
        this.minDigitsText.appendTo(this.minDigitsElem);
      }
    };
    this.localRecords = this.records;
    this.selectOptions = { type: 'Single' };
    this.prefixRules = { required: [this.customFn, 'Need atleast 5 letters'] };
    this.defaultRN = this.isRefNumGrid ? this.genums.refNoTypes.QRN.code : this.genums.refNoTypes.JRN.code;
    this.editSettings = {
      allowEditing: true,
      allowAdding: true,
      allowDeleting: true,
      newRowPosition: 'Bottom'
    };
    this.previewNumGenerator();
    
  }

  chngValueType(event: any): void {
  }

  public customFn(args) {
  }
}
