﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    RefNoConfigsServiceProxy,
    CreateOrEditRefNoConfigDto,
    RefNoConfigOrganizationUnitLookupTableDto,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';
import { ActivatedRoute, Router } from '@angular/router';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Observable } from '@node_modules/rxjs';
import { BreadcrumbItem } from '@app/shared/common/sub-header/sub-header.component';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    templateUrl: './create-or-edit-refNoConfig.component.html',
    animations: [appModuleAnimation()],
})
export class CreateOrEditRefNoConfigComponent extends AppComponentBase implements OnInit {
    active = false;
    saving = false;

    refNoConfig: CreateOrEditRefNoConfigDto = new CreateOrEditRefNoConfigDto();

    organizationUnitDisplayName = '';

    allOrganizationUnits: RefNoConfigOrganizationUnitLookupTableDto[];

    breadcrumbs: BreadcrumbItem[] = [
        new BreadcrumbItem(this.l('RefNoConfig'), '/app/admin/refNoConfig/refNoConfigs'),
        new BreadcrumbItem(this.l('Entity_Name_Plural_Here') + '' + this.l('Details')),
    ];

    constructor(
        injector: Injector,
        private _activatedRoute: ActivatedRoute,
        private _refNoConfigsServiceProxy: RefNoConfigsServiceProxy,
        private _router: Router,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.show(this._activatedRoute.snapshot.queryParams['id']);
    }

    show(refNoConfigId?: number): void {
        if (!refNoConfigId) {
            this.refNoConfig = new CreateOrEditRefNoConfigDto();
            this.refNoConfig.id = refNoConfigId;
            this.organizationUnitDisplayName = '';

            this.active = true;
        } else {
            this._refNoConfigsServiceProxy.getRefNoConfigForEdit(refNoConfigId).subscribe((result) => {
                this.refNoConfig = result.refNoConfig;

                this.organizationUnitDisplayName = result.organizationUnitDisplayName;

                this.active = true;
            });
        }
        this._refNoConfigsServiceProxy.getAllOrganizationUnitForTableDropdown().subscribe((result) => {
            this.allOrganizationUnits = result;
        });
    }

    save(): void {
        this.saving = true;

        this._refNoConfigsServiceProxy
            .createOrEdit(this.refNoConfig)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe((x) => {
                this.saving = false;
                this.notify.info(this.l('SavedSuccessfully'));
                this._router.navigate(['/app/admin/refNoConfig/refNoConfigs']);
            });
    }

    saveAndNew(): void {
        this.saving = true;

        this._refNoConfigsServiceProxy
            .createOrEdit(this.refNoConfig)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe((x) => {
                this.saving = false;
                this.notify.info(this.l('SavedSuccessfully'));
                this.refNoConfig = new CreateOrEditRefNoConfigDto();
            });
    }
}
