import { Component, ViewChild, Injector } from "@angular/core";
import { AppComponentBase } from "@shared/common/app-component-base";

import { appModuleAnimation } from '@shared/animations/routerTransition';
import { RefNoConfigsComponent } from './refNoConfigs-Parent.component';
import {  ProjectTypeDto, UtilsServiceProxy } from '@shared/service-proxies/service-proxies';

@Component({
    templateUrl: './refConfigs.component.html',
    animations: [appModuleAnimation()],
})


export class RefNoConfigTab extends AppComponentBase {
    @ViewChild('refNoConfigsParentView', { static: true })
    refNoConfigsParentView: RefNoConfigsComponent;
    projectTypes: ProjectTypeDto[] ;

    constructor(
        injector: Injector,
        private _utilsServiceProxy: UtilsServiceProxy
    ) {
        super(injector);
    }
    ngOnInit(): void {
        this._utilsServiceProxy.getAllProjectTypes().subscribe((result) => {
            this.projectTypes = result;
        });
    }
};