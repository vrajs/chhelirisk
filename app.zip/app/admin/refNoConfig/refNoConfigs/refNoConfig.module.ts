﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { RefNoConfigRoutingModule } from './refNoConfig-routing.module';
import { RefNoConfigsComponent } from './refNoConfigs-Parent.component';
import { CreateOrEditRefNoConfigModalComponent } from './create-or-edit-refNoConfig-modal.component';
import { ViewRefNoConfigModalComponent } from './view-refNoConfig-modal.component';

import { GridModule, EditService, ToolbarService, SortService, PageService } from '@syncfusion/ej2-angular-grids';


import { CheckBoxModule } from '@syncfusion/ej2-angular-buttons';

import { DropDownListAllModule } from '@syncfusion/ej2-angular-dropdowns';

import { DatePickerAllModule } from '@syncfusion/ej2-angular-calendars';

import { ToolbarModule } from '@syncfusion/ej2-angular-navigations';

import { NumericTextBoxAllModule } from '@syncfusion/ej2-angular-inputs';

import { DialogModule } from '@syncfusion/ej2-angular-popups';

import { GridAllModule } from '@syncfusion/ej2-angular-grids';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { RefNoConfigTab } from './refConfigs.component';

@NgModule({
    declarations: [RefNoConfigsComponent, CreateOrEditRefNoConfigModalComponent, ViewRefNoConfigModalComponent, RefNoConfigTab],
    imports: [
        AppSharedModule,
        RefNoConfigRoutingModule,
        AdminSharedModule,
        GridModule,
        CommonModule, ToolbarModule, GridAllModule, NumericTextBoxAllModule, DialogModule, DatePickerAllModule, DropDownListAllModule, ReactiveFormsModule, FormsModule, CheckBoxModule
    ],
    providers: [EditService, ToolbarService, SortService, PageService]
})
export class RefNoConfigModule {}
