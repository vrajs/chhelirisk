﻿import { Component, Injector, ViewEncapsulation, ViewChild, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RefNoConfigsServiceProxy, RefNoConfigDto, CreateOrEditRefNoConfigDto, CreateOrEditRefNoConfigDetailsDto, RefNoConfigDetailsServiceProxy } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditRefNoConfigModalComponent } from './create-or-edit-refNoConfig-modal.component';
import { finalize } from 'rxjs/operators';

import { ViewRefNoConfigModalComponent } from './view-refNoConfig-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';



@Component({
    selector: 'refNoConfigsParentView',
    templateUrl: './refNoConfigs-Parent.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})


export class RefNoConfigsComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditRefNoConfigModal', { static: true })
    createOrEditRefNoConfigModal: CreateOrEditRefNoConfigModalComponent;
    @ViewChild('viewRefNoConfigModalComponent', { static: true }) viewRefNoConfigModal: ViewRefNoConfigModalComponent;

    @Input() projectType: '';

    _entityTypeFullName = 'asq.econsys.Eco.RefNoConfig.RefNoConfig';
    entityHistoryEnabled = false;

    constructor(
        injector: Injector,
        private _refNoConfigsServiceProxy: RefNoConfigsServiceProxy,
    ) {
        super(injector);
    }
    refNoConfig: CreateOrEditRefNoConfigDto = new CreateOrEditRefNoConfigDto();
    quoteNoConfigDetailsDto: CreateOrEditRefNoConfigDetailsDto[];
    jobNoConfigDetailsDto: CreateOrEditRefNoConfigDetailsDto[];
    initialData: CreateOrEditRefNoConfigDto = new CreateOrEditRefNoConfigDto();

    saving = false;
    ngOnInit(): void {
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        this.quoteNoConfigDetailsDto = [];
        this.jobNoConfigDetailsDto = [];
        this.refNoConfig.refNumberRecords = [];
        
        this.spinnerService.show();
        this._refNoConfigsServiceProxy
            .getTypeDetails(this.projectType)
            .pipe(
                finalize(() => {
                })
            )
            .subscribe((result) => {
                this.getConfig(result);
                this.spinnerService.hide();
            }, () => {
                this.spinnerService.hide();
            });
    }
    getConfig(result){
        this.initialData = result;
        this.refNoConfig = result;
        if (result.refNumberRecords && result.refNumberRecords.length > 0) {
            this.dataStore(this.initialData);
        }
    }
    private dataStore = (result: CreateOrEditRefNoConfigDto) => {
        for (let i = 0; i < result.refNumberRecords.length; i++) {     
            for (let j = i+1; j < result.refNumberRecords.length; j++) {     
               if(Number(result.refNumberRecords[i].displayOrder) > Number(result.refNumberRecords[j].displayOrder)) {    
                  let temp = result.refNumberRecords[i];    
                  result.refNumberRecords[i] = result.refNumberRecords[j];    
                  result.refNumberRecords[j] = temp;    
               }     
            }     
        }    
        for (let i = 0; i < result.refNumberRecords.length; i++) {
            if (result.refNumberRecords[i].refType === this.genums.refNoTypes.QRN.code) {
                this.quoteNoConfigDetailsDto.push(result.refNumberRecords[i]);
            } else if (result.refNumberRecords[i].refType === this.genums.refNoTypes.JRN.code){
                this.jobNoConfigDetailsDto.push(result.refNumberRecords[i]);
            }
        }
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }

    modelChangeFn(event){
    }
    close(): void {
        location.reload();
    }

    showHistory(refNoConfig: RefNoConfigDto): void {
        this.entityTypeHistoryModal.show({
            entityId: refNoConfig.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteRefNoConfig(refNoConfig: RefNoConfigDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._refNoConfigsServiceProxy.delete(refNoConfig.id).subscribe(() => {
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    save(): void {

        let records: CreateOrEditRefNoConfigDetailsDto[] = [];
        if (this.refNoConfig.jrnSameAsQuoteNo) {
            this.jobNoConfigDetailsDto = [];
        }
        else if (!this.refNoConfig.jrnAutoGenerate && !this.refNoConfig.jrnSameAsQuoteNo){
            this.jobNoConfigDetailsDto = [];
        }
        else if (!this.refNoConfig.qrnAutoGenerate){
            this.quoteNoConfigDetailsDto = [];
        }
        records = records.concat(this.quoteNoConfigDetailsDto, this.jobNoConfigDetailsDto);

        if(this.refNoConfig.refNumberRecords == undefined || this.refNoConfig.refNumberRecords.length == 0) {
            this.refNoConfig.refNumberRecords = [];
        }

        if (records != null && records.length > 0) {
        this.refNoConfig.projectType = this.projectType;
        this.refNoConfig.refNumberRecords = [];
            records.forEach((element, index) => {
                let dobj: CreateOrEditRefNoConfigDetailsDto = new CreateOrEditRefNoConfigDetailsDto();
                element.minDigits = element.minDigits == null ? 0 : element.minDigits;
                element.startingFrom = element.startingFrom == null ? 0 : element.startingFrom;
                element.projectType = this.projectType;

                Object.assign(dobj, element);
                
                if(!this.refNoConfig.refNumberRecords.hasOwnProperty(index)) {
                    this.refNoConfig.refNumberRecords.push(dobj)
                } else {
                    this.refNoConfig.refNumberRecords[index] = dobj;
                }
            });
        }

        this.spinnerService.show();
        this._refNoConfigsServiceProxy
            .createOrEdit(this.refNoConfig)
            .pipe(
                finalize(() => {
                })
            )
            .subscribe((result) => {
                this.getConfig(result);
                this.spinnerService.hide();
                this.notify.info(this.l('SavedSuccessfully'));
            }, () => {
                this.spinnerService.hide();
            });

    }
}
