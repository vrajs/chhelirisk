﻿import { AppConsts } from '@shared/AppConsts';
import { Component, ViewChild, Injector, Output, EventEmitter, OnInit } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import {
    RefNoConfigsServiceProxy,
    GetRefNoConfigForViewDto,
    RefNoConfigDto,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { ActivatedRoute } from '@angular/router';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { BreadcrumbItem } from '@app/shared/common/sub-header/sub-header.component';
@Component({
    templateUrl: './view-refNoConfig.component.html',
    animations: [appModuleAnimation()],
})
export class ViewRefNoConfigComponent extends AppComponentBase implements OnInit {
    active = false;
    saving = false;

    item: GetRefNoConfigForViewDto;

    breadcrumbs: BreadcrumbItem[] = [
        new BreadcrumbItem(this.l('RefNoConfig'), '/app/admin/refNoConfig/refNoConfigs'),
        new BreadcrumbItem(this.l('RefNoConfigs') + '' + this.l('Details')),
    ];
    constructor(
        injector: Injector,
        private _activatedRoute: ActivatedRoute,
        private _refNoConfigsServiceProxy: RefNoConfigsServiceProxy
    ) {
        super(injector);
        this.item = new GetRefNoConfigForViewDto();
        this.item.refNoConfig = new RefNoConfigDto();
    }

    ngOnInit(): void {
        this.show(this._activatedRoute.snapshot.queryParams['id']);
    }

    show(refNoConfigId: number): void {
        this._refNoConfigsServiceProxy.getRefNoConfigForView(refNoConfigId).subscribe((result) => {
            this.item = result;
            this.active = true;
        });
    }
}
