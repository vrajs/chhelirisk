import {
    Component,
    ElementRef,
    EventEmitter,
    Injector,
    Input,
    OnInit,
    Output,
    ViewChild,
    forwardRef,
} from '@angular/core';
import { AppComponentBase } from '@shared/common/app-component-base';
import { SettingScopes, NameValueDto } from '@shared/service-proxies/service-proxies';
import { ControlValueAccessor, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'currency-combo',
    template: `
        <div class="form-group">
            <label for="currency">{{ 'Currency' | localize }}</label>
            <input
                type="text"
                [formControl]="selectedCurrency"
                name="currency"
                id="currency"
                class="form-control"
                [ngClass]="{ edited: settings.currency.currency }"
                [(ngModel)]="settings.currency.currency"
                maxlength="3"
            />
        </div>
        <div class="form-group">
            <label for="currency">{{ 'Currency Symbol' | localize }}</label>
            <input
                type="text"
                [formControl]="selectedCurrencySign"
                name="currencySign"
                id="currencySign"
                class="form-control"
                [ngClass]="{ edited: settings.currency.currencySign }"
                [(ngModel)]="settings.currency.currencySign"
                maxlength="10"
            />
        </div>
    `,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => CurrencyComboComponent),
            multi: true,
        },
    ],
})
export class CurrencyComboComponent extends AppComponentBase implements OnInit, ControlValueAccessor {
    @Input() defaultCurrencyScope: SettingScopes;
    @Input() settings;

    selectedCurrency = new FormControl('');
    selectedCurrencySign = new FormControl('');

    onTouched: any = () => {};

    constructor(injector: Injector) {
        super(injector);
    }

    ngOnInit(): void {
        let self = this;
    }

    writeValue(obj: any): void {
        if (this.selectedCurrency) {
            this.selectedCurrency.setValue(obj);
        }
        if (this.selectedCurrencySign) {
            this.selectedCurrencySign.setValue(obj);
        }
    }

    registerOnChange(fn: any): void {
        this.selectedCurrency.valueChanges.subscribe(fn);
    }

    registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    setDisabledState?(isDisabled: boolean): void {
        if (isDisabled) {
            this.selectedCurrency.disable();
        } else {
            this.selectedCurrency.enable();
        }
    }
}
