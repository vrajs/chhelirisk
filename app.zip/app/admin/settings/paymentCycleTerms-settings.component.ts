import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { EconsysSettings } from '@shared/AppEnums';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TenantSettingsEditDto } from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'paymentCyleTermsComponent',
    templateUrl: './paymentCycleTerms-settings.html',
    animations: [appModuleAnimation()],
    encapsulation: ViewEncapsulation.None,
})
export class PaymentCycleTerms extends AppComponentBase {
    @Input() settings: TenantSettingsEditDto;
    submitdates: object[];
    validTodates: object[];
    invoiceOnSubmit: object[];

    ngOnInit(): void {
        this.submitdates = EconsysSettings.dates.slice(0,-1);
        this.validTodates = EconsysSettings.dates;
        this.invoiceOnSubmit = EconsysSettings.invoice;
    }
}