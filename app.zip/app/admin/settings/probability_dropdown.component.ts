import { Component, Input, ViewEncapsulation, ViewChild, Output, EventEmitter, OnInit } from '@angular/core';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TenantSettingsEditDto } from '@shared/service-proxies/service-proxies';
import { RuleModel } from '@syncfusion/ej2-angular-querybuilder';
import { ModalDirective } from 'ngx-bootstrap/modal';

@Component({
    selector: 'probabilityDropdown',
    templateUrl: './probability_dropdown.component.html',
    animations: [appModuleAnimation()],
    encapsulation: ViewEncapsulation.None,
})
export class ProbabilityDropDownComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @Input() projectType: string;
    @Input() settings;
    @Input() id: number;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();
    @Output() toggleModal: EventEmitter<any> = new EventEmitter<any>();
    
    active = false;
    saving = false;
    probabilityListValue;
    public importRules: RuleModel;
    public customOperators: any;
    public customValues: any;
    
    close(): void {
        this.modalSave.emit(null);
        this.active = false;
        this.modal.hide();
    }

    save() {
        this.modalSave.emit(this.probabilityListValue);
        // this.settings.winProbabilitySettings[this.projectType].probabilityList.push(this.probabilityListValue);
        this.active = false;
        this.modal.hide();
    }

    show(): void {
        if (this.id == null){
            // this.probabilityListValue = new ProbabilityListEditDto();
            this.probabilityListValue = {
                key: null,
                value: null,
                rule: null
            }
            this.probabilityListValue.key = null;
            this.probabilityListValue.value = null;
            this.probabilityListValue.rule = null;
        }
        else {
            this.probabilityListValue = this.settings.winProbabilitySettings[this.projectType].probabilityList[this.id];
        }
        this.active = true;
        this.modal.show();
    }

    ruleChange(e){
        console.log('e',e)
    }
    ngOnInit(): void {
        this.show();
        this.importRules = {
        'condition': 'and',
        'rules': [{
                'label': 'Closure of Project(Internal)',
                'field': 'ClosureofProject(Internal)',
                'type': 'string',
                'operator': 'equal',
                'value': 'Yes'
            },
            ]
        };
        this.customOperators = [
            {value: 'equal', key: 'Equal'},
            {value: 'notequal', key: 'Not Equal'}
        ];
        this.customValues = ['Yes', 'No']
    }
}