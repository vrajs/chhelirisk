import { Component, EventEmitter, Injector, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { EconsysSettings } from '@shared/AppEnums';
import { AppComponentBase } from '@shared/common/app-component-base';
import { ProjectExReviewDetailsServiceProxy, TenantSettingsEditDto } from '@shared/service-proxies/service-proxies';
import { finalize } from 'rxjs/operators';

@Component({
    selector: 'reportGenerationIntervalComponent',
    templateUrl: './reportGeneration-settings.html',
    animations: [appModuleAnimation()],
    encapsulation: ViewEncapsulation.None,
})
export class ReportGenerationInterval extends AppComponentBase {
    @Input() settings: TenantSettingsEditDto;
    @Input() projectId?: any;
    @Input() projectExReviewDetailId?: any;
    @Input() typeReview: string;

    dates: object[];
    weekdays: string[];
    months: object[];
    recur: string[];
    dateRecurrance = true;
    dayRecurrance = false;
    monthsDisable: boolean
    weekDisable:boolean
    @Input() readonlyGrid?: string;
    constructor(
        injector: Injector,

        private _projectExReviewDetailsServiceProxy: ProjectExReviewDetailsServiceProxy,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.dates = EconsysSettings.dates.slice(0,-1);
        this.dates.push({date: '31', value: '31'});
        this.weekdays = EconsysSettings.weekdays;
        this.months = EconsysSettings.dates.slice(0,12);
        this.recur = EconsysSettings.recurrance;
        this.settings.reportGenIntervalSettings.projectId = this.projectId;
        this.settings.reportGenIntervalSettings.projectExReviewDetailId = this.projectExReviewDetailId;
        this.getAll();
    }

    onReportChange(period): void {
        const self = this;
        if (period === 'weekly') {
            self.settings.reportGenIntervalSettings.monthly = false;
            self.settings.reportGenIntervalSettings.weekly = true;
            self.settings.reportGenIntervalSettings.recurDate = 0;
            self.settings.reportGenIntervalSettings.recurDateMonthly = 0;
            self.settings.reportGenIntervalSettings.recurDaySeq = null;
            self.settings.reportGenIntervalSettings.recurDay = null;
            self.settings.reportGenIntervalSettings.recurDayMonthly = 0;
            
        } else if (period === 'monthly') {
            self.settings.reportGenIntervalSettings.weekly = false;
            self.settings.reportGenIntervalSettings.monthly = true;
            self.settings.reportGenIntervalSettings.recurWeekly = 0;
            self.settings.reportGenIntervalSettings.recurWeeklyDay = null;
        } else if (period === 'recurDate') {
            self.settings.reportGenIntervalSettings.dateRecurrance = true;
            self.settings.reportGenIntervalSettings.dayRecurrance = false;
            self.settings.reportGenIntervalSettings.recurDaySeq = null;
            self.settings.reportGenIntervalSettings.recurDay = null;
            self.settings.reportGenIntervalSettings.recurDayMonthly = 0;

            this.weekDisable = true;
            this.monthsDisable = false
        } else if (period === 'recurDay') {
            self.settings.reportGenIntervalSettings.dateRecurrance = false;
            self.settings.reportGenIntervalSettings.dayRecurrance = true;
            self.settings.reportGenIntervalSettings.recurDate = 0;
            self.settings.reportGenIntervalSettings.recurDateMonthly = 0;
            this.weekDisable = false;
            this.monthsDisable = true
        } 
    }
    
    toCamelCase(key, value) {
        if (value && typeof value === 'object') {
            for (var k in value) {
                if (/^[A-Z]/.test(k) && Object.hasOwnProperty.call(value, k)) {
                    value[k.charAt(0).toLowerCase() + k.substring(1)] = value[k];
                    delete value[k];
                }
            }
        }
        return value;
    }

    getAll() {
        this._projectExReviewDetailsServiceProxy
            .getReportSettingByExReviewId(this.projectExReviewDetailId, this.typeReview)
            .subscribe(
                (result) => {
                    if (result) {
                        this.settings.reportGenIntervalSettings = result;
                        if(!this.settings.reportGenIntervalSettings.monthly && !this.settings.reportGenIntervalSettings.monthly){
                            this.settings.reportGenIntervalSettings.monthly = true;
                            this.settings.reportGenIntervalSettings.dateRecurrance = true
                            this.weekDisable = true;
                            this.monthsDisable = false
                        }
                    }
                });
    }
}
