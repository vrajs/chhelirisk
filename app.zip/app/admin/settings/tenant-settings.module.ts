import { NgModule } from '@angular/core';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { TenantSettingsRoutingModule } from './tenant-settings-routing.module';
import { TenantSettingsComponent } from '@app/admin/settings/tenant-settings.component';
import { WinProbabilityModule } from './winProbability.component.module';
import { PaymentCycleTerms } from './paymentCycleTerms-settings.component';
import { ReportGenerationInterval } from './reportGeneration.component';
import { QueryBuilderModule } from '@syncfusion/ej2-angular-querybuilder';
import { WorkflowSettingsModule } from './workflow-settings.module';
import { CurrencyComboComponent } from './currency/currency-combo.component';

@NgModule({
    declarations: [TenantSettingsComponent, PaymentCycleTerms, ReportGenerationInterval, CurrencyComboComponent],
    imports: [AppSharedModule, AdminSharedModule, TenantSettingsRoutingModule, QueryBuilderModule, WinProbabilityModule, WorkflowSettingsModule],
    exports:[ReportGenerationInterval, CurrencyComboComponent]
})
export class TenantSettingsModule {}
