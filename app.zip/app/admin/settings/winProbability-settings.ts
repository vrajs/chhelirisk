import { Component, Input, ViewEncapsulation, Injector, ViewChild, OnInit } from '@angular/core';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { AppComponentBase } from '@shared/common/app-component-base';
import {  ProjectTypeDto, TenantSettingsEditDto, UtilsServiceProxy } from '@shared/service-proxies/service-proxies';
import { GridComponent } from '@syncfusion/ej2-angular-grids';
import { AppConsts } from '@shared/AppConsts';

import {
    EditSettingsModel,
    CommandModel,
    PageSettingsModel,
    InfiniteScrollSettingsModel,
    ToolbarItems,
} from '@syncfusion/ej2-grids';
import { ProbabilityDropDownComponent } from './probability_dropdown.component';

@Component({
    selector: 'winProbabilityComponent',
    templateUrl: './winProbability-settings.html',
    animations: [appModuleAnimation()],
    encapsulation: ViewEncapsulation.None,
})
export class WinProbabilityComponent extends AppComponentBase implements OnInit {
    @Input() settings;

    @ViewChild('winProbabilityGrid') public winProbabilityGrid: GridComponent;
    @ViewChild('probabilityDropdown', { static: true })
    probabilityDropdown: ProbabilityDropDownComponent;
    // @ViewChild('probabilityDropdown') probabilityDropdown:ProbabilityDropDownComponent;
    public editSettings: EditSettingsModel;
    public commands: CommandModel[];
    public options: PageSettingsModel | undefined;
    public infiniteOptions: InfiniteScrollSettingsModel | undefined;
    pageSettings: any = { pageSizes: true, pageSize: 10, pageCount: 0, currentPage: 1 };
    public toolbarOptions: ToolbarItems[];
    createModal: boolean = false;
    projectType: string;
    id: number;

    projectTypes: ProjectTypeDto[] ;
    constructor(
        injector: Injector,
        private _utilsServiceProxy: UtilsServiceProxy
    ) {
        super(injector);
    }
    ngOnInit(): void {
        this._utilsServiceProxy.getAllProjectTypes().subscribe((result) => {
            this.projectTypes = result;
            if (this.settings.winProbabilitySettings == null || Object.keys(this.settings.winProbabilitySettings).length != this.projectTypes.length){
                let i = 0;
                this.settings.winProbabilitySettings = this.settings.winProbabilitySettings != null ? this.settings.winProbabilitySettings : {};
                i = this.settings.winProbabilitySettings != null ? Object.keys(this.settings.winProbabilitySettings).length : i;
                for (i; i< this.projectTypes.length; i++){
                    // let probabilitySettings: WinProbabilityEditDto = new WinProbabilityEditDto();
                    let probabilitySettings = {
                        dropDown: false,
                        showRules : false,
                        probabilityList : []
                    };
                    let probabilityList = [];
                    let projectType = this.projectTypes[i].code;
                    probabilitySettings.dropDown = false;
                    probabilitySettings.showRules = false;
                    probabilitySettings.probabilityList = [];
                    this.settings.winProbabilitySettings[projectType] = probabilitySettings;
                }
            }
            else {
                
            }
        });
        this.editSettings = { allowEditing: true, allowDeleting: true, showDeleteConfirmDialog: true, allowAdding: true };
        this.commands = [
            { type: 'Edit', buttonOption: { cssClass: 'e-flat', iconCss: 'e-edit e-icons' } },
            { type: 'Delete', buttonOption: { cssClass: 'e-flat', iconCss: 'e-delete e-icons' } },
            { type: 'Cancel', buttonOption: { cssClass: 'e-flat', iconCss: 'e-cancel-icon e-icons' } },
        ];
        this.toolbarOptions = ['Add'];
        this.pageSettings = {
            pageSizes: false,
            pageSize: AppConsts.grid.defaultPageSize,
            currentPage: 1,
        };
        this.options = { pageSize: 50 };
        this.infiniteOptions = {};
    }
    onActionBegin(args, type) {
        if (args.requestType === "beginEdit"){
            this.openModal(type);
            this.id = args.rowIndex;
        }
    }
    openModal(type) {
        this.id = null;
        this.projectType = type;
        this.toggleModal();
    }
    toggleModal(){
        this.createModal = !this.createModal;
    }
    showRules(rule){
        var gridColumns = this.winProbabilityGrid.columns;
        var gridColumnsLen = this.winProbabilityGrid.columns.length;
        var actionColumn = gridColumns[gridColumnsLen -1];
        if (rule){
            var obj = { field: "rule", headerText: 'Condition', width: 120 };
            gridColumns[gridColumnsLen - 1] = obj as any;
            gridColumns.push(actionColumn as any);
            this.winProbabilityGrid.columns = gridColumns;
        }
        else {
            gridColumns.length = 3;
            gridColumns[gridColumns.length -1] = actionColumn;
        }
        this.winProbabilityGrid.refresh();
        // this.winProbabilityGrid.refreshColumns();
    }
    modalSave(result){
        if (this.id == null){
            if (result != null){
            let dobj: object = new Object();
            result.key = result.key ? result.key : null;
            result.value = result.value ? result.value : null;
            result.rule = result.rule ? result.rule : null;

            Object.assign(dobj, result);
            this.settings.winProbabilitySettings[this.projectType].probabilityList.push(dobj);
            }
        }
        else {
            if (result != null){
                this.settings.winProbabilitySettings[this.projectType].probabilityList[this.id] = result;
                this.id = 0;
            }
        }
        this.toggleModal();
        this.winProbabilityGrid.refresh();
    }
}