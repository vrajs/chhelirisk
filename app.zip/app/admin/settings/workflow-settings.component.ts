import { Component, Input, ViewEncapsulation, Injector, ViewChild, OnInit } from '@angular/core';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { AppComponentBase } from '@shared/common/app-component-base';
import { ProjectTypeDto, TenantSettingsEditDto, UtilsServiceProxy } from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'workflowSettings',
    templateUrl: './workflow-settings.component.html',
    animations: [appModuleAnimation()],
    encapsulation: ViewEncapsulation.None,
})
export class WorkflowSettingsComponent extends AppComponentBase implements OnInit {
    @Input() settings;
    selectedProjectType: string;
    projectType: string;
    id: number;
    projectTypes: ProjectTypeDto[];

    constructor(injector: Injector, private _utilsServiceProxy: UtilsServiceProxy) {
        super(injector);
    }

    ngOnInit(): void {
        this.settings = this.settings;
        if(this.settings.workFlowSettings.prj != undefined && this.settings.workFlowSettings.prj != null && this.settings.workFlowSettings.prj != '') {
            try {
                this.settings.workFlowSettings.prj = JSON.stringify(this.utilsService.parseJson(this.settings.workFlowSettings.prj));
            } catch (error) {
                
            }
        }
        if(this.settings.workFlowSettings.swk != undefined && this.settings.workFlowSettings.swk != null && this.settings.workFlowSettings.swk != '') {
            try {
                this.settings.workFlowSettings.swk = JSON.stringify(this.utilsService.parseJson(this.settings.workFlowSettings.swk));
            } catch (error) {
                
            }
        }
        if(this.settings.workFlowSettings.ppm != undefined && this.settings.workFlowSettings.ppm != null && this.settings.workFlowSettings.ppm != '') {
            try {
                this.settings.workFlowSettings.ppm = JSON.stringify(this.utilsService.parseJson(this.settings.workFlowSettings.ppm));
            } catch (error) {
                
            }
        }
        if(this.settings.workFlowSettings.tandM != undefined && this.settings.workFlowSettings.tandM != null && this.settings.workFlowSettings.tandM != '') {
            try {
                this.settings.workFlowSettings.tandM = JSON.stringify(this.utilsService.parseJson(this.settings.workFlowSettings.tandM));
            } catch (error) {
                
            }
        }
        if(this.settings.workFlowSettings.call != undefined && this.settings.workFlowSettings.call != null && this.settings.workFlowSettings.call != '') {
            try {
                this.settings.workFlowSettings.call = JSON.stringify(this.utilsService.parseJson(this.settings.workFlowSettings.call));
            } catch (error) {
                
            }
        }
    }
}
