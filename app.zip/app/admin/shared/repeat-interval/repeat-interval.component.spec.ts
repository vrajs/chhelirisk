import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepeatIntervalComponent } from './repeat-interval.component';

describe('RepeatIntervalComponent', () => {
  let component: RepeatIntervalComponent;
  let fixture: ComponentFixture<RepeatIntervalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepeatIntervalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepeatIntervalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
