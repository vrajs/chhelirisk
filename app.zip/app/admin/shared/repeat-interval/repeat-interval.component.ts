import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { IntervalSettingsDto } from '@app/shared/layout/interval-settings/interval-setting-dto';
import { EconsysSettings } from '@shared/AppEnums';

@Component({
  selector: 'app-repeat-interval',
  templateUrl: './repeat-interval.component.html',
  styleUrls: ['./repeat-interval.component.scss']
})
export class RepeatIntervalComponent implements OnInit,OnChanges {

  constructor(private changeDetectorRef: ChangeDetectorRef){

  }

  @Input() intervalSettings: IntervalSettingsDto;
  @Input() dateRecurrance = true;
  @Input() dayRecurrance = false;
  @Output() dataIntervalChange : EventEmitter<any> = new EventEmitter<any>();

  public dateFields: Object = { text: "date", value: "value" };

  ngOnChanges(changes: SimpleChanges): void {
  }

  dates: object[];
  weekdays: string[];
  months: object[];
  recur: string[];
  
  ngOnInit(): void {
    this.dates = EconsysSettings.dates.slice(0, -1);
    this.dates.push({ date: '31', value: '31' });
    this.weekdays = EconsysSettings.weekdays;
    this.months = EconsysSettings.dates.slice(0, 12);
    this.recur = EconsysSettings.recurrance;
  }

  onDataIntervalChange(e, period:any): void {
    this.dataIntervalChange.emit(period);
  }
}

