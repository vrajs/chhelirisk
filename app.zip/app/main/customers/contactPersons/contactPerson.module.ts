﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';
import {ContactPersonRoutingModule} from './contactPerson-routing.module';
import {ContactPersonsComponent} from './contactPersons.component';
import {CreateOrEditContactPersonModalComponent} from './create-or-edit-contactPerson-modal.component';
import {ViewContactPersonModalComponent} from './view-contactPerson-modal.component';



@NgModule({
    declarations: [
        ContactPersonsComponent,
        CreateOrEditContactPersonModalComponent,
        ViewContactPersonModalComponent,
        
    ],
    imports: [AppSharedModule, ContactPersonRoutingModule , AdminSharedModule ],
    
})
export class ContactPersonModule {
}
