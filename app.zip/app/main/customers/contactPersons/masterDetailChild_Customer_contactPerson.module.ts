﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';

import {MasterDetailChild_Customer_ContactPersonsComponent} from './masterDetailChild_Customer_contactPersons.component';
import {MasterDetailChild_Customer_CreateOrEditContactPersonModalComponent} from './masterDetailChild_Customer_create-or-edit-contactPerson-modal.component';
import {MasterDetailChild_Customer_ViewContactPersonModalComponent} from './masterDetailChild_Customer_view-contactPerson-modal.component';



@NgModule({
    declarations: [
        MasterDetailChild_Customer_ContactPersonsComponent,
        MasterDetailChild_Customer_CreateOrEditContactPersonModalComponent,
        MasterDetailChild_Customer_ViewContactPersonModalComponent,
        
    ],
    imports: [AppSharedModule , AdminSharedModule ],
    
			    exports: [
                    MasterDetailChild_Customer_ContactPersonsComponent,
                    MasterDetailChild_Customer_CreateOrEditContactPersonModalComponent,
                    MasterDetailChild_Customer_ViewContactPersonModalComponent,
                ]
			
})
export class MasterDetailChild_Customer_ContactPersonModule {
}
