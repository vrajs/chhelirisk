﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef} from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { ContactPersonsServiceProxy, CreateOrEditContactPersonDto ,ContactPersonOrganizationUnitLookupTableDto
					} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

             import { DateTimeService } from '@app/shared/common/timing/date-time.service';



@Component({
    selector: 'masterDetailChild_Customer_createOrEditContactPersonModal',
    templateUrl: './masterDetailChild_Customer_create-or-edit-contactPerson-modal.component.html'
})
export class MasterDetailChild_Customer_CreateOrEditContactPersonModalComponent extends AppComponentBase implements OnInit{
   
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    contactPerson: CreateOrEditContactPersonDto = new CreateOrEditContactPersonDto();

    organizationUnitDisplayName = '';

	allOrganizationUnits: ContactPersonOrganizationUnitLookupTableDto[];
					

    constructor(
        injector: Injector,
        private _contactPersonsServiceProxy: ContactPersonsServiceProxy,
             private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }
    
                 customerId: any;
             
    show(
                 customerId: any,
             contactPersonId?: number): void {
    
                 this.customerId = customerId;
             

        if (!contactPersonId) {
            this.contactPerson = new CreateOrEditContactPersonDto();
            this.contactPerson.id = contactPersonId;
            this.organizationUnitDisplayName = '';


            this.active = true;
            this.modal.show();
        } else {
            this._contactPersonsServiceProxy.getContactPersonForEdit(contactPersonId).subscribe(result => {
                this.contactPerson = result.contactPerson;

                this.organizationUnitDisplayName = result.organizationUnitDisplayName;


                this.active = true;
                this.modal.show();
            });
        }
        this._contactPersonsServiceProxy.getAllOrganizationUnitForTableDropdown().subscribe(result => {						
						this.allOrganizationUnits = result;
					});
					
        
    }

    save(): void {
            this.saving = true;
            
			
			
                this.contactPerson.customerId = this.customerId;
            
            this._contactPersonsServiceProxy.createOrEdit(this.contactPerson)
             .pipe(finalize(() => { this.saving = false;}))
             .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
             });
    }













    close(): void {
        this.active = false;
        this.modal.hide();
    }
    
     ngOnInit(): void {
        
     }    
}
