﻿import {AppConsts} from "@shared/AppConsts";
import { Component, ViewChild, Injector, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { GetContactPersonForViewDto, ContactPersonDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';

@Component({
    selector: 'masterDetailChild_Customer_viewContactPersonModal',
    templateUrl: './masterDetailChild_Customer_view-contactPerson-modal.component.html'
})
export class MasterDetailChild_Customer_ViewContactPersonModalComponent extends AppComponentBase {

    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    item: GetContactPersonForViewDto;


    constructor(
        injector: Injector
    ) {
        super(injector);
        this.item = new GetContactPersonForViewDto();
        this.item.contactPerson = new ContactPersonDto();
    }

    show(item: GetContactPersonForViewDto): void {
        this.item = item;
        this.active = true;
        this.modal.show();
    }
    
    

    close(): void {
        this.active = false;
        this.modal.hide();
    }
}
