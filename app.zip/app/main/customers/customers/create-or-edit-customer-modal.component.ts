﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    CustomersServiceProxy,
    CreateOrEditCustomerDto,
    CustomerOrganizationUnitLookupTableDto,
    RuleFlagsServiceProxy,
    ContactPersonDto,
    ContactPersonsServiceProxy,
    CreateOrEditContactPersonDto,
    UtilsServiceProxy,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { FlexiFieldDto } from '@shared/service-proxies/service-proxies';
import {
    DataSourceChangedEventArgs,
    DataStateChangeEventArgs,
    EditSettingsModel,
    PageSettingsModel,
    ToolbarItems,
    IEditCell,
} from '@syncfusion/ej2-grids';
import { GridComponent } from '@syncfusion/ej2-angular-grids';
import { Query, DataManager } from '@syncfusion/ej2-data';
import { CountryISO, PhoneNumberFormat, SearchCountryField } from 'ngx-intl-tel-input';
import * as _ from 'lodash';
import countries from '@assets/data/countries.json';
import { CheckBox } from '@syncfusion/ej2-angular-buttons';
import { TextBoxComponent } from '@syncfusion/ej2-angular-inputs';

@Component({
    selector: 'createOrEditCustomerModal',
    templateUrl: './create-or-edit-customer-modal.component.html',
})
export class CreateOrEditCustomerModalComponent extends AppComponentBase implements OnInit, AfterViewInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();
    @ViewChild('rebateDetail', { static: true }) public rebateDetail: TextBoxComponent;

    active = false;
    saving = false;

    frmFG: FormGroup = this.fb.group({});
    customer: CreateOrEditCustomerDto = new CreateOrEditCustomerDto();
    flexiFields: any[] = [];
    organizationUnitDisplayName = '';
    allOrganizationUnits: CustomerOrganizationUnitLookupTableDto[];
    ruleFlags: any[] = [];
    colors: { [key: string]: string } = {};

    public nameRules: object;
    public emailRules: object;
    public phoneRules: object;
    public RoleRules: object;
    public editSettings: EditSettingsModel;
    public toolbar: ToolbarItems[];
    contacts: any = [];
    public initialPage: PageSettingsModel;
    public item: ContactPersonDto;
    editeditemindex: any;
    isEdit: any;
    isPrimaryEP: Object;
    isRebate: boolean = false;
    // isPrimary = false;
    // isPrimaryName: any;
    @ViewChild('grid') public grid: GridComponent;
    public createOrEditContactPersonDto: Array<CreateOrEditContactPersonDto> = [];

    separateDialCode = false;
    SearchCountryField = SearchCountryField;
    CountryISO = CountryISO;
    PhoneNumberFormat = PhoneNumberFormat;
    preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
    CountryCode: any;
    userCountry: any;
    ruleFlag;


    public elmIsPrimary: HTMLElement;
    public chbIsPrimary: CheckBox;
    public iecIsPrimary: IEditCell = {
        create: () => {
            this.elmIsPrimary = document.createElement('input');
            return this.elmIsPrimary;
        },
        destroy: () => {
            this.chbIsPrimary.destroy();
        },
        read: (args) => {
            return this.chbIsPrimary.checked;
        },
        write: (args: { rowData: any; column: any; row: any; cell: any }) => {
            this.chbIsPrimary = new CheckBox({
                value: args.rowData[args.column.field],
                change: (e) => {
                    let ipchecked = this.contacts.findIndex(
                        (x) =>
                            x.isPrimary == true &&
                            x.name != args.rowData.name &&
                            x.email != args.rowData.email &&
                            x.phone != args.rowData.phone
                    );
                    if (!e.checked && ipchecked === -1) {
                        this.notify.warn(this.l('At least one cantact must be set as primary.'));
                        e.checked = true;
                        args.rowData.isPrimary = true;
                        this.chbIsPrimary.checked = true;
                        e.event.preventDefault();
                        return false;
                    }
                    if (e.checked && ipchecked !== -1) {
                        this.notify.warn(this.l('This will release Is Primary flag from another contact in list.'));
                        args.rowData.isPrimary = true;
                        this.contacts.map(x => {
                            x.isPrimary = false;
                        });
                    }
                },
            });
            if (this.contacts.length == 0) {
                args.rowData[args.column.field] = true;
                this.chbIsPrimary.checked = true;
                this.grid.setRowData(args.row.rowIndex, args.rowData);
                // this.chbIsPrimary.dataBind();
            }
            this.chbIsPrimary.appendTo(this.elmIsPrimary);
        },
    };

    phoneEditTemp = {
        create: function () {
            return '<input>';
        },
        read: function (args) {
            return args.ejMaskEdit('get_UnstrippedValue');
        },
        write: function (args) {
            args.element.ejMaskEdit({
                maskFormat: '99-99-9999',
                value: args.rowdata['ShipPostalCode'],
            });
        },
    };

    constructor(
        injector: Injector,
        private _customersServiceProxy: CustomersServiceProxy,
        private _dateTimeService: DateTimeService,
        private _utilsServiceProxy: UtilsServiceProxy,
        private fb: FormBuilder,
        private _contactPersonsServiceProxy: ContactPersonsServiceProxy
    ) {
        super(injector);
    }

    show(id?: number): void {
        this.userCountry = null;

        var tz = abp.timing.timeZoneInfo.windows.timeZoneId;
        Object.entries(CountryISO).forEach((x) => {
            if (x[0] == tz.split(' ')[0] || x[0] == tz.split(' ')[0] + tz.split(' ')[1]) this.userCountry = x[1];
        });
        if (!this.userCountry) this.userCountry = 'gb';
        this.CountryCode = this.userCountry;

        this._utilsServiceProxy.getRuleFlags().subscribe((result) => {
            if (result && result.length > 0) {
                this.ruleFlags = result.map((x) => ({ ...x.ruleFlag }));
                result.forEach((element) => {
                    this.colors[element.ruleFlag.id] = element.ruleFlag.hexColor;
                });
            }
        });

        this.getFlexiFields().then((result) => {

            if (!id) {
                this.customer = new CreateOrEditCustomerDto();
                this.customer.id = id;
                this.customer.dateField1 = this._dateTimeService.getStartOfDay();
                this.customer.dateField2 = this._dateTimeService.getStartOfDay();
                this.customer.dateField3 = this._dateTimeService.getStartOfDay();
                this.customer.dateField4 = this._dateTimeService.getStartOfDay();
                this.customer.dateField5 = this._dateTimeService.getStartOfDay();

                //let ruleFlag = this.ruleFlags.filter((x) => x.id == 'App.Customer.NewCustomerFlag')[0];
                this.ruleFlag = this.setting.get('App.Customer.NewCustomerFlag');
                this.customer.ruleFlagId = this.ruleFlag == null ? null : this.ruleFlag;
                if (this.frmFG.controls['businessRule'] != undefined) {
                    this.frmFG.controls['businessRule'].setValue(this.customer.ruleFlagId);
                }

                this.organizationUnitDisplayName = '';
                // this.customer.isRebate = false;
                // this.frmFG.controls['isRebate'].setValue(false);
                this.onChangeRebate(false);
                this.contacts = [];
                this.active = true;
                this.modal.show();
            } else {
                this._customersServiceProxy.getCustomerForEdit(id).subscribe((result) => {
                    this.customer = result.customer;
                    let country = countries.find((x) => {
                        if (result.customer.phone && x.dial_code == result.customer.phone.split(' ')[0]) return x;
                        else return null;
                    });
                    if (country) this.CountryCode = country.code;
                    else this.CountryCode = this.userCountry;

                    this.isRebate = result.customer.isRebate;
                    Object.keys(this.frmFG.controls).forEach((formKey) => {
                        Object.entries(this.customer).find(([key, value]) => {
                            if (formKey.toLowerCase() == key.toLowerCase()) {
                                this.frmFG.controls[formKey].setValue(value);
                            }
                        });
                    });
                    if (this.frmFG.controls['businessRule'] != undefined) {
                        this.frmFG.controls['businessRule'].setValue(this.customer.ruleFlagId);
                    }

                    this.onChangeRebate(this.frmFG.controls['isRebate'].value);

                    this.flexiFields.forEach((element) => {
                        if (element.inputType == 'date' && this.customer[element.name] != null) {
                            this.frmFG.get(element.name).setValue(this.customer[element.name].toFormat('yyyy-MM-dd'));
                        }
                    });

                    if (this.customer != null) {
                        this._contactPersonsServiceProxy
                            .getCustomerContactPerson(this.customer.id)
                            .subscribe((response) => {
                                // response.forEach((x) => {
                                //     if (x.isPrimary) this.isPrimary = true;
                                // });
                                // this.contacts = [];
                                this.contacts = response;
                            });
                    }

                    this.organizationUnitDisplayName = result.organizationUnitDisplayName;

                    this.active = true;
                    this.modal.show();
                });
            }
        });
        this._customersServiceProxy.getAllOrganizationUnitForTableDropdown().subscribe((result) => {
            this.allOrganizationUnits = result;
        });
    }

    save(): void {
        if (!this.frmFG.valid) {
            abp.notify.error(this.l('Please enter proper inputs'));
            return;
        }

        this.frmFG.addControl('id', new FormControl(''));
        this.frmFG.controls['id'].setValue(this.customer.id);
        if (this.frmFG.value.isRebate == null) {
            this.frmFG.controls['isRebate'].setValue(false);
        }

        if (!this.frmFG.value.isRebate) this.frmFG.value.rebateDetail = null;

        let formData: CreateOrEditCustomerDto = new CreateOrEditCustomerDto(); // = this.frmFG.value;
        Object.assign(formData, this.frmFG.value);
        formData.ruleFlagId = this.frmFG.get('businessRule').value;
        formData.contactPersons = [];

        // let phone = this.frmFG.get('phone').value;
        // if (phone != null) {
        //     formData.phone = phone.internationalNumber;
        // }

        let hasIsPrimary: boolean = false;
        if (this.contacts != null && this.contacts.length > 0) {
            this.contacts.forEach((element, index) => {
                let dobj: CreateOrEditContactPersonDto = new CreateOrEditContactPersonDto();
                Object.assign(dobj, element);
                formData.contactPersons[index] = dobj;
                hasIsPrimary = hasIsPrimary || dobj.isPrimary ? true : false;
            });
        }

        if (formData.contactPersons && formData.contactPersons.length == 0) {
            this.message.warn(this.l('AddContact'));
            return;
        }
        if (!hasIsPrimary) {
            this.message.warn(this.l('Please make at least one contact primary.'));
            return;
        } else {
            this.spinnerService.show();
            this.saving = true;
            this._customersServiceProxy
                .createOrEdit(formData)
                .pipe(
                    finalize(() => {
                        this.saving = false;
                    })
                )
                .subscribe(
                    (result) => {
                        this.spinnerService.hide();
                        this.saving = false;

                        if (result) {
                            this.notify.success(this.l('SavedSuccessfully'));
                            this.close();
                            let action = formData.id == null ? 'create' : 'edit';
                            formData.id = result;
                            this.modalSave.emit({ id: result, data: formData, action: action });
                            this.frmFG.reset();
                        }
                    },
                    (e) => {
                        this.spinnerService.hide();
                        this.saving = false;
                    }
                );
        }
    }

    close(cancel: boolean = false): void {
        this.active = false;
        this.frmFG.reset();
        if (cancel) {
            this.modalSave.emit({ id: null, data: null, action: null });
        }
        this.modal.hide();
        this.CountryCode = this.userCountry;
    }

    ngOnInit(): void {
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' };
        this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel', 'Search'];
        this.nameRules = { required: true, minLength: 1 };
        this.emailRules = { required: true, email: true };
        this.phoneRules = { required: true };//, number: true };
        this.RoleRules = { required: true };
        // this.getFlexiFields();
    }

    ngAfterViewInit() {}

    getFlexiFields() {
        return new Promise((resolve, reject) => {
            this.spinnerService.show();
            this._utilsServiceProxy
                .getFlexiFieldsBySectionId('customer-information')
                .subscribe((result: FlexiFieldDto[]) => {
                    if (result != null && result.length > 0) {
                        this.frmFG = this.fb.group({});
                        this.flexiFields = result
                            .sort((a, b) => a.sortOrder - b.sortOrder)
                            .filter((x) => x.isEnabled == true)
                            .map((x) => ({
                                type: x.htmlType,
                                label: x.displayName,
                                headerText: x.displayName,
                                inputType: x.htmlInputType,
                                name: _.camelCase(x.code),
                                code: _.camelCase(x.code),
                                field: _.camelCase(x.code),
                                validations: x.validations,
                            }));

                        const group = this.fb.group({});
                        this.flexiFields.forEach((field) => {
                            if (field.type === 'button') return;
                            let validations = [];
                            if (field.validations != null) {
                                try {
                                    let vals = field.validations
                                        .substring(1, field.validations.length - 1)
                                        .replace(/(?:\\)+/g, '');
                                    validations = JSON.parse(vals);
                                    field.validations = validations;
                                } catch (error) { }
                            }
                            const control = this.fb.control(field.value, this.bindValidations(validations || []));
                            group.addControl(field.name, control);
                        });
                        this.frmFG = group;
                        this.spinnerService.hide();
                        resolve(true);
                    }
                    this.spinnerService.hide();
                    resolve(false);
                });
        });
    }

    bindValidations(validations: any) {
        if (validations.length > 0) {
            const validList = [];
            validations.forEach((valid) => {
                switch (valid.name) {
                    case 'required':
                        validList.push(Validators.required);
                        break;
                    case 'pattern':
                        validList.push(Validators.pattern(valid.validator));
                        break;

                    default:
                        break;
                }
            });
            return Validators.compose(validList);
        }
        return null;
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach((field) => {
            const control = formGroup.get(field);
            control.markAsTouched({ onlySelf: true });
        });
    }

    isRequired(validations) {
        if (validations != null) {
            let idx = validations.filter((x) => x.name === 'required');
            return idx != null ? true : false;
        }
    }

    public rowDataBound(args): void { }

    actionHandler(args: any) {
        // console.log('%ccreate-or-edit-customer-modal.component.ts line:383 args', 'color: #007acc;', args);
        // if (args.requestType == 'add') {
        // } else if (args.requestType == 'save') {
        //     let ipchecked = this.contacts.findIndex(
        //         (x) =>
        //             x.isPrimary == true &&
        //             x.name != args.rowData.name &&
        //             x.email != args.rowData.email &&
        //             x.phone != args.rowData.phone
        //     );
        //     if (ipchecked !== -1 && this.contacts.length > 1) {
        //         this.contacts[ipchecked].isPrimary = false;
        //         this.grid.refresh();
        //     }
        // }
        if (args.requestType === 'delete') {
            if (args.data.length > 0 && args.data[0].id > 0) {
                this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
                    if (isConfirmed) {
                        this._contactPersonsServiceProxy.delete(args.data[0].id).subscribe(() => {
                            this.notify.success(this.l('SuccessfullyDeleted'));
                            if (args.data[0].isPrimary) {
                                this.contacts[0].isPrimary = true;
                                this.grid.refresh();
                            }
                        });
                    }
                });
            }
        }
    }

    public phoneChange(args: any, data): void {
        data[data.column.field] = args.value; // checkbox value
        this.grid.updateRow(args.event.target.closest('tr').rowIndex, data); // update the checkbox change value to the dataSource by passing current rowIndex and updated data to the updateRow method
    }

    dataBound(e): void {
        if (this.grid != undefined) {
            this.grid.hideScroll();
        }
    }

    changePreferredCountries() {
        this.preferredCountries = [CountryISO.India, CountryISO.Canada];
    }

    onChangeRebate(value) {
        this.frmFG.value.isRebate = value;
        this.isRebate = value;
        // this.rebateDetail.setDisabledState(!value)
        if (this.frmFG.get('rebateDetail') != undefined) {
            if (value) {
                this.frmFG.get('rebateDetail').enable();
            } else {
                this.frmFG.get('rebateDetail').disable();
            }
        }
    }
}
