﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { CustomerRoutingModule } from './customer-routing.module';
import { CustomersComponent } from './customers.component';
import { CreateOrEditCustomerModalComponent } from './create-or-edit-customer-modal.component';
import { ViewCustomerModalComponent } from './view-customer-modal.component';

import { MasterDetailChild_Customer_ContactPersonModule } from '@app/main/customers/contactPersons/masterDetailChild_Customer_contactPerson.module';
import { EditService, InfiniteScrollService, PageService, ToolbarService } from '@syncfusion/ej2-angular-grids';

@NgModule({
    declarations: [CustomersComponent, CreateOrEditCustomerModalComponent, ViewCustomerModalComponent],
    imports: [
        AppSharedModule,
        CustomerRoutingModule,
        AdminSharedModule,
        MasterDetailChild_Customer_ContactPersonModule
    ],
    exports: [
        CreateOrEditCustomerModalComponent
    ]
})
export class CustomerModule {}
