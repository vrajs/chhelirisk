﻿import { AppConsts } from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
    CustomersServiceProxy,
    CustomerDto,
    FlexiFieldDto,
    GetCustomerForViewDto,
    GridSettingsDto,
    UtilsServiceProxy,
} from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditCustomerModalComponent } from './create-or-edit-customer-modal.component';
import { ViewCustomerModalComponent } from './view-customer-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter, unset } from 'lodash-es';
import { DateTime } from 'luxon';
import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import {
    Column,
    ExcelExportProperties,
    infiniteScrollHandler,
    InfiniteScrollSettingsModel,
    PageSettingsModel,
    ToolbarItems,
} from '@syncfusion/ej2-grids';
import {
    GridComponent,
    EditSettingsModel,
    TextWrapSettingsModel, InfiniteScrollService
} from '@syncfusion/ej2-angular-grids';
import * as _ from 'lodash';
import { NgModel } from '@angular/forms';

@Component({
    templateUrl: './customers.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
    providers: [InfiniteScrollService]
})
export class CustomersComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditCustomerModal', { static: true })
    createOrEditCustomerModal: CreateOrEditCustomerModalComponent;

    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    advancedFiltersAreShown = false;
    filterText = '';
    nameFilter = '';
    emailFilter = '';
    phoneFilter = '';
    addressFilter = '';
    postalCodeFilter = '';
    sourceFilter = '';
    branchFilter = '';
    ruleFlagIdFilter = '';
    isRebateFilter = -1;
    rebateDetailFilter = '';
    maxCreditLimitFilter: number;
    maxCreditLimitFilterEmpty: number;
    minCreditLimitFilter: number;
    minCreditLimitFilterEmpty: number;
    stringField1Filter = '';
    stringfield2Filter = '';
    stringField3Filter = '';
    stringField4Filter = '';
    stringField5Filter = '';
    maxDecimalField1Filter: number;
    maxDecimalField1FilterEmpty: number;
    minDecimalField1Filter: number;
    minDecimalField1FilterEmpty: number;
    maxDecimalField2Filter: number;
    maxDecimalField2FilterEmpty: number;
    minDecimalField2Filter: number;
    minDecimalField2FilterEmpty: number;
    maxDecimalField3Filter: number;
    maxDecimalField3FilterEmpty: number;
    minDecimalField3Filter: number;
    minDecimalField3FilterEmpty: number;
    maxDecimalField4Filter: number;
    maxDecimalField4FilterEmpty: number;
    minDecimalField4Filter: number;
    minDecimalField4FilterEmpty: number;
    maxDecimalField5Filter: number;
    maxDecimalField5FilterEmpty: number;
    minDecimalField5Filter: number;
    minDecimalField5FilterEmpty: number;
    maxDateField1Filter: DateTime;
    minDateField1Filter: DateTime;
    maxDateField2Filter: DateTime;
    minDateField2Filter: DateTime;
    maxDateField3Filter: DateTime;
    minDateField3Filter: DateTime;
    maxDateField4Filter: DateTime;
    minDateField4Filter: DateTime;
    maxDateField5Filter: DateTime;
    minDateField5Filter: DateTime;
    organizationUnitDisplayNameFilter = '';

    _entityTypeFullName = 'asq.econsys.Eco.Customers.Customer';
    entityHistoryEnabled = false;
    contactPersonRowSelection: boolean[] = [];
    childEntitySelection: {} = {};
    flexiFields: any[] = [];
    customerGridData: any[] = [];
    public toolbarOptions: ToolbarItems[];
    public initialPage: PageSettingsModel;
    @ViewChild('gridcustomer') public gridcustomer: GridComponent;
    flexiProcessedGridData: Array<any> = [];
    @ViewChild('actiontemplate') public actiontemplate: NgModel;
    @ViewChild('templateRuleFlagId') public templateRuleFlagId: NgModel;

    maxResultCount: number = 50;
    skipCount: number = 0;
    sortColumn: string = '';
    sortDirection: string = '';
    totalRecordCount: number = 0;
    pageSettings: any = { pageSizes: true, pageSize: 10, pageCount: 0, currentPage: 1 };
    public wrapSettings: TextWrapSettingsModel = { wrapMode: 'Content' };
    public editSettings: EditSettingsModel;
    public infiniteOptions: InfiniteScrollSettingsModel | undefined;
    public isSearchContinue: boolean = false;
    ruleFlags: any[] = [];
    public scrollVal: number = 0;

    constructor(
        injector: Injector,
        private _customersServiceProxy: CustomersServiceProxy,
        private _notifyService: NotifyService,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
        private _dateTimeService: DateTimeService,
        private _utilsServiceProxy: UtilsServiceProxy
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();

        this._utilsServiceProxy.getRuleFlags().subscribe((result) => {
            if (result && result.length > 0) {
                this.ruleFlags = result.map((x) => ({ ...x.ruleFlag }));
            }
        });

        this.getFlexiFields();
        this.getAll();
        this.editSettings = { allowEditing: false, allowDeleting: false };
        this.toolbarOptions = ['ColumnChooser', 'Search', 'ExcelExport', 'Print'];
        this.pageSettings = {
            pageSizes: false,
            pageSize: AppConsts.grid.defaultPageSize,
            //pageCount: 0,
            currentPage: 1,
        };
        this.infiniteOptions = {};
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }

    getAll(event?: LazyLoadEvent) {
        if (this.filterText != '') {
            this.skipCount = 0;
            this.customerGridData = [];
        }

        this._customersServiceProxy
            .getAll(
                this.filterText,
                this.nameFilter,
                this.emailFilter,
                this.phoneFilter,
                this.addressFilter,
                this.postalCodeFilter,
                this.sourceFilter,
                this.branchFilter,
                this.ruleFlagIdFilter,
                this.isRebateFilter,
                this.rebateDetailFilter,
                this.maxCreditLimitFilter == null ? this.maxCreditLimitFilterEmpty : this.maxCreditLimitFilter,
                this.minCreditLimitFilter == null ? this.minCreditLimitFilterEmpty : this.minCreditLimitFilter,
                this.stringField1Filter,
                this.stringfield2Filter,
                this.stringField3Filter,
                this.stringField4Filter,
                this.stringField5Filter,
                this.maxDecimalField1Filter == null ? this.maxDecimalField1FilterEmpty : this.maxDecimalField1Filter,
                this.minDecimalField1Filter == null ? this.minDecimalField1FilterEmpty : this.minDecimalField1Filter,
                this.maxDecimalField2Filter == null ? this.maxDecimalField2FilterEmpty : this.maxDecimalField2Filter,
                this.minDecimalField2Filter == null ? this.minDecimalField2FilterEmpty : this.minDecimalField2Filter,
                this.maxDecimalField3Filter == null ? this.maxDecimalField3FilterEmpty : this.maxDecimalField3Filter,
                this.minDecimalField3Filter == null ? this.minDecimalField3FilterEmpty : this.minDecimalField3Filter,
                this.maxDecimalField4Filter == null ? this.maxDecimalField4FilterEmpty : this.maxDecimalField4Filter,
                this.minDecimalField4Filter == null ? this.minDecimalField4FilterEmpty : this.minDecimalField4Filter,
                this.maxDecimalField5Filter == null ? this.maxDecimalField5FilterEmpty : this.maxDecimalField5Filter,
                this.minDecimalField5Filter == null ? this.minDecimalField5FilterEmpty : this.minDecimalField5Filter,
                this.maxDateField1Filter === undefined
                    ? this.maxDateField1Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField1Filter),
                this.minDateField1Filter === undefined
                    ? this.minDateField1Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField1Filter),
                this.maxDateField2Filter === undefined
                    ? this.maxDateField2Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField2Filter),
                this.minDateField2Filter === undefined
                    ? this.minDateField2Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField2Filter),
                this.maxDateField3Filter === undefined
                    ? this.maxDateField3Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField3Filter),
                this.minDateField3Filter === undefined
                    ? this.minDateField3Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField3Filter),
                this.maxDateField4Filter === undefined
                    ? this.maxDateField4Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField4Filter),
                this.minDateField4Filter === undefined
                    ? this.minDateField4Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField4Filter),
                this.maxDateField5Filter === undefined
                    ? this.maxDateField5Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField5Filter),
                this.minDateField5Filter === undefined
                    ? this.minDateField5Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField5Filter),
                this.organizationUnitDisplayNameFilter,
                this.sortColumn + ' ' + this.sortDirection,
                this.skipCount,
                this.maxResultCount
            )
            .subscribe((result) => {
                if (result.items && result.items.length == 0) this.customerGridData = [];
                this.totalRecordCount = result.totalCount;
                this.customerGridData = this.customerGridData.concat(
                    result.items.map((x) => ({
                        ...x.customer,
                        isRebate: x.customer.isRebate ? 'Yes' : 'No',
                        organizationUnitDisplayName: x.organizationUnitDisplayName,
                        action: 'action',
                    }))
                );
                if (result.items.length > this.pageSettings.pageSize - 1) {
                    this.pageSettings.skipCount += this.pageSettings.pageSize;
                } else {
                    this.pageSettings.skipCount = 0;
                }
            });
    }

    reloadPage(): void {
        this.paginator.changePage(1);
    }

    createOrEditCustomer(id: number = null): void {
        this.createOrEditCustomerModal.show(id);
    }

    onModalSave(e) {
        if (e.action == 'edit' && e.id > 0) {
            let idx = this.customerGridData.findIndex((x) => x.id == e.id);
            if (idx >= 0) {
                this.customerGridData[idx] = e.data;
            }
        } else if (e.action == 'create') {
            this.customerGridData.push(e.data);
        }
        this.gridcustomer.refresh();
    }

    showHistory(customer: CustomerDto): void {
        this.entityTypeHistoryModal.show({
            entityId: customer.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteCustomer(customer: CustomerDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._customersServiceProxy.delete(customer.id).subscribe(() => {
                    let idx = this.customerGridData.findIndex((x) => x.id == customer.id);
                    if (idx >= 0) {
                        this.customerGridData.splice(idx, 1);
                    }
                    this.gridcustomer.refresh();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    // exportToExcel(): void {
    //     this._customersServiceProxy
    //         .getCustomersToExcel(
    //             this.filterText,
    //             this.nameFilter,
    //             this.emailFilter,
    //             this.addressFilter,
    //             this.postalCodeFilter,
    //             this.sourceFilter,
    //             this.branchFilter,
    //             this.ruleFlagIdFilter,
    //             this.isRebateFilter,
    //             this.rebateDetailFilter,
    //             this.maxCreditLimitFilter == null ? this.maxCreditLimitFilterEmpty : this.maxCreditLimitFilter,
    //             this.minCreditLimitFilter == null ? this.minCreditLimitFilterEmpty : this.minCreditLimitFilter,
    //             this.stringField1Filter,
    //             this.stringfield2Filter,
    //             this.stringField3Filter,
    //             this.stringField4Filter,
    //             this.stringField5Filter,
    //             this.maxDecimalField1Filter == null ? this.maxDecimalField1FilterEmpty : this.maxDecimalField1Filter,
    //             this.minDecimalField1Filter == null ? this.minDecimalField1FilterEmpty : this.minDecimalField1Filter,
    //             this.maxDecimalField2Filter == null ? this.maxDecimalField2FilterEmpty : this.maxDecimalField2Filter,
    //             this.minDecimalField2Filter == null ? this.minDecimalField2FilterEmpty : this.minDecimalField2Filter,
    //             this.maxDecimalField3Filter == null ? this.maxDecimalField3FilterEmpty : this.maxDecimalField3Filter,
    //             this.minDecimalField3Filter == null ? this.minDecimalField3FilterEmpty : this.minDecimalField3Filter,
    //             this.maxDecimalField4Filter == null ? this.maxDecimalField4FilterEmpty : this.maxDecimalField4Filter,
    //             this.minDecimalField4Filter == null ? this.minDecimalField4FilterEmpty : this.minDecimalField4Filter,
    //             this.maxDecimalField5Filter == null ? this.maxDecimalField5FilterEmpty : this.maxDecimalField5Filter,
    //             this.minDecimalField5Filter == null ? this.minDecimalField5FilterEmpty : this.minDecimalField5Filter,
    //             this.maxDateField1Filter === undefined
    //                 ? this.maxDateField1Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField1Filter),
    //             this.minDateField1Filter === undefined
    //                 ? this.minDateField1Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField1Filter),
    //             this.maxDateField2Filter === undefined
    //                 ? this.maxDateField2Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField2Filter),
    //             this.minDateField2Filter === undefined
    //                 ? this.minDateField2Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField2Filter),
    //             this.maxDateField3Filter === undefined
    //                 ? this.maxDateField3Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField3Filter),
    //             this.minDateField3Filter === undefined
    //                 ? this.minDateField3Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField3Filter),
    //             this.maxDateField4Filter === undefined
    //                 ? this.maxDateField4Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField4Filter),
    //             this.minDateField4Filter === undefined
    //                 ? this.minDateField4Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField4Filter),
    //             this.maxDateField5Filter === undefined
    //                 ? this.maxDateField5Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField5Filter),
    //             this.minDateField5Filter === undefined
    //                 ? this.minDateField5Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField5Filter),
    //             this.organizationUnitDisplayNameFilter
    //         )
    //         .subscribe((result) => {
    //             this._fileDownloadService.downloadTempFile(result);
    //         });
    // }

    selectEditTable(table) {
        this.childEntitySelection = {};
        this.childEntitySelection[table] = true;
    }

    openChildRowForContactPerson(index, table) {
        let isAlreadyOpened = this.contactPersonRowSelection[index];
        this.closeAllChildRows();
        this.contactPersonRowSelection = [];
        if (!isAlreadyOpened) {
            this.contactPersonRowSelection[index] = true;
        }
        this.selectEditTable(table);
    }

    closeAllChildRows(): void {
        this.contactPersonRowSelection = [];
    }

    getFlexiFields() {
        this.spinnerService.show();
        this._utilsServiceProxy
            .getFlexiFieldsBySectionId('customer-information')
            .subscribe((result: FlexiFieldDto[]) => {
                if (result != null && result.length > 0) {
                    let _flexiFields: any[] = result
                        // .sort((a, b) => a.sortOrder - b.sortOrder)
                        .filter((x) => x.isEnabled == true)
                        .map((x) => ({
                            type: x.htmlType,
                            label: x.displayName,
                            headerText: x.displayName,
                            inputType: x.htmlInputType,
                            name: x.code,
                            code: _.camelCase(x.code), // _.mapKeys(x, (v, k) => _.camelCase(x.code)),
                            field: _.camelCase(x.code),
                            validations: x.validations,
                            width:
                                x.code.toLocaleLowerCase() == 'name'
                                    ? 300
                                    : x.code.toLocaleLowerCase() == 'phone' ||
                                        x.code.toLocaleLowerCase() == 'postalcode'
                                        ? 140
                                        : 200,
                            template: x.code.toLocaleLowerCase() == 'businessrule' ? this.templateRuleFlagId : null,
                        }));

                    _flexiFields.unshift({
                        headerText: this.l('Action'),
                        field: 'action',
                        code: 'action',
                        label: 'Action',
                        // 'template': '#coltemplate'
                        template: this.actiontemplate,
                        sortOrder: -1,
                        width: 100,
                    });
                    this.flexiFields = _flexiFields.sort((a, b) => a.sortOrder - b.sortOrder);

                    this.gridcustomer.columns = this.flexiFields;

                    var savedProperties = this.utilsService.getGridSettings('gridcustomer');
                    if (savedProperties != null && savedProperties.columns != undefined) {
                        savedProperties.columns.forEach((element) => {
                            if (this.gridcustomer.getColumnByField(element.field) != undefined) {
                                this.gridcustomer.getColumnByField(element.field).visible = element.visible;
                            }
                        });
                        this.gridcustomer.refreshColumns();
                    } else {
                        let fields: string[] = [
                            'action',
                            'address',
                            'branch',
                            'phone',
                            'source',
                            'isRebate',
                            'rebateDetail',
                            'comments',
                        ];
                        this.flexiFields.forEach((element) => {
                            if (this.gridcustomer.getColumnByField(element.field) != undefined && fields.indexOf(element.field) === -1) {
                                this.gridcustomer.getColumnByField(element.field).visible = false;
                            }
                        });
                    }
                }
                this.spinnerService.hide();
            });
    }

    onActionBegin(args) {
        if (args.requestType == "searching") {
            this.filterText = args.searchString;
            this.getAll();
        }
        if (args.requestType == 'refresh') {
            var savedProperties1 = window.localStorage.getItem('gridcustomer');
            if (savedProperties1 != null) {
                this.gridcustomer.setProperties(savedProperties1);
            }
        } else if (args.requestType == 'beginEdit') {
            this.createOrEditCustomerModal.show(args.rowData['id']);
        }
        if (args.requestType == 'paging') {
            this.skipCount = (args.currentPage - 1) * this.pageSettings.pageSize;
            this.pageSettings.currentPage = args.currentPage;
            this.getAll();
        } else if (args.requestType == 'sorting') {
            if (args.columnName != null) {
                this.customerGridData = [];
                this.sortColumn = args.columnName;
                this.sortDirection = args.direction == 'Ascending' ? 'asc' : 'desc';
                this.getAll();
            }
        } else if (args.requestType === 'infiniteScroll' && this.customerGridData.length < this.totalRecordCount) {
            this.skipCount += this.maxResultCount;
            this.scrollVal = this.gridcustomer.getContent().firstElementChild.scrollTop;
            this.getAll();
        } else if (args.requestType == 'columnstate') {
            if (args.columns && args.columns.length > 0) {
                var savedProperties = JSON.parse(this.gridcustomer.getPersistData());
                savedProperties.columns.forEach(function (col) {
                    args.columns.forEach((element) => {
                        if (element.uid == col.uid) {
                            col.visible = element.visible;
                        }
                    });
                });
                this.utilsService.updateGridSettings('gridcustomer', savedProperties);
            }
        }
    }

    dataBound(e): void {
        this.gridcustomer.hideScroll();
    }

    getFlagColorHex(id) {
        if (this.ruleFlags != undefined) {
            let flag = this.ruleFlags.filter((x) => x.id == id)[0];
            return flag != null && flag != undefined ? flag.hexColor : '';
        }
        return id;
    }

    toolbarClick(args): void {
        if (args.item.id === 'gridcustomer_excelexport') {
            (this.gridcustomer.columns[0] as Column).visible = false;
            const excelExportProperties: ExcelExportProperties = {
                fileName: "Customer.xlsx",
                exportType: 'AllPages'
            };
            this.gridcustomer.excelExport(excelExportProperties);
            for (const columns of this.gridcustomer.columns) {
                if ((columns as Column).headerText === 'Action') {
                    (columns as Column).visible = false;
                    exportType: 'AllPages'
                }
            }
        }
    }

    load(e) {
        (this.gridcustomer.localeObj as any).localeStrings.Excelexport = 'Export To Excel';
        (this.gridcustomer.localeObj as any).localeStrings.Print = 'Print';
    }

}
