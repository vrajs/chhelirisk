﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef} from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import { FlexiFieldsServiceProxy, CreateOrEditFlexiFieldDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

             import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { FlexiFieldFlexiSectionLookupTableModalComponent } from './flexiField-flexiSection-lookup-table-modal.component';
import { HtmlHelper } from '@shared/helpers/HtmlHelper';


@Component({
    selector: 'createOrEditFlexiFieldModal',
    templateUrl: './create-or-edit-flexiField-modal.component.html'
})
export class CreateOrEditFlexiFieldModalComponent extends AppComponentBase implements OnInit{
   
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @ViewChild('flexiFieldFlexiSectionLookupTableModal', { static: true }) flexiFieldFlexiSectionLookupTableModal: FlexiFieldFlexiSectionLookupTableModalComponent;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    flexiField: CreateOrEditFlexiFieldDto = new CreateOrEditFlexiFieldDto();

    flexiSectionName = '';
    hasAdminAccess: boolean = false;


    constructor(
        injector: Injector,
        private _flexiFieldsServiceProxy: FlexiFieldsServiceProxy,
             private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }
    
    show(flexiFieldId?: number): void {
        this.hasAdminAccess = this.permission.isGranted("Pages.FlexiSections") ? true : false;
    
        if (!flexiFieldId) {
            this.flexiField = new CreateOrEditFlexiFieldDto();
            this.flexiField.id = flexiFieldId;
            this.flexiSectionName = '';


            this.active = true;
            this.modal.show();
        } else {
            this._flexiFieldsServiceProxy.getFlexiFieldForEdit(flexiFieldId).subscribe(result => {
                this.flexiField = result.flexiField;

                this.flexiSectionName = result.flexiSectionName;


                this.active = true;
                this.modal.show();
            });
        }
        
        
    }

    save(): void {
            this.saving = true;
            console.log('%ccreate-or-edit-flexiField-modal.component.ts line:69 this.flexiField.validations', 'color: #007acc;', this.flexiField.validations, typeof this.flexiField.validations);
			if(this.flexiField.validations != '' && this.flexiField.validations != null && this.flexiField.validations != 'null') {
                this.flexiField.validations = JSON.stringify(this.flexiField.validations);
                this.flexiField.validations = this.flexiField.validations.replace(/(?:\\[rn])+/g, '').replace(/(?:\\[t])+/g, '');

                // this.flexiField.validations = HtmlHelper.encodeJson(this.flexiField.validations);
            } else {
                this.flexiField.validations = null;
            }
			
            this._flexiFieldsServiceProxy.createOrEdit(this.flexiField)
             .pipe(finalize(() => { this.saving = false;}))
             .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
             });
    }

    openSelectFlexiSectionModal() {
        this.flexiFieldFlexiSectionLookupTableModal.id = this.flexiField.flexiSectionId;
        this.flexiFieldFlexiSectionLookupTableModal.displayName = this.flexiSectionName;
        this.flexiFieldFlexiSectionLookupTableModal.show();
    }


    setFlexiSectionIdNull() {
        this.flexiField.flexiSectionId = null;
        this.flexiSectionName = '';
    }


    getNewFlexiSectionId() {
        this.flexiField.flexiSectionId = this.flexiFieldFlexiSectionLookupTableModal.id;
        this.flexiSectionName = this.flexiFieldFlexiSectionLookupTableModal.displayName;
    }








    close(): void {
        this.active = false;
        this.modal.hide();
    }
    
     ngOnInit(): void {
        
     }    
}
