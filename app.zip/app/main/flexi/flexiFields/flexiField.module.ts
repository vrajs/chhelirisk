﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';
import {FlexiFieldRoutingModule} from './flexiField-routing.module';
import {FlexiFieldsComponent} from './flexiFields.component';
import {CreateOrEditFlexiFieldModalComponent} from './create-or-edit-flexiField-modal.component';
import {ViewFlexiFieldModalComponent} from './view-flexiField-modal.component';
import {FlexiFieldFlexiSectionLookupTableModalComponent} from './flexiField-flexiSection-lookup-table-modal.component';
    					


@NgModule({
    declarations: [
        FlexiFieldsComponent,
        CreateOrEditFlexiFieldModalComponent,
        ViewFlexiFieldModalComponent,
        
    					FlexiFieldFlexiSectionLookupTableModalComponent,
    ],
    imports: [AppSharedModule, FlexiFieldRoutingModule , AdminSharedModule ],
    
})
export class FlexiFieldModule {
}
