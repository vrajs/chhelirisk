﻿import {AppConsts} from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute , Router} from '@angular/router';
import { FlexiFieldsServiceProxy, FlexiFieldDto , FlexiFieldType } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditFlexiFieldModalComponent } from './create-or-edit-flexiField-modal.component';

import { ViewFlexiFieldModalComponent } from './view-flexiField-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import { DateTime } from 'luxon';

             import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    templateUrl: './flexiFields.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()]
})
export class FlexiFieldsComponent extends AppComponentBase {
    
    
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditFlexiFieldModal', { static: true }) createOrEditFlexiFieldModal: CreateOrEditFlexiFieldModalComponent;
    @ViewChild('viewFlexiFieldModalComponent', { static: true }) viewFlexiFieldModal: ViewFlexiFieldModalComponent;   
    
    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    advancedFiltersAreShown = false;
    filterText = '';
    codeFilter = '';
    displayNameFilter = '';
    maxSortOrderFilter : number;
		maxSortOrderFilterEmpty : number;
		minSortOrderFilter : number;
		minSortOrderFilterEmpty : number;
    isEnabledFilter = -1;
    htmlTypeFilter = '';
    htmlInputTypeFilter = '';
    validationsFilter = '';
    dbTypeFilter = '';
    fieldTypeFilter = -1;
        flexiSectionNameFilter = '';

    flexiFieldType = FlexiFieldType;

    _entityTypeFullName = 'asq.econsys.Flexi.FlexiField';
    entityHistoryEnabled = false;



    constructor(
        injector: Injector,
        private _flexiFieldsServiceProxy: FlexiFieldsServiceProxy,
        private _notifyService: NotifyService,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
             private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return this.isGrantedAny('Pages.Administration.AuditLogs') && customSettings.EntityHistory && customSettings.EntityHistory.isEnabled && _filter(customSettings.EntityHistory.enabledEntities, entityType => entityType === this._entityTypeFullName).length === 1;
    }

    getFlexiFields(event?: LazyLoadEvent) {
        if (this.primengTableHelper.shouldResetPaging(event)) {
            this.paginator.changePage(0);
            return;
        }

        this.primengTableHelper.showLoadingIndicator();

        this._flexiFieldsServiceProxy.getAll(
            this.filterText,
            this.codeFilter,
            this.displayNameFilter,
            this.maxSortOrderFilter == null ? this.maxSortOrderFilterEmpty: this.maxSortOrderFilter,
            this.minSortOrderFilter == null ? this.minSortOrderFilterEmpty: this.minSortOrderFilter,
            this.isEnabledFilter,
            this.htmlTypeFilter,
            this.htmlInputTypeFilter,
            this.validationsFilter,
            this.dbTypeFilter,
            this.fieldTypeFilter,
            this.flexiSectionNameFilter,
            this.primengTableHelper.getSorting(this.dataTable),
            this.primengTableHelper.getSkipCount(this.paginator, event),
            this.primengTableHelper.getMaxResultCount(this.paginator, event)
        ).subscribe(result => {
            this.primengTableHelper.totalRecordsCount = result.totalCount;
            this.primengTableHelper.records = result.items;
            this.primengTableHelper.hideLoadingIndicator();
        });
    }

    reloadPage(): void {
        this.paginator.changePage(this.paginator.getPage());
    }

    createFlexiField(): void {
        this.createOrEditFlexiFieldModal.show();        
    }


    showHistory(flexiField: FlexiFieldDto): void {
        this.entityTypeHistoryModal.show({
            entityId: flexiField.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: ''
        });
    }

    deleteFlexiField(flexiField: FlexiFieldDto): void {
        this.message.confirm(
            '',
            this.l('AreYouSure'),
            (isConfirmed) => {
                if (isConfirmed) {
                    this._flexiFieldsServiceProxy.delete(flexiField.id)
                        .subscribe(() => {
                            this.reloadPage();
                            this.notify.success(this.l('SuccessfullyDeleted'));
                        });
                }
            }
        );
    }

    exportToExcel(): void {
        this._flexiFieldsServiceProxy.getFlexiFieldsToExcel(
        this.filterText,
            this.codeFilter,
            this.displayNameFilter,
            this.maxSortOrderFilter == null ? this.maxSortOrderFilterEmpty: this.maxSortOrderFilter,
            this.minSortOrderFilter == null ? this.minSortOrderFilterEmpty: this.minSortOrderFilter,
            this.isEnabledFilter,
            this.htmlTypeFilter,
            this.htmlInputTypeFilter,
            this.validationsFilter,
            this.dbTypeFilter,
            this.fieldTypeFilter,
            this.flexiSectionNameFilter,
        )
        .subscribe(result => {
            this._fileDownloadService.downloadTempFile(result);
         });
    }
    
    
    
    
    
}
