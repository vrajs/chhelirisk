﻿import {NgModule} from '@angular/core';
import {AppSharedModule} from '@app/shared/app-shared.module';
import {AdminSharedModule} from '@app/admin/shared/admin-shared.module';

import {MasterDetailChild_Lead_LeadContactsComponent} from './masterDetailChild_Lead_leadContacts.component';
import {MasterDetailChild_Lead_CreateOrEditLeadContactModalComponent} from './masterDetailChild_Lead_create-or-edit-leadContact-modal.component';
import {MasterDetailChild_Lead_ViewLeadContactModalComponent} from './masterDetailChild_Lead_view-leadContact-modal.component';



@NgModule({
    declarations: [
        MasterDetailChild_Lead_LeadContactsComponent,
        MasterDetailChild_Lead_CreateOrEditLeadContactModalComponent,
        MasterDetailChild_Lead_ViewLeadContactModalComponent,
        
    ],
    imports: [AppSharedModule , AdminSharedModule ],
    
			    exports: [
                    MasterDetailChild_Lead_LeadContactsComponent,
                    MasterDetailChild_Lead_CreateOrEditLeadContactModalComponent,
                    MasterDetailChild_Lead_ViewLeadContactModalComponent,
                ]
			
})
export class MasterDetailChild_Lead_LeadContactModule {
}
