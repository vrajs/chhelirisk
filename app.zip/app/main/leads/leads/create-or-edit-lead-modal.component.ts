﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    LeadsServiceProxy,
    CreateOrEditLeadDto,
    LeadOrganizationUnitLookupTableDto,
    LeadLeadSourceLookupTableDto,
    LeadCustomerLookupTableDto,
    LeadProjectTypeLookupTableDto,
    FlexiFieldDto,
    LeadContactDto,
    CreateOrEditLeadContactDto,
    LeadContactsServiceProxy,
    UtilsServiceProxy,
    CustomersServiceProxy,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { CountryISO, PhoneNumberFormat, SearchCountryField } from 'ngx-intl-tel-input';
import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GridComponent, IEditCell, ToolbarItems } from '@syncfusion/ej2-angular-grids';
import { AutoCompleteComponent } from '@syncfusion/ej2-angular-dropdowns';
import * as _ from 'lodash';
import { DatePipe } from '@angular/common';
import { LuxonFormatPipe } from '@shared/utils/luxon-format.pipe';
import countries from '@assets/data/countries.json';
import { CheckBox } from '@syncfusion/ej2-angular-buttons';

@Component({
    selector: 'createOrEditLeadModal',
    templateUrl: './create-or-edit-lead-modal.component.html',
    providers: [DatePipe],
})
export class CreateOrEditLeadModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @ViewChild('normalgrid') public grid: GridComponent | any;
    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    lead: CreateOrEditLeadDto = new CreateOrEditLeadDto();
    leadContactEntity: CreateOrEditLeadContactDto = new CreateOrEditLeadContactDto();

    organizationUnitDisplayName = '';
    leadSourceTitle = '';
    customerName = '';
    projectTypeCode = '';

    allOrganizationUnits: LeadOrganizationUnitLookupTableDto[];
    allLeadSources: LeadLeadSourceLookupTableDto[];
    allCustomers: LeadCustomerLookupTableDto[];
    allProjectTypes: LeadProjectTypeLookupTableDto[];

    frmFG: FormGroup = this.fb.group({});
    flexiFields: any[] = [];
    leadEditId: any;
    getContactsByIdData: Object[];
    contacts: Array<LeadContactDto> = [];
    isExist: any = false;
    editsettings: Object = [];
    toolbar: any;
    pagesettings: Object;
    toolbarOptions: ToolbarItems[];
    data!: object[];
    nameValidation: Object;
    emailValidation: Object;
    phoneRules: Object;
    loadCustomerdata: Object[];
    customerId: any;
    AutoCompleteObj!: AutoCompleteComponent;
    fields: Object = { value: 'displayName' };
    value: string = '';
    // waterMark: string = 'Enter existing customer name';
    leadSourceData: Object[] = [];
    leadSourceId: any;
    fieldsLeadSourceId: Object = { text: 'displayName', value: 'id' };

    separateDialCode = false;
    SearchCountryField = SearchCountryField;
    CountryISO = CountryISO;
    PhoneNumberFormat = PhoneNumberFormat;
    preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
    CountryCode: any;
    userCountry: any;

    public elmIsPrimary: HTMLElement;
    public chbIsPrimary: CheckBox;
    public iecIsPrimary: IEditCell = {
        create: () => {
            this.elmIsPrimary = document.createElement('input');
            return this.elmIsPrimary;
        },
        destroy: () => {
            this.chbIsPrimary.destroy();
        },
        read: (args) => {
            return this.chbIsPrimary.checked;
        },
        write: (args: { rowData: any; column: any; row: any; cell: any }) => {
            this.chbIsPrimary = new CheckBox({
                value: args.rowData[args.column.field],
                change: (e) => {
                    let ipchecked = this.contacts.findIndex(
                        (x) =>
                            x.isPrimary == true &&
                            x.name != args.rowData.name &&
                            x.email != args.rowData.email &&
                            x.phone != args.rowData.phone
                    );
                    if (!e.checked && ipchecked === -1) {
                        this.notify.warn(this.l('At least one cantact must be set as primary.'));
                        e.checked = true;
                        args.rowData.isPrimary = true;
                        this.chbIsPrimary.checked = true;
                        e.event.preventDefault();
                        return false;
                    }
                    if (e.checked && ipchecked !== -1) {
                        this.notify.warn(this.l('This will release Is Primary flag from another contact in list.'));
                        args.rowData.isPrimary = true;
                        this.contacts.map(x => {
                            x.isPrimary = false;
                        });
                    }
                },
            });
            if (this.contacts.length == 0) {
                args.rowData[args.column.field] = true;
                this.chbIsPrimary.checked = true;
                this.grid.setRowData(args.row.rowIndex, args.rowData);
                // this.chbIsPrimary.dataBind();
            }
            this.chbIsPrimary.appendTo(this.elmIsPrimary);
        },
    };

    constructor(
        injector: Injector,
        private _leadsServiceProxy: LeadsServiceProxy,
        private _dateTimeService: DateTimeService,
        private fb: FormBuilder,
        private _utilsServiceProxy: UtilsServiceProxy,
        private _leadContactsServiceProxy: LeadContactsServiceProxy,
        private _customersServiceProxy: CustomersServiceProxy,
        private datepipe: DatePipe
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.getLeadSourceData();
        this.editsettings = {
            allowEditing: true,
            allowAdding: true,
            allowDeleting: true,
            mode: 'Normal',
            showDeleteConfirmDialog: true,
        };
        this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel', 'Search'];
        this.nameValidation = { required: true };
        this.emailValidation = { required: true, email: true };
        this.phoneRules = { required: true };//, number: true };
    }

    show(id?: number): void {
        this.getFlexiFields().then((result) => {
            this.userCountry = null;
            var tz = abp.timing.timeZoneInfo.windows.timeZoneId;
            Object.entries(CountryISO).forEach((x) => {
                if (x[0] == tz.split(' ')[0] || x[0] == tz.split(' ')[0] + tz.split(' ')[1]) this.userCountry = x[1];
            });
            if (!this.userCountry) this.userCountry = 'gb';
            this.CountryCode = this.userCountry;

            if (!id) {
                this.lead = new CreateOrEditLeadDto();
                this.lead.id = id;
                this.leadEditId = null;
                this.lead.anticipatedEnquiryReceiptDate = this._dateTimeService.getStartOfDay();
                this.lead.anticipatedOrderPlacementDate = this._dateTimeService.getStartOfDay();
                this.lead.dateField1 = this._dateTimeService.getStartOfDay();
                this.lead.dateField2 = this._dateTimeService.getStartOfDay();
                this.lead.dateField3 = this._dateTimeService.getStartOfDay();
                this.lead.dateField4 = this._dateTimeService.getStartOfDay();
                this.lead.dateField5 = this._dateTimeService.getStartOfDay();
                this.organizationUnitDisplayName = '';
                this.leadSourceTitle = '';
                this.customerName = '';
                this.projectTypeCode = '';
                this.active = true;
                this.modal.show();
            } else {
                this._leadsServiceProxy.getLeadForEdit(id).subscribe((result) => {
                    this.isExist = true;
                    this.lead = result.lead;
                    let country = countries.find((x) => {
                        if (result.lead.phone && x.dial_code == result.lead.phone.split(' ')[0]) return x;
                        else return null;
                    });
                    if (country) this.CountryCode = country.code;
                    else this.CountryCode = this.userCountry;
                    this.customerId = result.lead.customerId;
                    this.leadEditId = result.lead.id;
                    // this.getLeadContacts(this.leadEditId);
                    this.organizationUnitDisplayName = result.organizationUnitDisplayName;
                    this.leadSourceId = result.lead.leadSourceId;
                    this.customerName = result.lead.customerName;
                    this.projectTypeCode = result.projectTypeCode;

                    Object.keys(this.frmFG.controls).forEach((formKey) => {
                        Object.entries(this.lead).find(([key, value]) => {
                            if (formKey.toLowerCase() == key.toLowerCase()) {
                                this.frmFG.controls[formKey].setValue(value);
                            }
                        });
                    });

                    this.flexiFields.forEach((element) => {
                        if (element.inputType == 'date' && this.lead[element.name] != null) {
                            this.frmFG
                                .get(element.name)
                                .setValue(this.lead[element.name].toFormat(this.gconsts.dtfShortDisplay));
                        }
                    });
                    // if (this.lead != null) {
                    //     this._leadContactsServiceProxy.getLeadContactsById(this.lead.id).subscribe((response) => {
                    //         response.forEach((x) => {
                    //             if (x.isPrimary) this.isPrimary = true;
                    //         });
                    //     });
                    // }

                    // if (this.lead.anticipatedEnquiryReceiptDate != null) {
                    //     this.frmFG
                    //         .get('anticipatedEnquiryReceiptDate')
                    //         .setValue(this.lead.anticipatedEnquiryReceiptDate.toFormat(this.gconsts.dtfShortDisplay));
                    // }
                    // if (this.lead.anticipatedOrderPlacementDate != null) {
                    //     this.frmFG
                    //         .get('anticipatedOrderPlacementDate')
                    //         .setValue(this.lead.anticipatedOrderPlacementDate.toFormat(this.gconsts.dtfShortDisplay));
                    // }
                    // this.frmFG.get('customerName').disable({ onlySelf: true });
                    this.frmFG.get('customerAddress1').disable({ onlySelf: true });
                    this.frmFG.get('postalCode').disable({ onlySelf: true });
                    this.frmFG.get('email').disable({ onlySelf: true });
                    this.frmFG.get('phone').disable({ onlySelf: true });

                    let lsd: any = this.allLeadSources.filter((x) => x.id == this.lead.leadSourceId)[0];
                    if (lsd != null) {
                        this.frmFG.controls.leadSourceId.setValue(lsd.displayName);
                    }

                    this.active = true;
                    this.modal.show();
                });
            }
        });
        this._leadsServiceProxy.getAllLeadSourceForTableDropdown().subscribe((result) => {
            this.allLeadSources = result;
        });
        this._leadsServiceProxy.getAllOrganizationUnitForTableDropdown().subscribe((result) => {
            this.allOrganizationUnits = result;
        });
        this._leadsServiceProxy.getAllCustomerForTableDropdown().subscribe((result) => {
            this.allCustomers = result;
        });
        this._leadsServiceProxy.getAllProjectTypeForTableDropdown().subscribe((result) => {
            this.allProjectTypes = result;
        });
    }

    save(): void {
        if (!this.frmFG.valid) {
            abp.notify.error(this.l('Please enter proper inputs'));
            return;
        }
        if (this.customerId) {
            this._customersServiceProxy.getCustomerForView(this.customerId).subscribe((result) => {
                formData.customerAddress1 = result.customer.address1;
                formData.customerAddress2 = result.customer.address2;
                formData.email = result.customer.email;
                formData.postalCode = result.customer.postalCode;
                formData.phone = result.customer.phone;
            });
        }
        this.leadContactFunction(this.contacts);
        this.frmFG.value.id = this.leadEditId;
        this.frmFG.value.customerId = this.customerId;
        this.frmFG.value.leadSourceId = this.leadSourceId;
        let formData: CreateOrEditLeadDto = new CreateOrEditLeadDto();
        Object.assign(formData, this.frmFG.value);

        this.flexiFields.forEach((element) => {
            if (element.inputType == 'date') {
                if (formData[element.name] != null) {
                    const date2 =
                        typeof formData[element.name] === 'object'
                            ? DateTime.fromISO(formData[element.name])
                            : DateTime.fromFormat(formData[element.name], this.gconsts.dtfShortDisplay, {
                                zone: 'utc',
                            });
                    formData[element.name] = date2;
                }
            }
        });

        // let phone = this.frmFG.get('phone').value;
        // if (phone != null) {
        //     formData.phone = phone.internationalNumber;
        // }
        // let lsd: any = this.allLeadSources.filter(x => x.displayName.toLocaleLowerCase() == this.frmFG.value.leadSourceId.toLocaleLowerCase())[0];
        // if(lsd != null) {
        //     this.lead.leadSourceId = lsd.id;
        // }

        if (this.lead.status == null || this.lead.status == '') {
            formData.status = 'new';
        } else {
            formData.status = this.lead.status;
        }

        let hasIsPrimary: boolean = false;
        if (this.contacts != null && this.contacts.length > 0) {
            this.contacts.forEach((element, index) => {
                let dobj: LeadContactDto = new LeadContactDto();
                Object.assign(dobj, element);
                formData.leadContactObject[index] = dobj;
                hasIsPrimary = hasIsPrimary || dobj.isPrimary ? true : false;
            });
        }

        if (formData.leadContactObject && formData.leadContactObject.length == 0) {
            this.message.warn(this.l('AddContact'));
            return;
        }

        if (!hasIsPrimary) {
            this.message.warn(this.l('Please make at least one contact primary.'));
            return;
        } else {
            this.spinnerService.show();
            this.saving = true;
            this._leadsServiceProxy
                .createOrEdit(formData)
                .pipe(
                    finalize(() => {
                        this.saving = false;
                    })
                )
                .subscribe(
                    (result) => {
                        this.spinnerService.hide();
                        this.saving = false;
                        this.leadEditId = result;

                        if (result) {
                            this.notify.success(this.l('SavedSuccessfully'));
                            this.close();
                            let action = formData.id == null ? 'create' : 'edit';
                            formData.id = result;
                            this.modalSave.emit({ id: result, data: formData, action: action });
                            this.frmFG.reset();
                        }
                    },
                    () => {
                        this.spinnerService.hide();
                        this.saving = false;
                    }
                );
        }
    }

    close(): void {
        this.active = false;
        this.modal.hide();
        this.frmFG.reset();
        this.customerId = null;
        this.frmFG.get('customerAddress1').enable();
        this.frmFG.get('customerAddress2').enable();
        this.frmFG.get('postalCode').enable();
        this.frmFG.get('email').enable();
        this.frmFG.get('phone').enable();
        this.isExist = false;
        this.contacts = [];
    }

    getFlexiFields() {
        return new Promise((resolve, reject) => {
            this.spinnerService.show();
            this._utilsServiceProxy
                .getFlexiFieldsBySectionId('lead-information')
                .subscribe((result: FlexiFieldDto[]) => {
                    if (result != null && result.length > 0) {
                        this.frmFG = this.fb.group({});
                        this.flexiFields = result
                            .sort((a, b) => a.sortOrder - b.sortOrder)
                            .filter((x) => x.isEnabled == true)
                            .map((x) => ({
                                type: x.htmlType,
                                label: x.displayName,
                                headerText: x.displayName,
                                inputType: x.htmlInputType,
                                name: _.camelCase(x.code),
                                code: _.camelCase(x.code),
                                field: _.camelCase(x.code),
                                validations: x.validations,
                            }));

                        const group = this.fb.group({});
                        this.flexiFields.forEach((field) => {
                            if (field.type === 'button') return;
                            let validations = [];
                            if (field.validations != null) {
                                let vals = field.validations
                                    .substring(1, field.validations.length - 1)
                                    .replace(/(?:\\)+/g, '');
                                validations = JSON.parse(vals);
                                field.validations = validations;
                            }
                            const control = this.fb.control(field.value, this.bindValidations(validations || []));
                            group.addControl(field.name, control);
                        });
                        this.frmFG = group;
                        this.spinnerService.hide();
                        resolve(true);
                    }
                    this.spinnerService.hide();
                    resolve(false);
                });
        });
    }

    bindValidations(validations: any) {
        if (validations.length > 0) {
            const validList = [];
            validations.forEach((valid) => {
                switch (valid.name) {
                    case 'required':
                        validList.push(Validators.required);
                        break;
                    case 'pattern':
                        validList.push(Validators.pattern(valid.validator));
                        break;

                    default:
                        break;
                }
            });
            return Validators.compose(validList);
        }
        return null;
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach((field) => {
            const control = formGroup.get(field);
            control.markAsTouched({ onlySelf: true });
        });
    }

    isRequired(validations) {
        if (validations != null) {
            let idx = validations.filter((x) => x.name === 'required');
            return idx != null ? true : false;
        }
    }

    loadCustomer() {
        this._leadsServiceProxy.getAllCustomerForTableDropdown().subscribe((res) => {
            this.loadCustomerdata = res;
        });
    }

    getLeadContacts(id) {
        this._leadContactsServiceProxy.getLeadContactsById(id).subscribe((response) => {
            this.contacts = response;
            this.contacts.forEach((item) => {
                item.leadId = id;
            });
        });
    }

    leadContactFunction(args) {
        this.contacts = [];
        args.forEach((item) => {
            let obj = new LeadContactDto();
            if (this.isExist) {
                obj.id = item.id;
                obj.leadId = this.leadEditId;
            }
            obj.name = item.name;
            obj.email = item.email;
            obj.phone = item.phone;
            obj.isPrimary = item.isPrimary;
            this.contacts.push(obj);
        });
        this.frmFG.value.leadContactObject = this.contacts;
    }

    onChangeLeadContact(args: any): void {
        if (args.itemData != null && args.itemData.id != 0 && args.itemData.id != null) {
            this.customerId = args.itemData.id;
            // this.frmFG.get('customerId').setValue(args.itemData.id);
            let country = countries.find((x) => {
                if (args.itemData.phone && x.dial_code == args.itemData.phone.split(' ')[0]) return x;
                else if (
                    args.itemData.phone &&
                    x.dial_code == args.itemData.phone.split(' ')[0] + args.itemData.phone.split(' ')[1]
                )
                    return x;
                else return null;
            });
            if (country) this.CountryCode = country.code;
            else this.CountryCode = this.userCountry;
            this.frmFG.get('customerAddress1').setValue(args.itemData.address1);
            this.frmFG.get('customerAddress1').setValue(args.itemData.address2);
            this.frmFG.get('postalCode').setValue(args.itemData.postalCode);
            this.frmFG.get('email').setValue(args.itemData.email);
            this.frmFG.get('phone').setValue(args.itemData.phone);

            this.frmFG.get('customerAddress1').disable({ onlySelf: true });
            this.frmFG.get('customerAddress2').disable({ onlySelf: true });
            this.frmFG.get('postalCode').disable({ onlySelf: true });
            this.frmFG.get('email').disable({ onlySelf: true });
            this.frmFG.get('phone').disable({ onlySelf: true });
        } else {
            this.CountryCode = this.userCountry;
            this.customerId = null;
            this.frmFG.get('customerAddress1').setValue(null);
            this.frmFG.get('customerAddress2').setValue(null);
            this.frmFG.get('postalCode').setValue(null);
            this.frmFG.get('email').setValue(null);
            this.frmFG.get('phone').setValue(null);

            this.frmFG.get('customerAddress1').enable();
            this.frmFG.get('customerAddress2').enable();
            this.frmFG.get('postalCode').enable();
            this.frmFG.get('email').enable();
            this.frmFG.get('phone').enable();
        }
    }

    actionBegin(args) {
        // if (args.requestType == 'save') {
        //     let ipchecked = this.contacts.findIndex(
        //         (x) =>
        //             x.isPrimary == true &&
        //             x.name != args.rowData.name &&
        //             x.email != args.rowData.email &&
        //             x.phone != args.rowData.phone
        //     );
        //     if (ipchecked !== -1 && this.contacts.length > 1) {
        //         this.contacts[ipchecked].isPrimary = false;
        //         this.grid.refresh();
        //     }
        // }
        if (args.requestType == 'delete') {
            if (args.data.length > 0 && args.data[0].id > 0) {
                this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
                    if (isConfirmed) {
                        this._leadContactsServiceProxy.delete(args.data[0].id).subscribe(() => {
                            this.notify.success(this.l('SuccessfullyDeleted'));
                            if (args.data[0].isPrimary) {
                                this.contacts[0].isPrimary = true;
                                this.grid.refresh();
                            }
                        });
                    }
                });
            }
        }
    }

    getLeadSourceData() {
        this._leadsServiceProxy.getAllLeadSourceForTableDropdown().subscribe((response) => {
            response.forEach((x) => {
                this.leadSourceData.push({ displayName: x.displayName, id: x.id });
            });
        });
    }

    setLeadSource(e) {
        this.leadSourceId = e.itemData.id;
    }

    dataBound(e): void {
        if (this.grid != undefined) {
            this.grid.hideScroll();
        }
    }
}
