﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { LeadRoutingModule } from './lead-routing.module';
import { LeadsComponent } from './leads.component';
import { CreateOrEditLeadModalComponent } from './create-or-edit-lead-modal.component';
import { ViewLeadModalComponent } from './view-lead-modal.component';

import { MasterDetailChild_Lead_LeadContactModule } from '@app/main/leads/leadContacts/masterDetailChild_Lead_leadContact.module';

@NgModule({
    declarations: [LeadsComponent, CreateOrEditLeadModalComponent, ViewLeadModalComponent],
    imports: [AppSharedModule, LeadRoutingModule, AdminSharedModule, MasterDetailChild_Lead_LeadContactModule],
})
export class LeadModule {}
