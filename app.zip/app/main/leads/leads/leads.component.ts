﻿import { AppConsts } from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LeadsServiceProxy, LeadDto, FlexiFieldDto, UtilsServiceProxy } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditLeadModalComponent } from './create-or-edit-lead-modal.component';

import { ViewLeadModalComponent } from './view-lead-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import { DateTime } from 'luxon';
import * as _ from 'lodash';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import {
    CommandModel,
    EditSettingsModel,
    PageSettingsModel,
    ToolbarItems,
    InfiniteScrollSettingsModel,
    TextWrapSettingsModel,
    Column,
    ExcelExportProperties,
} from '@syncfusion/ej2-grids';
import { GridComponent, InfiniteScrollService } from '@syncfusion/ej2-angular-grids';
import { SwitchComponent } from '@syncfusion/ej2-angular-buttons';
import { NgModel } from '@angular/forms';
import { DatePipe } from '@angular/common';

@Component({
    templateUrl: './leads.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
    providers: [InfiniteScrollService, DatePipe],
})
export class LeadsComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditLeadModal', { static: true }) createOrEditLeadModal: CreateOrEditLeadModalComponent;
    @ViewChild('viewLeadModalComponent', { static: true }) viewLeadModal: ViewLeadModalComponent;
    @ViewChild('createOrEditLeadModal', { static: true })
    CreateOrEditLeadModalComponent: CreateOrEditLeadModalComponent;

    // @ViewChild('dataTable', { static: true }) dataTable: Table;
    // @ViewChild('paginator', { static: true }) paginator: Paginator;
    @ViewChild('gridlead') public gridlead: GridComponent;
    @ViewChild('actiontemplate') public actiontemplate: NgModel;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    advancedFiltersAreShown = false;
    filterText = '';
    projectNameFilter = '';
    customerNameFilter = '';
    customerAddressFilter = '';
    postalcodeFilter = '';
    emailfilter = '';
    phonefilter = '';
    siteNameFilter = '';
    endUserFilter = '';
    maxOrderProbabilityPercFilter: number;
    maxOrderProbabilityPercFilterEmpty: number;
    minOrderProbabilityPercFilter: number;
    minOrderProbabilityPercFilterEmpty: number;
    budgetOrderValueFilter = '';
    maxAnticipatedEnquiryReceiptDateFilter: DateTime;
    minAnticipatedEnquiryReceiptDateFilter: DateTime;
    maxAnticipatedOrderPlacementDateFilter: DateTime;
    minAnticipatedOrderPlacementDateFilter: DateTime;
    maxApproxProjectDurationMonthsFilter: number;
    maxApproxProjectDurationMonthsFilterEmpty: number;
    minApproxProjectDurationMonthsFilter: number;
    minApproxProjectDurationMonthsFilterEmpty: number;
    commentsFilter = '';
    statusFilter = '';
    stringField1Filter = '';
    stringField2Filter = '';
    stringField3Filter = '';
    stringField4Filter = '';
    stringField5Filter = '';
    maxDecimalField1Filter: number;
    maxDecimalField1FilterEmpty: number;
    minDecimalField1Filter: number;
    minDecimalField1FilterEmpty: number;
    maxDecimalField2Filter: number;
    maxDecimalField2FilterEmpty: number;
    minDecimalField2Filter: number;
    minDecimalField2FilterEmpty: number;
    maxDecimalField3Filter: number;
    maxDecimalField3FilterEmpty: number;
    minDecimalField3Filter: number;
    minDecimalField3FilterEmpty: number;
    maxDecimalField4Filter: number;
    maxDecimalField4FilterEmpty: number;
    minDecimalField4Filter: number;
    minDecimalField4FilterEmpty: number;
    maxDecimalField5Filter: number;
    maxDecimalField5FilterEmpty: number;
    minDecimalField5Filter: number;
    minDecimalField5FilterEmpty: number;
    maxDateField1Filter: DateTime;
    minDateField1Filter: DateTime;
    maxDateField2Filter: DateTime;
    minDateField2Filter: DateTime;
    maxDateField3Filter: DateTime;
    minDateField3Filter: DateTime;
    maxDateField4Filter: DateTime;
    minDateField4Filter: DateTime;
    maxDateField5Filter: DateTime;
    minDateField5Filter: DateTime;
    organizationUnitDisplayNameFilter = '';
    leadSourceTitleFilter = '';
    projectTypeCodeFilter = '';

    _entityTypeFullName = 'asq.econsys.Eco.Leads.Lead';
    entityHistoryEnabled = false;

    leadContactRowSelection: boolean[] = [];
    flexiFields: any[] = [];
    leadGridData: any[] = [];
    toolbarOptions: ToolbarItems[];
    flexiProcessedGridData: Array<any> = [];
    maxResultCount: number = 35;
    sortColumn: string = '';
    sortDirection: string = '';
    count = 0;
    totalRecordCount: number = 0;
    skipCount: number = 0;
    pageSettings: PageSettingsModel = {
        pageSizes: true,
        pageSize: AppConsts.grid.defaultPageSize,
        pageCount: 0,
        currentPage: 1,
    };
    editSettings: EditSettingsModel;
    infiniteOptions: InfiniteScrollSettingsModel;
    wrapSettings: TextWrapSettingsModel;
    public scrollVal: number = 0;

    childEntitySelection: {} = {};
    myLeads: boolean = true;
    @ViewChild('chkMyLeads') public chkMyLeads: SwitchComponent;

    constructor(
        injector: Injector,
        private _leadsServiceProxy: LeadsServiceProxy,
        private _fileDownloadService: FileDownloadService,
        private _dateTimeService: DateTimeService,
        private _utilsServiceProxy: UtilsServiceProxy,
        private datepipe: DatePipe
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.wrapSettings = { wrapMode: 'Content' };
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
        this.toolbarOptions = ['ColumnChooser', 'Search', 'ExcelExport', 'Print'];
        this.pageSettings = {
            pageSizes: false,
            pageSize: AppConsts.grid.defaultPageSize,
            pageCount: 0,
            currentPage: 1,
        };
        this.editSettings = { allowDeleting: true, showDeleteConfirmDialog: true };
        this.getFlexiFields().then((result) => {
            this.getAll();
        });
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }

    getAll(event?: LazyLoadEvent) {
        if (this.filterText != '') {
            this.skipCount = 0;
            this.leadGridData = [];
        }
        this._leadsServiceProxy
            .getAll(
                this.filterText,
                this.projectNameFilter,
                this.customerNameFilter,
                this.customerAddressFilter,
                this.postalcodeFilter,
                this.emailfilter,
                this.phonefilter,
                this.siteNameFilter,
                this.endUserFilter,
                this.maxOrderProbabilityPercFilter == null
                    ? this.maxOrderProbabilityPercFilterEmpty
                    : this.maxOrderProbabilityPercFilter,
                this.minOrderProbabilityPercFilter == null
                    ? this.minOrderProbabilityPercFilterEmpty
                    : this.minOrderProbabilityPercFilter,
                this.budgetOrderValueFilter,
                this.maxAnticipatedEnquiryReceiptDateFilter === undefined
                    ? this.maxAnticipatedEnquiryReceiptDateFilter
                    : this._dateTimeService.getEndOfDayForDate(this.maxAnticipatedEnquiryReceiptDateFilter),
                this.minAnticipatedEnquiryReceiptDateFilter === undefined
                    ? this.minAnticipatedEnquiryReceiptDateFilter
                    : this._dateTimeService.getStartOfDayForDate(this.minAnticipatedEnquiryReceiptDateFilter),
                this.maxAnticipatedOrderPlacementDateFilter === undefined
                    ? this.maxAnticipatedOrderPlacementDateFilter
                    : this._dateTimeService.getEndOfDayForDate(this.maxAnticipatedOrderPlacementDateFilter),
                this.minAnticipatedOrderPlacementDateFilter === undefined
                    ? this.minAnticipatedOrderPlacementDateFilter
                    : this._dateTimeService.getStartOfDayForDate(this.minAnticipatedOrderPlacementDateFilter),
                this.maxApproxProjectDurationMonthsFilter == null
                    ? this.maxApproxProjectDurationMonthsFilterEmpty
                    : this.maxApproxProjectDurationMonthsFilter,
                this.minApproxProjectDurationMonthsFilter == null
                    ? this.minApproxProjectDurationMonthsFilterEmpty
                    : this.minApproxProjectDurationMonthsFilter,
                this.commentsFilter,
                this.statusFilter,
                this.stringField1Filter,
                this.stringField2Filter,
                this.stringField3Filter,
                this.stringField4Filter,
                this.stringField5Filter,
                this.maxDecimalField1Filter == null ? this.maxDecimalField1FilterEmpty : this.maxDecimalField1Filter,
                this.minDecimalField1Filter == null ? this.minDecimalField1FilterEmpty : this.minDecimalField1Filter,
                this.maxDecimalField2Filter == null ? this.maxDecimalField2FilterEmpty : this.maxDecimalField2Filter,
                this.minDecimalField2Filter == null ? this.minDecimalField2FilterEmpty : this.minDecimalField2Filter,
                this.maxDecimalField3Filter == null ? this.maxDecimalField3FilterEmpty : this.maxDecimalField3Filter,
                this.minDecimalField3Filter == null ? this.minDecimalField3FilterEmpty : this.minDecimalField3Filter,
                this.maxDecimalField4Filter == null ? this.maxDecimalField4FilterEmpty : this.maxDecimalField4Filter,
                this.minDecimalField4Filter == null ? this.minDecimalField4FilterEmpty : this.minDecimalField4Filter,
                this.maxDecimalField5Filter == null ? this.maxDecimalField5FilterEmpty : this.maxDecimalField5Filter,
                this.minDecimalField5Filter == null ? this.minDecimalField5FilterEmpty : this.minDecimalField5Filter,
                this.maxDateField1Filter === undefined
                    ? this.maxDateField1Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField1Filter),
                this.minDateField1Filter === undefined
                    ? this.minDateField1Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField1Filter),
                this.maxDateField2Filter === undefined
                    ? this.maxDateField2Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField2Filter),
                this.minDateField2Filter === undefined
                    ? this.minDateField2Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField2Filter),
                this.maxDateField3Filter === undefined
                    ? this.maxDateField3Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField3Filter),
                this.minDateField3Filter === undefined
                    ? this.minDateField3Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField3Filter),
                this.maxDateField4Filter === undefined
                    ? this.maxDateField4Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField4Filter),
                this.minDateField4Filter === undefined
                    ? this.minDateField4Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField4Filter),
                this.maxDateField5Filter === undefined
                    ? this.maxDateField5Filter
                    : this._dateTimeService.getEndOfDayForDate(this.maxDateField5Filter),
                this.minDateField5Filter === undefined
                    ? this.minDateField5Filter
                    : this._dateTimeService.getStartOfDayForDate(this.minDateField5Filter),
                this.organizationUnitDisplayNameFilter,
                this.leadSourceTitleFilter,
                this.projectTypeCodeFilter,
                this.sortColumn + ' ' + this.sortDirection,
                this.skipCount,
                this.maxResultCount,
                this.myLeads
            )
            .subscribe((result) => {
                if (result.items && result.items.length > 0) {
                    this.totalRecordCount = result.totalCount;
                    this.leadGridData = this.leadGridData.concat(
                        result.items.map((x) => ({
                            ...x.lead,
                            organizationUnitDisplayName: x.organizationUnitDisplayName,
                            leadSourceId: x.leadSourceTitle,
                            anticipatedEnquiryReceiptDate:
                                x.lead.anticipatedEnquiryReceiptDate != null
                                    ? x.lead.anticipatedEnquiryReceiptDate.toFormat(this.gconsts.dtfShortDisplay)
                                    : null,
                            anticipatedOrderPlacementDate:
                                x.lead.anticipatedOrderPlacementDate != null
                                    ? x.lead.anticipatedOrderPlacementDate.toFormat(this.gconsts.dtfShortDisplay)
                                    : null,
                            dateField1:
                                x.lead.dateField1 != null
                                    ? x.lead.dateField1.toFormat(this.gconsts.dtfShortDisplay)
                                    : null,
                            dateField2:
                                x.lead.dateField2 != null
                                    ? x.lead.dateField2.toFormat(this.gconsts.dtfShortDisplay)
                                    : null,
                            dateField3:
                                x.lead.dateField3 != null
                                    ? x.lead.dateField3.toFormat(this.gconsts.dtfShortDisplay)
                                    : null,
                            dateField4:
                                x.lead.dateField4 != null
                                    ? x.lead.dateField4.toFormat(this.gconsts.dtfShortDisplay)
                                    : null,
                            dateField5:
                                x.lead.dateField5 != null
                                    ? x.lead.dateField5.toFormat(this.gconsts.dtfShortDisplay)
                                    : null,
                        }))
                    );
                }
                this.skipCount += this.pageSettings.pageSize;
            });
    }

    // reloadPage(): void {
    //     this.paginator.changePage(this.paginator.getPage());
    // }

    createLead(id: number = null): void {
        this.createOrEditLeadModal.show(id);
    }

    onModalSave(e) {
        var d = new Date(e.data.anticipatedEnquiryReceiptDate);
        e.data.anticipatedEnquiryReceiptDate = this.datepipe
            .transform(d.toLocaleDateString(), 'yyyy-MM-dd')
            .split('T')[0];
        e.data.anticipatedOrderPlacementDate = e.data.anticipatedOrderPlacementDate.toString().split('T')[0];

        this.createOrEditLeadModal.allLeadSources.filter((x) => {
            if (x.id == e.data.leadSourceId) e.data.leadSourceId = x.displayName;
        });
        if (e.action == 'edit' && e.id > 0) {
            let idx = this.leadGridData.findIndex((x) => x.id == e.id);
            if (idx >= 0) {
                this.leadGridData[idx] = e.data;
            }
        } else if (e.action == 'create') {
            this.leadGridData.push(e.data);
        }
        this.gridlead.refresh();
        // this.paginator.changePage(this.paginator.getPage());
    }

    showHistory(lead: LeadDto): void {
        this.entityTypeHistoryModal.show({
            entityId: lead.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteLead(lead: LeadDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._leadsServiceProxy.delete(lead.id).subscribe(() => {
                    let idx = this.leadGridData.findIndex((x) => x.id == lead.id);
                    if (idx >= 0) {
                        this.leadGridData.splice(idx, 1);
                    }
                    this.gridlead.refresh();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    selectEditTable(table) {
        this.childEntitySelection = {};
        this.childEntitySelection[table] = true;
    }

    openChildRowForLeadContact(index, table) {
        let isAlreadyOpened = this.leadContactRowSelection[index];
        this.closeAllChildRows();
        this.leadContactRowSelection = [];
        if (!isAlreadyOpened) {
            this.leadContactRowSelection[index] = true;
        }
        this.selectEditTable(table);
    }

    closeAllChildRows(): void {
        this.leadContactRowSelection = [];
    }

    getFlexiFields() {
        return new Promise((resolve, reject) => {
            this.spinnerService.show();
            this._utilsServiceProxy
                .getFlexiFieldsBySectionId('lead-information')
                .subscribe((result: FlexiFieldDto[]) => {
                    if (result != null && result.length > 0) {
                        let _flexiFields: any[] = result
                            .filter(
                                (x) => x.isEnabled == true //&&
                                // x.code != "CustomerAddress" &&
                                // x.code != "PostalCode" &&
                                // x.code != "Email" &&
                                // x.code != "Phone" &&
                                // x.code != "AnticipatedOrderPlacementDate" &&
                                // x.code != "ApproxProjectDurationMonths" &&
                                // x.code != "Comments" &&
                                // x.code != "Status"
                            )
                            .map((x) => ({
                                type: x.htmlType,
                                label: x.displayName,
                                headerText: x.displayName,
                                inputType: x.htmlInputType,
                                name: x.code,
                                code: _.camelCase(x.code),
                                field: _.camelCase(x.code),
                                validations: x.validations,
                                width: x.code.toLocaleLowerCase() == 'name' ? 300 : 200,
                            }));

                        _flexiFields.unshift({
                            headerText: this.l('Action'),
                            field: 'action',
                            code: 'action',
                            label: 'Action',
                            template: this.actiontemplate,
                            sortOrder: -1,
                            width: 100,
                        });
                        this.flexiFields = _flexiFields.sort((a, b) => a.sortOrder - b.sortOrder);

                        // this.flexiFields.forEach(element => {
                        //     if(element.inputType == 'date') {
                        //         element.format = this.gconsts.dtfShortDisplay;
                        //     }
                        // });
                        this.gridlead.columns = this.flexiFields;

                        var savedProperties = this.utilsService.getGridSettings('gridlead');
                        if (savedProperties != null && savedProperties.columns != undefined) {
                            savedProperties.columns.forEach((element) => {
                                if (this.gridlead.getColumnByField(element.field) != undefined) {
                                    this.gridlead.getColumnByField(element.field).visible = element.visible;
                                }
                            });
                        } else {
                            let fields: string[] = [
                                'action',
                                'customerAddress',
                                'postalCode',
                                'email',
                                'phone',
                                'endUser',
                                'anticipatedOrderPlacementDate',
                                'approxProjectDurationMonths',
                                'comments',
                            ];
                            this.flexiFields.forEach((element) => {
                                if (
                                    this.gridlead.getColumnByField(element.field) != undefined &&
                                    fields.indexOf(element.field) === -1
                                ) {
                                    this.gridlead.getColumnByField(element.field).visible = false;
                                }
                            });
                        }
                        this.gridlead.refreshColumns();
                        this.spinnerService.hide();
                        resolve(true);
                    }
                    this.spinnerService.hide();
                    resolve(false);
                });
        });
    }

    onActionBegin(args) {
        if (args.requestType == 'refresh' && this.scrollVal > 0) {
            this.gridlead.getContent().firstElementChild.scrollTop = this.scrollVal;
        }
        if (args.requestType == 'searching') {
            this.filterText = args.searchString;
            this.getAll();
        }
        if (args.requestType == 'beginEdit') {
            this.createOrEditLeadModal.show(args.rowData.id);
        } else if (args.requestType == 'delete') {
            this.deleteLead(args.data[0].id);
        }
        // if (args.requestType == "paging") {
        //     this.skipCount = (args.currentPage - 1) * this.pageSettings.pageSize;
        //     this.pageSettings.currentPage = args.currentPage;
        //     this.getAll();
        // }
        else if (args.requestType == 'sorting' && args.columnName) {
            this.skipCount = 0;
            this.leadGridData = [];
            this.sortColumn = args.columnName;
            this.sortDirection = args.direction == 'Ascending' ? 'asc' : 'desc';
            this.getAll();
        } else if (args.requestType === 'infiniteScroll' && this.leadGridData.length < this.totalRecordCount) {
            this.skipCount += this.maxResultCount;
            this.scrollVal = this.gridlead.getContent().firstElementChild.scrollTop;
            this.getAll();
        } else if (args.requestType == 'columnstate') {
            if (args.columns && args.columns.length > 0) {
                var savedProperties = JSON.parse(this.gridlead.getPersistData());
                var gridColumnsState = Object.assign([], this.gridlead.getColumns());
                savedProperties.columns.forEach(function (col) {
                    args.columns.forEach((element) => {
                        if (element.uid == col.uid) {
                            col.visible = element.visible;
                        }
                    });
                });
                this.utilsService.updateGridSettings('gridlead', savedProperties);
            }
        }
    }

    beforeDataBound(e) {
        this.pageSettings.totalRecordsCount = this.totalRecordCount;
    }

    // exportToExcel(): void {
    //     this._leadsServiceProxy
    //         .getLeadsToExcel(
    //             this.filterText,
    //             this.projectNameFilter,
    //             this.customerNameFilter,
    //             this.customerAddressFilter,
    //             this.postalcodeFilter,
    //             this.emailfilter,
    //             this.phonefilter,
    //             this.siteNameFilter,
    //             this.endUserFilter,
    //             this.maxOrderProbabilityPercFilter == null
    //                 ? this.maxOrderProbabilityPercFilterEmpty
    //                 : this.maxOrderProbabilityPercFilter,
    //             this.minOrderProbabilityPercFilter == null
    //                 ? this.minOrderProbabilityPercFilterEmpty
    //                 : this.minOrderProbabilityPercFilter,
    //             this.budgetOrderValueFilter,
    //             this.maxAnticipatedEnquiryReceiptDateFilter === undefined
    //                 ? this.maxAnticipatedEnquiryReceiptDateFilter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxAnticipatedEnquiryReceiptDateFilter),
    //             this.minAnticipatedEnquiryReceiptDateFilter === undefined
    //                 ? this.minAnticipatedEnquiryReceiptDateFilter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minAnticipatedEnquiryReceiptDateFilter),
    //             this.maxAnticipatedOrderPlacementDateFilter === undefined
    //                 ? this.maxAnticipatedOrderPlacementDateFilter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxAnticipatedOrderPlacementDateFilter),
    //             this.minAnticipatedOrderPlacementDateFilter === undefined
    //                 ? this.minAnticipatedOrderPlacementDateFilter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minAnticipatedOrderPlacementDateFilter),
    //             this.maxApproxProjectDurationMonthsFilter == null
    //                 ? this.maxApproxProjectDurationMonthsFilterEmpty
    //                 : this.maxApproxProjectDurationMonthsFilter,
    //             this.minApproxProjectDurationMonthsFilter == null
    //                 ? this.minApproxProjectDurationMonthsFilterEmpty
    //                 : this.minApproxProjectDurationMonthsFilter,
    //             this.commentsFilter,
    //             this.statusFilter,
    //             this.stringField1Filter,
    //             this.stringField2Filter,
    //             this.stringField3Filter,
    //             this.stringField4Filter,
    //             this.stringField5Filter,
    //             this.maxDecimalField1Filter == null ? this.maxDecimalField1FilterEmpty : this.maxDecimalField1Filter,
    //             this.minDecimalField1Filter == null ? this.minDecimalField1FilterEmpty : this.minDecimalField1Filter,
    //             this.maxDecimalField2Filter == null ? this.maxDecimalField2FilterEmpty : this.maxDecimalField2Filter,
    //             this.minDecimalField2Filter == null ? this.minDecimalField2FilterEmpty : this.minDecimalField2Filter,
    //             this.maxDecimalField3Filter == null ? this.maxDecimalField3FilterEmpty : this.maxDecimalField3Filter,
    //             this.minDecimalField3Filter == null ? this.minDecimalField3FilterEmpty : this.minDecimalField3Filter,
    //             this.maxDecimalField4Filter == null ? this.maxDecimalField4FilterEmpty : this.maxDecimalField4Filter,
    //             this.minDecimalField4Filter == null ? this.minDecimalField4FilterEmpty : this.minDecimalField4Filter,
    //             this.maxDecimalField5Filter == null ? this.maxDecimalField5FilterEmpty : this.maxDecimalField5Filter,
    //             this.minDecimalField5Filter == null ? this.minDecimalField5FilterEmpty : this.minDecimalField5Filter,
    //             this.maxDateField1Filter === undefined
    //                 ? this.maxDateField1Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField1Filter),
    //             this.minDateField1Filter === undefined
    //                 ? this.minDateField1Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField1Filter),
    //             this.maxDateField2Filter === undefined
    //                 ? this.maxDateField2Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField2Filter),
    //             this.minDateField2Filter === undefined
    //                 ? this.minDateField2Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField2Filter),
    //             this.maxDateField3Filter === undefined
    //                 ? this.maxDateField3Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField3Filter),
    //             this.minDateField3Filter === undefined
    //                 ? this.minDateField3Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField3Filter),
    //             this.maxDateField4Filter === undefined
    //                 ? this.maxDateField4Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField4Filter),
    //             this.minDateField4Filter === undefined
    //                 ? this.minDateField4Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField4Filter),
    //             this.maxDateField5Filter === undefined
    //                 ? this.maxDateField5Filter
    //                 : this._dateTimeService.getEndOfDayForDate(this.maxDateField5Filter),
    //             this.minDateField5Filter === undefined
    //                 ? this.minDateField5Filter
    //                 : this._dateTimeService.getStartOfDayForDate(this.minDateField5Filter),
    //             this.organizationUnitDisplayNameFilter,
    //             this.leadSourceTitleFilter,
    //             this.projectTypeCodeFilter
    //         )
    //         .subscribe((result) => {
    //             this._fileDownloadService.downloadTempFile(result);
    //         });
    // }

    dataBound(e): void {
        this.gridlead.autoFitColumns([
            'anticipatedEnquiryReceiptDate',
            'anticipatedOrderPlacementDate',
            'approxProjectDurationMonths',
        ]);
        // this.gridlead.autoFitColumns();
        this.gridlead.hideScroll();
    }

    filterMyLeads(e) {
        this.skipCount = 0;
        this.myLeads = !this.chkMyLeads.checked;
        this.leadGridData = [];
        this.totalRecordCount = 0;
        this.getAll();
    }

    toolbarClick(args): void {
        if (args.item.id === 'gridlead_excelexport') {
            (this.gridlead.columns[0] as Column).visible = false;
            const excelExportProperties: ExcelExportProperties = {
                fileName: 'Lead.xlsx',
                exportType: 'AllPages',
            };
            this.gridlead.excelExport(excelExportProperties);
            for (const columns of this.gridlead.columns) {
                if ((columns as Column).headerText === 'Action') {
                    (columns as Column).visible = false;
                    exportType: 'AllPages';
                }
            }
        }
    }

    load(e) {
        (this.gridlead.localeObj as any).localeStrings.Excelexport = 'Export To Excel';
        (this.gridlead.localeObj as any).localeStrings.Print = 'Print';
    }
}
