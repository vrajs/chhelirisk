﻿import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
    imports: [
        RouterModule.forChild([
            {
                path: '',
                children: [

                    {
                        path: 'projects/statusOfSubmittedQuotes',
                        loadChildren: () => import('./projects/statusOfSubmittedQuotes/statusOfSubmittedQuote.module').then(m => m.StatusOfSubmittedQuoteModule),
                        data: { permission: 'Pages.StatusOfSubmittedQuotes' }
                    },


                    {
                        path: 'projects/projectPreOrderInformations',
                        loadChildren: () => import('./projects/projectPreOrderInformations/projectPreOrderInformation.module').then(m => m.ProjectPreOrderInformationModule),
                        data: { permission: 'Pages.ProjectPreOrderInformations' }
                    },
                    {
                        path: 'projects/projectsMRABPLs',
                        loadChildren: () => import('./projects/projectsMRABPLs/projectMRABPL.module').then(m => m.ProjectMRABPLModule),
                        data: { permission: 'Pages.ProjectMRABPLs' }
                    },


                    {
                        path: 'projects/projectOpsConfirOfHands',
                        loadChildren: () => import('./projects/projectOpsConfirOfHands/projectOpsConfirOfHand.module').then(m => m.ProjectOpsConfirOfHandModule),
                        data: { permission: 'Pages.ProjectOpsConfirOfHands' }
                    },
                    {
                        path: 'projects/projectSalesToOpsHands',
                        loadChildren: () => import('./projects/projectSalesToOpsHands/projectSalesToOpsHand.module').then(m => m.ProjectSalesToOpsHandModule),
                        data: { permission: 'Pages.ProjectSalesToOpsHands' }
                    },
                     {
                        path: 'projects/projectPTCWs',
                        loadChildren: () => import('./projects/projectPTCWs/projectPTCW.module').then(m => m.ProjectPTCWModule),
                        data: { permission: 'Pages.ProjectPTCWs' }
                    },
                    {
                        path: 'projects/projectComRevOfCCs',
                        loadChildren: () => import('./projects/projectComRevOfCCs/projectComRevOfCC.module').then(m => m.ProjectComRevOfCCModule),
                        data: { permission: 'Pages.ProjectComRevOfCCs' }
                    },
                    {
                        path: 'projects/projectPersonnels',
                        loadChildren: () => import('./projects/projectPersonnels/projectPersonnel.module').then(m => m.ProjectPersonnelModule),
                        data: { permission: 'Pages.ProjectPersonnels' }
                    },

                    {
                        path: 'projects/projectQFDelegations',
                        loadChildren: () => import('./projects/projectQFDelegations/projectQFDelegation.module').then(m => m.ProjectQFDelegationModule),
                        data: { permission: 'Pages.ProjectQFDelegations' }
                    },

                    {
                        path: 'projects/projectQuoteForms',
                        loadChildren: () => import('./projects/projectQuoteForms/projectQuoteForm.module').then(m => m.ProjectQuoteFormModule),
                        data: { permission: 'Pages.ProjectQuoteForms' }
                    },


                    {
                        path: 'projects/projectSubcontractors',
                        loadChildren: () => import('./projects/projectSubcontractors/projectSubcontractor.module').then(m => m.ProjectSubcontractorModule),
                        data: { permission: 'Pages.ProjectSubcontractors' }
                    },


                    {
                        path: 'projects/projectKeyDeliverables',
                        loadChildren: () => import('./projects/projectKeyDeliverables/projectKeyDeliverable.module').then(m => m.ProjectKeyDeliverableModule),
                        data: { permission: 'Pages.ProjectKeyDeliverables' }
                    },


                    {
                        path: 'projects/projectReviewPlans',
                        loadChildren: () => import('./projects/projectReviewPlans/projectReviewPlan.module').then(m => m.ProjectReviewPlanModule),
                        data: { permission: 'Pages.ProjectReviewPlans' }
                    },


                    {
                        path: 'projects/projectExReviewRiskOpps',
                        loadChildren: () => import('./projects/projectExReviewRiskOpps/projectExReviewRiskOpp.module').then(m => m.ProjectExReviewRiskOppModule),
                        data: { permission: 'Pages.ProjectExReviewRiskOpps' }
                    },


                    {
                        path: 'projects/projectExReviewAppInvoiceForecasts',
                        loadChildren: () => import('./projects/projectExReviewAppInvoiceForecasts/projectExReviewAppInvoiceForecast.module').then(m => m.ProjectExReviewAppInvoiceForecastModule),
                        data: { permission: 'Pages.ProjectExReviewAppInvoiceForecasts' }
                    },


                    {
                        path: 'projects/projectBaselinePrograms',
                        loadChildren: () => import('./projects/projectBaselinePrograms/projectBaselineProgram.module').then(m => m.ProjectBaselineProgramModule),
                        data: { permission: 'Pages.ProjectBaselinePrograms' }
                    },


                    {
                        path: 'projects/projectCostDetails',
                        loadChildren: () => import('./projects/projectCostDetails/projectCostDetail.module').then(m => m.ProjectCostDetailModule),
                        data: { permission: 'Pages.ProjectCostDetails' }
                    },


                    {
                        path: 'projects/projectExReviewDetails',
                        loadChildren: () => import('./projects/projectExReviewDetails/projectExReviewDetail.module').then(m => m.ProjectExReviewDetailModule),
                        data: { permission: 'Pages.ProjectExReviewDetails' }
                    },


                    {
                        path: 'projects/projectExReviews',
                        loadChildren: () => import('./projects/projectExReviews/projectExReview.module').then(m => m.ProjectExReviewModule),
                        data: { permission: 'Pages.ProjectExReviews' }
                    },


                    {
                        path: 'projects/projectActions',
                        loadChildren: () => import('./projects/projectActions/projectAction.module').then(m => m.ProjectActionModule),
                        data: { permission: 'Pages.ProjectActions' }
                    },




                    {
                        path: 'siteRefConfig/siteRefConfigs',
                        loadChildren: () => import('./siteRefConfig/siteRefConfigs/siteRefConfig.module').then(m => m.SiteRefConfigModule),
                        data: { permission: 'Pages.SiteRefConfigs' }
                    },


                    {
                        path: 'projects/projectCommercials',
                        loadChildren: () => import('./projects/projectCommercials/projectCommercial.module').then(m => m.ProjectCommercialModule),
                        data: { permission: 'Pages.ProjectCommercials' }
                    },


                    {
                        path: 'projects/projectEngineerings',
                        loadChildren: () => import('./projects/projectEngineerings/projectEngineering.module').then(m => m.ProjectEngineeringModule),
                        data: { permission: 'Pages.ProjectEngineerings' }
                    },


                    {
                        path: 'projects/projectEstimates',
                        loadChildren: () => import('./projects/projectEstimates/projectEstimate.module').then(m => m.ProjectEstimateModule),
                        data: { permission: 'Pages.ProjectEstimates' }
                    },


                    // {
                    //     path: 'projects/projects',
                    //     loadChildren: () => import('./projects/projects/projects.module').then(m => m.ProjectsModule),
                    //     data: { permission: 'Pages.Projects' }
                    // },


                    {
                        path: 'projects',
                        loadChildren: () => import('./projects/projects/projects.module').then(m => m.ProjectsModule),
                        data: { permission: 'Pages.Projects' }
                    },
                    {
                        path: 'sales',
                        loadChildren: () => import('./sales/sales.module').then(m => m.SalesModule),
                        data: { permission: 'Pages.Leads' }
                    },
                    {
                        path: 'leads/leadContacts',
                        loadChildren: () => import('./leads/leadContacts/leadContact.module').then(m => m.LeadContactModule),
                        data: { permission: 'Pages.LeadContacts' }
                    },
                    {
                        path: 'leads/leads',
                        loadChildren: () => import('./leads/leads/lead.module').then(m => m.LeadModule),
                        data: { permission: 'Pages.Leads' }
                    },

                    {
                        path: 'leads/leadSources',
                        loadChildren: () => import('./leads/leadSources/leadSource.module').then(m => m.LeadSourceModule),
                        data: { permission: 'Pages.LeadSources' }
                    },

                    {
                        path: 'customers/contactPersons',
                        loadChildren: () => import('./customers/contactPersons/contactPerson.module').then(m => m.ContactPersonModule),
                        data: { permission: 'Pages.ContactPersons' }
                    },

                    {
                        path: 'customers/customers',
                        loadChildren: () => import('./customers/customers/customer.module').then(m => m.CustomerModule),
                        data: { permission: 'Pages.Customers' }
                    },

                    {
                        path: 'dashboard',
                        loadChildren: () => import('./dashboard/dashboard.module').then((m) => m.DashboardModule),
                        data: { permission: 'Pages.Tenant.Dashboard' },
                    },
                    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
                    { path: '**', redirectTo: 'dashboard' },
                ],
            },
        ]),
    ],
    exports: [RouterModule],
})
export class MainRoutingModule {}
