﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    ProjectActionsServiceProxy,
    CreateOrEditProjectActionDto,
    ProjectActionProjectLookupTableDto,
    ProjectActionNodeActionLookupTableDto,
    ProjectActionNodeTaskLookupTableDto,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    selector: 'createOrEditProjectActionModal',
    templateUrl: './create-or-edit-projectAction-modal.component.html',
})
export class CreateOrEditProjectActionModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    projectAction: CreateOrEditProjectActionDto = new CreateOrEditProjectActionDto();

    projectProjectName = '';
    nodeActionTitle = '';
    nodeActionTitle2 = '';
    nodeTaskTaskName = '';
    nodeTaskTaskName2 = '';

    allProjects: ProjectActionProjectLookupTableDto[];
    allNodeActions: ProjectActionNodeActionLookupTableDto[];
    allNodeTasks: ProjectActionNodeTaskLookupTableDto[];

    constructor(
        injector: Injector,
        private _projectActionsServiceProxy: ProjectActionsServiceProxy,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    show(projectActionId?: number): void {
        if (!projectActionId) {
            this.projectAction = new CreateOrEditProjectActionDto();
            this.projectAction.id = projectActionId;
            this.projectProjectName = '';
            this.nodeActionTitle = '';
            this.nodeActionTitle2 = '';
            this.nodeTaskTaskName = '';
            this.nodeTaskTaskName2 = '';

            this.active = true;
            this.modal.show();
        } else {
            this._projectActionsServiceProxy.getProjectActionForEdit(projectActionId).subscribe((result) => {
                this.projectAction = result.projectAction;

                this.projectProjectName = result.projectProjectName;
                this.nodeActionTitle = result.nodeActionTitle;
                this.nodeActionTitle2 = result.nodeActionTitle2;
                this.nodeTaskTaskName = result.nodeTaskTaskName;
                this.nodeTaskTaskName2 = result.nodeTaskTaskName2;

                this.active = true;
                this.modal.show();
            });
        }
        this._projectActionsServiceProxy.getAllProjectForTableDropdown().subscribe((result) => {
            this.allProjects = result;
        });
        this._projectActionsServiceProxy.getAllNodeActionForTableDropdown().subscribe((result) => {
            this.allNodeActions = result;
        });
        this._projectActionsServiceProxy.getAllNodeActionForTableDropdown().subscribe((result) => {
            this.allNodeActions = result;
        });
        this._projectActionsServiceProxy.getAllNodeTaskForTableDropdown().subscribe((result) => {
            this.allNodeTasks = result;
        });
        this._projectActionsServiceProxy.getAllNodeTaskForTableDropdown().subscribe((result) => {
            this.allNodeTasks = result;
        });
    }

    save(): void {
        this.saving = true;

        this._projectActionsServiceProxy
            .createOrEdit(this.projectAction)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
            });
    }

    close(): void {
        this.active = false;
        this.modal.hide();
    }

    ngOnInit(): void {}
}
