﻿import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProjectActionsComponent } from './projectActions.component';

const routes: Routes = [
    {
        path: '',
        component: ProjectActionsComponent,
        pathMatch: 'full',
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ProjectActionRoutingModule {}
