﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { ProjectActionRoutingModule } from './projectAction-routing.module';
import { ProjectActionsComponent } from './projectActions.component';
import { CreateOrEditProjectActionModalComponent } from './create-or-edit-projectAction-modal.component';
import { ViewProjectActionModalComponent } from './view-projectAction-modal.component';

@NgModule({
    declarations: [ProjectActionsComponent, CreateOrEditProjectActionModalComponent, ViewProjectActionModalComponent],
    imports: [AppSharedModule, ProjectActionRoutingModule, AdminSharedModule],
})
export class ProjectActionModule {}
