﻿import { AppConsts } from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectActionsServiceProxy, ProjectActionDto } from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { CreateOrEditProjectActionModalComponent } from './create-or-edit-projectAction-modal.component';

import { ViewProjectActionModalComponent } from './view-projectAction-modal.component';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    templateUrl: './projectActions.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class ProjectActionsComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;
    @ViewChild('createOrEditProjectActionModal', { static: true })
    createOrEditProjectActionModal: CreateOrEditProjectActionModalComponent;
    @ViewChild('viewProjectActionModalComponent', { static: true })
    viewProjectActionModal: ViewProjectActionModalComponent;

    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;

    advancedFiltersAreShown = false;
    filterText = '';
    statusFilter = '';
    metaDataFilter = '';
    projectProjectNameFilter = '';
    nodeActionTitleFilter = '';
    nodeActionTitle2Filter = '';
    nodeTaskTaskNameFilter = '';
    nodeTaskTaskName2Filter = '';

    _entityTypeFullName = 'asq.econsys.Eco.Projects.ProjectAction';
    entityHistoryEnabled = false;

    constructor(
        injector: Injector,
        private _projectActionsServiceProxy: ProjectActionsServiceProxy,
        private _notifyService: NotifyService,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.entityHistoryEnabled = this.setIsEntityHistoryEnabled();
    }

    private setIsEntityHistoryEnabled(): boolean {
        let customSettings = (abp as any).custom;
        return (
            this.isGrantedAny('Pages.Administration.AuditLogs') &&
            customSettings.EntityHistory &&
            customSettings.EntityHistory.isEnabled &&
            _filter(
                customSettings.EntityHistory.enabledEntities,
                (entityType) => entityType === this._entityTypeFullName
            ).length === 1
        );
    }

    getProjectActions(event?: LazyLoadEvent) {
        if (this.primengTableHelper.shouldResetPaging(event)) {
            this.paginator.changePage(0);
            if (this.primengTableHelper.records && this.primengTableHelper.records.length > 0) {
                return;
            }
        }

        this.primengTableHelper.showLoadingIndicator();

        this._projectActionsServiceProxy
            .getAll(
                this.filterText,
                this.statusFilter,
                this.metaDataFilter,
                this.projectProjectNameFilter,
                this.nodeActionTitleFilter,
                this.nodeActionTitle2Filter,
                this.nodeTaskTaskNameFilter,
                this.nodeTaskTaskName2Filter,
                this.primengTableHelper.getSorting(this.dataTable),
                this.primengTableHelper.getSkipCount(this.paginator, event),
                this.primengTableHelper.getMaxResultCount(this.paginator, event)
            )
            .subscribe((result) => {
                this.primengTableHelper.totalRecordsCount = result.totalCount;
                this.primengTableHelper.records = result.items;
                this.primengTableHelper.hideLoadingIndicator();
            });
    }

    reloadPage(): void {
        this.paginator.changePage(this.paginator.getPage());
    }

    createProjectAction(): void {
        this.createOrEditProjectActionModal.show();
    }

    showHistory(projectAction: ProjectActionDto): void {
        this.entityTypeHistoryModal.show({
            entityId: projectAction.id.toString(),
            entityTypeFullName: this._entityTypeFullName,
            entityTypeDescription: '',
        });
    }

    deleteProjectAction(projectAction: ProjectActionDto): void {
        this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
            if (isConfirmed) {
                this._projectActionsServiceProxy.delete(projectAction.id).subscribe(() => {
                    this.reloadPage();
                    this.notify.success(this.l('SuccessfullyDeleted'));
                });
            }
        });
    }

    exportToExcel(): void {
        this._projectActionsServiceProxy
            .getProjectActionsToExcel(
                this.filterText,
                this.statusFilter,
                this.metaDataFilter,
                this.projectProjectNameFilter,
                this.nodeActionTitleFilter,
                this.nodeActionTitle2Filter,
                this.nodeTaskTaskNameFilter,
                this.nodeTaskTaskName2Filter
            )
            .subscribe((result) => {
                this._fileDownloadService.downloadTempFile(result);
            });
    }
}
