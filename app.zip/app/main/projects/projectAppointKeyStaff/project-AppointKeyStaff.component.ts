import {
    Component,
    ElementRef,
    EventEmitter,
    Injector,
    Input,
    Output,
    ViewChild,
    ViewChildren,
    ViewEncapsulation,
    OnInit,
    AfterViewInit,
    QueryList

} from '@angular/core';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DashboardCustomizationConst } from '@app/shared/common/customizable-dashboard/DashboardCustomizationConsts';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import {
    CreateOrEditProjectPersonnelDto,
    GetProjectForViewDto,
    GetProjectRuleForViewDto,
    PagedResultDtoOfUserListDto,
    ProjectPersonnelsServiceProxy,
    ProjectsServiceProxy,
    UserListDto,
    UserServiceProxy,
    UtilsServiceProxy,
    CreateOrEditProjectAppointKeyStaffDto

} from '@shared/service-proxies/service-proxies';
import { finalize } from 'rxjs/operators';
import { DialogComponent } from '@syncfusion/ej2-angular-popups';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { ProjectViewWorkloadComponent } from '../projectViewWorkload/project-viewWorkload.component';
import { FormBuilder, FormGroup, ValidationErrors, Validators, ReactiveFormsModule, FormControl } from '@angular/forms';

@Component({
    templateUrl: './project-AppointKeyStaff.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
    selector: 'projectAppointKeyStaffComponent',
})
export class ProjectAppointKeyStaffComponent extends AppComponentBase implements OnInit, AfterViewInit {
    @ViewChild('viewWorkLoadModal', { static: true }) modal: ModalDirective;
    @ViewChildren('projectViewWorkloadComponent')
    public projectViewWorkloadComponents: QueryList<ProjectViewWorkloadComponent>;
    public projectViewWorkloadComponent: ProjectViewWorkloadComponent;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();
    @Input() projectId?: number;
    @Input() taskId?: string;
    @Input() stageId?: string;
    EngineeringLeaders: UserListDto[] = [];
    CommercialLeaders: UserListDto[] = [];
    ProjectLeaders: UserListDto[] = [];
    EngineeringLeader: any;
    ProjectLeader: any;
    CommercialLeader: any;
    workload: GetProjectForViewDto[] = [];
    allProjectPersonnel: any;
    allProjectPersonnelfilter: any;
    DeliverAs: any;
    Mode: any;

    userId: any;
    roleId: any;
    active = false;
    saving = false;

    filterText = '';
    organizationUnitDisplayNameFilter = '';
    projectProjectNameFilter = '';
    userNameFilter = '';
    roleNameFilter = '';
    nodeStageNameFilter = '';
    nodeTaskNameFilter = '';
    frmFG: FormGroup = this.fb.group({});
    hasAccess: boolean = false;

    constructor(
        injector: Injector,
        private _projectsServiceProxy: ProjectsServiceProxy,
        private _userServiceProxy: UserServiceProxy,
        private _utilserviceProxy: UtilsServiceProxy,
        private _projectPersonnelsServiceProxy: ProjectPersonnelsServiceProxy,
        private fb: FormBuilder
    ) {
        super(injector);
    }

    ngOnInit() { }

    ngAfterViewInit() {
        //this.hasAccess = this.permission.isGranted('Pages.Projects.AssignSalesLeader');
        this.projectViewWorkloadComponents.changes.subscribe((comps: QueryList<ProjectViewWorkloadComponent>) => {
            this.projectViewWorkloadComponent = comps.first;
        });
        this.show(this.projectId);
    }

    show(projectId?: number): void {
        this.active = true;
        this.projectId = projectId;

        this.getEngineeringLeaders();
        this.getCommercialLeaders();
        this.getProjectLeaders();

        this.frmFG = this.fb.group({
            projectId: [this.projectId, Validators.required],
            engineeringleaderuserId: [''],
            commercialleaderuserId: [''],
            projectleaderuserId: [''],
            comment: [''],
        });
        //this.Mode = ActionMode;

        if (!(projectId > 0)) {
            this.notify.error(this.l('Please select a project to proceed.'));
        }
    }

    

    getEngineeringLeaders() {
        this._utilserviceProxy
            .getUsersWithRole(this.genums.projectRoles.ENGINEERINGLEADER.title)
            .pipe(finalize(() => { }))
            .subscribe((result) => {
                this.EngineeringLeaders = result;
                this.EngineeringLeaders.map((x) => {
                    x.name = x.name + ' ' + x.surname + ' ( ' + x.emailAddress + ' )',
                        x.id = x.id;
                });
                this.setEngineeringLeaderFormValue();
            });
    }

    getCommercialLeaders() {
        this._utilserviceProxy
            .getUsersWithRole(this.genums.projectRoles.COMMERCIALLEADER.title)
            .pipe(finalize(() => { }))
            .subscribe((result) => {
                this.CommercialLeaders = result;
                this.CommercialLeaders.map((x) => {
                    x.name = x.name + ' ' + x.surname + ' ( ' + x.emailAddress + ' )';
                });
                this.setCommercialLeaderFormValue();
            });
    }

    getProjectLeaders() {
        this._utilserviceProxy
            .getUsersWithRole(this.genums.projectRoles.PROJECTLEAD.title)
            .pipe(finalize(() => { }))
            .subscribe((result) => {
                this.ProjectLeaders = result;
                //console.log(result);
                this.ProjectLeaders.map((x) => {
                    x.name = x.name + ' ' + x.surname + ' ( ' + x.emailAddress + ' )';
                });
                this.setProjectLeaderFormValue();
            });
    }

    showWorkload(TypeUser: any): void {
        if (TypeUser == 0) {
            this.projectViewWorkloadComponent.viewWorkload(this.frmFG.get('engineeringleaderuserId').value);
        }
        else if (TypeUser == 1) {
            this.projectViewWorkloadComponent.viewWorkload(this.frmFG.get('commercialleaderuserId').value);
        }
        else if (TypeUser == 2) {
            this.projectViewWorkloadComponent.viewWorkload(this.frmFG.get('projectleaderuserId').value);
        }
    }

    save(statusId: string = this.genums.projectStatuses.save.code): void {
        if (this.frmFG.get('engineeringleaderuserId').value == null || this.frmFG.get('engineeringleaderuserId').value == '') {
            abp.notify.error(this.l('Please select Enginnering Lead'));
            this.frmFG.get('engineeringleaderuserId').markAsDirty();
            this.frmFG.get('engineeringleaderuserId').markAllAsTouched();
            return;
        }
        if (this.frmFG.get('commercialleaderuserId').value == null || this.frmFG.get('commercialleaderuserId').value == '') {
            abp.notify.error(this.l('Please select Commercial Lead'));
            this.frmFG.get('commercialleaderuserId').markAsDirty();
            this.frmFG.get('commercialleaderuserId').markAllAsTouched();
            return;
        }
        if (this.frmFG.get('projectleaderuserId').value == null || this.frmFG.get('projectleaderuserId').value == '') {
            abp.notify.error(this.l('Please select Commercial Lead'));
            this.frmFG.get('projectleaderuserId').markAsDirty();
            this.frmFG.get('projectleaderuserId').markAllAsTouched();
            return;
        }
        if (!this.frmFG.valid) {
            this.notify.warn(this.l('Invalid inputs'));
            return;
        }
        let formData: any = {};
        formData.projectId = this.projectId;
        formData.nodeStageId = this.stageId;
        formData.statusId = statusId;
        formData.nodeTaskId = this.genums.projectTasks.APPOINTKEYSTAFF.code;
        formData.comment = this.frmFG.get('comment').value;
        formData.UserRoleList = [];
      
        
        let user = this.EngineeringLeaders.filter((x) => x.id == this.frmFG.get('engineeringleaderuserId').value)[0];
       
        if (user) {
            //console.log(this.allProjectPersonnel);
            //var formData = new CreateOrEditProjectAppointKeyStaffDto();
            this.userId = this.frmFG.get('engineeringleaderuserId').value;
            var Enginneeringcheck = this.allProjectPersonnel.filter(x=>x.nodeTaskTaskName == this.genums.projectTasks.APPOINTKEYSTAFF.title 
                && x.roleName==this.genums.projectRoles.ENGINEERINGLEADER.title);
            if (Enginneeringcheck.length != 0) {
                formData.id = Enginneeringcheck[0].projectPersonnel.id;
            }
            this.roleId = user.roles.filter(x => x.roleName == this.genums.projectRoles.ENGINEERINGLEADER.title)[0].roleId;
            formData.UserRoleList.push({userid: this.userId,roleid:this.roleId, id: formData.id})
        }

        this.userId = this.frmFG.get('commercialleaderuserId').value;
        user = this.CommercialLeaders.filter((x) => x.id == this.frmFG.get('commercialleaderuserId').value)[0];
        if (user) {
            var CommercialCheck = this.allProjectPersonnel.filter(x=>x.nodeTaskTaskName == this.genums.projectTasks.APPOINTKEYSTAFF.title 
                && x.roleName==this.genums.projectRoles.COMMERCIALLEADER.title);
            if (CommercialCheck.length != 0) {
                formData.id = CommercialCheck[0].projectPersonnel.id;
            }
            // var formData = new CreateOrEditProjectAppointKeyStaffDto();
            this.roleId = user.roles.filter(x => x.roleName == this.genums.projectRoles.COMMERCIALLEADER.title)[0].roleId;
            formData.UserRoleList.push({userid: this.userId,roleid:this.roleId, id: formData.id})
        }

        this.userId = this.frmFG.get('projectleaderuserId').value;

        user = this.ProjectLeaders.filter((x) => x.id == this.frmFG.get('projectleaderuserId').value)[0];
        if (user) {

            var ProjectLeaderCheck = this.allProjectPersonnel.filter(x=>x.nodeTaskTaskName == this.genums.projectTasks.APPOINTKEYSTAFF.title 
                && x.roleName==this.genums.projectRoles.PROJECTLEAD.title);
            if (ProjectLeaderCheck.length != 0) {
                formData.id = ProjectLeaderCheck[0].projectPersonnel.id;
            }
            this.roleId = user.roles.filter(x => x.roleName == this.genums.projectRoles.PROJECTLEAD.title)[0].roleId;
            formData.UserRoleList.push({userid: this.userId,roleid:this.roleId, id: formData.id})
        }

        this.spinnerService.show();
        this._projectPersonnelsServiceProxy.createOrEditAppointKeyStaff(formData).subscribe(
            (result) => {
                this.modalSave.emit(result);
                this.spinnerService.hide();

                this.notify.info(this.l('SavedSuccessfully'));
                this.saving = false;
                this.frmFG.get('comment').setValue('');
            },
            () => {
                this.spinnerService.hide();
                this.saving = false;
            }
        );
    }

    close(): void {
        this.modal.hide();
    }

    getFormValidationErrors() {
        Object.keys(this.frmFG.controls).forEach((key) => {
            const controlErrors: ValidationErrors = this.frmFG.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach((keyError) => {
                    console.log(
                        'Key control: ' + key + ', keyError: ' + keyError + ', err value: ',
                        controlErrors[keyError]
                    );
                    this.frmFG.get(key).markAsDirty();
                    this.frmFG.get(key).markAllAsTouched();
                });
            }
        });
    }

    setEngineeringLeaderFormValue() {
        this._projectsServiceProxy.getProjectPersonnel(this.projectId).subscribe((result) => {
            this.allProjectPersonnel = result.filter(x=>x.nodeTaskTaskName == this.genums.projectTasks.APPOINTKEYSTAFF.title);
            this.allProjectPersonnelfilter = this.allProjectPersonnel.filter(x=>x.roleName==this.genums.projectRoles.ENGINEERINGLEADER.title);
            if (this.allProjectPersonnelfilter.length != 0) {
                var currentEnginerringLeader = this.EngineeringLeaders.filter(
                    (x) => x.id == this.allProjectPersonnelfilter[0].projectPersonnel.userId
                );
                this.frmFG.get('engineeringleaderuserId').setValue(currentEnginerringLeader[0].id);
            }
        });
    }

    setCommercialLeaderFormValue() {
        this._projectsServiceProxy.getProjectPersonnel(this.projectId).subscribe((result) => {
            this.allProjectPersonnel = result.filter(x=>x.nodeTaskTaskName == this.genums.projectTasks.APPOINTKEYSTAFF.title);
            this.allProjectPersonnelfilter = this.allProjectPersonnel.filter(x=>x.roleName==this.genums.projectRoles.COMMERCIALLEADER.title);
            if (this.allProjectPersonnelfilter.length != 0) {
                var currentCommercialleader = this.CommercialLeaders.filter(
                    (x) => x.id == this.allProjectPersonnelfilter[0].projectPersonnel.userId
                );
                this.frmFG.get('commercialleaderuserId').setValue(currentCommercialleader[0].id);
            }
        });
    }

    setProjectLeaderFormValue() {
        this._projectsServiceProxy.getProjectPersonnel(this.projectId).subscribe((result) => {
            this.allProjectPersonnel = result.filter(x=>x.nodeTaskTaskName == this.genums.projectTasks.APPOINTKEYSTAFF.title);
            this.allProjectPersonnelfilter = this.allProjectPersonnel.filter(x=>x.roleName==this.genums.projectRoles.PROJECTLEAD.title);
            if (this.allProjectPersonnelfilter.length != 0) {
                var currentProjectLeader = this.ProjectLeaders.filter(
                    (x) => x.id == this.allProjectPersonnelfilter[0].projectPersonnel.userId
                );
                this.frmFG.get('projectleaderuserId').setValue(currentProjectLeader[0].id);
            }
        });
    }
}
