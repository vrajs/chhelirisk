import { NgModule } from '@angular/core';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { DialogModule } from '@syncfusion/ej2-angular-popups';
import { ProjectViewWorkloadModule } from '../projectViewWorkload/project-viewWorkload.module';
import { ProjectAppointKeyStaffRoutingModule } from './project-AppointKeyStaff-routing.module';
import { ProjectAppointKeyStaffComponent } from './project-AppointKeyStaff.component';

@NgModule({
    declarations: [ ProjectAppointKeyStaffComponent ],
    imports: [AppSharedModule, AdminSharedModule, ProjectAppointKeyStaffRoutingModule , DialogModule, ProjectViewWorkloadModule ],
    exports: [ProjectAppointKeyStaffComponent]
})
export class ProjectAppointKeyStaffModule {}
