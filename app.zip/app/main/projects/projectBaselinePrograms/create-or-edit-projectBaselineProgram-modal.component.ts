﻿// import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
// import { ModalDirective } from 'ngx-bootstrap/modal';
// import { finalize } from 'rxjs/operators';
// import {
//     ProjectBaselineProgramsServiceProxy,
//     CreateOrEditProjectBaselineProgramDto,
//     ProjectBaselineProgramProjectLookupTableDto,
//     ProjectBaselineProgramProjectExReviewDetailLookupTableDto,
// } from '@shared/service-proxies/service-proxies';
// import { AppComponentBase } from '@shared/common/app-component-base';
// import { DateTime } from 'luxon';

// import { DateTimeService } from '@app/shared/common/timing/date-time.service';

// @Component({
//     selector: 'createOrEditProjectBaselineProgramModal',
//     templateUrl: './create-or-edit-projectBaselineProgram-modal.component.html',
// })
// export class CreateOrEditProjectBaselineProgramModalComponent extends AppComponentBase implements OnInit {
//     @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

//     @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

//     active = false;
//     saving = false;

//     projectBaselineProgram: CreateOrEditProjectBaselineProgramDto = new CreateOrEditProjectBaselineProgramDto();

//     projectProjectName = '';
//     projectExReviewDetailTitle = '';

//     allProjects: ProjectBaselineProgramProjectLookupTableDto[];
//     allProjectExReviewDetails: ProjectBaselineProgramProjectExReviewDetailLookupTableDto[];

//     constructor(
//         injector: Injector,
//         private _projectBaselineProgramsServiceProxy: ProjectBaselineProgramsServiceProxy,
//         private _dateTimeService: DateTimeService
//     ) {
//         super(injector);
//     }

//     show(projectBaselineProgramId?: number): void {
//         if (!projectBaselineProgramId) {
//             this.projectBaselineProgram = new CreateOrEditProjectBaselineProgramDto();
//             this.projectBaselineProgram.id = projectBaselineProgramId;
//             this.projectBaselineProgram.startDate = this._dateTimeService.getStartOfDay();
//             this.projectBaselineProgram.endDate = this._dateTimeService.getStartOfDay();
//             this.projectProjectName = '';
//             this.projectExReviewDetailTitle = '';

//             this.active = true;
//             this.modal.show();
//         } else {
//             this._projectBaselineProgramsServiceProxy
//                 .getProjectBaselineProgramForEdit(projectBaselineProgramId)
//                 .subscribe((result) => {
//                     this.projectBaselineProgram = result.projectBaselineProgram;

//                     this.projectProjectName = result.projectProjectName;
//                     this.projectExReviewDetailTitle = result.projectExReviewDetailTitle;

//                     this.active = true;
//                     this.modal.show();
//                 });
//         }
//         this._projectBaselineProgramsServiceProxy.getAllProjectForTableDropdown().subscribe((result) => {
//             this.allProjects = result;
//         });
//         this._projectBaselineProgramsServiceProxy.getAllProjectExReviewDetailForTableDropdown().subscribe((result) => {
//             this.allProjectExReviewDetails = result;
//         });
//     }

//     save(): void {
//         this.saving = true;

//         this._projectBaselineProgramsServiceProxy
//             .createOrEdit(this.projectBaselineProgram)
//             .pipe(
//                 finalize(() => {
//                     this.saving = false;
//                 })
//             )
//             .subscribe(() => {
//                 this.notify.info(this.l('SavedSuccessfully'));
//                 this.close();
//                 this.modalSave.emit(null);
//             });
//     }

//     close(): void {
//         this.active = false;
//         this.modal.hide();
//     }

//     ngOnInit(): void {}
// }
