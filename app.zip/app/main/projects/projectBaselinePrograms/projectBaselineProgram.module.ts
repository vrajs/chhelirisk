import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { ProjectBaselineProgramRoutingModule } from './projectBaselineProgram-routing.module';
import { ProjectBaselineProgramsComponent } from './projectBaselinePrograms.component';
import { DatePickerAllModule } from '@syncfusion/ej2-angular-calendars';
import { ViewProjectBaselineProgramModalComponent } from './view-projectBaselineProgram-modal.component';
import { TooltipModule } from '@syncfusion/ej2-angular-popups';
import { UploadDocuementsModule } from '../UploadDocuments/upload_documents.module'
@NgModule({
    declarations: [
        ProjectBaselineProgramsComponent,
        ViewProjectBaselineProgramModalComponent,
    ],
    imports: [AppSharedModule, ProjectBaselineProgramRoutingModule, AdminSharedModule,DatePickerAllModule, TooltipModule,UploadDocuementsModule],
    exports:[ProjectBaselineProgramsComponent]
})
export class ProjectBaselineProgramModule {}
