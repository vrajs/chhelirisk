﻿import { AppConsts } from '@shared/AppConsts';
import { Component, Injector, ViewEncapsulation, ViewChild, Input, ElementRef, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
    ProjectBaselineProgramsServiceProxy,
    ProjectBaselineProgramDto,
    FlexiFieldDto,
    UtilsServiceProxy,
    CreateOrEditProjectBaselineProgramDto,
    ProjectsServiceProxy,
} from '@shared/service-proxies/service-proxies';
import { NotifyService } from 'abp-ng2-module';
import { AppComponentBase } from '@shared/common/app-component-base';
import { TokenAuthServiceProxy } from '@shared/service-proxies/service-proxies';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Table } from 'primeng/table';
import { Paginator } from 'primeng/paginator';
import { LazyLoadEvent } from 'primeng/api';
import { FileDownloadService } from '@shared/utils/file-download.service';
import { EntityTypeHistoryModalComponent } from '@app/shared/common/entityHistory/entity-type-history-modal.component';
import { filter as _filter } from 'lodash-es';
import { DateTime } from 'luxon';
import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { dataBound, IEditCell, InfiniteScrollSettingsModel, PageSettingsModel, ToolbarItems } from '@syncfusion/ej2-grids';
import { GridComponent, EditSettingsModel, TextWrapSettingsModel } from '@syncfusion/ej2-angular-grids';
import * as _ from 'lodash';
import { FormBuilder, FormControl, FormGroup, NgModel } from '@angular/forms';
import { finalize } from 'rxjs/operators';
import { DatePicker } from '@syncfusion/ej2-angular-calendars';
import { UploaderComponent } from '@syncfusion/ej2-angular-inputs';
import { TooltipComponent } from '@syncfusion/ej2-angular-popups';
import { CheckBoxComponent } from '@syncfusion/ej2-angular-buttons';

@Component({
    selector: 'app-projectexreview-baseLine-program',
    templateUrl: './projectBaselinePrograms.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()],
})
export class ProjectBaselineProgramsComponent extends AppComponentBase {
    @ViewChild('entityTypeHistoryModal', { static: true }) entityTypeHistoryModal: EntityTypeHistoryModalComponent;

    @ViewChild('dataTable', { static: true }) dataTable: Table;
    @ViewChild('paginator', { static: true }) paginator: Paginator;
    @Output() baselineFilePass = new EventEmitter<any>();
    @Input() readonlyGrid?: string;
    advancedFiltersAreShown = false;
    filterText = '';

    organizationUnitDisplayNameFilter = '';

    _entityTypeFullName = 'asq.econsys.Eco.Projects.ProjectBaselineProgram';
    entityHistoryEnabled = false;
    contactPersonRowSelection: boolean[] = [];
    childEntitySelection: {} = {};
    flexiFields: any[] = [];
    baselineProgramGridData: any[] = [];
    public toolbarOptions: ToolbarItems[];
    public initialPage: PageSettingsModel;
    @ViewChild('gridBaselineProgram') public gridBaselineProgram: GridComponent;
    flexiProcessedGridData: Array<any> = [];
    @ViewChild('actiontemplate') public actiontemplate: NgModel;
    @ViewChild('templateRuleFlagId') public templateRuleFlagId: NgModel;

    tooltipbase = false;
    selectedFileIds: string[] = [];
    azureSelectFile: Array<Object> = [];
    valid = false;
    public dropElement1Base: HTMLElement = document.getElementsByClassName('control-fluid')[0] as HTMLElement;

    // syncfusion uploader
    @ViewChild('uploaderEl1Base') public uploadObj: UploaderComponent;
    @ViewChild('tooltipbase') public control: TooltipComponent;
    @ViewChild('checkboxBase') public checkboxBase: CheckBoxComponent;
    @ViewChild('uploadDocInputLabel') uploadDocInputLabel: ElementRef;


    @Input() projectId: number;
    @Input() projectExReviewId: number;
    @Input() projectExReviewDetailId: number;
    @Input() typeReview: string;


    maxResultCount: number = 50;
    skipCount: number = 0;
    sortColumn: string = '';
    sortDirection: string = '';
    totalRecordCount: number = 0;
    pageSettings: any = { pageSizes: true, pageSize: 10, pageCount: 0, currentPage: 1 };
    public wrapSettings: TextWrapSettingsModel = { wrapMode: 'Content' };

    public infiniteOptions: InfiniteScrollSettingsModel | undefined;
    public isSearchContinue: boolean = false;
    ruleFlags: any[] = [];

    titleFilter = '';
    maxStartDateFilter: DateTime;
    minStartDateFilter: DateTime;
    maxEndDateFilter: DateTime;
    minEndDateFilter: DateTime;
    commentFilter = '';
    projectProjectNameFilter = '';
    projectExReviewDetailTitleFilter = '';
    public editSettings: EditSettingsModel;
    public toolbarSettings: ToolbarItems[];

    saving: boolean = false;
    @ViewChild('grid')
    projectid: number;
    id: number;
    reviewtype: string;
    submitting = false;
    frmFG: FormGroup = this.fb.group({});

    public grid: GridComponent;
    public startDateParams: IEditCell;
    public endDateParams: IEditCell;
    public requiredRule: object
    public requiredWithMaxRule: object
    public dateFormatopt: Object;
    public startDateElem: HTMLElement;
    public endDateElem: HTMLElement;
    public startDatePickerObj: DatePicker;
    public endDatePickerObj: DatePicker;
    public filesBaseline: any;
    fileListBaseline: any;
    toolTip = false;

    constructor(
        injector: Injector,
        private _projectBaselineProgramsServiceProxy: ProjectBaselineProgramsServiceProxy,
        private _tokenAuth: TokenAuthServiceProxy,
        private _activatedRoute: ActivatedRoute,
        private _fileDownloadService: FileDownloadService,
        private _dateTimeService: DateTimeService,
        private _projectsServiceProxy: ProjectsServiceProxy,
        private fb: FormBuilder,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.initializeGridSetting();
        this.initializeStartDate();
        this.initializeEndDate();
        this.getAll();
    }
    ngAfterViewInit() {

        this.getAzureFileList();
    }
    getAll() {
        this.baselineProgramGridData = [];
        this._projectBaselineProgramsServiceProxy
            .getAll(
                this.filterText,
                this.titleFilter,
                this.typeReview,
                this.maxStartDateFilter === undefined
                    ? this.maxStartDateFilter
                    : this._dateTimeService.getEndOfDayForDate(this.maxStartDateFilter),
                this.minStartDateFilter === undefined
                    ? this.minStartDateFilter
                    : this._dateTimeService.getStartOfDayForDate(this.minStartDateFilter),
                this.maxEndDateFilter === undefined
                    ? this.maxEndDateFilter
                    : this._dateTimeService.getEndOfDayForDate(this.maxEndDateFilter),
                this.minEndDateFilter === undefined
                    ? this.minEndDateFilter
                    : this._dateTimeService.getStartOfDayForDate(this.minEndDateFilter),
                this.commentFilter,
                this.projectProjectNameFilter,
                this.projectExReviewDetailTitleFilter,
                this.projectId,this.projectExReviewDetailId,
                '',
                0,
                50
            )
            .subscribe((result) => {
                if (result.items && result.items.length == 0) this.baselineProgramGridData = [];
                this.totalRecordCount = result.totalCount;

                this.baselineProgramGridData = this.baselineProgramGridData.concat(
                    result.items.map((x) => ({
                        ...x.projectBaselineProgram,

                        action: 'action',
                    }))
                );
                // (this.grid as GridComponent).refresh();
                if (result.items.length > this.pageSettings.pageSize - 1) {
                    this.pageSettings.skipCount += this.pageSettings.pageSize;
                } else {
                    this.pageSettings.skipCount = 0;
                }
            });
    }

    actionHandler(args: any) {
        if (args.requestType == 'save') {
            let createOrEditPBP = this.mappingPBPDto(args.data)
            this.createOrEditProjectBaselineProgram(createOrEditPBP);
        }

        if (args.requestType === 'delete') {
            this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
                if (isConfirmed) {
                    this.deleteProjectBaselineProgram(args.data[0].id)
                }
            });
        }
    }

    createOrEditProjectBaselineProgram(createOrEditPBP: CreateOrEditProjectBaselineProgramDto) {
        this.spinnerService.show();
        let attachments = [];
        if (this.filesBaseline && this.filesBaseline.length > 0) {
            attachments = [];
            this.filesBaseline.forEach((element) => {
                attachments.push({ fileName: element.name, data: element.rawFile });
            });
        }
        this._projectBaselineProgramsServiceProxy
            .createOrEdit(JSON.stringify(createOrEditPBP), attachments)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(
                (result) => {
                    this.saving = false;

                    this.spinnerService.hide();
                    this.notify.info(this.l('SavedSuccessfully'));
                },
                () => {
                    this.saving = false;
                    this.spinnerService.hide();
                }
            );
    }
    fileChange() {
        let attachments = [];
        if (this.filesBaseline && this.filesBaseline.length > 0) {
            attachments = [];
            this.filesBaseline.forEach((element) => {
                attachments.push({ fileName: element.name, data: element.rawFile });
            });
        }
        this.baselineFilePass.emit(attachments);
    }
    deleteProjectBaselineProgram(id) {
        this._projectBaselineProgramsServiceProxy.delete(id).subscribe(() => {
            let idx = this.baselineProgramGridData.findIndex((x) => x.id == id);
            if (idx >= 0) {
                this.baselineProgramGridData.splice(idx, 1);
            }
            // this.grid.refresh();
            this.notify.success(this.l('SuccessfullyDeleted'));
        });
    }

    initializeStartDate() {
        this.startDateParams = {
            create: () => {
                this.startDateElem = document.createElement('input');
                return this.startDateElem;
            },
            read: () => {
                return this.startDatePickerObj.value;
            },
            destroy: () => {
                this.startDatePickerObj.destroy();
            },
            write: (args) => {
                this.startDatePickerObj = new DatePicker({
                    value: new Date(args.rowData[args.column.field]),
                    floatLabelType: 'Never',
                    created: created.bind(this),
                });
                function created() {
                    this.startDatePickerObj.inputElement.disabled = true;
                }
                this.startDatePickerObj.appendTo(this.startDateElem);
            }
        };
    }

    initializeEndDate() {
        this.endDateParams = {
            create: () => {
                this.endDateElem = document.createElement('input');
                return this.endDateElem;
            },
            read: () => {
                return this.endDatePickerObj.value;
            },
            destroy: () => {
                this.endDatePickerObj.destroy();
            },
            write: (args) => {
                this.endDatePickerObj = new DatePicker({
                    value: new Date(args.rowData[args.column.field]),
                    floatLabelType: 'Never',
                    created: created.bind(this),
                });
                function created() {
                    this.endDatePickerObj.inputElement.disabled = true;
                }
                this.endDatePickerObj.appendTo(this.endDateElem);
            }
        };
    }

    initializeGridSetting() {
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' };
        this.toolbarSettings = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
        this.dateFormatopt = { type: "dateTime", format: "M/d/y" };
        this.requiredRule = { required: true };
        this.requiredWithMaxRule = { required: true, maxLength: [20, 'Add maximum 20 character'] };
    }

    mappingPBPDto(args: any) {
        let createOrEditPBP: CreateOrEditProjectBaselineProgramDto = new CreateOrEditProjectBaselineProgramDto();
        args.loggedDate = new Date();
        Object.assign(createOrEditPBP, args);
        createOrEditPBP.projectExReviewDetailId = this.projectExReviewDetailId;
        createOrEditPBP.projectId = this.projectId;
        createOrEditPBP.reviewType = this.typeReview;
        return createOrEditPBP;
    }

    azureFilesUpload() {
        if (this.azureSelectFile.length > 0) {
            this.spinnerService.show();
            this._projectsServiceProxy.uploadFileFromAzure(this.selectedFileIds).subscribe(res => {
                this.azureSelectFile = [];
                this.spinnerService.hide();
            });
        }
        if (this.azureSelectFile.length > 0 && this.uploadObj.filesData.length == 0)
            this.notify.info(this.l('SavedSuccessfully'));
        else if (this.azureSelectFile.length == 0 && this.uploadObj.filesData.length == 0)
            this.notify.error(this.l("Please select files to upload."));
    }

    save(statusId: string = this.genums.projectStatuses.save.code): void {
        switch (statusId) {
            case this.genums.projectStatuses.save.code:
                this.saving = true;
                break;
            case this.genums.projectStatuses.submit.code:
                this.submitting = true;
                break;

            default:
                break;
        }
        this.saving = true;
        this.frmFG.addControl('id', new FormControl(''));
        this.frmFG.controls['id'].setValue(this.projectId);
        this.frmFG.value['projectId'] = this.projectId;

        let formData: any = {}; // UpdateRTQDto = new UpdateRTQDto(); // = this.frmFG.value;
        Object.assign(formData, this.frmFG.value);
        formData.projectId = this.projectId;
        formData.statusId = statusId;
        let attachments = [];

        var files = this.uploadObj.getFilesData();
        if (files && files.length > 0) {
            formData.attachments = [];
            files.forEach((element) => {
                formData.attachments.push({ fileName: element.name, data: element.rawFile });
            });
        }

        this.spinnerService.show();
        if (this.typeReview == 'baseline') {
            formData.comment = "Production of Baseline Program in Delivery Plan Baseline";
        }
        else {
            formData.comment = "Production of Baseline Program in Delivery Review";
        }

        this._projectsServiceProxy
            .updateRTQ(formData.projectId, statusId, formData.comment, formData.attachments)
            .pipe(
                finalize(() => {
                    this.saving = false;
                    this.submitting = false;
                })
            )
            .subscribe(
                (result) => {
                    this.notify.info(this.l('SavedSuccessfully'));
                    this.spinnerService.hide();
                    this.saving = false;
                    this.submitting = false;
                    this.uploadObj.refresh();
                    this.selectedFileIds = [];
                    // this.getAzureFileList();
                    // this.frmFG.controls['comment'].setValue('');
                    Object.keys(this.frmFG.controls).forEach(control => {
                        this.frmFG.controls[control].markAsPristine();
                        this.frmFG.controls[control].setErrors(null);
                    });
                },
                () => {
                    this.spinnerService.hide();
                    this.saving = false;
                    this.submitting = false;
                }
            );
        this.azureFilesUpload();
    }

    getAzureFileList() {
        this._projectsServiceProxy.getProjectFileList(this.projectId, this.genums.projectTasks.PREPAREPROJECTDELIVERYPLANBASELINE.code).subscribe((result) => {
            this.fileListBaseline = result[0];
            if (this.fileListBaseline != undefined) {
                if (this.fileListBaseline.length > 0) this.toolTip = true;
            }
        });
    }
}