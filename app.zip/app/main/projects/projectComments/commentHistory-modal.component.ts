import { Component, EventEmitter, Injector, Input, OnInit, Output, ViewChild } from '@angular/core';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { AppConsts } from '@shared/AppConsts';
import { AppComponentBase } from '@shared/common/app-component-base';
import { ProjectDto, ProjectCommentsServiceProxy, UserListDto } from '@shared/service-proxies/service-proxies';
import { LocalStorageService } from '@shared/utils/local-storage.service';
import { ModalDirective } from 'ngx-bootstrap/modal';

@Component({
    selector: 'commentHistoryModal',
    templateUrl: './commentHistory-modal.component.html',
    animations: [appModuleAnimation()],
})
export class CommentHistoryModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();
    @Input() projectId: any;
    @Input() project: ProjectDto = new ProjectDto();

    active = false;
    saving = false;
    constructor(
        injector: Injector,
        private _projectCommentsServiceProxy: ProjectCommentsServiceProxy,
        private _localStorageService: LocalStorageService
    ) {
        super(injector);
    }

    comments: Array<any> = [];

    ngOnInit(): void {}

    show(projectId?: number): void {
        this.modal.show();
        this._projectCommentsServiceProxy.getProjectComments(projectId).subscribe((result) => {
            this.comments = result;
            this.comments.map(x => {
                let gmtDate = new Date(x.creationTime.toString());
                x.creationTime = gmtDate.toLocaleString();
            })
            this.setUsersProfilePictureUrl(this.comments);
            console.log('%ccommentHistory-modal.component.ts line:38 this.comments', 'color: #007acc;', this.comments);
        });
    }

    close(): void {
        this.active = false;
        this.modal.hide();
    }

    setUsersProfilePictureUrl(comments: any[]): void {
        for (let i = 0; i < comments.length; i++) {
            let user = comments[i].creatorUser;
            if(user != null) {
                this._localStorageService.getItem(AppConsts.authorization.encrptedAuthTokenName, function (err, value) {
                    let profilePictureUrl =
                        AppConsts.remoteServiceBaseUrl +
                        '/Profile/GetProfilePictureByUser?userId=' +
                        user.id +
                        '&' +
                        AppConsts.authorization.encrptedAuthTokenName +
                        '=' +
                        encodeURIComponent(value.token);
                    (user as any).profilePictureUrl = profilePictureUrl;
                    comments[i].creatorUser.profilePictureUrl = profilePictureUrl;
                });
            } else {
                comments[i].creatorUser = new UserListDto();
                comments[i].creatorUser.profilePictureUrl = AppConsts.appBaseUrl + '/assets/common/images/default-profile-picture.png'
            }
        }
    }
}
