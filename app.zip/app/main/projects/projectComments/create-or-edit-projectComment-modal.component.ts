﻿import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    ProjectCommentsServiceProxy,
    CreateOrEditProjectCommentDto,
    ProjectCommentProjectLookupTableDto,
    ProjectCommentNodeTaskLookupTableDto,
    ProjectCommentProjectCommentLookupTableDto,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';

@Component({
    selector: 'createOrEditProjectCommentModal',
    templateUrl: './create-or-edit-projectComment-modal.component.html',
})
export class CreateOrEditProjectCommentModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    projectComment: CreateOrEditProjectCommentDto = new CreateOrEditProjectCommentDto();

    projectProjectName = '';
    nodeTaskTaskName = '';
    projectCommentComment = '';

    allProjects: ProjectCommentProjectLookupTableDto[];
    allNodeTasks: ProjectCommentNodeTaskLookupTableDto[];
    allProjectComments: ProjectCommentProjectCommentLookupTableDto[];

    constructor(
        injector: Injector,
        private _projectCommentsServiceProxy: ProjectCommentsServiceProxy,
        private _dateTimeService: DateTimeService
    ) {
        super(injector);
    }

    show(projectCommentId?: number): void {
        if (!projectCommentId) {
            this.projectComment = new CreateOrEditProjectCommentDto();
            this.projectComment.id = projectCommentId;
            this.projectProjectName = '';
            this.nodeTaskTaskName = '';
            this.projectCommentComment = '';

            this.active = true;
            this.modal.show();
        } else {
            this._projectCommentsServiceProxy.getProjectCommentForEdit(projectCommentId).subscribe((result) => {
                this.projectComment = result.projectComment;

                this.projectProjectName = result.projectProjectName;
                this.nodeTaskTaskName = result.nodeTaskTaskName;
                this.projectCommentComment = result.projectCommentComment;

                this.active = true;
                this.modal.show();
            });
        }
        this._projectCommentsServiceProxy.getAllProjectForTableDropdown().subscribe((result) => {
            this.allProjects = result;
        });
        this._projectCommentsServiceProxy.getAllNodeTaskForTableDropdown().subscribe((result) => {
            this.allNodeTasks = result;
        });
        this._projectCommentsServiceProxy.getAllProjectCommentForTableDropdown().subscribe((result) => {
            this.allProjectComments = result;
        });
    }

    save(): void {
        this.saving = true;

        this._projectCommentsServiceProxy
            .createOrEdit(this.projectComment)
            .pipe(
                finalize(() => {
                    this.saving = false;
                })
            )
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(null);
            });
    }

    close(): void {
        this.active = false;
        this.modal.hide();
    }

    ngOnInit(): void {}
}
