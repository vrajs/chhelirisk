﻿import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProjectCommentsComponent } from './projectComments.component';

const routes: Routes = [
    {
        path: '',
        component: ProjectCommentsComponent,
        pathMatch: 'full',
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ProjectCommentRoutingModule {}
