﻿import { NgModule } from '@angular/core';
import { AppSharedModule } from '@app/shared/app-shared.module';
import { AdminSharedModule } from '@app/admin/shared/admin-shared.module';
import { ProjectCommentRoutingModule } from './projectComment-routing.module';
import { ProjectCommentsComponent } from './projectComments.component';
import { CreateOrEditProjectCommentModalComponent } from './create-or-edit-projectComment-modal.component';
import { ViewProjectCommentModalComponent } from './view-projectComment-modal.component';
import { CommentHistoryModalComponent } from './commentHistory-modal.component';

@NgModule({
    declarations: [
        ProjectCommentsComponent,
        CreateOrEditProjectCommentModalComponent,
        ViewProjectCommentModalComponent,
        CommentHistoryModalComponent
    ],
    imports: [AppSharedModule, ProjectCommentRoutingModule, AdminSharedModule],
    exports: [CommentHistoryModalComponent]
})
export class ProjectCommentModule {}
