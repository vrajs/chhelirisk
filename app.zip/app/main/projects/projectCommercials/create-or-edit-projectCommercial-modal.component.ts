import { Component, ViewChild, Injector, Output, EventEmitter, OnInit, ElementRef, Input } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { finalize } from 'rxjs/operators';
import {
    ProjectCommercialsServiceProxy,
    CreateOrEditProjectCommercialDto,
    ProjectCommercialProjectLookupTableDto,
    ProjectCommercialRuleElementLookupTableDto,
    ProjectCommercialRuleValueLookupTableDto,
    ProjectCommercialRuleFlagLookupTableDto,
    ProjectCommercialRevenueRangeLookupTableDto,
    GetFlexiFieldForViewDto,
    GetRevenueRangeForViewDto,
    GetRuleConfigurationForViewDto,
    GetRuleElementForViewDto,
    GetRuleValueForViewDto,
    GetProjectCommercialForViewDto,
    ProjectFileDto,
} from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { DateTime } from 'luxon';

import { DateTimeService } from '@app/shared/common/timing/date-time.service';
import { FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';
import { UploadDocuments } from '../UploadDocuments/upload_documents.component';
import { AppEnums } from '@shared/AppEnums';

@Component({
    selector: 'createOrEditProjectCommercialModal',
    templateUrl: './create-or-edit-projectCommercial-modal.component.html',
})
export class CreateOrEditProjectCommercialModalComponent extends AppComponentBase implements OnInit {
    @ViewChild('createOrEditModal', { static: true }) modal: ModalDirective;
    @ViewChild('uploadDocuments', { static: true })
    UploadDocuments: UploadDocuments;
    @Input() selectedproject?: Number;
    @Input() revenueRange?: Number;
    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();
    @Output() projectCommercialModal: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;

    projectCommercial: CreateOrEditProjectCommercialDto = new CreateOrEditProjectCommercialDto();
    projectTask = AppEnums.projectTasks.ADDCOMMERCIAL.code;
    projectProjectName = '';
    ruleElementTitle = '';
    ruleValueTitle = '';
    ruleFlagTitle = '';
    revenueRangeTitle = '';
    create: Boolean;
    projectType: string;

    allProjects: ProjectCommercialProjectLookupTableDto[];
    allRuleElements: ProjectCommercialRuleElementLookupTableDto[];
    allRuleValues: ProjectCommercialRuleValueLookupTableDto[];
    allRuleFlags: ProjectCommercialRuleFlagLookupTableDto[];
    allRevenueRanges: ProjectCommercialRevenueRangeLookupTableDto[];

    data: any;
    frmFG: FormGroup;

    ruleElementsForView: GetRuleElementForViewDto[] = [];
    ruleValuesForView: GetRuleValueForViewDto[] = [];
    ProjectCommercialsForView: GetProjectCommercialForViewDto[] = [];
    revenueRangesForView: GetRevenueRangeForViewDto[] = [];
    ruleConfiguration: GetRuleConfigurationForViewDto[] = [];
    flexiFields: any[] = [];

    fileList: ProjectFileDto[] = [];

    constructor(
        injector: Injector,
        private _projectCommercialsServiceProxy: ProjectCommercialsServiceProxy,
        private _dateTimeService: DateTimeService,
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
    ) {
        super(injector);
    }

    show(ProjectCommercialId?: number): void {
        this.getAllData();
        if (!ProjectCommercialId) {
            this.projectCommercial = new CreateOrEditProjectCommercialDto();
            this.projectCommercial.id = ProjectCommercialId;
            this.ruleElementTitle = '';
            this.ruleValueTitle = '';
            this.ruleFlagTitle = '';
            this.revenueRangeTitle = '';
            this.projectProjectName = '';

            this.active = true;
            this.modal.show();
        } else {
            this._projectCommercialsServiceProxy
                .getProjectCommercialForEdit(ProjectCommercialId)
                .subscribe((result) => {
                    this.projectCommercial = result.projectCommercial;

                    this.ruleElementTitle = result.ruleElementTitle;
                    this.ruleValueTitle = result.ruleValueTitle;
                    this.ruleFlagTitle = result.ruleFlagTitle;
                    this.revenueRangeTitle = result.revenueRangeTitle;
                    this.projectProjectName = result.projectProjectName;

                    this.active = true;
                    this.modal.show();
                });
        }
    }

    close(): void {
        this.active = false;
        this.modal.hide();
        this.projectCommercialModal.emit();
    }

    ngOnInit(): void {
        // this.show();
        this.route.queryParamMap.subscribe((params) => {
            this.projectType = params.get('type');
        });
        this.frmFG = this.formBuilder.group({
            flexiFaProjectCommercial: this.formBuilder.array([]),
        });
    }

    getAllData() {
        this._projectCommercialsServiceProxy.getAllProjectCommercialData(Number(this.selectedproject)).subscribe((result) => {
            this.ruleElementsForView = result.ruleElements; //.filter((x) => x.ruleElement.ruleTypeId == 'commercial');
            this.ruleValuesForView = result.ruleValues;
            this.revenueRangesForView = result.revenueRanges;
            this.ProjectCommercialsForView = result.projectCommercial;
            this.ruleConfiguration = result.ruleConfigurations;
            // this.flexiFields = result.flexiFields; //.filter((x) => x.flexiField.flexiSectionId == 'commercial');
            this.fileList = result.commercialFiles

            this.flexiFields = [];
            if (result.flexiFields != null && result.flexiFields.length > 0) {
                result.flexiFields.forEach((element1) => {
                    let element = element1.flexiField;
                    let metaDataAll = this.utilsService.parseFlexiJson(element.metaData);
                    if (metaDataAll && metaDataAll.flowData != null) {
                        let metaData: any = metaDataAll.flowData.filter(
                            (x) => x.projectType.toLowerCase() == this.projectType.toLowerCase()
                        )[0];
                        let baseValidations = this.utilsService.parseFlexiJson(element.validations) || [];
                        let validations = _.unionBy(baseValidations, metaData.validations || [], 'name');

                        if (metaData != null && metaData.enabled == 1) {
                            let tfield: any = {
                                type: element.htmlType,
                                label: metaData.displayName,
                                headerText: metaData.displayName,
                                inputType: element.htmlInputType,
                                name: _.camelCase(element.code),
                                code: _.camelCase(element.code),
                                field: _.camelCase(element.code),
                                validations: validations,
                                enabled: metaData.enabled,
                                required: metaData.required,
                                readonly: metaData.readonly,
                                disabled: metaData.disabled,
                                sortOrder: metaData.sortOrder,
                                isUploadFile: metaData.isUploadFile
                            };
                            if (tfield.required == 1) {
                                let valrequired = tfield.validations == null ? null : tfield.validations.filter(x => x.validator == 'required');
                                if (valrequired == null || valrequired[0] == null) {
                                    tfield.validations.push({
                                        name: 'required',
                                        message: this.l('This field is required.'),
                                        validator: 'required',
                                    });
                                }
                            }
                            this.flexiFields.push(tfield);
                        }
                    }
                });
            }

            this.flexiFields = this.flexiFields.length == 0 ? [] : this.flexiFields.sort((a, b) => a.sortOrder - b.sortOrder);
            this.createForm();
        });
    }
    get flexiFaProjectCommercial(): FormArray {
        return this.frmFG.get('flexiFaProjectCommercial') as FormArray;
    }

    getRuleElementById(elementId) {
        if (elementId != null && elementId != undefined) {
            const element = this.ruleElementsForView.filter((x) => x.ruleElement.id == elementId);
            return element[0].ruleElement.title;
        }
    }

    getRuleValueById(valueId) {
        if (valueId != null && valueId != undefined) {
            const element = this.ruleValuesForView.filter((x) => x.ruleValue != null && x.ruleValue.id == valueId);
            return element && element.length > 0 && element[0].ruleValue != null ? element[0].ruleValue.title : null;
        }
    }
    valueChange(event, index) {
        var ruleValueTitle = this.getRuleValueById(event.value);
        let frmFGArray = this.frmFG.get('flexiFaProjectCommercial') as FormArray;

        frmFGArray.controls[index].patchValue({ ruleValue: ruleValueTitle });
    }
    ruleValuesByElementId(id) {
        let result = this.ruleValuesForView.filter((x) => x.ruleValue.ruleElementId == id);
        this.data = result;

        return result;
    }

    createForm() {
        const flexiFaProjectCommercial = this.frmFG.get('flexiFaProjectCommercial') as FormArray;
        flexiFaProjectCommercial.clear();
        if (
            this.ProjectCommercialsForView.filter((x) => x.projectCommercial.projectId == this.selectedproject)
                .length != 0
        ) {
            this.create = false;
            this.flexiFields.forEach((field, index2) => {
                if (field != null && field.enabled == 1) {
                    let es = this.ProjectCommercialsForView.filter(
                        (x) =>
                            x.projectCommercial.ruleElementId == Number(field.code) &&
                            x.projectCommercial.projectId == this.selectedproject
                    )[0];
                    let rcFlag = (es == undefined || es == null) ? null : this.ruleConfiguration.filter(
                        (x) =>
                            x.ruleConfiguration.ruleElementId == Number(field.code) &&
                            es.projectCommercial.ruleValueId != null
                    )[0];
                    let elementFiles = this.fileList.filter(rec => JSON.parse(rec.metaData).RuleElementId == field.code)

                    flexiFaProjectCommercial.push(
                        this.formBuilder.group({
                            id: new FormControl(es != undefined ? es.projectCommercial.id : null, []),
                            ruleValueId: new FormControl(es != undefined ? es.projectCommercial.ruleValueId : '', this.utilsService.bindValidations((field.validations != null ? field.validations : []) || [])), //Validators.required),
                            ruleElementId: new FormControl(Number(field.code), Validators.required),
                            projectId: new FormControl(this.selectedproject, Validators.required),
                            haschanges: false,
                            ruleConfigFlag: new FormControl(rcFlag != undefined && rcFlag != null ? rcFlag.ruleConfiguration.ruleFlagId : null),
                            isUploadFile: new FormControl(field.isUploadFile),
                            ruleValue: new FormControl(es != undefined ? es.ruleValueTitle : ''),
                            attachments: new FormControl([]),
                            fileList: new FormControl(elementFiles)
                        })
                    );
                }
            });

        } else {
            this.create = true;

            this.flexiFields.forEach((field, index2) => {
                if (field != null && field.enabled == 1) {
                    flexiFaProjectCommercial.push(
                        this.formBuilder.group({
                            ruleValueId: new FormControl('', this.utilsService.bindValidations((field.validations != null ? field.validations : []) || [])), //Validators.required),
                            ruleElementId: new FormControl(Number(field.code), Validators.required),
                            projectId: new FormControl(this.selectedproject, Validators.required),
                            haschanges: false,
                            ruleConfigFlag: new FormControl(null),
                            isUploadFile: new FormControl(field.isUploadFile),
                            ruleValue: new FormControl(''),
                            attachments: new FormControl([])
                        })
                    );
                }
            });
        }
    }

    saveFlexiProjectCommercial() {
        let formdata: CreateOrEditProjectCommercialDto[] = [];
        this.getFormValidationErrors(this.frmFG);
        if (!this.frmFG.valid) {
            this.notify.warn(this.l('Invalid inputs'));
            return;
        }
        let attachmentInfo: any = {};
        let attachments = [];
        let formData: any = {}
        let attachRule: CreateOrEditProjectCommercialDto[] = [];
        this.frmFG.value.flexiFaProjectCommercial.forEach((element, index) => {
            let dobj: CreateOrEditProjectCommercialDto = new CreateOrEditProjectCommercialDto();
            element.projectId = this.selectedproject;
            element.revenueRangeId = this.revenueRange;

            dobj.ruleValueId = Number(element.ruleValueId) == 0 ? null : Number(element.ruleValueId);
            dobj.ruleElementId = Number(element.ruleElementId);
            dobj.revenueRangeId = element.revenueRangeId;
            dobj.projectId = element.projectId;
            if (element.id) {
                dobj.id = element.id;
            }
            if (element.attachments && element.attachments.length > 0) {
                element.attachments.forEach((e) => {
                    attachments.push(e);
                    attachRule.push(dobj);
                });
            }
            formdata.push(dobj);
        });
        formData.attachments = [];
        attachments.forEach(attachment => {
            formData.attachments.push({ fileName: attachment.name, data: attachment.rawFile });
        });
        // this.message.confirm('', this.l('AreYouSure'), (isConfirmed) => {
        //     if (isConfirmed) {
        this.spinnerService.show();
        this._projectCommercialsServiceProxy
            .createOrEdit(JSON.stringify(formdata), formData.attachments, JSON.stringify(attachRule))

            .subscribe(
                (result) => {
                    this.spinnerService.hide();
                    this.notify.info(this.l('SavedSuccessfully'));
                    this.close();
                    this.modalSave.emit(result);
                },
                () => {
                    this.spinnerService.hide();
                }
            );
        //     }
        // });
    }

    setFormControlValue(event: any, frmitem: any, index) {
        if (event.isInteracted) {
            let frmFGArray = this.frmFG.get('flexiFaProjectCommercial') as FormArray;
            let val = frmFGArray.controls[index].value;
            val.ruleValueId = event.value;
            frmFGArray.controls[index].patchValue(val);
        }
    }

    getFormValidationErrors(frmFG) {
        if (frmFG == undefined) { return; }
        Object.keys(frmFG.controls.flexiFaProjectCommercial['controls']).forEach((key) => {
            Object.keys(frmFG.controls.flexiFaProjectCommercial['controls'][key].controls).forEach((key1) => {
                const controlErrors: ValidationErrors =
                    frmFG.controls.flexiFaProjectCommercial['controls'][key].get(key1).errors;
                if (controlErrors != null) {
                    Object.keys(controlErrors).forEach((keyError) => {
                        frmFG.controls.flexiFaProjectCommercial['controls'][key].get(key1).markAsDirty();
                        frmFG.controls.flexiFaProjectCommercial['controls'][key].get(key1).markAllAsTouched();
                    });
                }
            });
        });
    }

    documentEmitter(file, arrayItem) {
        console.log('%ccreate-or-edit-projectCommercial-modal.component.ts line:364 file, arrayItem', 'color: #007acc;', file, arrayItem);
        this.flexiFaProjectCommercial.value.forEach(x => {
            if (x.ruleValueId == arrayItem.value.ruleValueId) x.attachments.push(file[0]);
        });
    }

}
